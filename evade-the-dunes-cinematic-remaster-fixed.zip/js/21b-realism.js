/* ==================================================================
   CINEMATIC REALISM LAYER — 21b-realism.js
   ------------------------------------------------------------------
   Loaded just before 16-main.js. Adds the "air" that sells realism:
     1. NEAR-CAMERA DUST MOTES — a few hundred glittering motes
        drifting in a wrapping box around the camera, back-lit by the
        sun (phase-dependent brightness). The single cheapest trick
        that makes a desert feel volumetric.
     2. DISTANT DUST-STORM CURTAINS — huge soft sheets orbiting the
        player far out near the horizon, drifting with the wind.
        They give the empty desert parallax and a sense of scale.
     3. WORM + CREATURE MATERIAL POLISH — subsurface-ish sheen,
        clearcoat wetness and environment reflections on every
        creature material.
     4. Global animation clocks for the sky dust bands and the
        terrain glitter (covers modes where the composer is off).
   Exposes window.__updateRealism(dt, rdt), called by 16-main.js.
   ================================================================== */

/* ================================================================
   1. NEAR-CAMERA DUST MOTES
   ================================================================ */
const REALISM = {
  motesOn: !!GRAPHICS.dustMotes,
};

const MOTES_N = 260;
const MOTE_BOX = 84;                 // wrap box side (m)
const moteGeo = new THREE.BufferGeometry();
{
  const pos  = new Float32Array(MOTES_N * 3);
  const seed = new Float32Array(MOTES_N);
  const size = new Float32Array(MOTES_N);
  for(let i=0;i<MOTES_N;i++){
    pos[i*3+0] = (Math.random()-0.5) * MOTE_BOX;
    pos[i*3+1] = (Math.random()-0.5) * 22.0;
    pos[i*3+2] = (Math.random()-0.5) * MOTE_BOX;
    seed[i]    = Math.random() * 100.0;
    size[i]    = 0.5 + Math.random() * 1.05;      // point-size scale
  }
  moteGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  moteGeo.setAttribute('aSeed',    new THREE.BufferAttribute(seed, 1));
  moteGeo.setAttribute('aSize',    new THREE.BufferAttribute(size, 1));
}
const moteUniforms = {
  uTime:   { value: 0 },
  uCamPos: { value: new THREE.Vector3() },
  uSunDir: { value: new THREE.Vector3(-0.55, 0.40, -0.42).normalize() },
  uSunCol: { value: new THREE.Color(1.0, 0.88, 0.68) },
  uOpacity:{ value: 0.55 },
  uBox:    { value: MOTE_BOX },
};
const motes = new THREE.Points(moteGeo, new THREE.ShaderMaterial({
  transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  uniforms: moteUniforms,
  vertexShader: /* glsl */`
    attribute float aSeed;
    attribute float aSize;
    uniform float uTime;
    uniform vec3  uCamPos;
    uniform float uBox;
    varying float vFade;
    varying float vSeed;
    varying vec3  vWorld;
    void main(){
      /* drift + wobble, then wrap into a box centred on the camera */
      float t = uTime;
      vec3 p = position;
      p.x += t * 1.15 + sin(t * 0.31 + aSeed * 3.1) * 1.6;
      p.y += sin(t * 0.23 + aSeed * 7.7) * 0.9;
      p.z += t * 0.55 + cos(t * 0.27 + aSeed * 5.3) * 1.4;
      vec3 rel = p - uCamPos;
      rel = mod(rel + uBox * 0.5, uBox) - uBox * 0.5;
      vec3 world = uCamPos + rel;
      world.y = clamp(world.y, uCamPos.y - 5.0, uCamPos.y + 13.0);
      vWorld = world;
      vec4 mv = modelViewMatrix * vec4(world, 1.0);
      float dist = max(0.4, -mv.z);
      vFade  = smoothstep(1.5, 6.0, dist) * (1.0 - smoothstep(26.0, 40.0, dist));
      vSeed  = aSeed;
      gl_Position = projectionMatrix * mv;
      gl_PointSize = aSize * (300.0 / dist);
    }`,
  fragmentShader: /* glsl */`
    uniform vec3  uSunDir;
    uniform vec3  uSunCol;
    uniform float uOpacity;
    uniform float uTime;
    varying float vFade;
    varying float vSeed;
    varying vec3  vWorld;
    void main(){
      vec2 c = gl_PointCoord * 2.0 - 1.0;
      float r = dot(c, c);
      if(r > 1.0) discard;
      float body = (1.0 - r) * (1.0 - r);
      vec3 V = normalize(vWorld - cameraPosition);
      /* back-lit: motes between the camera and the sun glow hardest */
      float back = pow(max(dot(V, normalize(uSunDir)), 0.0), 2.2);
      float tw = 0.55 + 0.45 * sin(uTime * 2.4 + vSeed * 13.0);
      vec3 col = mix(uSunCol * 0.30, uSunCol * 1.25, back);
      float a = body * vFade * uOpacity * (0.16 + 0.84 * back) * tw;
      gl_FragColor = vec4(col, a);
    }`,
}));
motes.frustumCulled = false;
motes.renderOrder = 6;
motes.visible = REALISM.motesOn;
scene.add(motes);

/* ================================================================
   2. DISTANT DUST-STORM CURTAINS
   ================================================================ */
function makeStormSheetTexture(){
  const W=512, H=256;
  const cv=document.createElement('canvas'); cv.width=W; cv.height=H;
  const g=cv.getContext('2d'), img=g.createImageData(W,H), d=img.data;
  const hI=(x,y)=>{ let h=Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+77;
    h=Math.imul(h^(h>>>13),1274126177); h^=h>>>16; return (h>>>0)/4294967296; };
  const vn=(x,y)=>{ const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const a=hI(xi,yi), b=hI(xi+1,yi), c=hI(xi,yi+1), e=hI(xi+1,yi+1);
    return a+(b-a)*u+(c-a)*v+(a-b-c+e)*u*v; };
  const fbm=(x,y,o)=>{ let s=0,a=0.5,f=1,n=0; for(let i=0;i<o;i++){ s+=vn(x*f,y*f)*a; n+=a; f*=2; a*=0.5; } return s/n; };
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){
    const nx=x/W, ny=y/H;
    /* horizontally stretched turbulent sheet, fading to nothing at all edges */
    const n = fbm(nx*3.0, ny*9.0, 4);
    const n2 = fbm(nx*8.0+4.7, ny*20.0+2.3, 3);
    const edgeX = Math.sin(nx*Math.PI);                    // soft left/right
    const edgeY = Math.pow(Math.sin(ny*Math.PI), 1.4);     // soft top/bottom
    let a = edgeX * edgeY * Math.max(0, (n*0.75 + n2*0.45 - 0.28));
    a = Math.min(1, a * 1.9);
    const i=(y*W+x)*4;
    d[i]=214; d[i+1]=178; d[i+2]=132; d[i+3]=(a*255)|0;
  }
  g.putImageData(img,0,0);
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
const stormSheetTex = makeStormSheetTexture();
const STORM_N = 7;
const storms = [];
for(let i=0;i<STORM_N;i++){
  const w = 320 + Math.random()*380;
  const h = 70 + Math.random()*110;
  const mat = new THREE.MeshBasicMaterial({
    map: stormSheetTex, transparent: true, opacity: 0.0,
    depthWrite: false, side: THREE.DoubleSide, fog: true,
    color: 0xd8b68a,
  });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  m.geometry.translate(0, h*0.42, 0);       // pivot low so it hangs like a curtain
  m.renderOrder = 4;
  m.frustumCulled = false;
  scene.add(m);
  storms.push({
    mesh: m, mat,
    ang: Math.random() * Math.PI * 2,
    radius: 340 + Math.random() * 320,
    height: 30 + Math.random() * 70,
    drift: (0.0035 + Math.random()*0.004) * (Math.random()<0.5?1:-1),
    bob: Math.random() * 10,
    maxOp: 0.055 + Math.random() * 0.075,
    phase: Math.random() * Math.PI * 2,
  });
}

/* ================================================================
   3. CREATURE MATERIAL POLISH
   ================================================================ */
(function polishCreatureMaterials(){
  try{
    if(typeof envTex !== 'undefined' && envTex){
      const bump = (mat, sheenAmt, ccAmt, envI) => {
        if(!mat) return;
        if(sheenAmt && mat.sheen !== undefined){
          mat.sheen = sheenAmt;
          mat.sheenRoughness = 0.55;
          if(mat.sheenColor) mat.sheenColor.set(0xd8c39a);
        }
        if(ccAmt && mat.clearcoat !== undefined){
          mat.clearcoat = ccAmt;
          mat.clearcoatRoughness = 0.62;
        }
        mat.envMap = envTex;
        mat.envMapIntensity = envI;
        if(mat.normalMap && mat.normalScale) mat.normalScale.multiplyScalar(1.2);
        mat.needsUpdate = true;
      };
      /* regular worms — sun-bleached hide with a faint damp sheen */
      if(typeof wormSkinMat !== 'undefined'){ bump(wormSkinMat, 0.38, 0.10, 0.35); }
      if(typeof wormHeadMat !== 'undefined'){ bump(wormHeadMat, 0.30, 0.16, 0.45); }
      if(typeof wormPlateMat !== 'undefined'){ bump(wormPlateMat, 0, 0, 0.30); }
      if(typeof wormRidgeMat !== 'undefined'){ bump(wormRidgeMat, 0, 0, 0.25); }
      if(typeof moundMat !== 'undefined'){ bump(moundMat, 0, 0, 0.18); }
      /* alpha worm — the colossus deserves the wet, light-eating look */
      if(typeof alphaMats !== 'undefined'){
        bump(alphaMats.skin,  0.34, 0.12, 0.32);
        bump(alphaMats.head,  0.30, 0.18, 0.42);
        bump(alphaMats.plate, 0, 0, 0.35);
        bump(alphaMats.ridge, 0, 0, 0.28);
        if(alphaMats.lip)  bump(alphaMats.lip,  0.25, 0.20, 0.5);
      }
    }
  }catch(e){ /* materials are polish, never a crash */ }
})();

/* ================================================================
   4. PER-FRAME DRIVER
   ================================================================ */
const _rsCam = new THREE.Vector3();
function __updateRealism(dt, rdt){
  const t = performance.now() / 1000;

  /* sky dust bands + terrain glitter clocks (all modes) */
  if(typeof skyUniforms !== 'undefined') skyUniforms.uTime.value = t;
  try{
    const mats = [terrainMat, farGround.material];
    for(const m of mats){
      const sh = m && m.userData && m.userData.realismShader;
      if(sh) sh.uniforms.uGlintTime.value = t;
    }
  }catch(e){}

  /* dust motes */
  if(motes.visible){
    moteUniforms.uTime.value = t;
    moteUniforms.uCamPos.value.copy(camera.position);
    try{ moteUniforms.uSunDir.value.copy(sunDir); }catch(e){}
    moteUniforms.uOpacity.value = 0.34 + 0.18 * Math.sin(t * 0.11);
  }

  /* storm curtains: orbit slowly around the player, Y-billboarded */
  _rsCam.copy(camera.position);
  for(let i=0;i<storms.length;i++){
    const s = storms[i];
    s.ang += s.drift * dt;
    const px = _rsCam.x + Math.sin(s.ang) * s.radius;
    const pz = _rsCam.z + Math.cos(s.ang) * s.radius;
    let gy = 0;
    try{ gy = terrainH(px, pz); }catch(e){}
    s.mesh.position.set(px, Math.max(gy, 0) + s.height + Math.sin(t*0.13 + s.phase)*3.0, pz);
    s.mesh.rotation.y = Math.atan2(_rsCam.x - px, _rsCam.z - pz);
    const pulse = 0.72 + 0.28 * Math.sin(t * 0.05 + s.phase * 2.1);
    s.mat.opacity = s.maxOp * pulse;
  }
}
window.__updateRealism = __updateRealism;

/* live settings hook — wired from 17-graphics.onGraphicsLiveChange */
window.__onRealismLive = function(key, value){
  if(key === 'dustMotes'){
    REALISM.motesOn = !!value;
    motes.visible = REALISM.motesOn;
  }
};
