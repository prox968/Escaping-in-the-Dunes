/* UI messages and game state */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- UI ---------------- */
let msgTimer=null;
function showMsg(text,dur=2.6,cls){
  const el=$('msg');
  el.textContent=text; el.classList.add('show');
  el.classList.toggle('alpha', cls==='alpha');
  clearTimeout(msgTimer);
  msgTimer=setTimeout(()=>el.classList.remove('show'), dur*1000);
}
const seisCtx=$('seis').getContext('2d');
const sNoise=[], sWorm=[];
const SEIS_NOISE='#f0be74', SEIS_WORM='#e08a48', SEIS_WORM_HOT='#ff6a45';
function drawSeismo(){
  const w=220,h=64,g=seisCtx;
  g.clearRect(0,0,w,h);
  g.fillStyle='#0c0804'; g.fillRect(0,0,w,h);
  g.strokeStyle='rgba(240,200,140,0.10)'; g.lineWidth=1;
  for(const f of [0.25,0.5,0.75]){ g.beginPath(); g.moveTo(0,h*f); g.lineTo(w,h*f); g.stroke(); }
  const yOf=v=>h-4-Math.min(v,1.12)*(h-12);
  g.setLineDash([3,3]); g.strokeStyle='rgba(240,200,140,0.28)';
  g.beginPath(); g.moveTo(0,yOf(0.28)); g.lineTo(w,yOf(0.28)); g.stroke();
  g.setLineDash([]);
  if(sNoise.length>1){
    /* rhythm / engine / digger noise — the player's own footprint */
    g.strokeStyle=SEIS_NOISE; g.lineWidth=1.4; g.beginPath();
    for(let i=0;i<sNoise.length;i++){
      const x=i/(sNoise.length-1)*w, y=yOf(sNoise[i]);
      i?g.lineTo(x,y):g.moveTo(x,y);
    }
    g.stroke();
    /* living worm pressure — separate trace, thicker and hotter as an attack commits */
    g.strokeStyle=wormAttack>0.32?SEIS_WORM_HOT:SEIS_WORM;
    g.lineWidth=1.2+clamp(wormAttack,0,1)*0.8;
    g.beginPath();
    for(let i=0;i<sWorm.length;i++){
      const x=i/(sWorm.length-1)*w, y=yOf(sWorm[i]);
      i?g.lineTo(x,y):g.moveTo(x,y);
    }
    g.stroke();
  }
}

/* ---------------- game state ---------------- */
let gameState='title', elapsed=0, attention=0, noiseLevel=0, wormNear=0, wormSeis=0, wormAttack=0, shake=0, wobble=0, timeScale=1;
let spice=0, thumperCount=2, thumpRegenT=0, dmgFlash=0, digBonus=0;
let overShown=false, deathReal=0, lastShaiMsg=-10, lowHullWarned=false, lookBackAmt=0;
let collectFlash=0, airVigSm=0;
let best=0;  /* preview build: best score kept in memory only */
const difficulty={aggr:0};
const worms=[]; const spawnQueue=[];
/* reinforcements: there is no cap on how many worms can be out, but every extra worm
   takes longer to answer the call than the one before it (45 s, then +70, +90, +110 s…) */
let wormSpawnN=0;
function wormSpawnGap(n){ return 50+n*20; }
function resetSpawnQueue(){ wormSpawnN=0; spawnQueue.length=0; spawnQueue.push({t:45}); }
resetSpawnQueue();
const camPos=new THREE.Vector3(12, terrainH(12,-14)+5, -14);
const camLook=new THREE.Vector3(0, player.pos.y+1.5, 0);
const deathSpin=new THREE.Vector3();

class WormRef extends Worm{}
worms.push(new WormRef(0));

function spawnWorm(){
  worms.push(new WormRef(worms.length));
  wormSpawnN++;
  spawnQueue.push({t:elapsed+wormSpawnGap(wormSpawnN)});
}
