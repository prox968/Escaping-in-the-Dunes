/* ==================================================================
   21-drive-wheel.js — spinning car wheel on hover of DRIVE btn
   ------------------------------------------------------------------
   When the user hovers the #startBtn (labelled "DRIVE"):
     • a detailed offroad wheel (canvas) slides in to the LEFT of the
       button and starts spinning
   When they stop hovering:
     • the wheel stops spinning and slides back out
   When they CLICK the button:
     • the wheel does a shrink-down animation (spin + scale to 0)
       before startGame() actually fires — so the click feels like
       the jeep "kicking off" the menu
   The wheel is drawn procedurally on a 120×120 canvas (no assets):
     • outer tire (knobby BFG-style tread blocks)
     • beadlock rim ring
     • 8-spoke alloy wheel
     • central hub with 5 lug nuts
     • brake disc visible behind the spokes
   ================================================================== */

(function(){
  /* ---- DOM ---- */
  let canvas, ctx, btn, wrap;
  let W = 120, H = 120;
  let DPR = 1;

  /* ---- state ---- */
  let hovering = false;
  let spinning = false;       /* wheel is currently spinning (visual) */
  let spinAngle = 0;          /* current rotation, radians */
  let spinVel = 0;            /* radians per second */
  let visible = 0;            /* 0..1 — wheel slide-in / fade-in amount */
  let clickAnim = 0;          /* 0..1 — shrink-down on click (1 = fully gone) */
  let clickActive = false;

  /* ---- boot ---- */
  function boot(){
    canvas = document.getElementById('driveWheel');
    btn    = document.getElementById('startBtn');
    wrap   = document.getElementById('driveWrap');
    if(!canvas || !btn || !wrap) return;
    ctx = canvas.getContext('2d');
    /* match the canvas's CSS size for crisp rendering on HiDPI */
    _resize();
    addEventListener('resize', _resize);

    /* hover detection — pointerenter / pointerleave (better than mouseenter
       because it works with stylus + touch too) */
    wrap.addEventListener('pointerenter', ()=>{ hovering = true; });
    wrap.addEventListener('pointerleave', ()=>{ hovering = false; });
    /* also detect hover on the button itself (covers touch tap) */
    btn.addEventListener('pointerenter', ()=>{ hovering = true; });

    /* click — start the shrink-down animation, then fire startGame */
    btn.addEventListener('click', (e)=>{
      if(clickActive) return;
      clickActive = true;
      clickAnim = 0;
      /* let the shrink animation play out, THEN start the game */
      setTimeout(()=>{
        /* call the real startGame (12-alpha-worm.js) */
        if(typeof startGame === 'function'){
          try{ startGame(); }catch(e){}
        }
        /* reset the wheel state so it's clean for next time the title shows */
        clickActive = false;
        clickAnim = 0;
        spinning = false;
        spinVel = 0;
        visible = 0;
        hovering = false;
      }, 480);
    }, {capture:false});

    /* start the render loop */
    _loop();
  }

  function _resize(){
    DPR = Math.min(devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    W = Math.max(40, Math.round(rect.width  || 120));
    H = Math.max(40, Math.round(rect.height || 120));
    canvas.width  = W * DPR;
    canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }

  /* ---- per-frame update ---- */
  function _step(dt){
    /* target visibility: 1 when hovering OR click-animating, 0 otherwise */
    const wantVisible = (hovering || clickActive) ? 1 : 0;
    visible += (wantVisible - visible) * Math.min(1, dt * 10);
    if(visible < 0.001 && !hovering && !clickActive) visible = 0;

    /* spin: accelerate while hovering, decelerate otherwise */
    const wantSpin = (hovering && !clickActive);
    const targetVel = wantSpin ? 18 : 0;       /* ~3 revs/sec */
    spinVel += (targetSpinAdjusted(targetVel) - spinVel) * Math.min(1, dt * 6);
    spinAngle += spinVel * dt;

    /* click shrink animation */
    if(clickActive){
      clickAnim = Math.min(1, clickAnim + dt / 0.48);  /* 480ms total */
    }
  }

  /* the target spin speed is dampened during the click shrink so the
     wheel looks like it's tearing itself away — fast spin + shrink */
  function targetSpinAdjusted(base){
    if(!clickActive) return base;
    /* accelerate during click for drama, then snap to 0 at end */
    const k = clickAnim;
    if(k < 0.7) return base * (1 + k * 1.5);   /* spin up to 2.05× */
    return base * (1 - (k - 0.7) / 0.3);       /* brake to 0 in last 30% */
  }

  /* ---- draw the wheel ----
     The wheel is drawn in its own coordinate system (center = canvas
     center). Rotation is applied via ctx.rotate(spinAngle). The whole
     thing is then scaled by (1 - clickAnim) for the shrink-down. */
  function _draw(){
    ctx.clearRect(0, 0, W, H);
    if(visible < 0.001 && !clickActive) return;

    const cx = W/2, cy = H/2;
    /* overall scale: visible (slide-in) × (1 - clickAnim) (shrink-down) */
    const visScale = 0.6 + 0.4 * visible;       /* small → full size */
    const clickScale = 1 - clickAnim * 0.95;    /* shrink to 5% by end */
    /* tiny extra bounce on the shrink (squash) */
    const squash = clickActive ? (1 + Math.sin(clickAnim * Math.PI) * 0.08) : 1;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(visScale * clickScale, visScale * clickScale * squash);
    ctx.globalAlpha = visible * (1 - clickAnim * 0.4);

    /* the wheel itself, rotated by spinAngle */
    ctx.save();
    ctx.rotate(spinAngle);
    _drawWheel(0, 0);
    ctx.restore();

    /* contact shadow under the wheel (always upright) */
    ctx.save();
    ctx.globalAlpha *= 0.5;
    const shGr = ctx.createRadialGradient(0, H*0.32, 0, 0, H*0.32, W*0.42);
    shGr.addColorStop(0, 'rgba(0,0,0,0.55)');
    shGr.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = shGr;
    ctx.beginPath();
    ctx.ellipse(0, H*0.32, W*0.42, H*0.10, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  /* ---- procedural offroad wheel ----
     Drawn centered at (0,0), radius = W/2 * 0.92. Layers (back to front):
       1. brake disc (dark grey, behind everything)
       2. tire (black rubber with knobby tread blocks around the rim)
       3. beadlock ring (machined alloy ring just inside the tire)
       4. rim (alloy with 8 spokes)
       5. hub (centre cap with 5 lug nuts)
     The tread blocks are the key detail — they're the visual cue that
     the wheel is spinning (without them it'd look like a smooth disc). */
  function _drawWheel(x, y){
    const R = W * 0.46;           /* outer tire radius */
    const tireW = R * 0.22;       /* tire sidewall thickness */
    const treadR = R;             /* tread block tip radius */
    const treadInner = R - tireW * 0.55;
    const rimR = R - tireW;       /* rim outer = tire inner */
    const beadR = rimR + tireW * 0.18;  /* beadlock sits on the tire shoulder */
    const hubR = rimR * 0.28;

    ctx.save();
    ctx.translate(x, y);

    /* 1. brake disc — visible behind the spokes, dark gunmetal */
    ctx.beginPath();
    ctx.arc(0, 0, rimR * 0.88, 0, Math.PI*2);
    ctx.fillStyle = '#2a2622';
    ctx.fill();
    /* drilled holes in the disc for that motorsport look */
    ctx.fillStyle = '#0e0c0a';
    for(let i=0;i<8;i++){
      const a = i * Math.PI/4 + Math.PI/8;
      const dr = rimR * 0.62;
      ctx.beginPath();
      ctx.arc(Math.cos(a)*dr, Math.sin(a)*dr, rimR*0.07, 0, Math.PI*2);
      ctx.fill();
    }

    /* 2. tire — black rubber */
    ctx.beginPath();
    ctx.arc(0, 0, R, 0, Math.PI*2);
    ctx.fillStyle = '#1a1815';
    ctx.fill();
    /* sidewall shading — slightly lighter ring inside the tread */
    const sidGr = ctx.createRadialGradient(0, 0, rimR, 0, 0, R);
    sidGr.addColorStop(0, 'rgba(60,55,50,0.35)');
    sidGr.addColorStop(0.7, 'rgba(20,18,16,0)');
    sidGr.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = sidGr;
    ctx.beginPath();
    ctx.arc(0, 0, R, 0, Math.PI*2);
    ctx.fill();

    /* knobby tread blocks around the rim — 24 blocks */
    const N_TREAD = 24;
    for(let i=0;i<N_TREAD;i++){
      const a = (i / N_TREAD) * Math.PI * 2;
      ctx.save();
      ctx.rotate(a);
      /* tread block — a chunky rectangle at the outer edge */
      const bw = (Math.PI * 2 * treadInner / N_TREAD) * 0.78;
      const bh = treadR - treadInner;
      ctx.fillStyle = '#0c0a08';
      ctx.fillRect(-bw/2, -treadR, bw, bh * 0.95);
      /* tiny wear highlight on the leading edge */
      ctx.fillStyle = 'rgba(110,100,90,0.18)';
      ctx.fillRect(-bw/2, -treadR, bw*0.18, bh*0.95);
      /* sand caught in the tread (random specks) */
      if(i % 3 === 0){
        ctx.fillStyle = 'rgba(220,190,140,0.5)';
        ctx.fillRect(-bw*0.25, -treadR + bh*0.3, 1.4, 1.4);
        ctx.fillRect( bw*0.15, -treadR + bh*0.6, 1.2, 1.2);
      }
      ctx.restore();
    }

    /* 3. beadlock ring — machined alloy ring with bolts */
    ctx.beginPath();
    ctx.arc(0, 0, beadR, 0, Math.PI*2);
    ctx.lineWidth = tireW * 0.18;
    ctx.strokeStyle = '#a89878';
    ctx.stroke();
    /* highlight on top, shadow on bottom (fake lighting) */
    ctx.beginPath();
    ctx.arc(0, 0, beadR, -Math.PI*0.8, -Math.PI*0.2);
    ctx.lineWidth = tireW * 0.06;
    ctx.strokeStyle = 'rgba(255,235,180,0.45)';
    ctx.stroke();
    /* beadlock bolts — 16 small bolts around the ring */
    const N_BOLTS = 16;
    for(let i=0;i<N_BOLTS;i++){
      const a = (i / N_BOLTS) * Math.PI * 2;
      const bx = Math.cos(a) * beadR;
      const by = Math.sin(a) * beadR;
      ctx.beginPath();
      ctx.arc(bx, by, tireW*0.10, 0, Math.PI*2);
      ctx.fillStyle = '#605548';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(bx - tireW*0.03, by - tireW*0.03, tireW*0.04, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(220,200,160,0.7)';
      ctx.fill();
    }

    /* 4. rim — alloy with 8 spokes */
    /* outer rim ring */
    ctx.beginPath();
    ctx.arc(0, 0, rimR, 0, Math.PI*2);
    ctx.fillStyle = '#1d1a16';
    ctx.fill();
    /* inner rim ring (lip) */
    ctx.beginPath();
    ctx.arc(0, 0, rimR * 0.95, 0, Math.PI*2);
    ctx.fillStyle = '#2c2823';
    ctx.fill();
    /* 8 spokes — thick alloy bars from hub to rim */
    const N_SPOKES = 8;
    for(let i=0;i<N_SPOKES;i++){
      const a = (i / N_SPOKES) * Math.PI * 2;
      ctx.save();
      ctx.rotate(a);
      /* spoke body — tapered, machined alloy */
      const spokeW = rimR * 0.16;
      const spokeLen = rimR * 0.92 - hubR;
      ctx.fillStyle = '#9a8a6a';
      ctx.beginPath();
      ctx.moveTo(-spokeW*0.55, -hubR*0.9);
      ctx.lineTo( spokeW*0.55, -hubR*0.9);
      ctx.lineTo( spokeW*0.40, -rimR*0.92);
      ctx.lineTo(-spokeW*0.40, -rimR*0.92);
      ctx.closePath();
      ctx.fill();
      /* highlight on the leading side */
      ctx.fillStyle = 'rgba(240,220,180,0.55)';
      ctx.beginPath();
      ctx.moveTo(-spokeW*0.55, -hubR*0.9);
      ctx.lineTo(-spokeW*0.20, -hubR*0.9);
      ctx.lineTo(-spokeW*0.12, -rimR*0.92);
      ctx.lineTo(-spokeW*0.40, -rimR*0.92);
      ctx.closePath();
      ctx.fill();
      /* shadow on the trailing side */
      ctx.fillStyle = 'rgba(20,15,10,0.45)';
      ctx.beginPath();
      ctx.moveTo( spokeW*0.20, -hubR*0.9);
      ctx.lineTo( spokeW*0.55, -hubR*0.9);
      ctx.lineTo( spokeW*0.40, -rimR*0.92);
      ctx.lineTo( spokeW*0.12, -rimR*0.92);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    /* 5. hub — centre cap with 5 lug nuts */
    /* outer hub ring */
    ctx.beginPath();
    ctx.arc(0, 0, hubR, 0, Math.PI*2);
    ctx.fillStyle = '#7a6c52';
    ctx.fill();
    /* hub face — slightly recessed */
    ctx.beginPath();
    ctx.arc(0, 0, hubR * 0.85, 0, Math.PI*2);
    ctx.fillStyle = '#5a4f3e';
    ctx.fill();
    /* 5 lug nuts in a pentagon */
    const N_LUGS = 5;
    for(let i=0;i<N_LUGS;i++){
      const a = (i / N_LUGS) * Math.PI * 2 - Math.PI/2;
      const lr = hubR * 0.55;
      const lx = Math.cos(a) * lr, ly = Math.sin(a) * lr;
      /* lug nut body */
      ctx.beginPath();
      ctx.arc(lx, ly, hubR*0.16, 0, Math.PI*2);
      ctx.fillStyle = '#3a3328';
      ctx.fill();
      /* hex highlight */
      ctx.beginPath();
      ctx.arc(lx - hubR*0.04, ly - hubR*0.04, hubR*0.07, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(220,200,160,0.6)';
      ctx.fill();
    }
    /* centre cap — small dark dot */
    ctx.beginPath();
    ctx.arc(0, 0, hubR*0.18, 0, Math.PI*2);
    ctx.fillStyle = '#1a1612';
    ctx.fill();

    /* sand dust caught in the beadlock / tread (a few specks for realism) */
    ctx.fillStyle = 'rgba(220,190,140,0.7)';
    for(let i=0;i<6;i++){
      const a = Math.random() * Math.PI * 2;
      const r = beadR + (Math.random()-0.5) * tireW * 0.4;
      ctx.fillRect(Math.cos(a)*r, Math.sin(a)*r, 1.2, 1.2);
    }

    ctx.restore();
  }

  /* ---- main loop ---- */
  let _last = performance.now();
  function _loop(){
    requestAnimationFrame(_loop);
    const now = performance.now();
    const dt = Math.min((now - _last)/1000, 0.05);
    _last = now;
    _step(dt);
    _draw();
  }

  /* ---- boot ---- */
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  }else{
    boot();
  }
})();
