/* Audio engine: SFX loading, 3D positional audio, looping beds */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- audio ---------------- */
/* Real SFX live in the project's SFX/ folder. The game looks for it next to the
   page first (deployed preview: ./SFX/...), then one level up (repo: game/../SFX/...). */
const SFX_BASES=['SFX/','../SFX/'];
const SFX_FILES={
  wormJump:['Worms_SFX/Normal_worms_SFX/Jump-Land/Normal_Worm_Jump01.wav',
            'Worms_SFX/Normal_worms_SFX/Jump-Land/Normal_Worm_Jump02.wav',
            'Worms_SFX/Normal_worms_SFX/Jump-Land/Normal_Worm_Jump03.wav',
            'Worms_SFX/Normal_worms_SFX/Jump-Land/Normal_Worm_Jump04.wav',
            'Worms_SFX/Normal_worms_SFX/Jump-Land/Normal_Worm_Jump.mp3'],
  wormSwim:['Worms_SFX/Normal_worms_SFX/Swim/worm_swim01.mp3'],
  alphaPreRoar:['Worms_SFX/AlphaWorm_SFX/AlphaWorm_PreEruption_Roar.mp3'],
  alphaErupt:['Worms_SFX/AlphaWorm_SFX/AlphaWorm_Jump+swimming.mp3'],
  alphaBreach:['Worms_SFX/AlphaWorm_SFX/AlphaWorm_Jump+swimming.mp3'],
  music:['Game_SFX/OST/Soundtrack_TensionMoments.mp3'],
  ambient:['Game_SFX/Atmosphere - Ambient/Ambient_Desert.mp3'],
  windGust:['Game_SFX/Atmosphere - Ambient/Wind_Gust.mp3'],
  thumperThrow:['Game_SFX/Thumper - SFX/Thumper_Throw.wav'],
  thumperPlant:['Game_SFX/Thumper - SFX/Thumper_Plant.wav'],
  thumperCollect:['Game_SFX/Thumper - SFX/Thumper_Collect.mp3'],
  thumperMax:['Game_SFX/Thumper - SFX/Thumper_Max.wav'],
  uiClick:['Game_SFX/UI - SFX/Clicks/UI_ButtonClick01.wav','Game_SFX/UI - SFX/Clicks/UI_ButtonClick02.wav','Game_SFX/UI - SFX/Clicks/UI_ButtonClick03.wav'],
  uiTab:['Game_SFX/UI - SFX/Tabs-SFX/UI_TabChange01.wav','Game_SFX/UI - SFX/Tabs-SFX/UI_TabChange02.wav','Game_SFX/UI - SFX/Tabs-SFX/UI_TabChange03.wav'],
  uiOpenClose:['Game_SFX/UI - SFX/Menus/UI_Open-Close.wav'],
  uiBarDrag:['Game_SFX/UI - SFX/Bars-SFX/UI_BarDrag.wav'],
  uiHover:['Game_SFX/UI - SFX/Bars-SFX/UI_BarDrag.wav'],
  spiceCollect:['Game_SFX/Collectibles - SFX/Spice_Collect.mp3'],
  explosion:['Game_SFX/Explosives - SFX/Explosion.wav'],
  jeepEngine:['Jeep_SFX/Engine/Jeep_Engine.wav'],
  suspension:['Jeep_SFX/Suspension/Suspension_Creak01.wav','Jeep_SFX/Suspension/Suspension_Creak02.wav','Jeep_SFX/Suspension/Suspension_Creak03.wav'],
  hardLand:['Jeep_SFX/Other/Jeep_HardLand.wav','Jeep_SFX/Other/Jeep_HardLand_02.wav'],
  highWind:['Jeep_SFX/Other/High_Speed_Wind.wav'],
  handbrake:['Jeep_SFX/Other/Handbrake.wav','Jeep_SFX/Other/HandBrake_Leave.wav']
};
const SFX_URLS={ thump:'', impact:'', roar:'', pickup:'', breach:'' };   // optional extra one-shots (URLs)
const sfxBuf={};        // name -> AudioBuffer | AudioBuffer[] (variants)
const sfxEl={};         // name -> url[]  (HTMLAudio fallback, e.g. when opened from file://)
const sfxLast={};       // name -> last variant index (avoid repeats)
const longVoices=new Set();
const followVoices=new Set();   // positional voices that track a moving object
/* ---- 3D positional audio ----
   Ears ride on the buggy and face where the camera looks. Each positional sound goes
   gain -> air-absorption lowpass -> HRTF panner, with an optional un-panned "spread"
   share so colossal sources (the Alpha) feel enveloping instead of point-like. */
const _lf=new THREE.Vector3(), _lu=new THREE.Vector3();
function setAP(param,v,t){ param.setTargetAtTime(v,t,0.025); }
function updateListener(){
  const L=AC.listener, t=AC.currentTime, p=player.pos;
  camera.getWorldDirection(_lf); _lu.set(0,1,0).applyQuaternion(camera.quaternion);
  if(L.positionX){
    setAP(L.positionX,p.x,t); setAP(L.positionY,p.y+1.5,t); setAP(L.positionZ,p.z,t);
    setAP(L.forwardX,_lf.x,t); setAP(L.forwardY,_lf.y,t); setAP(L.forwardZ,_lf.z,t);
    setAP(L.upX,_lu.x,t); setAP(L.upY,_lu.y,t); setAP(L.upZ,_lu.z,t);
  } else {
    L.setPosition(p.x,p.y+1.5,p.z); L.setOrientation(_lf.x,_lf.y,_lf.z,_lu.x,_lu.y,_lu.z);
  }
}
function airCutoff(d,k){ return clamp(20000*Math.exp(-d/(k||420)), 700, 20000); }
function makeSpatial(opt={}){
  const input=AC.createGain();
  const lp=AC.createBiquadFilter(); lp.type='lowpass'; lp.Q.value=0.5; lp.frequency.value=20000;
  const pn=AC.createPanner();
  pn.panningModel=opt.model||'HRTF'; pn.distanceModel='inverse';
  pn.refDistance=opt.ref||30; pn.rolloffFactor=opt.rolloff!=null?opt.rolloff:1; pn.maxDistance=10000;
  const out=opt.bus||master;
  const spread=opt.spread||0;
  const wet=AC.createGain(); wet.gain.value=1-spread;
  input.connect(lp); lp.connect(wet).connect(pn).connect(out);
  let dry=null;
  if(spread>0){
    dry=AC.createGain(); dry.gain.value=spread*clamp((opt.ref||30)/30,0,1); lp.connect(dry).connect(out);
  }
  return {
    input, pn, lp,
    place(P,now){
      const t=AC.currentTime, y=(P.y!=null?P.y:terrainH(P.x,P.z));
      if(pn.positionX){
        if(now){ pn.positionX.value=P.x; pn.positionY.value=y; pn.positionZ.value=P.z; }
        else { setAP(pn.positionX,P.x,t); setAP(pn.positionY,y,t); setAP(pn.positionZ,P.z,t); }
      } else pn.setPosition(P.x,y,P.z);
      const d=Math.hypot(P.x-player.pos.x, P.z-player.pos.z);
      const f=airCutoff(d,opt.air);
      if(now) lp.frequency.value=f; else lp.frequency.setTargetAtTime(f,t,0.1);
    },
    dispose(){ try{ input.disconnect(); pn.disconnect(); lp.disconnect(); wet.disconnect(); if(dry) dry.disconnect(); }catch(e){} }
  };
}
/* worm swimming: one panned loop per lesser worm, placed at its head under the sand */
const swimVoices=new Map();
function swimVoice(w){
  let v=swimVoices.get(w);
  if(v) return v;
  const s=AC.createBufferSource(); s.buffer=sfxBuf.wormSwim; s.loop=true;
  const g=AC.createGain(); g.gain.value=0;
  const big=w.tier==='giant';
  /* the giant's swim is pitched way down, carries much further and gets a heavy low end;
     a compressor keeps the extra gain from clipping. Lesser worms get a depth filter:
     buried and distant = muffled, shallow and hunting = close and bright. */
  const sp=makeSpatial(big ? {ref:140, rolloff:0.8, air:1100, spread:0.25} : {ref:38, rolloff:1, air:380});
  let lp=null;
  if(big){
    const ls=AC.createBiquadFilter(); ls.type='lowshelf'; ls.frequency.value=170; ls.gain.value=8;
    const cp=AC.createDynamicsCompressor(); cp.threshold.value=-14; cp.ratio.value=4; cp.attack.value=0.02; cp.release.value=0.3;
    s.connect(ls).connect(g).connect(cp).connect(sp.input);
  } else {
    lp=AC.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=900; lp.Q.value=0.6;
    s.connect(lp).connect(g).connect(sp.input);
  }
  s.start(0, Math.random()*sfxBuf.wormSwim.duration);   // desync the loops
  v={s,g,sp,big,lp,detune:0.95+Math.random()*0.10}; swimVoices.set(w,v); return v;
}
/* A short, low, positional sand-pressure pulse for the instant a worm commits
   to an attack. It is deliberately not an alarm: just a muffled heave under
   the sand, with a global rate limit so several worms can never stack it. */
let lastWormPressureT=-99;
function wormPressureSfx(pos, strength=1, rate=1){
  if(!AC) return;
  const t0=AC.currentTime;
  if(t0-lastWormPressureT<0.22) return;
  lastWormPressureT=t0;
  const sp=makeSpatial({ref:26, rolloff:1.15, air:300});
  sp.place({x:pos.x,z:pos.z},true);
  const dur=0.50+0.16*clamp(strength,0,1.4);
  const n=AC.createBufferSource(); n.buffer=noiseBuf;
  const f=AC.createBiquadFilter(); f.type='lowpass'; f.Q.value=0.7;
  f.frequency.setValueAtTime(190*rate,t0);
  f.frequency.exponentialRampToValueAtTime(72*rate,t0+dur);
  const g=AC.createGain();
  g.gain.setValueAtTime(0.0001,t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.02,0.15*strength),t0+0.055);
  g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  n.connect(f).connect(g).connect(sp.input);
  n.start(t0); n.stop(t0+dur+0.04);
  const o=AC.createOscillator(); o.type='sine';
  o.frequency.setValueAtTime(52*rate,t0);
  o.frequency.exponentialRampToValueAtTime(31*rate,t0+dur*0.9);
  const og=AC.createGain();
  og.gain.setValueAtTime(0.0001,t0);
  og.gain.exponentialRampToValueAtTime(Math.max(0.01,0.09*strength),t0+0.045);
  og.gain.exponentialRampToValueAtTime(0.0001,t0+dur*0.85);
  o.connect(og).connect(sp.input); o.start(t0); o.stop(t0+dur);
  n.onended=()=>sp.dispose();
}
let sfxBase=null;
const sfxPath=rel=>sfxBase+rel.split('/').map(encodeURIComponent).join('/');
function pickVariant(name,n){
  if(n<2) return 0;
  let i=Math.floor(Math.random()*n);
  if(i===sfxLast[name]) i=(i+1)%n;
  sfxLast[name]=i; return i;
}
function playSfx(name, vol=1, rate=1, dist=0, opt={}){
  if(!AC) return false;
  const g0=vol*(opt.rawDist?1:clamp(1-dist/280,0.08,1));
  let b=sfxBuf[name];
  if(b){
    if(Array.isArray(b)) b=b[pickVariant(name,b.length)];
    const s=AC.createBufferSource(); s.buffer=b; s.playbackRate.value=rate;
    const positional=!!(opt.pos||opt.follow);
    const g=AC.createGain(); g.gain.value=positional?vol:g0;
    s.connect(g);
    let sp=null;
    if(positional){
      sp=makeSpatial(opt); g.connect(sp.input);
      const P=opt.follow?opt.follow():opt.pos; sp.place(P,true);
    } else g.connect(opt.bus||master);
    s.start(AC.currentTime+(opt.delay||0));
    const v={s,g,sp,follow:opt.follow};
    if(opt.follow) followVoices.add(v);
    if(opt.long) longVoices.add(v);
    s.onended=()=>{ longVoices.delete(v); followVoices.delete(v); if(sp) sp.dispose(); };
    return true;
  }
  const urls=sfxEl[name];
  if(urls){
    const a=new Audio(urls[pickVariant(name,urls.length)]);
    a.volume=clamp(g0*master.gain.value,0,1); a.playbackRate=rate; a.preservesPitch=false;
    setTimeout(()=>a.play().catch(()=>{}), (opt.delay||0)*1000);
    if(opt.long){ const v={el:a}; longVoices.add(v); a.onended=()=>longVoices.delete(v); }
    return true;
  }
  return false;
}
function stopLongSfx(fade=0.4){
  if(!AC) return;
  const t=AC.currentTime;
  for(const v of longVoices){
    if(v.s){ v.g.gain.cancelScheduledValues(t); v.g.gain.setTargetAtTime(0,t,fade/3); try{ v.s.stop(t+fade); }catch(e){} }
    else if(v.el){ v.el.pause(); }
  }
  longVoices.clear(); followVoices.clear();
}
async function fetchBuf(url){
  const res=await fetch(url);
  if(!res.ok) throw new Error('HTTP '+res.status);
  return await AC.decodeAudioData(await res.arrayBuffer());
}
async function findSfxBase(){
  const probe=SFX_FILES.wormJump[0];
  for(const b of SFX_BASES){
    sfxBase=b;
    try{ const r=await fetch(sfxPath(probe)); if(r.ok){ await r.arrayBuffer(); return b; } }catch(e){}
  }
  sfxBase=SFX_BASES[0];
  return null;
}
async function loadSfx(){
  if(!AC) return;
  const found=await findSfxBase();
  const fileMode=location.protocol==='file:';
  const jobs=Object.entries(SFX_FILES).map(async ([k,list])=>{
    if(fileMode||!found){ sfxEl[k]=list.map(sfxPath); return; }   // fetch is blocked on file:// → <audio> fallback
    try{
      const results=await Promise.allSettled(list.map(r=>fetchBuf(sfxPath(r))));
      const bufs=results.filter(r=>r.status==='fulfilled').map(r=>r.value);
      const failed=results.filter(r=>r.status==='rejected');
      if(!bufs.length) throw failed[0].reason;
      if(failed.length) console.warn('[sfx] missing '+failed.length+' variant(s) for "'+k+'"');
      sfxBuf[k]=bufs.length>1?bufs:bufs[0];
      console.log('[sfx] loaded', k);
    }catch(e){
      console.warn('[sfx] could not decode "'+k+'", using <audio> fallback', e);
      sfxEl[k]=list.map(sfxPath);
    }
  });
  for(const k in SFX_URLS){
    const url=SFX_URLS[k]; if(!url) continue;
    jobs.push(fetchBuf(url).then(b=>{ sfxBuf[k]=b; }).catch(e=>console.warn('[sfx] could not load "'+k+'"',e)));
  }
  await Promise.all(jobs);
  startLoops();
}
/* ---- looping beds: worm swimming + tension soundtrack ---- */
let swimG=null, swimEl=null, musicG=null, musicSrc=null, musicEl=null;
let ambientG=null, ambientSrc=null, ambientEl=null, jeepLoopG=null, jeepLoopSrc=null, jeepLoopEl=null, speedWindG=null, speedWindSrc=null, speedWindEl=null;
let tension=0, tensionHold=0, musicSilentT=99, musicLvl=0;
function startLoopAsset(key){
  if(sfxBuf[key]){
    const g=AC.createGain(); g.gain.value=0; g.connect(master);
    const src=AC.createBufferSource(); src.buffer=sfxBuf[key]; src.loop=true; src.connect(g); src.start();
    return {g,src,el:null};
  }
  if(sfxEl[key]){
    const el=new Audio(sfxEl[key][0]); el.loop=true; el.volume=0; el.preservesPitch=false;
    el.play().catch(()=>{}); return {g:null,src:null,el};
  }
  return null;
}
function setLoopLevel(loop,level,rate=1){
  if(!loop) return;
  if(loop.g) loop.g.gain.setTargetAtTime(level,AC.currentTime,0.25);
  if(loop.src) loop.src.playbackRate.setTargetAtTime(rate,AC.currentTime,0.2);
  if(loop.el){ loop.el.volume=clamp(level*master.gain.value,0,1); loop.el.playbackRate=rate; }
}
function startLoops(){
  ambientG=startLoopAsset('ambient');
  jeepLoopG=startLoopAsset('jeepEngine');
  speedWindG=startLoopAsset('highWind');
  if(sfxBuf.wormSwim){
    swimG=true;   // per-worm positional voices, see swimVoice()
  } else if(sfxEl.wormSwim){
    swimEl=new Audio(sfxEl.wormSwim[0]); swimEl.loop=true; swimEl.volume=0; swimEl.preservesPitch=false;
    swimEl.play().catch(()=>{});
  }
  if(sfxBuf.music){
    musicG=AC.createGain(); musicG.gain.value=0; musicG.connect(master);
  } else if(sfxEl.music){
    musicEl=new Audio(sfxEl.music[0]); musicEl.loop=true; musicEl.volume=0;
  }
}
function musicRestart(){
  if(musicG){
    if(musicSrc){ try{ musicSrc.stop(); }catch(e){} }
    musicSrc=AC.createBufferSource(); musicSrc.buffer=sfxBuf.music; musicSrc.loop=true;
    musicSrc.connect(musicG); musicSrc.start();
  } else if(musicEl){ musicEl.currentTime=0; musicEl.play().catch(()=>{}); }
}
function updateLoops(dt){
  const t=AC.currentTime;
  /* worm swimming: loudest lesser worm that is close & shallow */
  let near=0, rate=1;
  for(const w of worms){
    if(w.state==='gone') continue;
    if(w.nearContrib>near){ near=w.nearContrib; rate=(0.9+clamp(w.spd/60,0,1)*0.25)*(w.tier==='giant'?GIANT_PITCH:1); }
  }
  const swimV=Math.min(near,1)*0.48;
  updateListener();
  const inGame=gameState==='play'&&player.alive;
  const speed01=clamp(Math.abs(player.speedF)/VMAX,0,1.25);
  setLoopLevel(ambientG,(inGame&&!alpha.active)?0.09+0.035*clamp(speed01,0,1):0,0.92);   // dune wind; the desert goes quiet for the Alpha
  setLoopLevel(jeepLoopG,inGame?0.10+speed01*0.11:0,0.78+speed01*0.52);
  setLoopLevel(speedWindG,inGame?Math.max(0,speed01-0.18)*0.22:0,0.8+speed01*0.4);
  for(const v of followVoices) v.sp.place(v.follow(),false);
  if(swimG){
    for(const w of worms){
      const v=swimVoice(w);
      const d=horizDist(w.pos,player.pos);
      const st=w.state;
      const surge=(st==='coil'||st==='emerge'||st==='lunge')?1.16:1;
      const lvl = (st==='gone') ? 0 : v.big
        ? (w.swimLvl||0)*1.9*clamp(1-(d-1100)/600,0,1)       // the giant: much louder, heard from far away
        : (w.swimLvl||0)*0.66*surge*clamp(1-(d-540)/280,0,1);
      v.g.gain.setTargetAtTime(gameState!=='title'?lvl:0,t,0.25);
      v.s.playbackRate.setTargetAtTime((0.9+clamp(w.spd/60,0,1)*0.25)*v.detune*(v.big?GIANT_PITCH:1),t,0.4);
      if(v.lp){
        const open=clamp(1-(w.depth||0)/(w.headR*3.0)+((st==='coil'||st==='emerge'||st==='lunge')?0.22:0),0,1);
        v.lp.frequency.setTargetAtTime(450+3600*open,t,0.25);
      }
      v.sp.place(w.pos,false);
    }
  }
  else if(swimEl){ swimEl.volume=clamp(swimV*master.gain.value,0,1); swimEl.playbackRate=rate; }
  /* tension music: the alpha, or a lesser worm actively hunting nearby */
  const play=gameState==='play'&&player.alive;
  let hot=alpha.active;
  if(!hot) for(const w of worms) if((w.state==='hunt'||w.state==='coil'||w.state==='lunge'||w.state==='dive'||w.state==='emerge')&&w.nearContrib>0.38){ hot=true; break; }
  if(hot&&play) tensionHold=alpha.active?0:9; else tensionHold-=dt;
  /* during the Alpha sequence the music is cut entirely: only the jeep and the world remain */
  const want=(play&&tensionHold>0&&!alpha.active)?0.3:0;
  if(want>0 && musicSilentT>14) musicRestart();          // fresh start after a long calm
  const k=want>musicLvl?0.6:(alpha.active?0.9:(play?0.22:0.9));   // fade in ~2 s, hard cut for the Alpha
  musicLvl+=(want-musicLvl)*Math.min(1,k*dt);
  musicSilentT = musicLvl<0.01 ? musicSilentT+dt : 0;
  if(musicG) musicG.gain.setTargetAtTime(musicLvl,t,0.05);
  else if(musicEl){ musicEl.volume=clamp(musicLvl*master.gain.value,0,1); if(musicLvl<0.003&&musicSilentT>2) musicEl.pause(); }
}
let AC=null, master, engGain, engOsc, engSub, engFilt, windG, rumbleG, noiseBuf;
function initAudio(){
  if(AC){ AC.resume(); return; }
  try{ AC=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ return; }
  master=AC.createGain(); master.gain.value=0.85; master.connect(AC.destination);
  const len=AC.sampleRate*2;
  noiseBuf=AC.createBuffer(1,len,AC.sampleRate);
  const d=noiseBuf.getChannelData(0);
  for(let i=0;i<len;i++) d[i]=Math.random()*2-1;
  const w=AC.createBufferSource(); w.buffer=noiseBuf; w.loop=true;
  const wf=AC.createBiquadFilter(); wf.type='bandpass'; wf.frequency.value=500; wf.Q.value=0.4;
  windG=AC.createGain(); windG.gain.value=0.02;
  w.connect(wf).connect(windG).connect(master); w.start();
  engOsc=AC.createOscillator(); engOsc.type='sawtooth'; engOsc.frequency.value=45;
  engSub=AC.createOscillator(); engSub.type='sine'; engSub.frequency.value=24;
  engFilt=AC.createBiquadFilter(); engFilt.type='lowpass'; engFilt.frequency.value=260;
  engGain=AC.createGain(); engGain.gain.value=0;
  engOsc.connect(engFilt); engSub.connect(engFilt); engFilt.connect(engGain).connect(master);
  engOsc.start(); engSub.start();
  const r=AC.createBufferSource(); r.buffer=noiseBuf; r.loop=true;
  const rf=AC.createBiquadFilter(); rf.type='lowpass'; rf.frequency.value=75;
  rumbleG=AC.createGain(); rumbleG.gain.value=0;
  r.connect(rf).connect(rumbleG).connect(master); r.start();
  const dr=AC.createOscillator(); dr.type='sine'; dr.frequency.value=54;
  const dg=AC.createGain(); dg.gain.value=0.018;
  dr.connect(dg).connect(master); dr.start();
  loadSfx();
}
function roar(dist, big=false, rate=1){
  if(playSfx('roar', big?0.9:0.62, rate, dist)) return;
  if(!AC) return;
  const t0=AC.currentTime, g=clamp(1-dist/260,0.12,1)*(big?0.8:0.55);
  const o=AC.createOscillator(); o.type='sawtooth';
  o.frequency.setValueAtTime(110*rate,t0);
  o.frequency.exponentialRampToValueAtTime(34*rate,t0+1.1);
  const f=AC.createBiquadFilter(); f.type='lowpass';
  f.frequency.setValueAtTime(420,t0); f.frequency.exponentialRampToValueAtTime(120,t0+1.1);
  const gn=AC.createGain();
  gn.gain.setValueAtTime(0.0001,t0);
  gn.gain.linearRampToValueAtTime(g,t0+0.09);
  gn.gain.exponentialRampToValueAtTime(0.0001,t0+1.25);
  o.connect(f).connect(gn).connect(master); o.start(t0); o.stop(t0+1.3);
  const n=AC.createBufferSource(); n.buffer=noiseBuf;
  const nf=AC.createBiquadFilter(); nf.type='lowpass'; nf.frequency.value=600;
  const ng=AC.createGain();
  ng.gain.setValueAtTime(0.0001,t0);
  ng.gain.linearRampToValueAtTime(g*0.4,t0+0.06);
  ng.gain.exponentialRampToValueAtTime(0.0001,t0+0.9);
  n.connect(nf).connect(ng).connect(master); n.start(t0); n.stop(t0+1);
}
function thumpSfx(pos){
  if(playSfx('thump',0.55,0.92+Math.random()*0.16, 0, pos?{pos:{x:pos.x,z:pos.z}, ref:22}:{})) return;
  if(!AC) return;
  const t0=AC.currentTime;
  let out=master;
  if(pos){ const sp=makeSpatial({ref:22, rolloff:1}); sp.place(pos,true); out=sp.input; setTimeout(()=>sp.dispose(),600); }
  const o=AC.createOscillator(); o.type='sine';
  o.frequency.setValueAtTime(70,t0); o.frequency.exponentialRampToValueAtTime(44,t0+0.15);
  const g=AC.createGain();
  g.gain.setValueAtTime(0.4,t0); g.gain.exponentialRampToValueAtTime(0.0001,t0+0.18);
  o.connect(g).connect(out); o.start(t0); o.stop(t0+0.2);
}
/* whoosh as the thumper leaves your hand — brighter and longer for a hard throw */
function throwSfx(p){
  if(!AC) return;
  const t0=AC.currentTime, dur=0.32+p*0.3;
  const n=AC.createBufferSource(); n.buffer=noiseBuf; n.playbackRate.value=0.8+p*0.4;
  const f=AC.createBiquadFilter(); f.type='bandpass'; f.Q.value=1.4;
  f.frequency.setValueAtTime(380,t0); f.frequency.exponentialRampToValueAtTime(1500+p*1600,t0+dur*0.35);
  f.frequency.exponentialRampToValueAtTime(500,t0+dur);
  const g=AC.createGain();
  g.gain.setValueAtTime(0.0001,t0); g.gain.exponentialRampToValueAtTime(0.16+p*0.12,t0+dur*0.3);
  g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  n.connect(f).connect(g).connect(master); n.start(t0); n.stop(t0+dur+0.05);
  const o=AC.createOscillator(); o.type='triangle';               // the stake "clunk" off the rack
  o.frequency.setValueAtTime(210,t0); o.frequency.exponentialRampToValueAtTime(90,t0+0.08);
  const og=AC.createGain(); og.gain.setValueAtTime(0.12,t0); og.gain.exponentialRampToValueAtTime(0.0001,t0+0.1);
  o.connect(og).connect(master); o.start(t0); o.stop(t0+0.12);
}
/* stake punching into the sand where it lands (positional) */
function landSfx(pos){
  if(!AC) return;
  const t0=AC.currentTime;
  const sp=makeSpatial({ref:24, rolloff:1}); sp.place(pos,true); setTimeout(()=>sp.dispose(),900);
  const n=AC.createBufferSource(); n.buffer=noiseBuf;
  const f=AC.createBiquadFilter(); f.type='lowpass'; f.frequency.setValueAtTime(1400,t0); f.frequency.exponentialRampToValueAtTime(180,t0+0.3);
  const g=AC.createGain(); g.gain.setValueAtTime(0.5,t0); g.gain.exponentialRampToValueAtTime(0.0001,t0+0.4);
  n.connect(f).connect(g).connect(sp.input); n.start(t0); n.stop(t0+0.45);
  const o=AC.createOscillator(); o.type='sine';
  o.frequency.setValueAtTime(95,t0); o.frequency.exponentialRampToValueAtTime(40,t0+0.25);
  const og=AC.createGain(); og.gain.setValueAtTime(0.5,t0); og.gain.exponentialRampToValueAtTime(0.0001,t0+0.3);
  o.connect(og).connect(sp.input); o.start(t0); o.stop(t0+0.32);
}
function pickupSfx(){
  if(playSfx('pickup',0.6)) return;
  if(!AC) return;
  const t0=AC.currentTime;
  [660,990].forEach((f,i)=>{
    const o=AC.createOscillator(); o.type='sine';
    o.frequency.setValueAtTime(f,t0+i*0.05);
    const g=AC.createGain();
    g.gain.setValueAtTime(0.09,t0+i*0.05); g.gain.exponentialRampToValueAtTime(0.0001,t0+i*0.05+0.22);
    o.connect(g).connect(master); o.start(t0+i*0.05); o.stop(t0+i*0.05+0.25);
  });
}
function impactSfx(){
  if(playSfx('impact',0.7)) return;
  if(!AC) return;
  const t0=AC.currentTime;
  const n=AC.createBufferSource(); n.buffer=noiseBuf;
  const f=AC.createBiquadFilter(); f.type='lowpass'; f.frequency.value=300;
  const g=AC.createGain();
  g.gain.setValueAtTime(0.55,t0); g.gain.exponentialRampToValueAtTime(0.0001,t0+0.35);
  n.connect(f).connect(g).connect(master); n.start(t0); n.stop(t0+0.4);
  const o=AC.createOscillator(); o.type='sine';
  o.frequency.setValueAtTime(120,t0); o.frequency.exponentialRampToValueAtTime(45,t0+0.3);
  const og=AC.createGain();
  og.gain.setValueAtTime(0.4,t0); og.gain.exponentialRampToValueAtTime(0.0001,t0+0.32);
  o.connect(og).connect(master); o.start(t0); o.stop(t0+0.35);
}
/* positional underground rumble (digger thumpers): filtered noise + sub tone */
function diggerRumbleSfx(pos, intensity){
  if(!AC) return;
  const d=horizDist(pos,player.pos);
  const vol=clamp(intensity*(1-d/300),0,1);
  if(vol<0.05) return;
  const sp=makeSpatial({ref:26, rolloff:1, air:300});
  const t0=AC.currentTime, dur=0.42+Math.random()*0.2;
  const n=AC.createBufferSource(); n.buffer=noiseBuf; n.loop=true;
  const f=AC.createBiquadFilter(); f.type='lowpass'; f.frequency.value=150+Math.random()*90;
  const g=AC.createGain(); g.gain.setValueAtTime(0.0001,t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.02,vol*0.8),t0+0.06);
  g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  n.connect(f).connect(g).connect(sp.input);
  sp.place({x:pos.x,z:pos.z},true);
  n.start(t0); n.stop(t0+dur+0.05);
  n.onended=()=>sp.dispose();
  const o=AC.createOscillator(); o.type='sine'; o.frequency.value=38+Math.random()*14;
  const og=AC.createGain(); og.gain.setValueAtTime(0.0001,t0);
  og.gain.exponentialRampToValueAtTime(Math.max(0.02,vol*0.5),t0+0.05);
  og.gain.exponentialRampToValueAtTime(0.0001,t0+dur*0.8);
  o.connect(og).connect(sp.input); o.start(t0); o.stop(t0+dur);
}
/* explosive detonation: the Explosion.wav sample, else a synthesized sharp crack + rolling body + sub-bass drop */
function boomSfx(dist, pos){
  const spOpt=pos?{model:'equalpower', ref:60, rolloff:1, spread:0.15, pos:{x:pos.x,z:pos.z}}:{};
  if(playSfx('explosion', 1.0, 0.92+Math.random()*0.16, pos?0:dist, spOpt)) return;
  if(!AC) return;
  const g0=clamp(1-dist/420,0.3,1), t0=AC.currentTime;
  const n=AC.createBufferSource(); n.buffer=noiseBuf;
  const nf=AC.createBiquadFilter(); nf.type='highpass'; nf.frequency.value=900;
  const ng=AC.createGain(); ng.gain.setValueAtTime(0.55*g0,t0); ng.gain.exponentialRampToValueAtTime(0.0001,t0+0.18);
  n.connect(nf).connect(ng).connect(master); n.start(t0); n.stop(t0+0.2);
  const n2=AC.createBufferSource(); n2.buffer=noiseBuf;
  const f2=AC.createBiquadFilter(); f2.type='lowpass'; f2.frequency.setValueAtTime(2200,t0); f2.frequency.exponentialRampToValueAtTime(120,t0+0.9);
  const g2=AC.createGain(); g2.gain.setValueAtTime(0.9*g0,t0); g2.gain.exponentialRampToValueAtTime(0.0001,t0+1.1);
  n2.connect(f2).connect(g2).connect(master); n2.start(t0); n2.stop(t0+1.2);
  const o=AC.createOscillator(); o.type='sine';
  o.frequency.setValueAtTime(140,t0); o.frequency.exponentialRampToValueAtTime(28,t0+0.7);
  const og=AC.createGain(); og.gain.setValueAtTime(1.0*g0,t0); og.gain.exponentialRampToValueAtTime(0.0001,t0+0.9);
  o.connect(og).connect(master); o.start(t0); o.stop(t0+1.0);
}
function splashSfx(dist, pos, rate=1, vol=1){
  if(playSfx('breach',0.8*vol,rate,dist)){ roar(dist*0.8,vol>1,rate); return; }
  const o=pos?{pos:{x:pos.x,z:pos.z}, ref:40*vol, rolloff:0.9}:{};
  if(playSfx('wormJump', 0.38*vol, (0.8+Math.random()*0.08)*rate, dist*0.6, o)){ if(dist<90) impactSfx(); return; }
  impactSfx(); roar(dist*0.8,vol>1,rate);
}
/* ---- the Alpha's swim: one long positional loop that rides on its head ----
   AlphaWorm_Jump+swimming has a soft attack and a long fade-out, so only its sustained
   middle section is looped. Falls back to an <audio> element when opened from file://. */
let alphaSwimV=null;
function alphaSwimStart(fromStart=false){
  if(!AC) return;
  if(alphaSwimV) alphaSwimStop(0.2);
  if(sfxBuf.alphaBreach){
    const b=Array.isArray(sfxBuf.alphaBreach)?sfxBuf.alphaBreach[0]:sfxBuf.alphaBreach;
    const s=AC.createBufferSource(); s.buffer=b; s.loop=true;
    s.loopStart=Math.min(1.4,b.duration*0.1); s.loopEnd=Math.max(s.loopStart+1,b.duration-4.2);
    /* bass-boosted and much louder: a heavy low shelf plus a sub bump, a lowpass that is
       nearly closed while it's buried and opens when it breaks out, and a compressor so
       the extra gain stays clean */
    const ls=AC.createBiquadFilter(); ls.type='lowshelf'; ls.frequency.value=140; ls.gain.value=11;
    const pk=AC.createBiquadFilter(); pk.type='peaking'; pk.frequency.value=55; pk.Q.value=0.9; pk.gain.value=6;
    const lp=AC.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=420; lp.Q.value=0.5;
    const g=AC.createGain(); g.gain.value=0;
    const cp=AC.createDynamicsCompressor(); cp.threshold.value=-16; cp.knee.value=8; cp.ratio.value=5; cp.attack.value=0.03; cp.release.value=0.4;
    const sp=makeSpatial(typeof ALPHA_SPATIAL!=='undefined'?ALPHA_SPATIAL:{ref:700, rolloff:0.35, spread:0.45, air:2600});
    s.connect(ls).connect(pk).connect(lp).connect(g).connect(cp).connect(sp.input);
    s.start(fromStart?AC.currentTime+0.02:AC.currentTime+0.25, fromStart?0:s.loopStart);   // fromStart keeps the file's opening hit (the breach)
    alphaSwimV={s,g,sp,lp,lvl:0,breach:!!fromStart};
  } else if(sfxEl.alphaBreach){
    const el=new Audio(sfxEl.alphaBreach[0]); el.loop=true; el.volume=0; el.preservesPitch=false;
    el.play().catch(()=>{});
    alphaSwimV={el,lvl:0};
  }
}
const ALPHA_SWIM_GAIN=2.6;
function alphaSwimLevel(level, pos, rate=1, open=1){
  const v=alphaSwimV; if(!v||!AC) return;
  v.lvl=level;
  if(v.s){
    const t=AC.currentTime;
    v.g.gain.setTargetAtTime(level*ALPHA_SWIM_GAIN, t, 0.35);
    if(v.lp) v.lp.frequency.setTargetAtTime(420*Math.pow(18000/420, clamp(open,0,1)), t, 0.4);
    v.s.playbackRate.setTargetAtTime(rate, t, 0.6);
    if(pos) v.sp.place(pos,false);
  } else if(v.el){
    const d=pos?Math.hypot(pos.x-player.pos.x,pos.z-player.pos.z):0;
    v.el.volume=clamp(level*clamp(1.2-d/4000,0.35,1)*master.gain.value,0,1);
  }
}
function alphaSwimStop(fade=1.5){
  const v=alphaSwimV; if(!v) return;
  alphaSwimV=null;
  if(v.s && AC){
    const t=AC.currentTime;
    v.g.gain.cancelScheduledValues(t); v.g.gain.setTargetAtTime(0,t,fade/3);
    try{ v.s.stop(t+fade+0.1); }catch(e){}
    v.s.onended=()=>v.sp.dispose();
  } else if(v.el){
    const el=v.el, v0=el.volume, t0=performance.now();
    const step=()=>{ const k=(performance.now()-t0)/(fade*1000); if(k>=1){ el.pause(); return; } el.volume=v0*(1-k); requestAnimationFrame(step); };
    step();
  }
}
let lastBrakeSound=0, lastSuspensionSound=0, lastWindGust=0, lastLandSound=0, wasHandbraking=false;
function updateAudio(){
  if(!AC) return;
  const t=AC.currentTime;
  const sp=Math.min(Math.abs(player.speedF)/VMAX,1.3);
  const engOn=(gameState==='play')&&player.alive;
  const tsPitch = 0.55 + 0.45*timeScale;   // cinematic slow-mo: the engine drops in pitch
  engGain.gain.setTargetAtTime(engOn?0.022+sp*0.035:0, t, 0.09);
  engOsc.frequency.setTargetAtTime((40+sp*95)*tsPitch, t, 0.08);
  engSub.frequency.setTargetAtTime((20+sp*48)*tsPitch, t, 0.08);
  engFilt.frequency.setTargetAtTime((220+sp*900)*(0.6+0.4*timeScale), t, 0.1);
  windG.gain.setTargetAtTime((0.009+sp*0.085)*(0.4+0.6*timeScale), t, 0.15);
  const now=performance.now()/1000;
  if(engOn && player.handbrake && !wasHandbraking && now-lastBrakeSound>0.65){
    playSfx('handbrake',0.48,0.92+Math.random()*0.16,0); lastBrakeSound=now;
  }
  wasHandbraking=!!player.handbrake;
  /* suspension audio: driven by real suspension events from the physics step */
  if(engOn && player.susMaxV>1.1 && now-lastSuspensionSound>0.55+Math.random()*0.4){
    playSfx('suspension',0.24+Math.min(player.susMaxV,4)*0.14,0.8+Math.random()*0.4,0);
    lastSuspensionSound=now;
  }
  if(engOn && player.susClunk>0 && now-lastLandSound>0.75){
    playSfx('hardLand',0.4+Math.min(0.5,player.susClunk*0.22),0.78+Math.random()*0.3,0);
    lastLandSound=now;
  }
  /* wind: rolling gusts sweep the dunes whether you're parked or flying — closer together and
     louder the faster you go */
  if(engOn && now-lastWindGust>(sp>0.6?7+Math.random()*8:13+Math.random()*17)){
    playSfx('windGust',0.10+sp*0.12,0.85+Math.random()*0.3,0); lastWindGust=now;
  }
  const realSwim=!!(swimG||swimEl);
  rumbleG.gain.setTargetAtTime(Math.min(wormNear*(realSwim?0.3:0.55),0.5), t, 0.12);
  updateLoops(Math.min(0.1,t-(updateAudio.lt||t))); updateAudio.lt=t;
}
const _barDragVals=new WeakMap();
const UI_BUTTON_SEL='button, [role="switch"], .set-preset, .set-apply, .set-toggle, [data-puff]';
let _uiOpenCloseClick=false, _hoverEl=null;
function playUiSfx(name,vol=0.45,rate=1){
  if(!AC) initAudio();
  return playSfx(name,vol,rate,0);
}
function playUiHoverSfx(){
  if(!AC) return;
  if(!sfxBuf.uiHover && !sfxEl.uiHover) return;
  playSfx('uiHover',0.09+Math.random()*0.03,1.28+Math.random()*0.12,0);
}
function playUiOpenCloseSfx(){
  _uiOpenCloseClick=true;
  setTimeout(()=>{ _uiOpenCloseClick=false; },0);
  playUiSfx('uiOpenClose',0.52);
}
function _uiBoot(){
  addEventListener('pointerdown', e=>{
    if(AC){ if(AC.state==='suspended') AC.resume(); return; }
    const el=e.target&&e.target.closest?e.target.closest('button, input, [data-puff]'):null;
    if(el) initAudio();
  },{capture:true,passive:true});
  addEventListener('keydown', e=>{
    if(AC){ if(AC.state==='suspended') AC.resume(); return; }
    if(e.code==='Enter'||e.code==='Space'||e.code==='Escape'||e.code==='KeyP') initAudio();
  },{capture:true});
  addEventListener('click', e=>{
    const t=e.target;
    if(!t||!t.closest) return;
    const tab=t.closest('.set-tab');
    if(tab){ playUiSfx('uiTab',0.44+Math.random()*0.05,0.97+Math.random()*0.07); return; }
    if(_uiOpenCloseClick){ _uiOpenCloseClick=false; return; }
    const el=t.closest(UI_BUTTON_SEL);
    if(el && !el.disabled) playUiSfx('uiClick',0.36+Math.random()*0.06,0.94+Math.random()*0.12);
  },{passive:true});
  addEventListener('input', e=>{
    const t=e.target;
    if(!t||!t.matches||!t.matches('input[type="range"], .set-slider')) return;
    if(_barDragVals.get(t)===t.value) return;
    _barDragVals.set(t,t.value);
    playUiSfx('uiBarDrag',0.26+Math.random()*0.04,0.97+Math.random()*0.08);
  },{passive:true});
  addEventListener('pointerover', e=>{
    if(e.pointerType==='touch') return;
    const el=e.target&&e.target.closest?e.target.closest(UI_BUTTON_SEL):null;
    if(!el||el===_hoverEl||el.disabled) return;
    _hoverEl=el;
    playUiHoverSfx();
  },{passive:true});
  addEventListener('pointerout', e=>{
    const el=e.target&&e.target.closest?e.target.closest(UI_BUTTON_SEL):null;
    if(el&&el===_hoverEl&&!(e.relatedTarget&&el.contains(e.relatedTarget))) _hoverEl=null;
  },{passive:true});
}
if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded', _uiBoot);
}else{
  _uiBoot();
}

