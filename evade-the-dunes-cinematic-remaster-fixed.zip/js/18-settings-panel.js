/* ==================================================================
   18-settings-panel.js — organized settings tab UI
   ------------------------------------------------------------------
   A single full-screen overlay (#setPanel) with three tabs:
     GRAPHICS  — preset selector (kept here too for one-stop tuning) +
                 per-setting overrides (shadows, textures, view distance,
                 bloom strength/radius/threshold, lens flare on/off,
                 bloom-sky toggle), audio-less.
     CAMERA    — FOV base, FOV rush, distance, height, shake, roll,
                 smoothing, look-back speed. All live-tunable.
     UI FX     — UI sand-particle toggles + intensity.

   Opened via the SETTINGS button on the title / game-over screen, OR
   via a key (default: ESC). Closing it resumes the game.

   The panel uses the same desert palette as the title screen and is
   fully keyboard-navigable (Tab + Enter + arrow keys on sliders).
   ================================================================== */

(function(){
  /* ---- state ---- */
  let panelEl = null, open = false, currentTab = 'graphics';
  const TABS = [
    {id:'graphics', label:'GRAPHICS'},
    {id:'camera',   label:'CAMERA'},
    {id:'ui',       label:'UI FX'},
    {id:'howto',    label:'HOW TO PLAY'},
  ];

  /* ---- per-setting definitions ----
     Each entry tells the panel how to render + wire the control.
     type: 'preset' | 'toggle' | 'slider' | 'select'
     reload: true  → changing this needs a reload (debonced)
     live:   true  → can be tuned without a reload (handled by
                     onGraphicsLiveChange in 17-graphics.js)
  */
  const GFX_SETTINGS = [
    {key:'shadowEnabled',    label:'REAL-TIME SHADOWS',  type:'toggle', reload:true,
      help:'Shadow map from the sun. Big cost on integrated GPUs.'},
    {key:'shadowMode',       label:'SHADOW FILTER',      type:'select', reload:true,
      options:[{value:'hard',label:'HARD'},{value:'soft',label:'SOFT'}],
      help:'HARD keeps detail crisp and cheap. SOFT blends shadow edges.'},
    {key:'shadowMapSize',    label:'SHADOW MAP SIZE',    type:'slider', min:1024, max:4096, step:512, reload:true, unit:'px',
      help:'Higher resolution = finer shadows. 3072 is the High default.'},
    {key:'shadowCameraHalf', label:'SHADOW COVERAGE',    type:'slider', min:80, max:240, step:10, reload:true, unit:'m',
      help:'Half-width of the sun shadow frustum. Smaller = sharper shadows.'},
    {key:'antialias',        label:'MSAA ANTIALIASING',  type:'toggle', reload:true,
      help:'Smooths jagged edges. ~20% fill-rate cost.'},
    {key:'sandTexSize',      label:'SAND TEXTURE SIZE',  type:'slider', min:256, max:1024, step:128, reload:true, unit:'px',
      help:'Resolution of the procedural sand sheet. Higher = sharper dunes.'},
    {key:'sandRoughnessMap', label:'SAND ROUGHNESS MAP', type:'toggle', reload:true,
      help:'Adds a per-pixel roughness map. Subtle but free on desktop.'},
    {key:'envMap',           label:'ENVIRONMENT REFLECTIONS', type:'toggle', reload:true,
      help:'PMREM environment map for the vehicle + worm materials.'},
    {key:'viewDistance',     label:'TERRAIN VIEW DISTANCE', type:'slider', min:2, max:5, step:1, reload:true, unit:'chunks',
      help:'How many chunks stream around the jeep. 2 = 5×5, 5 = 11×11.'},
    {key:'terrainPolyMax',   label:'TERRAIN POLYGON BUDGET', type:'slider', min:800, max:5200, step:200, reload:true, unit:'tris',
      help:'Triangles in a near chunk. Far chunks automatically use a lighter LOD.'},
    {key:'particleMul',      label:'DUST PARTICLE DENSITY', type:'slider', min:0.2, max:1.5, step:0.05, reload:true, unit:'×',
      help:'Multiplies the size of the dust particle pool.'},
    {key:'pixelRatioCap',    label:'PIXEL RATIO CAP',     type:'slider', min:0.75, max:2, step:0.25, reload:true, unit:'×',
      help:'Caps devicePixelRatio. 1 = render at CSS pixels (cheap).'},
    {key:'fogFar',           label:'FOG DISTANCE',        type:'slider', min:200, max:800, step:20, live:true, unit:'m',
      help:'How far the desert fades into haze.'},
    {key:'sunIntensity',     label:'SUN INTENSITY',       type:'slider', min:1.5, max:5.0, step:0.1, live:true, unit:'×',
      help:'Directional light brightness.'},
    {key:'lensFlare',        label:'LENS GHOSTING',       type:'toggle', live:true,
      help:'Soft chromatic ghosts mirrored through the sun. No streak or column.'},
    {key:'postFX',           label:'BLOOM POST-PROCESSING', type:'toggle', live:true,
      help:'EffectComposer + soft bloom.'},
    {key:'bloomStrength',    label:'BLOOM STRENGTH',      type:'slider', min:0, max:2.0, step:0.05, live:true, unit:'×',
      help:'Bloom intensity. 0 = off, 0.3 = subtle, 1.0 = strong.'},
    {key:'bloomRadius',      label:'BLOOM RADIUS',        type:'slider', min:0, max:1.5, step:0.05, live:true, unit:'×',
      help:'How far the bloom spreads from a bright pixel.'},
    {key:'bloomThreshold',   label:'BLOOM THRESHOLD',     type:'slider', min:0.4, max:1.6, step:0.02, live:true, unit:'×',
      help:'Luminance cutoff for bloom. Higher = tighter, sun-only bloom.'},
    {key:'bloomSky',         label:'BLOOM THE SKY TOO',   type:'toggle', live:true,
      help:'Off by default (recommended) — keeps the sky/sun clean. On = creative.'},
    {key:'godRays',          label:'GOD RAYS',            type:'toggle', live:true,
      help:'Volumetric light shafts from the HDR sun, occluded by terrain and worms.'},
    {key:'godRayStrength',   label:'GOD RAY STRENGTH',    type:'slider', min:0, max:1.2, step:0.02, live:true, unit:'×',
      help:'Intensity of the light shafts. 0.4 is the cinematic default.'},
    {key:'caAmount',         label:'CHROMATIC ABERRATION', type:'slider', min:0, max:6, step:0.1, live:true, unit:'px',
      help:'Radial red/blue lens split toward the frame corners. 0 = perfect lens.'},
    {key:'filmGrain',        label:'FILM GRAIN',          type:'slider', min:0, max:0.08, step:0.002, live:true, unit:'×',
      help:'Animated sensor grain, strongest in the shadows.'},
    {key:'heatShimmer',      label:'HEAT SHIMMER',        type:'slider', min:0, max:2, step:0.05, live:true, unit:'×',
      help:'Screen-space refraction band above the horizon — hot desert air.'},
    {key:'dustMotes',        label:'NEAR DUST MOTES',     type:'toggle', live:true,
      help:'Glittering sand motes drifting around the camera, back-lit by the sun.'},
    {key:'toneExposure',     label:'FILM EXPOSURE',       type:'slider', min:0.6, max:1.6, step:0.02, live:true, unit:'×',
      help:'Exposure feeding the filmic (ACES) tone map. The remastered grade lives around 1.1.'},
    {key:'gradeSat',         label:'COLOR SATURATION',    type:'slider', min:0.4, max:1.3, step:0.01, live:true, unit:'×',
      help:'Post-grade saturation. Below 1.0 calms the desert orange; 1.0 = untouched.'},
    {key:'gradeVignette',    label:'LENS VIGNETTE',       type:'slider', min:0, max:0.8, step:0.02, live:true, unit:'×',
      help:'Soft darkening toward the frame corners. Sits on top of the screen-space vignette.'},
  ];

  const CAM_SETTINGS_DEF = [
    {key:'fovBase',    label:'CAMERA FOV',          type:'slider', min:0, max:110, step:1, unit:'°',
      help:'0 = use each camera mode\'s default. 50-110 = manual override.'},
    {key:'fovRush',    label:'SPEED FOV RUSH',      type:'slider', min:0, max:2.0, step:0.05, unit:'×',
      help:'Multiplies the FOV widening at speed. 0 = no rush.'},
    {key:'distance',   label:'FOLLOW DISTANCE',     type:'slider', min:0.6, max:1.6, step:0.05, unit:'×',
      help:'How far the camera sits behind the jeep.'},
    {key:'height',     label:'FOLLOW HEIGHT',       type:'slider', min:0.6, max:1.6, step:0.05, unit:'×',
      help:'How high the camera rides above the jeep.'},
    {key:'shake',      label:'SHAKE AMPLITUDE',     type:'slider', min:0, max:2.0, step:0.05, unit:'×',
      help:'Camera shake on impacts. 0 = none.'},
    {key:'roll',       label:'CORNER ROLL',         type:'slider', min:0, max:2.0, step:0.05, unit:'×',
      help:'How much the camera banks into corners.'},
    {key:'smoothing',  label:'RIG SMOOTHING',       type:'slider', min:0.5, max:2.0, step:0.05, unit:'×',
      help:'Spring stiffness of the follow rig. Higher = snappier.'},
    {key:'lookBack',   label:'LOOK-BACK SPEED',     type:'slider', min:0.3, max:2.5, step:0.05, unit:'×',
      help:'How fast the Q-look-back transition happens.'},
  ];

  const UIP_SETTINGS_DEF = [
    {key:'enabled',   label:'UI PARTICLES',         type:'toggle',
      help:'Sand puffs on button clicks, trickles on slider drags.'},
    {key:'intensity', label:'PARTICLE INTENSITY',   type:'slider', min:0, max:1.5, step:0.05, unit:'×',
      help:'Count + size multiplier for UI sand particles.'},
    {key:'onButtons', label:'PUFF ON BUTTON CLICKS', type:'toggle',
      help:'Quick radial sand burst when a button is pressed.'},
    {key:'onSliders', label:'TRICKLE ON SLIDER DRAG', type:'toggle',
      help:'Fine sand stream while dragging a slider thumb.'},
    {key:'onTabs',    label:'SCATTER ON TAB SWITCH', type:'toggle',
      help:'Sideways sand spray when switching tabs.'},
  ];

  /* =================================================================
     PANEL DOM — built once on boot, kept hidden until opened.
     ================================================================= */
  function _buildPanel(){
    panelEl = document.createElement('div');
    panelEl.id = 'setPanel';
    panelEl.className = 'set-panel hidden';
    panelEl.setAttribute('role','dialog');
    panelEl.setAttribute('aria-modal','true');
    panelEl.setAttribute('aria-label','Settings');
    panelEl.innerHTML = `
      <div class="set-card">
        <div class="set-head">
          <div class="set-title">
            <span class="set-kicker">SHAI-HULUD · SETTINGS</span>
            <h2>CONFIGURE THE RUN</h2>
          </div>
          <button class="set-close" type="button" aria-label="Close settings">✕<span>CLOSE</span></button>
        </div>
        <div class="set-tabs" role="tablist">
          ${TABS.map(t=>`<button class="set-tab" role="tab" data-tab="${t.id}" aria-selected="false">${t.label}</button>`).join('')}
        </div>
        <div class="set-body">
          <div class="set-pane" data-pane="graphics"></div>
          <div class="set-pane" data-pane="camera"></div>
          <div class="set-pane" data-pane="ui"></div>
          <div class="set-pane" data-pane="howto"></div>
        </div>
        <div class="set-foot">
          <button class="set-reset" type="button">RESET TAB TO PRESET</button>
          <span class="set-hint">CHANGES TO TEXTURES · SHADOWS · VIEW DISTANCE NEED A RELOAD</span>
          <button class="set-apply" type="button">APPLY &amp; RELOAD</button>
        </div>
      </div>`;
    document.body.appendChild(panelEl);

    /* tab buttons */
    panelEl.querySelectorAll('.set-tab').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.dataset.tab;
        _switchTab(id);
        /* scatter particles on tab switch */
        if(window.uiParticles){
          const r = btn.getBoundingClientRect();
          const dirX = id === 'graphics' ? -1 : (id === 'ui' ? 1 : 0);
          window.uiParticles.scatter(r.left + r.width/2, r.top + r.height/2, dirX);
        }
      });
    });
    /* close button */
    panelEl.querySelector('.set-close').addEventListener('click', closeSettings);
    /* apply + reload */
    panelEl.querySelector('.set-apply').addEventListener('click', ()=>{
      /* if there are no pending reload-needed changes, just close */
      if(!_needsReload()){ closeSettings(); return; }
      if(window.uiParticles){
        const r = panelEl.querySelector('.set-apply').getBoundingClientRect();
        window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 22);
      }
      setTimeout(()=>location.reload(), 220);
    });
    /* reset tab to preset */
    panelEl.querySelector('.set-reset').addEventListener('click', ()=>{
      _resetTabToPreset();
      if(window.uiParticles){
        const r = panelEl.querySelector('.set-reset').getBoundingClientRect();
        window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 16);
      }
    });

    /* close on ESC + click outside */
    addEventListener('keydown', e=>{
      if(!open) return;
      if(e.code === 'Escape'){ e.preventDefault(); closeSettings(); }
    });
    panelEl.addEventListener('pointerdown', e=>{
      if(e.target === panelEl) closeSettings();
    });

    /* populate panes */
    _populateGraphicsPane();
    _populateCameraPane();
    _populateUIPane();
    _populateHowToPane();

    /* default tab */
    _switchTab('graphics', true);
  }

  /* =================================================================
     GRAPHICS PANE — preset row + per-setting controls
     ================================================================= */
  function _populateGraphicsPane(){
    const pane = panelEl.querySelector('[data-pane="graphics"]');
    /* preset row (re-uses the same data as the title-screen selector) */
    const presetsHTML = `
      <div class="set-section">
        <div class="set-section-lbl">PRESET</div>
        <div class="set-presets">
          ${Object.keys(GRAPHICS_PRESETS).map(m=>`
            <button class="set-preset" data-mode="${m}" type="button">
              <span class="sp-name">${GRAPHICS_PRESETS[m].label}</span>
              <span class="sp-tag">${GRAPHICS_PRESETS[m].tag}</span>
            </button>`).join('')}
        </div>
        <div class="set-section-help">Presets are starting points — every setting below can still be tweaked individually.</div>
      </div>`;
    const settingsHTML = `
      <div class="set-section">
        <div class="set-section-lbl">DETAILS</div>
        <div class="set-grid">
          ${GFX_SETTINGS.map(def=>_renderSettingRow(def,'graphics')).join('')}
        </div>
      </div>`;
    pane.innerHTML = presetsHTML + settingsHTML;

    /* preset click: switch + reload (presets change everything).
       Switching presets CLEARS all overrides (see setGraphicsMode in
       00-graphics.js) so the new mode applies completely clean. */
    pane.querySelectorAll('.set-preset').forEach(btn=>{
      if(btn.dataset.mode === GRAPHICS_MODE) btn.classList.add('active');
      btn.addEventListener('click', ()=>{
        if(btn.classList.contains('confirm')){
          setGraphicsMode(btn.dataset.mode);  // writes localStorage + reloads
          return;
        }
        /* first click on any preset (including the active one, which
           clears overrides back to the pure preset) asks for confirm */
        pane.querySelectorAll('.set-preset').forEach(b=>b.classList.remove('confirm'));
        btn.classList.add('confirm');
        clearTimeout(_populateGraphicsPane._t);
        _populateGraphicsPane._t = setTimeout(()=>btn.classList.remove('confirm'), 3000);
      });
    });

    /* wire each setting row */
    GFX_SETTINGS.forEach(def=>_wireSettingRow(pane, def, 'graphics'));
  }

  function _renderSettingRow(def, kind){
    const live = def.live;
    const v = _getSettingValue(kind || 'graphics', def.key);
    if(def.type === 'toggle'){
      const on = !!v;
      return `
        <div class="set-row" data-key="${def.key}">
          <div class="set-row-lbl">
            <span class="set-row-name">${def.label}</span>
            <span class="set-row-help">${def.help||''}</span>
          </div>
          <button class="set-toggle ${on?'on':''}" type="button" data-toggle="${def.key}" role="switch" aria-checked="${on}">
            <span class="tg-knob"></span>
            <span class="tg-off">OFF</span><span class="tg-on">ON</span>
            ${live?'<span class="set-row-tag live">LIVE</span>':'<span class="set-row-tag">RELOAD</span>'}
          </button>
        </div>`;
    }
    if(def.type === 'select'){
      return `
        <div class="set-row" data-key="${def.key}">
          <div class="set-row-lbl">
            <span class="set-row-name">${def.label}</span>
            <span class="set-row-help">${def.help||''}</span>
          </div>
          <div class="set-select-wrap">
            <select class="set-select" data-select="${def.key}" aria-label="${def.label}">
              ${(def.options||[]).map(o=>`<option value="${o.value}" ${o.value===v?'selected':''}>${o.label}</option>`).join('')}
            </select>
            ${live?'<span class="set-row-tag live">LIVE</span>':'<span class="set-row-tag">RELOAD</span>'}
          </div>
        </div>`;
    }
    if(def.type === 'slider'){
      const pct = ((v - def.min) / (def.max - def.min)) * 100;
      return `
        <div class="set-row" data-key="${def.key}">
          <div class="set-row-lbl">
            <span class="set-row-name">${def.label}</span>
            <span class="set-row-help">${def.help||''}</span>
          </div>
          <div class="set-slider-wrap">
            <input class="set-slider" type="range" min="${def.min}" max="${def.max}" step="${def.step}" value="${v}" data-slider="${def.key}" aria-label="${def.label}">
            <div class="set-slider-track"><i style="width:${pct}%"></i></div>
            <span class="set-slider-val">${_formatSliderValue(v, def)}</span>
            ${live?'<span class="set-row-tag live">LIVE</span>':'<span class="set-row-tag">RELOAD</span>'}
          </div>
        </div>`;
    }
    return '';
  }
  function _formatSliderValue(v, def){
    if(def.unit === 'px') return v + 'px';
    if(def.unit === '×')  return (Math.round(v*100)/100) + '×';
    if(def.unit === '°')  return Math.round(v) + '°';
    if(def.unit === 'm')  return Math.round(v) + 'm';
    if(def.unit === 'chunks') return v + ' chunks';
    if(def.unit === 'tris') return Math.round(v).toLocaleString() + ' tris';
    return String(v);
  }

  function _getGfxValue(key){
    if(key in GRAPHICS_OVERRIDES) return GRAPHICS_OVERRIDES[key];
    return GRAPHICS_PRESETS[GRAPHICS_MODE][key];
  }
  function _setGfxValue(def, value){
    /* store as override (so it survives preset switches + reload) */
    setGraphicsOverride(def.key, value);
    /* if the value matches the preset default, drop the override so the
       panel reads "clean" — keeps the override list lean. */
    const presetDefault = GRAPHICS_PRESETS[GRAPHICS_MODE][def.key];
    if(presetDefault === value){
      delete GRAPHICS_OVERRIDES[def.key];
      try{ localStorage.setItem('etd-graphics-overrides', JSON.stringify(GRAPHICS_OVERRIDES)); }catch(e){}
    }
    if(!def.live){
      _needsReload(true);
    }
  }

  function _wireSettingRow(pane, def, kind){
    /* kind: 'graphics' | 'camera' | 'ui' */
    if(def.type === 'toggle'){
      const btn = pane.querySelector(`[data-toggle="${def.key}"]`);
      if(!btn) return;
      btn.addEventListener('click', ()=>{
        const cur = _getSettingValue(kind, def.key);
        const next = !cur;
        _setSettingValue(kind, def, next);
        btn.classList.toggle('on', next);
        btn.setAttribute('aria-checked', next);
        if(window.uiParticles){
          const r = btn.getBoundingClientRect();
          window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 10);
        }
      });
    }else if(def.type === 'select'){
      const sel = pane.querySelector(`[data-select="${def.key}"]`);
      if(!sel) return;
      sel.addEventListener('change', ()=>{
        _setSettingValue(kind, def, sel.value);
        if(window.uiParticles){
          const r = sel.getBoundingClientRect();
          window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 8);
        }
      });
    }else if(def.type === 'slider'){
      const input = pane.querySelector(`[data-slider="${def.key}"]`);
      const track = input ? input.nextElementSibling : null;
      const valEl = track ? track.nextElementSibling : null;
      if(!input) return;
      input.addEventListener('input', ()=>{
        const v = +input.value;
        _setSettingValue(kind, def, v);
        const pct = ((v - def.min) / (def.max - def.min)) * 100;
        if(track) track.querySelector('i').style.width = pct + '%';
        if(valEl) valEl.textContent = _formatSliderValue(v, def);
      });
    }
  }

  function _getSettingValue(kind, key){
    if(kind === 'graphics') return _getGfxValue(key);
    if(kind === 'camera')   return CAMERA_SETTINGS[key];
    if(kind === 'ui')       return UI_PARTICLE_SETTINGS[key];
  }
  function _setSettingValue(kind, def, value){
    if(kind === 'graphics') _setGfxValue(def, value);
    else if(kind === 'camera')  setCameraSetting(def.key, value);
    else if(kind === 'ui')      setUIParticleSetting(def.key, value);
  }

  /* =================================================================
     CAMERA PANE — live-tunable camera multipliers
     ================================================================= */
  function _populateCameraPane(){
    const pane = panelEl.querySelector('[data-pane="camera"]');
    /* read-out showing the current camera mode */
    const modeName = (typeof CAM_MODES !== 'undefined' && CAM_MODES[camIndex])
      ? CAM_MODES[camIndex].label : '—';
    const camInfo = `
      <div class="set-section">
        <div class="set-section-lbl">ACTIVE CAMERA</div>
        <div class="set-cam-info">
          <span class="set-cam-name">${modeName}</span>
          <span class="set-cam-cycle">PRESS V IN-GAME TO CYCLE · 1-8 DIRECT</span>
        </div>
      </div>`;
    const settingsHTML = `
      <div class="set-section">
        <div class="set-section-lbl">RIG</div>
        <div class="set-grid">
          ${CAM_SETTINGS_DEF.map(def=>{
            /* render using the same row template, but tag everything LIVE */
            const def2 = Object.assign({live:true}, def);
            return _renderSettingRow(def2, 'camera');
          }).join('')}
        </div>
        <div class="set-section-help">Camera settings apply LIVE — drive around while you tweak.</div>
        <div class="set-cam-reset-row">
          <button class="set-cam-reset" type="button" data-puff>RESET CAMERA TO DEFAULTS</button>
          <span class="set-cam-saved">SAVED AUTOMATICALLY</span>
        </div>
      </div>`;
    pane.innerHTML = camInfo + settingsHTML;
    CAM_SETTINGS_DEF.forEach(def=>_wireSettingRow(pane, Object.assign({live:true}, def), 'camera'));
    /* wire the dedicated camera reset button — clears localStorage + reloads
       the pane with the defaults. Doesn't touch graphics settings. */
    const resetBtn = pane.querySelector('.set-cam-reset');
    if(resetBtn){
      resetBtn.addEventListener('click', ()=>{
        Object.assign(CAMERA_SETTINGS, CAMERA_SETTINGS_DEFAULTS);
        try{ localStorage.setItem('etd-camera-settings', JSON.stringify(CAMERA_SETTINGS)); }catch(e){}
        _populateCameraPane();
        if(window.uiParticles){
          const r = resetBtn.getBoundingClientRect();
          window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 18);
        }
      });
    }
  }

  /* =================================================================
     UI FX PANE — DOM sand particle toggles
     ================================================================= */
  function _populateUIPane(){
    const pane = panelEl.querySelector('[data-pane="ui"]');
    const settingsHTML = `
      <div class="set-section">
        <div class="set-section-lbl">UI SAND PARTICLES</div>
        <div class="set-grid">
          ${UIP_SETTINGS_DEF.map(def=>{
            const def2 = Object.assign({live:true}, def);
            return _renderSettingRow(def2, 'ui');
          }).join('')}
        </div>
        <div class="set-section-help">Tiny sand puffs on every UI interaction — try clicking a button right now to test.</div>
      </div>`;
    pane.innerHTML = settingsHTML;
    UIP_SETTINGS_DEF.forEach(def=>_wireSettingRow(pane, Object.assign({live:true}, def), 'ui'));
  }

  /* =================================================================
     HOW TO PLAY PANE — controls reference + tutorial text
     =================================================================
     The title screen used to show this stuff; the menu is cleaner
     without it, so it lives here now. The controls grid mirrors the
     old title-right column. The tutorial block is a fuller version
     of the title-screen fine print — expanded to cover the thumper
     + digger loop, the spice chain, the airborne cinema mode, and
     the alpha worm, all of which the title screen never had room
     to explain. */
  const HOWTO_CONTROLS = [
    {key:'W A S D', desc:'DRIVE — accelerate, brake, steer'},
    {key:'SHIFT',   desc:'OVERDRIVE — burn fuel faster for a top-speed rush'},
    {key:'SPACE',   desc:'HANDBRAKE — break your driving rhythm to fool the worm'},
    {key:'Q',       desc:'LOOK BACK — glance over your shoulder at the dust trail'},
    {key:'E',       desc:'TAP to DROP a thumper · HOLD + MOUSE to aim and throw it'},
    {key:'F',       desc:'DIGGER — deploy a longer-range rhythm lure (uses a slot)'},
    {key:'G',       desc:'BLAST — detonate a carried explosive digger (one per run)'},
    {key:'R',       desc:'CINEMATIC SLOW-MO — hold while AIRBORNE for a brief bullet-time'},
    {key:'V',       desc:'CYCLE CAMERA — chase · hood · bumper · cockpit · drone · free'},
    {key:'1-8',     desc:'DIRECT CAMERA — DRONE · CHASE · HOOD · BUMPER · COCKPIT · DRIFT · FREE · REAR'},
    {key:'P',       desc:'OPEN SETTINGS — anytime, even mid-run'},
    {key:'ESC',     desc:'PAUSE THE RUN — or close any open overlay'},
  ];
  const HOWTO_TIPS = [
    {h:'THE WORM LISTENS', t:'Speed and spice draw the worm. Stillness starves it. Drive without rhythm — vary your speed, take breaks, never let the dunes feel a steady beat for too long.'},
    {h:'HULL IS PERMANENT', t:'Every bite leaves a scar. There is no repair in the deep desert — slow down before you risk it. A few good decisions early mean hours of survival later.'},
    {h:'THUMPERS', t:'Tap E to drop a thumper where you stand — it pounds the sand and pulls the worm away from you. Hold E and move the mouse to aim a long throw: the further it lands, the more time you buy. You carry up to three; the dunes will return what they take.'},
    {h:'DIGGER & BLAST', t:'F drops a longer-lasting digger lure — useful for a longer distraction. Carry an explosive digger and G detonates it under a worm for an outright kill. Salvage explosive diggers from the deep desert.'},
    {h:'SPICE CHAIN', t:'Collect spice for a speed boost. Chain a second spice while the boost burns for +20 km/h, a third for +15 km/h, and the boost refreshes. The longer you chain, the faster you fly — and the louder your engine gets.'},
    {h:'SALVAGE', t:'Lost thumpers and abandoned diggers sit out in the dunes. Drive over them to refill your rack — every pickup is one more lifeline against the worm.'},
    {h:'CINEMA MODE', t:'Crest a dune at speed and you go airborne. Hold R while in the air for a brief slow-motion — perfect for lining up a thumper throw or just admiring the wreck. The meter recharges while you are on the ground.'},
    {h:'THE ALPHA', t:'Past seven minutes, the desert itself may rise. The Alpha worm is not a monster — it is weather. When the horizon heaves, turn away and do not look back. Survive it and the dunes leave salvage in its wake.'},
    {h:'CAMERAS', t:'V cycles through eight cameras. 1–8 pick one directly. Find the rig that matches how you drive — cockpit for tension, drone for scouting, drift for chaos.'},
    {h:'SETTINGS', t:'P opens this panel anytime — even mid-run. Bloom, FOV and camera rig are all LIVE-tunable; texture, shadow and view-distance changes reload the page.'},
  ];
  function _populateHowToPane(){
    const pane = panelEl.querySelector('[data-pane="howto"]');
    const controlsHTML = `
      <div class="howto-section">
        <div class="howto-section-lbl">CONTROLS</div>
        <div class="howto-ctrls">
          ${HOWTO_CONTROLS.map(c=>`<div><b>${c.key}</b><span>${c.desc}</span></div>`).join('')}
        </div>
      </div>`;
    const tipsHTML = `
      <div class="howto-section">
        <div class="howto-section-lbl">THE DESERT</div>
        ${HOWTO_TIPS.map(t=>`<div class="howto-tip"><strong>${t.h}</strong><em>·</em> ${t.t}</div>`).join('')}
      </div>`;
    pane.innerHTML = controlsHTML + tipsHTML;
  }

  /* =================================================================
     TAB SWITCHING
     ================================================================= */
  function _switchTab(id, silent){
    currentTab = id;
    panelEl.querySelectorAll('.set-tab').forEach(b=>{
      const on = b.dataset.tab === id;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on);
    });
    panelEl.querySelectorAll('.set-pane').forEach(p=>{
      p.classList.toggle('active', p.dataset.pane === id);
    });
    if(!silent && window.uiParticles){
      /* scatter when switching tabs */
      const r = panelEl.querySelector(`.set-tab[data-tab="${id}"]`).getBoundingClientRect();
      const dirX = id === 'graphics' ? -1 : (id === 'ui' ? 1 : 0);
      window.uiParticles.scatter(r.left + r.width/2, r.top + r.height/2, dirX);
    }
  }

  /* =================================================================
     RESET TAB TO PRESET
     ================================================================= */
  function _resetTabToPreset(){
    if(currentTab === 'graphics'){
      clearGraphicsOverrides();
      /* re-populate the pane so the controls reflect preset values */
      _populateGraphicsPane();
      /* tag for reload because texture/shadow settings may have changed */
      _needsReload(true);
    }else if(currentTab === 'camera'){
      Object.assign(CAMERA_SETTINGS, CAMERA_SETTINGS_DEFAULTS);
      try{ localStorage.setItem('etd-camera-settings', JSON.stringify(CAMERA_SETTINGS)); }catch(e){}
      _populateCameraPane();
    }else if(currentTab === 'ui'){
      Object.assign(UI_PARTICLE_SETTINGS, UI_PARTICLE_DEFAULTS);
      try{ localStorage.setItem('etd-ui-particles', JSON.stringify(UI_PARTICLE_SETTINGS)); }catch(e){}
      _populateUIPane();
    }else if(currentTab === 'howto'){
      /* nothing to reset on the How to play tab — it is read-only */
    }
  }

  /* =================================================================
     RELOAD TRACKING — show "needs reload" hint when any reload-needed
     setting has been changed.
     ================================================================= */
  let _reloadNeeded = false;
  function _needsReload(set){
    if(set) _reloadNeeded = true;
    const applyBtn = panelEl ? panelEl.querySelector('.set-apply') : null;
    if(applyBtn){
      applyBtn.classList.toggle('pending', _reloadNeeded);
      applyBtn.textContent = _reloadNeeded ? 'APPLY & RELOAD' : 'DONE';
    }
    return _reloadNeeded;
  }
  /* called from 00-graphics.js when a non-live override is set */
  window._scheduleGraphicsReload = function(){
    _needsReload(true);
  };

  /* =================================================================
     OPEN / CLOSE
     ================================================================= */
  function openSettings(){
    if(open) return;
    playUiOpenCloseSfx();
    if(!panelEl) _buildPanel();
    open = true;
    panelEl.classList.remove('hidden');
    /* pause the game loop while the panel is open (16-main.js checks
       this flag — see that file) */
    window.settingsOpen = true;
    /* if we're mid-game, blur the active element so keyboard input
       doesn't drive the jeep */
    if(document.activeElement && document.activeElement.blur) document.activeElement.blur();
    /* puff on the panel itself for feedback */
    if(window.uiParticles){
      const r = panelEl.querySelector('.set-card').getBoundingClientRect();
      window.uiParticles.puff(r.left + r.width/2, r.top + 30, 18);
    }
  }
  function closeSettings(){
    if(!open) return;
    open = false;
    playUiOpenCloseSfx();
    panelEl.classList.add('hidden');
    window.settingsOpen = false;
    if(window.uiParticles){
      const r = panelEl.querySelector('.set-close').getBoundingClientRect();
      window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 10);
    }
  }
  window.openSettings = openSettings;
  window.closeSettings = closeSettings;

  /* =================================================================
     WIRE THE SETTINGS BUTTONS ON THE TITLE + GAME-OVER SCREENS
     ================================================================= */
  function _wireOpenButtons(){
    document.querySelectorAll('[data-open-settings]').forEach(btn=>{
      btn.addEventListener('click', openSettings);
    });
    /* also expose a global key (P) to open it in-game */
    addEventListener('keydown', e=>{
      if(open) return;
      if(e.code === 'KeyP' && (gameState === 'play' || gameState === 'title')){
        /* P is the in-game settings hotkey */
        e.preventDefault();
        openSettings();
      }
    });
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', _wireOpenButtons);
  }else{
    _wireOpenButtons();
  }
})();
