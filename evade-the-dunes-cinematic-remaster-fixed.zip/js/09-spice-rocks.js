/* Spice patches and rocks */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- spice / rocks ---------------- */
const PATCH_N=11, GRAINS=46;           // fewer patches out at once (was 16)
const spiceMesh=new THREE.InstancedMesh(
  new THREE.OctahedronGeometry(0.5),
  new THREE.MeshStandardMaterial({color:0xcf7a2e, emissive:0x8a3c0c, emissiveIntensity:0.5, roughness:0.6, flatShading:true}),
  PATCH_N*GRAINS
);
spiceMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
spiceMesh.frustumCulled=false;
scene.add(spiceMesh);
const patches=[];
const _pm=new THREE.Matrix4(), _pq=new THREE.Quaternion(), _ps=new THREE.Vector3(), _pe=new THREE.Euler(), _pc=new THREE.Color();

/* ---- pickup animation ----
   When a patch is harvested its grains don't just vanish: they tremble loose, levitate,
   swirl around the patch and then get pulled into the vehicle one after another
   (staggered), shrinking as they arrive. The dust plume swells and drifts up while it
   fades, a soft glow flares around the player, and each grain that lands throws a spark. */
const SPICE_PULL=0.72;                 // seconds each grain takes to fly into the vehicle
const _spA=new THREE.Vector3();        // scratch vector for the pickup animation
const spiceGlowTex=(()=>{              // small radial-gradient texture for the pickup flare
  const c=document.createElement('canvas'); c.width=c.height=64;
  const g=c.getContext('2d'), gr=g.createRadialGradient(32,32,0,32,32,32);
  gr.addColorStop(0,'rgba(255,225,160,1)');
  gr.addColorStop(0.35,'rgba(255,170,70,0.55)');
  gr.addColorStop(1,'rgba(255,140,40,0)');
  g.fillStyle=gr; g.fillRect(0,0,64,64);
  return new THREE.CanvasTexture(c);
})();
const spiceFlash=new THREE.Sprite(new THREE.SpriteMaterial({
  map:spiceGlowTex, color:0xffffff, transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending
}));
spiceFlash.visible=false; scene.add(spiceFlash);
let spiceFlashT=1;                     // 0..1 progress of the flare, 1 = idle

function smooth01(x){ x=Math.min(1,Math.max(0,x)); return x*x*(3-2*x); }

function startCollect(p){
  p.collecting=true; p.collectT=0; p.gdone.fill(0);
  p.sprite.visible=true;               // plume stays up while the grains are pulled away
  spiceFlashT=0;
}

function animateCollect(p,dt){
  p.collectT+=dt;
  const tx=player.pos.x, tz=player.pos.z;
  const ty=(Number.isFinite(player.pos.y)?player.pos.y:terrainH(tx,tz))+1.2;   // pull-in target: just above the vehicle
  let remaining=0;
  for(let g=0;g<GRAINS;g++){
    if(p.gdone[g]) continue;
    const lt=(p.collectT-p.gdelay[g])/SPICE_PULL;
    if(lt>=1){
      /* arrived: hide it and flick a tiny spark off the vehicle */
      p.gdone[g]=1;
      _pm.makeScale(0.0001,0.0001,0.0001);
      spiceMesh.setMatrixAt(p.idx0+g,_pm);
      if((g&3)===0){
        const a=Math.random()*Math.PI*2;
        spawnP(tx+(Math.random()-0.5)*1.6, ty, tz+(Math.random()-0.5)*1.6,
          Math.cos(a)*2.2, 1.5+Math.random()*2, Math.sin(a)*2.2,
          0.4, 0.6, 1,0.8,0.45, 1.2, 1, PT_SPARK);
      }
      continue;
    }
    remaining++;
    const t=Math.max(lt,0), i3=g*3;
    const ox=p.gpos[i3]-p.x, oz=p.gpos[i3+2]-p.z;
    /* 1) levitate — ease up off the ground with a little wobble */
    const lift=Math.sin(Math.min(t/0.45,1)*Math.PI*0.5)*p.glift[g] + Math.sin(elapsed*9+g)*0.12*Math.min(t*4,1);
    /* 2) swirl around the patch centre, spreading out slightly */
    const th=t*(3.5+p.gspin[g]), c=Math.cos(th), s=Math.sin(th);
    const rad=1+0.45*Math.min(t/0.5,1);
    const px=p.x+(ox*c-oz*s)*rad, pz=p.z+(ox*s+oz*c)*rad, py=p.gpos[i3+1]+lift;
    /* 3) suction — late, accelerating homing onto the (moving) vehicle */
    const k=Math.pow(Math.max(0,(t-0.25)/0.75),2.2);
    _spA.set(px+(tx-px)*k, py+(ty-py)*k, pz+(tz-pz)*k);
    /* grains swell a touch when they come loose, then shrink away as they arrive */
    const sc=p.gscl[g]*(1+0.3*Math.min(t*3,1))*(1-0.97*smooth01((t-0.65)/0.35));
    _pe.set(p.grot[i3]+t*p.gspin[g]*2, p.grot[i3+1]+t*p.gspin[g]*3, p.grot[i3+2]);
    _pq.setFromEuler(_pe);
    _pm.compose(_spA, _pq, _ps.set(sc,sc,sc));
    spiceMesh.setMatrixAt(p.idx0+g,_pm);
  }
  spiceMesh.instanceMatrix.needsUpdate=true;

  /* plume: puffs up, rises and fades out */
  const e=Math.min(p.collectT/1.0,1);
  p.sprite.scale.set(8+9*e, 26+16*e, 1);
  p.sprite.position.y=p.baseY+e*9;
  p.sprite.material.opacity=0.38*Math.pow(1-e,1.5);

  if(remaining===0){
    p.collecting=false; p.sprite.visible=false;
    p.sprite.scale.set(8,26,1);
  }
}

function updateSpiceFlash(dt){
  if(spiceFlashT>=1){ spiceFlash.visible=false; return; }
  spiceFlashT=Math.min(1,spiceFlashT+dt/0.5);
  const f=spiceFlashT;
  spiceFlash.visible=true;
  spiceFlash.position.set(player.pos.x,
    (Number.isFinite(player.pos.y)?player.pos.y:terrainH(player.pos.x,player.pos.z))+1.4, player.pos.z);
  const sz=5+10*Math.sqrt(f);
  spiceFlash.scale.set(sz,sz,1);
  spiceFlash.material.opacity=0.75*Math.pow(1-f,2);
}

function placePatch(p){
  const a=Math.random()*Math.PI*2, d=180+Math.random()*300;
  p.x=player.pos.x+Math.cos(a)*d; p.z=player.pos.z+Math.sin(a)*d;
  p.alive=true; p.collecting=false; p.baseY=terrainH(p.x,p.z)+15;
  p.sprite.visible=true;
  p.sprite.scale.set(8,26,1);
  p.sprite.position.set(p.x, p.baseY, p.z);
  for(let g=0;g<GRAINS;g++){
    const r=Math.random()*6.5, ang=Math.random()*Math.PI*2;
    const gx=p.x+Math.cos(ang)*r, gz=p.z+Math.sin(ang)*r;
    const gy=terrainH(gx,gz)+0.25;
    _pe.set(Math.random()*3,Math.random()*3,Math.random()*3);
    _pq.setFromEuler(_pe);
    const s=0.5+Math.random()*0.9; _ps.set(s,s,s);
    _pm.compose(_v1.set(gx, gy, gz), _pq, _ps);
    spiceMesh.setMatrixAt(p.idx0+g,_pm);
    _pc.setHex(0xb85f24).lerp(new THREE.Color(0xe09a4a), Math.random());
    spiceMesh.setColorAt(p.idx0+g,_pc);
    /* remember each grain's resting pose + per-grain random values for the pickup animation */
    const i3=g*3;
    p.gpos[i3]=gx; p.gpos[i3+1]=gy; p.gpos[i3+2]=gz;
    p.grot[i3]=_pe.x; p.grot[i3+1]=_pe.y; p.grot[i3+2]=_pe.z;
    p.gscl[g]=s;
    p.gdelay[g]=Math.random()*0.22+(r/6.5)*0.12;      // staggered start (0 – 0.34 s)
    p.glift[g]=1.4+Math.random()*2.6;                 // how high it levitates before the pull
    p.gspin[g]=(Math.random()<0.5?-1:1)*(1+Math.random()*3);
  }
  spiceMesh.instanceMatrix.needsUpdate=true;
  if(spiceMesh.instanceColor) spiceMesh.instanceColor.needsUpdate=true;
}
for(let i=0;i<PATCH_N;i++){
  const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:plumeTex, color:0xd9a468, transparent:true, opacity:0.2, depthWrite:false}));
  sprite.scale.set(8,26,1); scene.add(sprite);
  const p={idx0:i*GRAINS, x:0, z:0, alive:false, respawnT:0, sprite, baseY:0, ph:Math.random()*9,
    collecting:false, collectT:0,
    gpos:new Float32Array(GRAINS*3), grot:new Float32Array(GRAINS*3), gscl:new Float32Array(GRAINS),
    gdelay:new Float32Array(GRAINS), glift:new Float32Array(GRAINS), gspin:new Float32Array(GRAINS),
    gdone:new Uint8Array(GRAINS)};
  patches.push(p);
  placePatch(p);
}
function updateSpice(dt){
  updateSpiceFlash(dt);
  for(const p of patches){
    if(p.collecting){ animateCollect(p,dt); continue; }
    if(!p.alive){
      p.respawnT-=dt;
      if(p.respawnT<=0) placePatch(p);
      continue;
    }
    p.sprite.position.y=p.baseY+Math.sin(elapsed*0.6+p.ph)*1.5;
    p.sprite.material.opacity=0.15+0.07*Math.sin(elapsed*2.1+p.ph);
    if(horizDist(p,player.pos)>800){ placePatch(p); continue; }
    if(gameState==='play' && player.alive && horizDist(p,player.pos)<10){
      p.alive=false; p.respawnT=12+Math.random()*6;
      startCollect(p);                 // grains animate into the vehicle instead of popping out of existence
      spice++; player.hp=Math.min(100,player.hp+10);
      if(player.boost>0){
        /* chain: diminishing tiers — 2nd pickup +20 km/h, 3rd +15, capped at three pickups */
        if(player.boostChain<2){
          player.boostChain++;
          player.boost=3.4+player.boostChain*0.6;
          showMsg(player.boostChain===1?'SPICE CHAIN ×2 — +20 KM/H':'SPICE CHAIN ×3 — +15 KM/H',1.8);
        } else {
          player.boost=3.9;   /* at max chain: refresh the burn, no further tier bonus */
          showMsg('SPICE CHAIN ×3 — MAX · BURN REFRESHED',1.8);
        }
      } else {
        player.boost=3.2; player.boostChain=0;
        showMsg('SPICE HARVESTED — BOOST',1.6);
      }
      attention=Math.min(1,attention+0.18);
      playSfx('spiceCollect',0.72,0.96+Math.random()*0.08,0);
      pickupSfx();
      if(window.flashCollectVignette) window.flashCollectVignette();
      showMsg('SPICE HARVESTED — BOOST',1.6);
      for(let k=0;k<18;k++){
        const a=Math.random()*Math.PI*2;
        spawnP(p.x, terrainH(p.x,p.z)+0.6, p.z, Math.cos(a)*4, 3+Math.random()*4, Math.sin(a)*4,
          0.6, 0.8, 1,0.75,0.4, 1.5, 1, PT_SPARK);
      }
    }
  }
}
const rockN=30;
const rockMesh=new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1,0),
  new THREE.MeshStandardMaterial({color:0x6b5c4a, roughness:1, flatShading:true}), rockN);
rockMesh.castShadow=true; rockMesh.frustumCulled=false; scene.add(rockMesh);
const rockPos=[];
for(let i=0;i<rockN;i++){
  const a=Math.random()*Math.PI*2, d=60+Math.random()*440;
  const x=Math.cos(a)*d, z=Math.sin(a)*d;
  rockPos.push(new THREE.Vector3(x,0,z));
  const s=0.6+Math.random()*1.7;
  _pe.set(Math.random()*3,Math.random()*3,Math.random()*3); _pq.setFromEuler(_pe);
  _pm.compose(_v1.set(x, terrainH(x,z)+s*0.15, z), _pq, _ps.set(s, s*0.7, s));
  rockMesh.setMatrixAt(i,_pm);
}
function updateRocks(){
  let dirty=false;
  for(let i=0;i<rockN;i++){
    const rp=rockPos[i];
    if(horizDist(rp,player.pos)>650){
      const a=Math.random()*Math.PI*2, d=220+Math.random()*320;
      rp.set(player.pos.x+Math.cos(a)*d, 0, player.pos.z+Math.sin(a)*d);
      const s=0.6+Math.random()*1.7;
      _pe.set(Math.random()*3,Math.random()*3,Math.random()*3); _pq.setFromEuler(_pe);
      _pm.compose(_v1.set(rp.x, terrainH(rp.x,rp.z)+s*0.15, rp.z), _pq, _ps.set(s, s*0.7, s));
      rockMesh.setMatrixAt(i,_pm);
      dirty=true;
    }
  }
  if(dirty) rockMesh.instanceMatrix.needsUpdate=true;
}
