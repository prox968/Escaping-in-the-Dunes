/* Contact shadows and the buggy (vehicle model) */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- contact shadows ---------------- */
const carShadowGroup = new THREE.Group();
const carShadowMesh = new THREE.Mesh(
  new THREE.PlaneGeometry(3.6, 5.6),
  new THREE.MeshBasicMaterial({map:shadowTex, transparent:true, opacity:0.65, depthWrite:false})
);
carShadowMesh.rotation.x = -Math.PI/2;
carShadowGroup.add(carShadowMesh);
scene.add(carShadowGroup);

function updateCarShadow(){
  const gY = terrainH(player.pos.x, player.pos.z);
  carShadowGroup.position.set(player.pos.x, gY + 0.09, player.pos.z);
  /* tilt the shadow with the terrain slope under the wheels (clamped so it can
     never poke out from under the car on steep faces) */
  carShadowGroup.rotation.order='YXZ';
  carShadowGroup.rotation.y = player.heading;
  carShadowGroup.rotation.x = -Math.PI/2 + clamp(player.terrPitch||0, -0.45, 0.45)*0.8;
  carShadowGroup.rotation.z = -clamp(player.terrRoll||0, -0.45, 0.45)*0.8;
  const hAbove = Math.max(0, player.pos.y - gY);
  const vis = clamp(1 - hAbove*0.45, 0.28, 1);
  carShadowMesh.material.opacity = 0.65 * vis;
  const spd = Math.abs(player.speedF);
  carShadowMesh.scale.set(1 + spd*0.005, 1 + spd*0.012, 1);
}

/* ---------------- the buggy ----------------
   Surface-modeled side-by-side: the body is lofted hulls (superellipse
   cross-sections through stations, like a CAD loft), the fenders are thin
   shells swept around the wheel arches, wheels run crowned tires on beadlock
   rims with live brakes. External contract kept exactly: wheels[] fields,
   CAR dims, wear system, antenna + flag, everything the physics drives. */
const CAR = { restY:0.47, wheelR:0.47, track:1.84, wheelbase:2.95, maxComp:0.26, maxExt:0.24 };
const carRoot=new THREE.Group(), carBody=new THREE.Group();
carRoot.add(carBody); scene.add(carRoot);
const wheels=[];
let flagMesh=null, flagGeo=null, flagBase=null, antenna=null;
let wheelSpin=0;

{
  const texBody  = makeBodyTexture();
  const texBodyR = makeBodyRoughness();
  const tireT    = makeTireTextures();
  const texSide  = makeSidewallTexture();
  const texMetal = makeMetalTexture();
  const texSeat  = makeSeatTexture();
  const texMesh  = makeGrilleTexture();
  const texDecal = makeDecalTexture();
  const texDustRing = makeDustRingTexture();
  /* dark desert-beige body panels, dusty finish */
  const mBody = new THREE.MeshPhysicalMaterial({map:texBody, color:0xc7b088, roughnessMap:texBodyR, roughness:0.94,
      metalness:0.14, clearcoat:0.55, clearcoatRoughness:0.22, envMap:envTex, envMapIntensity:0.60});
  /* fenders are thin plastic shells (open underneath) — shaded on both faces */
  const mFender = mBody.clone(); mFender.side=THREE.DoubleSide;
  const mRed  = new THREE.MeshStandardMaterial({color:0xb3371f, roughness:0.46, metalness:0.34,
      envMap:envTex, envMapIntensity:0.9});
  /* the tubular poles: almost black */
  const mPipe = new THREE.MeshStandardMaterial({color:0x1b1814, roughness:0.52, metalness:0.5,
      envMap:envTex, envMapIntensity:0.7});
  const mDark = new THREE.MeshStandardMaterial({map:texMetal, color:0x655e50, roughness:0.78, metalness:0.28,
      envMap:envTex, envMapIntensity:0.55});
  const mBlack= new THREE.MeshStandardMaterial({map:texMetal, color:0x474239, roughness:0.72, metalness:0.28,
      envMap:envTex, envMapIntensity:0.5});
  const mChrome=new THREE.MeshStandardMaterial({color:0xd6d9dc, roughness:0.09, metalness:1.0,
      envMap:envTex, envMapIntensity:1.9});
  const mWheel= new THREE.MeshStandardMaterial({color:0x3f3b33, roughness:0.42, metalness:0.75,
      envMap:envTex, envMapIntensity:0.9});
  /* real transmissive glass: refracts the scene behind it (windscreen) */
  const mGlass= new THREE.MeshPhysicalMaterial({color:0xdfe9ee, roughness:0.05, metalness:0.0,
      transmission:0.88, thickness:0.6, ior:1.52, envMap:envTex, envMapIntensity:2.0});
  const mLED  = new THREE.MeshStandardMaterial({color:0xf5f2e8, emissive:0xffffff, emissiveIntensity:2.4,
      roughness:0.15, metalness:0.1, envMap:envTex, envMapIntensity:0.6});
  const mTail = new THREE.MeshStandardMaterial({color:0x2a0805, emissive:0xff2213, emissiveIntensity:1.9, roughness:0.35});
  const mScreen=new THREE.MeshStandardMaterial({color:0x06222c, emissive:0x1a7ea8, emissiveIntensity:0.7, roughness:0.3});
  const mTread= new THREE.MeshStandardMaterial({map:tireT.map, normalMap:tireT.normalMap,
      normalScale:new THREE.Vector2(1.2,1.2), roughness:0.95, metalness:0.0});
  const mSide = new THREE.MeshStandardMaterial({map:texSide, roughness:0.9, metalness:0.0});
  const mSeat = new THREE.MeshStandardMaterial({map:texSeat, color:0xd9bd92, roughness:0.92, metalness:0.05});
  const mMesh = new THREE.MeshStandardMaterial({map:texMesh, roughness:0.9, metalness:0.1});
  const mDisc = new THREE.MeshStandardMaterial({color:0x3c3c3f, roughness:0.32, metalness:0.92,
      envMap:envTex, envMapIntensity:1.0});
  const mFlag = new THREE.MeshStandardMaterial({color:0xff7a18, roughness:0.75, metalness:0.0, side:THREE.DoubleSide});
  const mDecal= new THREE.MeshStandardMaterial({map:texDecal, transparent:true, roughness:0.4, metalness:0.1,
      side:THREE.DoubleSide});

  const add=(mesh,parent)=>{ mesh.castShadow=true; (parent||carBody).add(mesh); return mesh; };
  const cyl=(r1,r2,h,seg,mat)=>new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,seg),mat);
  /* smooth beveled box: rounded-rectangle shape, extruded with a bevel */
  const RBgeo=(w,h,d,r=0.05,b=0.025,seg=2)=>{
    const hw=w/2-b, hh=h/2-b;
    r=Math.min(r,hw-0.001,hh-0.001);
    const s=new THREE.Shape();
    s.moveTo(-hw+r,-hh);
    s.lineTo(hw-r,-hh);  s.quadraticCurveTo(hw,-hh,hw,-hh+r);
    s.lineTo(hw,hh-r);   s.quadraticCurveTo(hw,hh,hw-r,hh);
    s.lineTo(-hw+r,hh);  s.quadraticCurveTo(-hw,hh,-hw,hh-r);
    s.lineTo(-hw,-hh+r); s.quadraticCurveTo(-hw,-hh,-hw+r,-hh);
    const g=new THREE.ExtrudeGeometry(s,{depth:Math.max(0.02,d-b*2),bevelEnabled:true,
        bevelThickness:b,bevelSize:b,bevelSegments:seg,curveSegments:seg+3});
    g.translate(0,0,-(d-b*2)/2);
    return g;
  };
  const RB=(w,h,d,mat,x,y,z,rx=0,ry=0,rz=0,parent,r=0.05,b=0.025)=>{
    const m=new THREE.Mesh(RBgeo(w,h,d,r,b),mat);
    m.position.set(x,y,z); m.rotation.set(rx,ry,rz);
    return add(m,parent);
  };
  /* tube between two points (roll cage, A-arms, brackets) */
  const tube=(a,b,r,mat,parent)=>{
    const dir=new THREE.Vector3().subVectors(b,a), l=dir.length();
    const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,l,10),mat);
    m.position.copy(a).addScaledVector(dir,0.5);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
    return add(m,parent);
  };
  /* red coil-over shock between two points */
  const coilOver=(a,b)=>{
    const dir=new THREE.Vector3().subVectors(b,a), l=dir.length();
    const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir.clone().normalize());
    const put=(geo,t,mat)=>{
      const m=new THREE.Mesh(geo,mat);
      m.position.copy(a).addScaledVector(dir,t); m.quaternion.copy(q); add(m); return m;
    };
    put(new THREE.CylinderGeometry(0.026,0.026,l*0.8,10),0.46,mChrome);   // shaft
    put(new THREE.CylinderGeometry(0.05,0.055,l*0.40,12),0.26,mPipe);      // damper body
    put(new THREE.SphereGeometry(0.038,10,8),0.02,mPipe);                  // top eye
    put(new THREE.SphereGeometry(0.032,10,8),0.985,mPipe);                 // bottom eye
    for(let i=0;i<9;i++){                                                 // coil
      const t=0.36+0.40*(i/8);
      const ring=new THREE.Mesh(new THREE.TorusGeometry(0.082,0.019,8,16),mPipe);
      ring.position.copy(a).addScaledVector(dir,t);
      ring.quaternion.copy(q); ring.rotateX(Math.PI/2);
      add(ring);
    }
  };

  /* ================= surfacing: lofted hulls + swept fenders ================= */
  /* cross-section point: a superellipse (squareness e) with independent up/down
     half-heights, so one section can be a low bonnet and the next a tall tub */
  const secPt=(s,a)=>{
    const c=Math.cos(a), sn=Math.sin(a), e=s.e||0.6;
    return [ s.w*Math.sign(c)*Math.pow(Math.abs(c),e),
             s.y + (sn>=0?s.hU:s.hD)*Math.sign(sn)*Math.pow(Math.abs(sn),e) ];
  };
  /* loft stations (z must descend) into one smooth watertight hull */
  const loftGeo=(secs,n)=>{
    const rows=secs.length, cols=n+1, P=rows*cols;
    const pos=new Float32Array((P+2)*3), uv=new Float32Array((P+2)*2);
    let k=0;
    for(let i=0;i<rows;i++){ const s=secs[i];
      for(let j=0;j<cols;j++){
        const p=secPt(s,j/n*Math.PI*2);
        pos[k*3]=p[0]; pos[k*3+1]=p[1]; pos[k*3+2]=s.z;
        uv[k*2]=j/n; uv[k*2+1]=i/(rows-1); k++;
      }
    }
    const idx=[];
    for(let i=0;i<rows-1;i++) for(let j=0;j<n;j++){
      const a=i*cols+j, b=a+1, c=a+cols, d=c+1;
      idx.push(a,c,b, b,c,d);
    }
    /* end caps: fans to the section centre */
    const c0=P, c1=P+1, r0=(rows-1)*cols;
    pos[c0*3]=0; pos[c0*3+1]=secs[0].y;        pos[c0*3+2]=secs[0].z;
    pos[c1*3]=0; pos[c1*3+1]=secs[rows-1].y;   pos[c1*3+2]=secs[rows-1].z;
    for(let j=0;j<n;j++){ idx.push(c0, j, j+1); idx.push(c1, r0+j+1, r0+j); }
    const g=new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos,3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv,2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
  };
  const loft=(secs,n,mat,parent)=>add(new THREE.Mesh(loftGeo(secs,n),mat),parent);
  /* fender shell: a curled U-section swept around the wheel arch (z-y plane) */
  const archFender=(wx,wz,cy,R,a0,a1,hw,droop,crown,mat)=>{
    const segs=Math.max(10,Math.round(Math.abs(a1-a0)/0.075));
    const prof=[[-hw,droop],[-hw*0.86,-droop*0.35],[-hw*0.46,crown],[0,crown+0.02],
                [hw*0.46,crown],[hw*0.86,-droop*0.35],[hw,droop]];
    const rows=segs+1, cols=prof.length;
    const pos=new Float32Array(rows*cols*3), uv=new Float32Array(rows*cols*2);
    let k=0;
    for(let i=0;i<rows;i++){
      const a=a0+(a1-a0)*i/segs, sa=Math.sin(a), ca=Math.cos(a);
      for(let j=0;j<cols;j++){
        const rn=R+prof[j][1];
        pos[k*3]=wx+prof[j][0];
        pos[k*3+1]=cy+ca*rn;
        pos[k*3+2]=wz+sa*rn;
        uv[k*2]=j/(cols-1); uv[k*2+1]=i/segs; k++;
      }
    }
    const idx=[];
    for(let i=0;i<rows-1;i++) for(let j=0;j<cols-1;j++){
      const a=i*cols+j, b=a+1, c=a+cols, d=c+1;
      idx.push(a,c,b, b,c,d);
    }
    const g=new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos,3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv,2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return add(new THREE.Mesh(g,mat));
  };

  /* ---------- body hulls ---------- */
  /* sill tub: the dark floor/sill the seats sit on, cockpit between the arches */
  loft([
    {z: 1.30, y:0.44, w:0.44, hU:0.20, hD:0.16, e:0.60},
    {z: 0.80, y:0.44, w:0.66, hU:0.20, hD:0.15, e:0.62},
    {z: 0.10, y:0.43, w:0.68, hU:0.21, hD:0.15, e:0.62},
    {z:-0.50, y:0.43, w:0.68, hU:0.21, hD:0.15, e:0.62},
    {z:-0.85, y:0.44, w:0.64, hU:0.20, hD:0.15, e:0.60}
  ],20,mDark,null);
  /* bonnet hull: dash → nose, one smooth painted surface (fascia + chin built in) */
  loft([
    {z: 2.34, y:0.60, w:0.26, hU:0.09, hD:0.20, e:0.62},
    {z: 2.24, y:0.62, w:0.38, hU:0.12, hD:0.24, e:0.60},
    {z: 2.02, y:0.66, w:0.50, hU:0.16, hD:0.28, e:0.58},
    {z: 1.70, y:0.68, w:0.60, hU:0.22, hD:0.30, e:0.56},
    {z: 1.35, y:0.70, w:0.62, hU:0.27, hD:0.26, e:0.56},
    {z: 1.05, y:0.70, w:0.58, hU:0.28, hD:0.24, e:0.58}
  ],20,mBody,null);
  /* engine deck hull: bulkhead behind the seats → tail, radiator sits on top */
  loft([
    {z:-0.70, y:0.70, w:0.58, hU:0.28, hD:0.30, e:0.58},
    {z:-1.10, y:0.68, w:0.62, hU:0.30, hD:0.30, e:0.60},
    {z:-1.60, y:0.66, w:0.58, hU:0.28, hD:0.30, e:0.60},
    {z:-2.00, y:0.62, w:0.48, hU:0.24, hD:0.26, e:0.60},
    {z:-2.24, y:0.56, w:0.34, hU:0.16, hD:0.20, e:0.62}
  ],20,mBody,null);

  /* ---------- fenders: shells swept around the arches ---------- */
  for(const sx of [-1,1]){
    /* front: tight arch over the steering wheel, ends before the A-pillar */
    archFender(sx*0.92, 1.50, 0.60, 0.63, -1.75, 1.85, 0.23, -0.10, 0.050, mFender);
    /* rear: longer, wider shell sweeping toward the tail */
    archFender(sx*0.92,-1.45, 0.60, 0.64, -1.55, 1.95, 0.26, -0.12, 0.055, mFender);
    /* mounting stays from the hull flanks up to the fender skirt edges — the
       shell's inner skirt edge sits at radial 0.53 (front) / 0.52 (rear)
       from the axles; the stays land on it so they read as welded tabs */
    /* fender strut at the arch's trailing tip only: the gap between the tire's
       shoulder and the shell is too tight for a brace over the wheel, but the
       rear corridor (behind the tire's steer sweep) is clean */
    tube(new THREE.Vector3(sx*0.56,0.42,0.86), new THREE.Vector3(sx*0.700,0.50,0.97), 0.016, mBlack);
    tube(new THREE.Vector3(sx*0.57,0.76,-1.10), new THREE.Vector3(sx*0.655,1.04,-1.18), 0.020, mBlack);
    tube(new THREE.Vector3(sx*0.47,0.72,-1.86), new THREE.Vector3(sx*0.655,0.79,-1.94), 0.020, mBlack);
  }

  /* ---------- doors with livery ---------- */
  for(const sx of [-1,1]){
    RB(0.075,0.42,1.55,mBody, sx*0.715,0.58, 0.225, 0,0,0, null, 0.03, 0.012);
    RB(0.028,0.05,0.15,mBlack, sx*0.765,0.67, 0.72, 0,0,0, null, 0.012, 0.006);   // handle
    const decal=new THREE.Mesh(new THREE.PlaneGeometry(0.86,0.34),mDecal);
    decal.position.set(sx*0.765,0.60,0.20);
    decal.rotation.y=sx>0?Math.PI/2:-Math.PI/2;
    if(sx<0) decal.scale.x=-1;
    decal.receiveShadow=true;
    carBody.add(decal);
  }

  /* ---------- front fascia ---------- */
  RB(0.56,0.26,0.06,mMesh, 0,0.63,2.31, -0.06,0,0, null, 0.02, 0.01);          // grille
  tube(new THREE.Vector3(-0.31,0.79,2.33), new THREE.Vector3(0.31,0.79,2.33), 0.022, mPipe);
  tube(new THREE.Vector3(-0.31,0.47,2.33), new THREE.Vector3(0.31,0.47,2.33), 0.022, mPipe);
  for(const sx of [-1,1]){
    tube(new THREE.Vector3(sx*0.31,0.47,2.33), new THREE.Vector3(sx*0.31,0.79,2.33), 0.022, mPipe);
    RB(0.30,0.045,0.045,mLED, sx*0.38,0.78,2.27, 0,-sx*0.35,-sx*0.10, null, 0.015, 0.008); // LED slash
  }
  /* red tube bumper with brush-guard risers */
  tube(new THREE.Vector3(-0.80,0.40,2.52), new THREE.Vector3(0.80,0.40,2.52), 0.045, mPipe);
  for(const sx of [-1,1]){
    tube(new THREE.Vector3(sx*0.80,0.40,2.52), new THREE.Vector3(sx*0.55,0.66,2.30), 0.035, mPipe);
    tube(new THREE.Vector3(sx*0.80,0.40,2.52), new THREE.Vector3(sx*0.80,0.64,2.32), 0.035, mPipe);
    tube(new THREE.Vector3(sx*0.34,0.40,2.52), new THREE.Vector3(sx*0.34,0.72,2.36), 0.028, mPipe);
    const hook=new THREE.Mesh(new THREE.TorusGeometry(0.045,0.012,6,12),mBlack);
    hook.position.set(sx*0.40,0.32,2.40); hook.rotation.x=Math.PI/2; add(hook);
  }
  RB(1.30,0.18,0.04,mMesh, 0,0.34,2.47, 0,0,0, null, 0.02, 0.01);              // lower mesh
  /* hood vents + pins */
  for(const sx of [-1,1]) for(let i=0;i<3;i++)
    RB(0.15,0.013,0.05,mBlack, sx*0.33,0.910-i*0.038,1.62+i*0.17, -0.10,0,-sx*0.12, null, 0.006, 0.003);
  for(const sx of [-1,1])
    RB(0.04,0.016,0.055,mChrome, sx*0.21,0.715,2.17, -0.10,0,0, null, 0.008, 0.004);

  /* ---------- tail: lights, mesh, radiator, exhaust ---------- */
  for(const sx of [-1,1]){
    RB(0.15,0.08,0.05,mTail, sx*0.20,0.62,-2.26, 0,0,0, null, 0.02, 0.01);
    /* header pipes curving down the sides to the tips */
    tube(new THREE.Vector3(sx*0.40,0.86,-1.28), new THREE.Vector3(sx*0.56,0.66,-1.86), 0.030, mChrome);
    tube(new THREE.Vector3(sx*0.56,0.66,-1.86), new THREE.Vector3(sx*0.48,0.44,-2.20), 0.033, mChrome);
    const tip=cyl(0.042,0.048,0.14,12,mChrome); tip.rotation.x=Math.PI/2;
    tip.position.set(sx*0.48,0.42,-2.24); add(tip);
  }
  RB(0.34,0.05,0.04,mTail, 0,0.50,-2.26, 0,0,0, null, 0.012, 0.006);           // centre brake strip
  RB(0.34,0.16,0.03,mMesh, 0,0.44,-2.25, 0,0,0, null, 0.012, 0.006);           // tail mesh
  /* radiator + twin fans under the rear deck */
  RB(0.64,0.34,0.07,mMesh, 0,1.00,-1.34, -0.30,0,0, null, 0.02, 0.01);
  for(const sx of [-1,1]){
    const ring=new THREE.Mesh(new THREE.TorusGeometry(0.095,0.016,8,20),mBlack);
    ring.position.set(sx*0.16,1.045,-1.395); ring.rotation.x=-Math.PI/2-0.30; add(ring);
    const fdisc=new THREE.Mesh(new THREE.CircleGeometry(0.088,20),mBlack);
    fdisc.position.copy(ring.position).z-=0.004; fdisc.rotation.x=-Math.PI/2-0.30;
    fdisc.castShadow=false; carBody.add(fdisc);
    const fanhub=cyl(0.022,0.022,0.03,8,mWheel); fanhub.rotation.x=-0.30;
    fanhub.position.set(sx*0.16,1.045,-1.375); add(fanhub);
  }
  /* ---------- roll cage: red tubes, black windshield frame, gussets ---------- */
  tube(new THREE.Vector3(-0.80,1.00,1.18), new THREE.Vector3(0.80,1.00,1.18), 0.042, mBlack);
  tube(new THREE.Vector3(-0.78,1.99,0.58), new THREE.Vector3(0.78,1.99,0.58), 0.042, mBlack);
  for(const sx of [-1,1]){
    tube(new THREE.Vector3(sx*0.80,1.00,1.18), new THREE.Vector3(sx*0.78,1.99,0.58), 0.042, mBlack); // A-pillars
    tube(new THREE.Vector3(sx*0.78,0.80,-0.95), new THREE.Vector3(sx*0.78,2.00,-0.95), 0.048, mPipe); // hoop uprights
    tube(new THREE.Vector3(sx*0.78,1.99,0.58), new THREE.Vector3(sx*0.78,2.00,-0.95), 0.045, mPipe);  // roof rails
    tube(new THREE.Vector3(sx*0.78,2.00,-0.95), new THREE.Vector3(sx*0.92,0.60,-2.05), 0.038, mPipe); // rear braces
    tube(new THREE.Vector3(sx*0.78,0.85,-1.80), new THREE.Vector3(-sx*0.78,1.95,-1.02), 0.032, mPipe);// rear X-braces
    /* braces tying the cage roots to the hulls */
    tube(new THREE.Vector3(sx*0.78,0.86,-0.97), new THREE.Vector3(sx*0.52,0.80,-1.10), 0.032, mPipe);
    tube(new THREE.Vector3(sx*0.80,0.99,1.17), new THREE.Vector3(sx*0.55,0.94,1.30), 0.028, mBlack);
    /* gusset plates — the pillar mount plate masks where the A-pillar grazes
       the front fender shell so it reads as bolted through it */
    RB(0.014,0.20,0.16,mPipe, sx*0.785,1.925, 0.625, 0.78,0,0, null, 0.006, 0.003);
    RB(0.014,0.20,0.16,mPipe, sx*0.785,1.925,-0.885,-0.78,0,0, null, 0.006, 0.003);
    RB(0.016,0.15,0.22,mPipe, sx*0.800,1.125,1.115, 0,0,0, null, 0.006, 0.003);
  }
  tube(new THREE.Vector3(-0.78,2.00,-0.95), new THREE.Vector3(0.78,2.00,-0.95), 0.048, mPipe);
  tube(new THREE.Vector3(-0.78,1.30,-0.95), new THREE.Vector3(0.78,1.30,-0.95), 0.032, mPipe);
  /* roof with vent slats + LED light bar on the leading edge */
  RB(1.40,0.08,1.40,mBody, 0,2.07,-0.20, 0,0,0, null, 0.04, 0.02);
  RB(1.40,0.05,0.10,mBlack, 0,2.085,0.52, 0,0,0, null, 0.02, 0.01);
  for(let i=0;i<5;i++)
    RB(1.20,0.018,0.06,mBlack, 0,2.115,-0.55+i*0.16, 0,0,0, null, 0.006, 0.003);
  RB(0.95,0.075,0.09,mBlack, 0,2.135,0.48, 0,0,0, null, 0.02, 0.01);
  RB(0.86,0.045,0.02,mLED, 0,2.135,0.428, 0,0,0, null, 0.01, 0.005);

  /* ---------- cockpit ---------- */
  RB(1.20,0.30,0.40,mBlack, 0,1.00,0.95, 0,0,0, null, 0.05, 0.025);           // dash
  RB(0.42,0.20,0.14,mBlack, -0.40,1.16,0.86, -0.45,0,0, null, 0.03, 0.015);   // gauge pod
  RB(0.26,0.13,0.02,mScreen, -0.40,1.16,0.785, -0.45,0,0, null, 0.01, 0.005); // tripmap screen
  /* tach with chrome bezel + needle on the pod face */
  const tac=new THREE.Mesh(new THREE.TorusGeometry(0.052,0.012,8,20),mChrome);
  tac.position.set(-0.40,1.175,0.772); tac.rotation.x=-0.45; add(tac);
  const tacF=new THREE.Mesh(new THREE.CircleGeometry(0.048,18),mBlack);
  tacF.position.set(-0.40,1.175,0.768); tacF.rotation.x=-0.45; tacF.castShadow=false; carBody.add(tacF);
  const tacN=RB(0.008,0.042,0.004,mRed, -0.405,1.185,0.762, -0.45,0,-0.3, null, 0.002, 0.001); tacN.castShadow=false;
  RB(0.30,0.26,0.80,mDark, 0,0.80,-0.10, 0,0,0, null, 0.04, 0.02);            // console
  const shifter=cyl(0.02,0.03,0.16,8,mChrome); shifter.position.set(0,0.96,0.18); shifter.rotation.z=0.25; add(shifter);
  const knob=new THREE.Mesh(new THREE.SphereGeometry(0.038,10,8),mBlack); knob.position.set(0.018,1.04,0.18); add(knob);
  const col=cyl(0.03,0.03,0.30,8,mBlack); col.position.set(-0.40,1.04,0.75); col.rotation.x=1.15; add(col);
  /* three-spoke steering wheel on the column */
  const swG=new THREE.Group(); swG.position.set(-0.40,1.06,0.60); swG.rotation.x=-1.15; carBody.add(swG);
  const swRim=new THREE.Mesh(new THREE.TorusGeometry(0.15,0.021,10,26),mBlack);
  swRim.castShadow=true; swG.add(swRim);
  for(const a of [-Math.PI/2, Math.PI*5/6, Math.PI/6]){
    const sp=new THREE.Mesh(RBgeo(0.026,0.125,0.018,0.008,0.004),mBlack);
    sp.castShadow=true;
    sp.position.set(Math.cos(a)*0.072, Math.sin(a)*0.072, 0);
    sp.rotation.z=a-Math.PI/2; swG.add(sp);
  }
  const swHub=new THREE.Mesh(new THREE.CylinderGeometry(0.046,0.05,0.05,16),mBlack);
  swHub.rotation.x=Math.PI/2; swHub.castShadow=true; swG.add(swHub);
  tube(new THREE.Vector3(0.30,1.18,0.78), new THREE.Vector3(0.66,1.18,0.78), 0.02, mBlack); // grab handle
  /* bucket seats with bolsters, piping, 4-point harness + anti-sub strap */
  for(const sx of [-1,1]){
    RB(0.46,0.14,0.50,mSeat, sx*0.42,0.71,-0.30, 0,0,0, null, 0.05, 0.03);    // cushion
    RB(0.46,0.64,0.13,mSeat, sx*0.42,1.04,-0.58, 0.12,0,0, null, 0.05, 0.03); // backrest
    for(const bx of [-0.20,0.20])
      RB(0.08,0.58,0.12,mSeat, sx*0.42+bx,1.04,-0.555, 0.12,0,0, null, 0.03, 0.015);
    RB(0.46,0.035,0.135,mRed, sx*0.42,1.345,-0.615, 0.12,0,0, null, 0.012, 0.006); // red piping
    RB(0.24,0.20,0.10,mSeat, sx*0.42,1.48,-0.64, 0.12,0,0, null, 0.04, 0.02);      // headrest
    RB(0.06,0.16,0.105,mRed, sx*0.42,1.48,-0.64, 0.12,0,0, null, 0.015, 0.006);    // headrest stripe
    for(const bx of [-0.13,0.13])
      RB(0.09,0.56,0.015,mDark, sx*0.42+bx,1.06,-0.505, 0.12,0,0, null, 0.008, 0.004);
    RB(0.10,0.07,0.03,mChrome, sx*0.42,1.00,-0.50, 0.12,0,0, null, 0.012, 0.006);  // cam-lock buckle
    RB(0.085,0.30,0.014,mDark, sx*0.42,0.82,-0.24, -0.55,0,0, null, 0.006, 0.003); // anti-sub strap
  }

  /* ---------- chassis: sliders, skid, tie-downs, coil-overs, fuel cap ---------- */
  for(const sx of [-1,1]){
    /* side rails tuck under the sill edge: the wheels begin at x 0.70, so the
       rail rides at 0.58 and only its lower flank shows, like a nerf bar.
       The front tip stops at z 1.00 — any further forward and the steered
       front tire's shoulder swings through it at full compression. */
    tube(new THREE.Vector3(sx*0.58,0.36,1.00), new THREE.Vector3(sx*0.58,0.36,-1.60), 0.042, mBlack);
    tube(new THREE.Vector3(sx*0.58,0.36,0.90), new THREE.Vector3(sx*0.48,0.44,0.90), 0.024, mBlack);
    tube(new THREE.Vector3(sx*0.58,0.36,-1.20), new THREE.Vector3(sx*0.47,0.44,-1.20), 0.024, mBlack);
  }
  RB(1.30,0.07,2.90,mBlack, 0,0.24,-0.05, 0,0,0, null, 0.03, 0.015);
  for(const [tx,tz,ty] of [[-0.22,-1.45,0.955],[0.22,-1.45,0.955],[-0.22,-1.85,0.888],[0.22,-1.85,0.888]]){
    const lp=new THREE.Mesh(new THREE.TorusGeometry(0.035,0.008,6,12),mBlack);
    lp.position.set(tx,ty,tz); lp.rotation.x=Math.PI/2; add(lp);
  }
  for(const sx of [-1,1]){
    /* shocks tuck under the bodywork; the red coils show below the hull edge */
    coilOver(new THREE.Vector3(sx*0.30,0.94,1.12), new THREE.Vector3(sx*0.53,0.40,1.40));
    coilOver(new THREE.Vector3(sx*0.28,0.92,-0.85), new THREE.Vector3(sx*0.62,0.52,-1.38));
  }
  tube(new THREE.Vector3(-0.30,0.94,1.12), new THREE.Vector3(0.30,0.94,1.12), 0.02, mPipe);
  tube(new THREE.Vector3(-0.28,0.94,-0.85), new THREE.Vector3(0.28,0.94,-0.85), 0.02, mPipe);
  const fcap=cyl(0.05,0.05,0.02,12,mChrome); fcap.rotation.z=Math.PI/2; fcap.position.set(0.595,0.80,-1.35); add(fcap);
  /* rear bumper tube */
  tube(new THREE.Vector3(-0.82,0.42,-2.28), new THREE.Vector3(0.82,0.42,-2.28), 0.042, mPipe);
  for(const sx of [-1,1]){
    tube(new THREE.Vector3(sx*0.82,0.42,-2.28), new THREE.Vector3(sx*0.72,0.64,-2.02), 0.032, mPipe);
    tube(new THREE.Vector3(sx*0.82,0.42,-2.28), new THREE.Vector3(sx*0.86,0.62,-2.06), 0.032, mPipe);
  }

  /* ---------- wheels: crowned tires, beadlock rims, live brakes ---------- */
  /* tread crown: a shallow lathe so the tire is round, not a cylinder */
  const tireGeo=(()=>{
    const pts=[new THREE.Vector2(0.452,-0.170), new THREE.Vector2(0.466,-0.105),
               new THREE.Vector2(0.472,0.0),     new THREE.Vector2(0.466,0.105),
               new THREE.Vector2(0.452,0.170)];
    const g=new THREE.LatheGeometry(pts,40); g.rotateZ(-Math.PI/2); return g;
  })();
  const shoulderGeo = new THREE.TorusGeometry(0.435,0.05,10,30);
  shoulderGeo.rotateY(Math.PI/2);
  const wallGeo = new THREE.CircleGeometry(0.435,30);
  const spokeGeo = RBgeo(0.07,0.07,0.26,0.025,0.012,2);
  const hubGeo = new THREE.CylinderGeometry(0.07,0.07,0.36,12);
  hubGeo.rotateZ(Math.PI/2);
  const capGeo = new THREE.CylinderGeometry(0.09,0.09,0.05,14);
  capGeo.rotateZ(Math.PI/2);
  const wheelPlateGeo = new THREE.CylinderGeometry(0.30,0.30,0.02,20);
  wheelPlateGeo.rotateZ(Math.PI/2);
  const blGeo = new THREE.TorusGeometry(0.315,0.026,8,28);
  blGeo.rotateY(Math.PI/2);
  const blBoltGeo = new THREE.CylinderGeometry(0.014,0.014,0.03,6);
  blBoltGeo.rotateZ(Math.PI/2);
  const calGeo = RBgeo(0.115,0.20,0.095,0.02,0.01);

  const defs=[
    {lx: 0.92, lz: 1.50, front:true },
    {lx:-0.92, lz: 1.50, front:true },
    {lx: 0.92, lz:-1.45, front:false},
    {lx:-0.92, lz:-1.45, front:false}
  ];
  for(const d of defs){
    const steer=new THREE.Group(); steer.position.set(d.lx,0,d.lz); carRoot.add(steer);
    const susp=new THREE.Group();  susp.position.y=CAR.restY; steer.add(susp);
    const spin=new THREE.Group();  susp.add(spin);

    /* tire: crowned tread + rounded shoulders + textured sidewalls */
    const tire=new THREE.Mesh(tireGeo, mTread);
    tire.castShadow=true; spin.add(tire);
    for(const sx of [-1,1]){
      const sh=new THREE.Mesh(shoulderGeo,mTread);
      sh.position.x=sx*0.18; sh.castShadow=true; spin.add(sh);
      const wall=new THREE.Mesh(wallGeo,mSide);
      wall.rotation.y=sx*Math.PI/2; wall.position.x=sx*0.22; spin.add(wall);
    }
    /* brake disc (spins) + valve stem */
    const disc=new THREE.Mesh(new THREE.CylinderGeometry(0.185,0.185,0.03,24),mDisc);
    disc.rotation.z=Math.PI/2; spin.add(disc);
    const valve=cyl(0.008,0.008,0.045,6,mChrome);
    valve.rotation.z=Math.PI/2; valve.position.set(0.165,0.41,0); spin.add(valve);
    /* dust ring that builds up with driving */
    const dustRing=new THREE.Mesh(
      new THREE.CylinderGeometry(CAR.wheelR+0.014,CAR.wheelR+0.014,0.40,28,1,true),
      new THREE.MeshStandardMaterial({map:texDustRing, transparent:true, opacity:0, roughness:1.0,
          metalness:0.0, depthWrite:false}));
    dustRing.rotation.z=Math.PI/2; susp.add(dustRing);
    /* beadlock rim: dark center, 6 spokes, black lock ring with perimeter bolts */
    const rim=new THREE.Group(); spin.add(rim);
    const plate=new THREE.Mesh(wheelPlateGeo,mBlack); plate.position.x=0.02; rim.add(plate);
    for(let i=0;i<6;i++){
      const a=i/6*Math.PI*2;
      const sp=new THREE.Mesh(spokeGeo,mWheel);
      sp.rotation.x=a;
      sp.position.set(0,-Math.sin(a)*0.18,Math.cos(a)*0.18);
      sp.castShadow=true; rim.add(sp);
    }
    rim.add(new THREE.Mesh(hubGeo,mWheel));
    for(const sx of [0.19,-0.19]){
      const ring=new THREE.Mesh(blGeo,mBlack); ring.position.x=sx; ring.castShadow=true; rim.add(ring);
      const cap=new THREE.Mesh(capGeo,mWheel); cap.position.x=sx*0.95; rim.add(cap);
      for(let i=0;i<12;i++){
        const a=i/12*Math.PI*2;
        const bl=new THREE.Mesh(blBoltGeo,mChrome);
        bl.position.set(sx*1.08,Math.cos(a)*0.315,Math.sin(a)*0.315);
        rim.add(bl);
      }
    }
    /* red brake caliper clamped over the disc — on the knuckle, so it does not spin */
    const cal=new THREE.Mesh(calGeo,mRed);
    cal.position.set(-Math.sign(d.lx)*0.055,0.135,0.135);
    cal.rotation.x=2.356; cal.castShadow=true; steer.add(cal);
    /* red A-arms reaching to the chassis */
    const inward=-Math.sign(d.lx);
    for(const az of [-0.30,0.30]){
      tube(new THREE.Vector3(inward*0.55,0.62,az), new THREE.Vector3(0,0.52,0), 0.028, mPipe, steer);
      tube(new THREE.Vector3(inward*0.55,0.34,az), new THREE.Vector3(0,0.44,0), 0.034, mPipe, steer);
    }
    tube(new THREE.Vector3(inward*0.55,0.34,-0.30), new THREE.Vector3(inward*0.55,0.34,0.30), 0.024, mPipe, steer);
    /* axle stub toward the chassis */
    const stub=cyl(0.055,0.055,0.16,10,mBlack); stub.rotation.z=Math.PI/2;
    stub.position.x=-Math.sign(d.lx)*0.20; steer.add(stub);

    wheels.push({lx:d.lx, lz:d.lz, front:d.front, steer, susp, spin,
                 y:CAR.restY, vel:0, k:d.front?250:225, c:d.front?25:24, spinVel:0, load:1,
                 dust:0, dustRing});
  }

  /* ---------- realism details ---------- */
  /* tinted half-windscreen in the black frame — kept subtle so it never reads
     as a dark plate floating on the open cockpit */
  const mGlassTint=new THREE.MeshPhysicalMaterial({color:0x3d4750, roughness:0.07, metalness:0.62,
      clearcoat:1.0, clearcoatRoughness:0.08, transparent:true, opacity:0.2, depthWrite:false,
      envMap:envTex, envMapIntensity:1.5, side:THREE.DoubleSide});
  const wsGlass=new THREE.Mesh(new THREE.BoxGeometry(1.52,0.55,0.035),mGlassTint);
  wsGlass.position.set(0,1.32,0.965); wsGlass.rotation.x=-0.36; add(wsGlass);
  /* side mirrors on the A-pillars */
  for(const sx of [-1,1]){
    tube(new THREE.Vector3(sx*0.80,1.55,1.02), new THREE.Vector3(sx*0.95,1.58,0.99), 0.018, mBlack);
    RB(0.05,0.16,0.12,mBlack, sx*0.97,1.60,0.99, 0,0,0, null, 0.015, 0.008);
  }

  /* ---------- dynamic wear: scratches, scuffs, wheel dust ---------- */
  const texScratch =makeScratchTexture();
  const texScuff   =makeScuffTexture();
  const texDustFilm=makeDustFilmTexture();
  const mScratch=new THREE.MeshStandardMaterial({map:texScratch, transparent:true, opacity:0, roughness:0.9,
      metalness:0.05, depthWrite:false, polygonOffset:true, polygonOffsetFactor:-2});
  const mScuff=new THREE.MeshStandardMaterial({map:texScuff, transparent:true, opacity:0, roughness:0.95,
      metalness:0.05, depthWrite:false, polygonOffset:true, polygonOffsetFactor:-2});
  const mDirt=new THREE.MeshStandardMaterial({map:texDustFilm, transparent:true, opacity:0, roughness:1.0,
      metalness:0.0, depthWrite:false, polygonOffset:true, polygonOffsetFactor:-3});
  const wearAnchors=[
    /* doors */
    {p:[ 0.760,0.58, 0.62], r:[0, Math.PI/2, 0.05], s:[0.50,0.24]},
    {p:[-0.760,0.58, 0.62], r:[0,-Math.PI/2,-0.05], s:[0.50,0.24]},
    {p:[ 0.760,0.58,-0.18], r:[0, Math.PI/2, 0.05], s:[0.50,0.24]},
    {p:[-0.760,0.58,-0.18], r:[0,-Math.PI/2,-0.05], s:[0.50,0.24]},
    /* fender skirts (tilted with the shell) */
    {p:[ 1.135,1.08, 1.72], r:[ 0.35, Math.PI/2,-0.30], s:[0.38,0.20]},
    {p:[-1.135,1.08, 1.72], r:[-0.35,-Math.PI/2, 0.30], s:[0.38,0.20]},
    {p:[ 1.135,1.06, 1.28], r:[ 0.35, Math.PI/2,-0.30], s:[0.38,0.20]},
    {p:[-1.135,1.06, 1.28], r:[-0.35,-Math.PI/2, 0.30], s:[0.38,0.20]},
    {p:[ 1.150,1.06,-1.28], r:[ 0.35, Math.PI/2,-0.30], s:[0.42,0.22]},
    {p:[-1.150,1.06,-1.28], r:[-0.35,-Math.PI/2, 0.30], s:[0.42,0.22]},
    {p:[ 1.150,1.08,-1.62], r:[ 0.35, Math.PI/2,-0.30], s:[0.42,0.22]},
    {p:[-1.150,1.08,-1.62], r:[-0.35,-Math.PI/2, 0.30], s:[0.42,0.22]},
    /* hood top */
    {p:[ 0.22,0.880, 1.75], r:[-Math.PI/2+0.16,0,-0.10], s:[0.48,0.28]},
    {p:[-0.22,0.880, 1.75], r:[-Math.PI/2+0.16,0, 0.10], s:[0.48,0.28]},
    /* nose + tail */
    {p:[0,0.62, 2.36], r:[0,0,0], s:[0.44,0.20]},
    {p:[0,0.58,-2.27], r:[0, Math.PI,0], s:[0.54,0.22]},
    {p:[0,0.48,-2.27], r:[0, Math.PI,0], s:[0.54,0.18]}
  ];
  const wearPool=[];
  for(const a of wearAnchors){
    for(let k=0;k<2;k++){
      const kind=k===0?'scratch':'scuff';
      const m=new THREE.Mesh(new THREE.PlaneGeometry(a.s[0],a.s[1]), kind==='scratch'?mScratch.clone():mScuff.clone());
      m.position.set(a.p[0]+(Math.random()-0.5)*0.10, a.p[1]+(Math.random()-0.5)*0.10, a.p[2]);
      m.rotation.set(a.r[0], a.r[1], a.r[2]+(Math.random()-0.5)*0.8);
      m.renderOrder=2;
      carBody.add(m);
      wearPool.push({mesh:m, kind, active:false, target:0});
    }
  }
  const dirtAnchors=[
    {p:[ 0.763,0.46, 0.92], r:[0, Math.PI/2, 0.02], s:[0.66,0.30], max:0.50},
    {p:[-0.763,0.46, 0.92], r:[0,-Math.PI/2,-0.02], s:[0.66,0.30], max:0.50},
    {p:[ 0.763,0.46,-0.34], r:[0, Math.PI/2, 0.02], s:[0.72,0.32], max:0.54},
    {p:[-0.763,0.46,-0.34], r:[0,-Math.PI/2,-0.02], s:[0.72,0.32], max:0.54},
    {p:[ 1.145,0.98, 1.52], r:[0.28, Math.PI/2,-0.28], s:[0.48,0.24], max:0.46},
    {p:[-1.145,0.98, 1.52], r:[-0.28,-Math.PI/2, 0.28], s:[0.48,0.24], max:0.46},
    {p:[ 1.145,0.98,-1.46], r:[0.28, Math.PI/2,-0.28], s:[0.56,0.28], max:0.52},
    {p:[-1.145,0.98,-1.46], r:[-0.28,-Math.PI/2, 0.28], s:[0.56,0.28], max:0.52},
    {p:[ 0.26,0.90, 1.72], r:[-Math.PI/2+0.16,0,-0.08], s:[0.54,0.28], max:0.38},
    {p:[-0.26,0.90, 1.72], r:[-Math.PI/2+0.16,0, 0.08], s:[0.54,0.28], max:0.38},
    {p:[0,0.62,-2.26], r:[0, Math.PI,0], s:[0.58,0.24], max:0.40},
    {p:[0,0.48,-2.26], r:[0, Math.PI,0], s:[0.52,0.20], max:0.44}
  ];
  const dirtPool=[];
  for(const a of dirtAnchors){
    const m=new THREE.Mesh(new THREE.PlaneGeometry(a.s[0],a.s[1]),mDirt.clone());
    m.position.set(a.p[0]+(Math.random()-0.5)*0.06,a.p[1]+(Math.random()-0.5)*0.05,a.p[2]);
    m.rotation.set(a.r[0],a.r[1],a.r[2]+(Math.random()-0.5)*0.5);
    m.renderOrder=1;
    carBody.add(m);
    dirtPool.push({mesh:m,max:a.max,seed:Math.random()*0.2});
  }
  const wear={drive:0, revealed:0, dirt:0, puffT:0};
  function revealWearDecal(kind){
    const c=wearPool.find(s=>!s.active&&(kind?s.kind===kind:true));
    if(!c) return false;
    c.active=true;
    c.target=kind==='scuff'?0.3+Math.random()*0.12:0.45+Math.random()*0.2;
    c.mesh.material.opacity=0.01;
    return true;
  }
  function addImpactDamage(strength){
    const n=Math.min(4, 1+Math.floor(strength/9));
    let added=0;
    for(let i=0;i<n;i++) if(revealWearDecal(Math.random()<0.55?'scratch':'scuff')) added++;
    wear.dirt=Math.min(1,wear.dirt+0.02+strength*0.0015);
    if(added) burstDust(player.pos, 4, 3);
  }
  function updateVehicleWear(dt){
    const spd=Math.abs(player.speedF);
    /* wheel dust: builds with speed, shakes off during hard spin, settles when parked */
    for(const w of wheels){
      if(!w.dustRing) continue;
      const spin=Math.abs(w.spinVel||0);
      let target=spd>4?clamp(0.12+spd*0.02,0,0.8):0;
      if(spin>16) target*=Math.max(0,1-(spin-16)*0.07);
      w.dust=clamp(w.dust+(target>w.dust?(target-w.dust)*Math.min(1,dt*0.8):-dt*0.10),0,0.85);
      w.dustRing.material.opacity=w.dust;
    }
    /* sand scouring slowly scratches the panels (subtle — max 6 faint marks) */
    if(spd>8&&player.alive){
      wear.drive+=dt*spd*0.0045;
      while(wear.revealed<6&&wear.drive>(wear.revealed+1)*2.4){ revealWearDecal('scratch'); wear.revealed++; }
    }
    /* fine dust film builds lower on the body, strongest behind the wheels */
    if(player.alive){
      const gain=(spd/46)*0.030+(player.boost>0?0.018:0);
      wear.dirt=clamp(wear.dirt+dt*gain,0,1);
    }
    for(const d of dirtPool){
      const target=clamp(wear.dirt*d.max+d.seed*wear.dirt,0,d.max);
      const mat=d.mesh.material;
      mat.opacity+= (target-mat.opacity)*Math.min(1,dt*0.8);
    }
    /* wheel dust puffs are emitted by updatePlayer in 13-player-physics.js */
    /* fade-ins for newly revealed decals */
    for(const s of wearPool)
      if(s.active&&s.mesh.material.opacity<s.target)
        s.mesh.material.opacity=Math.min(s.target, s.mesh.material.opacity+dt*1.6);
  }
  function resetVehicleWear(){
    wear.drive=0; wear.revealed=0; wear.dirt=0; wear.puffT=0;
    for(const s of wearPool){ s.active=false; s.target=0; s.mesh.material.opacity=0; }
    for(const d of dirtPool) d.mesh.material.opacity=0;
    for(const w of wheels){ w.dust=0; if(w.dustRing) w.dustRing.material.opacity=0; }
  }
  window.updateVehicleWear=updateVehicleWear;
  window.addImpactDamage=addImpactDamage;
  window.resetVehicleWear=resetVehicleWear;

  /* ---------- whip antenna + orange safety flag (physics-driven) ---------- */
  const mWhip=new THREE.MeshStandardMaterial({color:0x1a1815, roughness:0.75, metalness:0.25});
  const NSEG=7, SEGLEN=0.26;
  const wbase=new THREE.Group();
  wbase.position.set(-0.50,0.83,-1.76);
  wbase.rotation.set(-0.12,0,0.16);
  carBody.add(wbase);
  antenna={joints:[]};
  let wparent=wbase;
  for(let i=0;i<NSEG;i++){
    const j=new THREE.Group();
    wparent.add(j);
    const t=i/(NSEG-1);
    const r=lerp(0.020,0.006,t);
    const seg=new THREE.Mesh(new THREE.CylinderGeometry(r*0.85, r, SEGLEN, 6), mWhip);
    seg.position.y=SEGLEN/2; seg.castShadow=true; j.add(seg);
    const next=new THREE.Group(); next.position.y=SEGLEN; j.add(next);
    antenna.joints.push({g:j, x:0, z:0, vx:0, vz:0, k:70+i*34, c:2*Math.sqrt(70+i*34)*0.42, ph:Math.random()*9});
    wparent=next;
  }
  flagGeo=new THREE.PlaneGeometry(0.46,0.24,8,4);
  flagGeo.translate(0.23,0,0);
  flagBase=Float32Array.from(flagGeo.attributes.position.array);
  flagMesh=new THREE.Mesh(flagGeo, mFlag);
  flagMesh.rotation.y=Math.PI/2;
  flagMesh.position.y=SEGLEN-0.05;
  flagMesh.castShadow=true;
  wparent.add(flagMesh);
}
