/* 3D tire trails: pressed-sand tracks behind every wheel (realistic relief version, v2) */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ================================================================
   3D TIRE TRAILS — pressed sand with real relief

   Needs from the rest of the game (all already in your files):
     scene, elapsed, sunDir (01-core / 11-ui), terrainH() (01-core), VMAX (01-core)

   How it works
   - The ribbon is DRAPED on the real terrain: every stored point samples
     terrainH() under the tire and at both edges, so the track follows dunes
     and side slopes instead of cutting through them.
   - The shader never paints sand colour. It MULTIPLIES whatever the terrain
     already looks like (sand texture, sun, shadows, fog), so the track keeps
     the ground's own grain and brightness. Relief is lit with the game's own
     sunDir: one wall of the track catches light, the other falls into shadow.
   - Profile: rounded depression + raised berm of displaced sand on both
     sides + chevron tread pressed into the bottom + sand grain/clods.
   - Wheel state drives it: sliding, wheelspin and locked wheels make wider,
     rougher tracks with smeared tread, bigger berms and washboard ripples;
     light wheel load makes shallow tracks; fast wheels spread the edges.
   - Wind erosion: tracks get shallower, softer and lose their tread long
     before they vanish, instead of just fading out.
   - Airborne wheels break the track (tr.lift()), with a short taper at both
     ends instead of a ribbon stretched through the air.

   API (compatible with the old file):
     tireTrails[i].push(x, groundY, z, rx, rz, strength [, slide, speed, load])
         -> true if a point was added. groundY must be the terrain height
            under the wheel (no lift needed, the trail adds its own).
         slide 0..1  (lateral slip / wheelspin / lock), speed m/s, load 0..1.3
     tireTrails[i].lift()    wheel left the ground: end the current track
     tireTrails[i].update()  call every frame
     tireTrails[i].clear()
   ================================================================ */

/* ---- tweakables ------------------------------------------------ */
const TRAIL_PTS   = 320;    // points kept per wheel (x TRAIL_STEP = trail length in meters)
const TRAIL_STEP  = 0.30;   // meters between stored points
const TRAIL_LIFE  = 14.0;   // seconds until a track is fully gone
const TRAIL_RIB   = 1.9;    // ribbon half-width / tire half-width (room for the side berms)
const TRAIL_LIFT  = 0.07;   // meters above the analytic terrain (terrain mesh is a coarse grid)
const TRAIL_SLIP_GAIN = 3.0;// how strongly turning (rad per meter) counts as sliding when no slide is given
const TRAIL_REBASE = 1700;  // distance counter wrap (multiple of every pattern period, keeps float precision)

/* ---- tileable sand-grain noise (r,g,b = 3 independent noises) ---- */
function makeSandNoiseTexture(){
  const N=128;
  const cv=document.createElement('canvas'); cv.width=N; cv.height=N;
  const g=cv.getContext('2d');
  const img=g.createImageData(N,N), d=img.data;
  function rng(seed){ return function(){ seed|=0; seed=seed+0x6D2B79F5|0; let t=Math.imul(seed^seed>>>15,1|seed); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
  function lattice(cells,seed){ const r=rng(seed), a=new Float32Array(cells*cells); for(let i=0;i<a.length;i++) a[i]=r(); return a; }
  function smp(a,cells,u,v){
    const x=u*cells, y=v*cells, x0=Math.floor(x), y0=Math.floor(y);
    let fx=x-x0, fy=y-y0; fx=fx*fx*(3-2*fx); fy=fy*fy*(3-2*fy);
    const xa=((x0%cells)+cells)%cells, xb=(xa+1)%cells, ya=((y0%cells)+cells)%cells, yb=(ya+1)%cells;
    const top=a[ya*cells+xa]*(1-fx)+a[ya*cells+xb]*fx;
    const bot=a[yb*cells+xa]*(1-fx)+a[yb*cells+xb]*fx;
    return top*(1-fy)+bot*fy;
  }
  for(let c=0;c<3;c++){
    const o1=lattice(8,101+c*17), o2=lattice(16,202+c*31), o3=lattice(32,303+c*43);
    for(let y=0;y<N;y++) for(let x=0;x<N;x++){
      const u=x/N, v=y/N;
      let n=0.50*smp(o1,8,u,v)+0.30*smp(o2,16,u,v)+0.20*smp(o3,32,u,v);
      n=Math.min(1,Math.max(0,(n-0.5)*1.6+0.5));
      d[(y*N+x)*4+c]=(n*255)|0;
    }
  }
  for(let i=0;i<N*N;i++) d[i*4+3]=255;
  g.putImageData(img,0,0);
  const tex=new THREE.CanvasTexture(cv);
  tex.wrapS=tex.wrapT=THREE.RepeatWrapping;
  tex.colorSpace=THREE.NoColorSpace;      // data texture, not a color
  tex.anisotropy=4;
  return tex;
}
const treadTex=makeSandNoiseTexture();

const trailMat=new THREE.ShaderMaterial({
  transparent:true, depthWrite:false, side:THREE.DoubleSide, fog:true,
  /* multiplicative blend: result = shader output * what is already on screen.
     The track darkens / brightens the real terrain instead of painting over it. */
  blending:THREE.CustomBlending, blendEquation:THREE.AddEquation,
  blendSrc:THREE.DstColorFactor, blendDst:THREE.ZeroFactor,
  blendSrcAlpha:THREE.ZeroFactor, blendDstAlpha:THREE.OneFactor,
  polygonOffset:true, polygonOffsetFactor:-3, polygonOffsetUnits:-3,
  uniforms:THREE.UniformsUtils.merge([ THREE.UniformsLib.fog, {
    uTex:{value:treadTex},
    uColor:{value:new THREE.Color(0.40,0.33,0.26)},   // multiplier in deep shadow / compressed sand
    uLight:{value:new THREE.Color(1.26,1.19,1.06)},   // multiplier on the sunlit wall / berm
    uSun:{value:sunDir},                               // shared with the game: always in sync
    uOpacity:{value:0.92},
    uTime:{value:0},
    uLife:{value:TRAIL_LIFE},
    uBump:{value:2.6}                                  // relief exaggeration (higher = deeper looking tracks)
  }]),
  vertexShader:`
    attribute vec4 aData;   // x: strength*fades, y: birth time, z: slide 0..1, w: speed 0..1
    varying vec2 vUv; varying vec3 vW; varying vec3 vRel; varying vec4 vD;
    #include <fog_pars_vertex>
    void main(){
      vUv=uv; vD=aData;
      vec4 wp=modelMatrix*vec4(position,1.0);
      vW=wp.xyz;                       // absolute: noise lookups only
      vRel=wp.xyz-cameraPosition;      // camera relative: keeps derivatives precise far from the origin
      vec4 mvPosition=viewMatrix*wp;
      gl_Position=projectionMatrix*mvPosition;
      #include <fog_vertex>
    }`,
  fragmentShader:`
    uniform sampler2D uTex; uniform vec3 uColor; uniform vec3 uLight; uniform vec3 uSun;
    uniform float uOpacity, uTime, uLife, uBump;
    varying vec2 vUv; varying vec3 vW; varying vec3 vRel; varying vec4 vD;
    #include <fog_pars_fragment>
    const float CORE=0.56;   // fraction of ribbon half-width covered by the tire itself

    void main(){
      float age=clamp((uTime-vD.y)/uLife,0.0,1.0);
      float fade=vD.x*(1.0-smoothstep(0.72,1.0,age));
      float slide=vD.z, spd=vD.w;
      float x=vUv.x*2.0-1.0, ax=abs(x), v=vUv.y;

      vec3 nA=texture2D(uTex, vW.xz*0.35).rgb;   // broad wobble
      vec3 nB=texture2D(uTex, vW.xz*2.10).rgb;   // fine grain
      float erosion=pow(1.0-age,1.25);           // wind slowly fills the track

      /* ---- height profile (meters-ish) ---- */
      float edge=ax+(nA.r-0.5)*(0.10+0.16*slide);              // ragged edge, rougher when sliding
      float soft=0.10+0.18*age;                                // wind softens the shoulders
      float bowl=1.0-smoothstep(CORE-soft, CORE+soft*0.6, edge);
      float bermC=CORE+0.17+0.04*slide;
      float bermW=0.11+0.08*age;
      float berm=exp(-pow((edge-bermC)/bermW,2.0));
      berm*=(0.55+0.90*slide+0.35*spd)*(0.70+0.60*nA.g);       // lumpy, bigger when sliding / fast
      float clods=(nB.r-0.5)*0.010*berm;                       // crumbly sand thrown up on the berm

      // chevron tread pressed into the bottom of the track
      float pitch=0.085;
      float ph=v/pitch+ax*1.6;
      float aliasFade=1.0-smoothstep(0.35,0.80,fwidth(ph));    // no shimmering far away
      float f=fract(ph);
      float lug=smoothstep(0.0,0.14,f)*(1.0-smoothstep(0.52,0.66,f));
      lug*=smoothstep(0.06,0.14,ax)*(1.0-smoothstep(CORE-0.12,CORE-0.02,ax));
      float treadVis=(1.0-smoothstep(0.10,0.65,age))*(1.0-0.85*slide)*aliasFade;

      // sliding wheels: smeared streaks along the track + washboard ripples when digging
      float streak=texture2D(uTex, vec2(ax*0.9, v*0.12)).b;
      float ripple=0.5+0.5*sin(v*25.1327+nA.b*3.0);            // 25.13 = 2*pi / 0.25 m
      float rippleAmt=smoothstep(0.55,1.0,slide)*(1.0-smoothstep(0.35,0.7,age));

      float h = erosion*( -0.035*bowl*(1.0+0.5*slide) + 0.022*berm + clods
                          -0.014*lug*bowl*treadVis
                          -0.012*slide*streak*bowl
                          -0.007*rippleAmt*ripple*bowl );
      h += (nB.g-0.5)*0.004*(bowl+berm)*(0.4+erosion);         // sand grain

      /* ---- bump-mapped normal (orientation independent, relative to the draped ribbon) ---- */
      vec3 dpx=dFdx(vRel), dpy=dFdy(vRel);
      vec3 N=normalize(cross(dpx,dpy)); if(N.y<0.0) N=-N;
      float dhx=dFdx(h), dhy=dFdy(h);
      vec3 r1=cross(dpy,N), r2=cross(N,dpx);
      float det=dot(dpx,r1);
      vec3 grad=sign(det)*(dhx*r1+dhy*r2);
      vec3 Nb=normalize(abs(det)*N-uBump*grad);

      /* ---- shading factors (relative to the ground the track lies on) ---- */
      vec3 L=normalize(uSun);
      float sunFac=smoothstep(-0.05,0.35,dot(N,L));            // faces away from the sun: less contrast
      float lit=clamp((dot(Nb,L)-dot(N,L))*2.4,-1.0,1.0)*(0.35+0.65*sunFac);
      float ao=bowl*erosion*(0.30+0.25*(1.0-smoothstep(0.0,0.5,ax)));
      float compress=bowl*erosion*0.20;                        // compacted sand reads slightly darker
      float dA=clamp(clamp(-lit,0.0,1.0)*0.60+ao+compress,0.0,0.88);
      float lA=clamp(lit,0.0,1.0)*0.50;

      #ifdef USE_FOG
        #ifdef FOG_EXP2
          float fogF=1.0-exp(-fogDensity*fogDensity*vFogDepth*vFogDepth);
        #else
          float fogF=smoothstep(fogNear,fogFar,vFogDepth);
        #endif
      #else
        float fogF=0.0;
      #endif
      float amt=fade*uOpacity*(1.0-fogF)*(1.0-smoothstep(0.82,1.0,ax));   // soft ribbon edge, melts into fog

      if(amt<0.01 || dA+lA<0.004) discard;
      vec3 k=mix(vec3(1.0),uColor,clamp(dA*amt,0.0,1.0))*mix(vec3(1.0),uLight,clamp(lA*amt,0.0,1.0));
      gl_FragColor=vec4(k,1.0);
    }`
});

/* UniformsUtils.merge() clones values: re-link the shared sun vector and the one noise texture */
trailMat.uniforms.uSun.value=sunDir;
trailMat.uniforms.uTex.value=treadTex;

class TireTrail{
  constructor(halfWidth){
    this.halfWidth=halfWidth;
    this.pts=[]; this.dist=0; this.dirty=false; this.lifted=false;
    this.pos=new Float32Array(TRAIL_PTS*2*3);
    this.uvs=new Float32Array(TRAIL_PTS*2*2);
    this.dat=new Float32Array(TRAIL_PTS*2*4);
    const idx=new Uint16Array((TRAIL_PTS-1)*6);
    for(let i=0;i<TRAIL_PTS-1;i++){
      const a=i*2,b=i*2+1,c=(i+1)*2,e=(i+1)*2+1;
      idx[i*6+0]=a; idx[i*6+1]=c; idx[i*6+2]=b;
      idx[i*6+3]=b; idx[i*6+4]=c; idx[i*6+5]=e;
    }
    const geo=new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pos,3));
    geo.setAttribute('uv', new THREE.BufferAttribute(this.uvs,2));
    geo.setAttribute('aData', new THREE.BufferAttribute(this.dat,4));
    geo.setIndex(new THREE.BufferAttribute(idx,1));
    geo.setDrawRange(0,0);
    this.geo=geo;
    this.mesh=new THREE.Mesh(geo, trailMat);
    this.mesh.frustumCulled=false;
    this.mesh.renderOrder=2;
    scene.add(this.mesh);
  }
  clear(){ this.pts.length=0; this.dist=0; this.dirty=false; this.lifted=false; this.geo.setDrawRange(0,0); }

  /* wheel left the ground: end the current track with a short taper */
  lift(){
    if(this.lifted || !this.pts.length) return;
    this.pts[this.pts.length-1].cut=true;
    this.lifted=true; this.dirty=true;
  }

  push(x,y,z,rx,rz,strength,slide,speed,load){
    let last=this.pts[this.pts.length-1];
    let d=0, gap=false;
    if(last){
      d=Math.hypot(x-last.x, z-last.z);
      if(d<TRAIL_STEP) return false;
      if(d>8){ this.clear(); last=undefined; d=0; }        // teleport / respawn: don't stretch a ribbon across the map
    }
    if(!last){ this.dist=0; gap=true; }
    if(this.lifted){ gap=true; this.lifted=false; }        // touchdown after a jump: fresh track

    /* speed (m/s): given by the caller, else measured from time between points */
    let sp=speed;
    if(sp===undefined || sp===null){
      const dt = last ? elapsed-last.t : 0;
      sp = (last && dt>1e-4) ? d/dt : 0;
    }

    /* curvature of the previous point (turning = sliding), computed once when its successor arrives */
    if(last){
      const pp=this.pts[this.pts.length-2];
      if(pp){
        const h1=Math.atan2(last.z-pp.z,last.x-pp.x), h2=Math.atan2(z-last.z,x-last.x);
        let dh=h2-h1; dh=Math.atan2(Math.sin(dh),Math.cos(dh));
        last.cv=Math.abs(dh)/Math.max(0.05,(Math.hypot(x-pp.x,z-pp.z))*0.5);
      }
    }

    /* drape on the terrain: height under the tire and at both edges */
    const hw0=this.halfWidth*TRAIL_RIB*1.15;
    const haveT=(typeof terrainH==='function');
    const yc=(y!==undefined && y!==null && isFinite(y)) ? y : (haveT ? terrainH(x,z) : 0);
    const yl=haveT ? terrainH(x-rx*hw0, z-rz*hw0) : yc;
    const yr=haveT ? terrainH(x+rx*hw0, z+rz*hw0) : yc;

    if(last) this.dist+=d;
    if(this.dist>TRAIL_REBASE){                            // keep distance small (float precision); period-safe
      for(const q of this.pts) q.dist-=TRAIL_REBASE;
      this.dist-=TRAIL_REBASE;
    }
    this.pts.push({x,z,rx,rz,yc,yl,yr,hw0,t:elapsed,dist:this.dist,
                   s:strength, sl:slide||0, sp, ld:(load===undefined||load===null)?1:load,
                   cv:undefined, cut:false, gap});
    if(this.pts.length>TRAIL_PTS) this.pts.shift();
    this.dirty=true;
    return true;
  }

  update(){
    trailMat.uniforms.uTime.value=elapsed;
    const P=this.pts;
    while(P.length && elapsed-P[0].t>TRAIL_LIFE){ P.shift(); this.dirty=true; }
    if(!this.dirty) return;                          // geometry only rebuilds when points change
    this.dirty=false;
    const m=P.length;
    if(m<2){ this.geo.setDrawRange(0,0); return; }

    const vref=(typeof VMAX!=='undefined')?VMAX:30;
    const hw=this.halfWidth*TRAIL_RIB;
    for(let i=0;i<m;i++){
      const p=P[i], i6=i*6, i4=i*4, i8=i*8;
      const cv = p.cv!==undefined ? p.cv : (i>0 && P[i-1].cv!==undefined ? P[i-1].cv : 0);
      const slide=Math.min(1, Math.max(p.sl, cv*TRAIL_SLIP_GAIN*0.5));
      const spd=Math.min(1, Math.abs(p.sp)/vref);
      const w=hw*(1+0.18*slide+0.12*spd);            // fast / sliding wheels spread more sand
      const k=Math.min(1.5, w/p.hw0);                // extrapolate the cross-slope to the actual width
      const yL=p.yc+(p.yl-p.yc)*k+TRAIL_LIFT;
      const yR=p.yc+(p.yr-p.yc)*k+TRAIL_LIFT;
      this.pos[i6+0]=p.x-p.rx*w; this.pos[i6+1]=yL; this.pos[i6+2]=p.z-p.rz*w;
      this.pos[i6+3]=p.x+p.rx*w; this.pos[i6+4]=yR; this.pos[i6+5]=p.z+p.rz*w;
      this.uvs[i4+0]=0; this.uvs[i4+1]=p.dist;       // v = meters along the track
      this.uvs[i4+2]=1; this.uvs[i4+3]=p.dist;
      const endFade=Math.min(Math.pow(i/(m-1),0.55)*1.6, 1);            // oldest end tapers out
      const cutFade=(p.cut||p.gap)?0:1;                                 // taper where the wheel left / touched the ground
      const load=0.55+0.45*Math.min(p.ld,1);                            // light wheel = shallow track
      const str=Math.min(1.2,(p.s||1))*load*endFade*cutFade;
      for(let q=0;q<2;q++){
        const o=i8+q*4;
        this.dat[o+0]=str; this.dat[o+1]=p.t; this.dat[o+2]=slide; this.dat[o+3]=spd;
      }
    }
    this.geo.attributes.position.needsUpdate=true;
    this.geo.attributes.uv.needsUpdate=true;
    this.geo.attributes.aData.needsUpdate=true;
    this.geo.setDrawRange(0,(m-1)*6);
  }
}
const tireTrails = wheels.map(()=>new TireTrail(0.18));
