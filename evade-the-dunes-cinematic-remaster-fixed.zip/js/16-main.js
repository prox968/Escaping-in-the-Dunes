/* Main loop and boot */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- main loop ---------------- */
let last=performance.now();
/* ---- cinematic slow motion: hold R while airborne ----
   The world runs on dt=rdt*timeScale (worms, particles, physics all slow down);
   the camera and HUD run on real time, so look controls stay responsive.
   Budget + cooldown prevent abuse; timeScale is always restored. */
const SLOWMO_SCALE=0.35, SLOWMO_BUDGET=2.6, SLOWMO_CD=4;
let slowMoBudget=SLOWMO_BUDGET, slowMoCd=0;
let slowMoActive=false;
function updateSlowMo(rdt){
  /* the death sequence owns timeScale while we're dead (slow-mo into the wreck) */
  if(gameState==='dead'){ slowMoActive=false; return; }
  slowMoCd-=rdt;
  const airborne = gameState==='play' && player.alive && !player.grounded && (player.airT||0)>0.08;
  const want = airborne && keys.KeyR && slowMoCd<=0 && slowMoBudget>0;
  slowMoActive=want;
  const target = want ? SLOWMO_SCALE : 1;
  timeScale += (target-timeScale)*Math.min(1, 9*rdt);   // smooth in and out
  if(timeScale<0.995){
    slowMoBudget=Math.max(0, slowMoBudget - rdt*timeScale);
    if(slowMoBudget<=0) slowMoCd=SLOWMO_CD;
  } else if(player.grounded){
    slowMoBudget=Math.min(SLOWMO_BUDGET, slowMoBudget + rdt*0.9);   // recharges on the ground
  }
}
function loop(){
  requestAnimationFrame(loop);
  const now=performance.now();
  const rdt=Math.min((now-last)/1000,0.05); last=now;
  /* If the Settings panel OR the pause menu is open, freeze the
     simulation but keep the camera + audio running so the scene looks
     alive in the background. The user can still drag a slider and see
     live changes (bloom strength, lens ghosts, etc.) thanks to
     onGraphicsLiveChange() in 17-graphics.js. */
  const settingsOpen = !!(window.settingsOpen);
  const paused = !!(window.paused);
  const freeze = settingsOpen || paused;
  updateSlowMo(rdt);
  const dt=rdt*timeScale;
  if(gameState==='play' && !freeze) elapsed+=dt;
  difficulty.aggr=clamp(elapsed/100,0,1);
  if(gameState!=='title' && !freeze){
    setPOwner(P_JEEP, 1.4);
    updatePlayer(dt);
    updateSuspension(dt);
    setPOwner(0);
    updateAntenna(dt);
  } else if(gameState!=='title' && freeze){
    /* keep the suspension + antenna idling so the jeep doesn't look frozen */
    updateSuspension(dt);
    updateAntenna(dt);
  } else {
    noiseLevel=0; attention=Math.max(0,attention-0.3*dt);
    updateSuspension(dt);
    updateAntenna(dt);
  }
  if(!freeze){
    updateWorms(dt);
    updateDeathFx(dt, rdt);         // death sequence (slow-mo, fire, shatter) — owns the wreck transform
    updateThumper(dt);
    updateDigger(dt);
    updateThrow(dt, rdt);
    updateThumperPickups(dt);
    updateSpice(dt);
    updateRocks();
  }
  updateParticles(dt);
  if(window.__updateRealism) window.__updateRealism(dt, rdt);   // cinematic realism layer
  updateClouds(dt);
  updateShockwaves(dt);
  updateRings(dt);
  if(!freeze) updateEcology(dt);
  updateCarShadow();
  if(window.updateVehicleWear && !freeze) window.updateVehicleWear(dt);
  updateCamera(rdt);
  if(!freeze){
    updateChunks(player.pos.x,player.pos.z,3);
    processChunkRefresh(alpha.active?12:(giantOut?8:4), player.pos.x, player.pos.z);   // the alpha reshapes kilometres of sand
  }
  scene.fog.near = 55 + 160*alphaFog + 250*alphaCineW;
  scene.fog.far  = 470 + 1500*alphaFog + 900*alphaCineW;
  points.material.uniforms.uFar.value = 500 + 2000*alphaFog;
  viewR = alphaFog>0.04 ? VIEW_MAX : VIEW;
  if(!freeze) updateFarGround(rdt);
  sun.position.copy(player.pos).addScaledVector(sunDir,300);
  sun.target.position.copy(player.pos);
  sky.position.copy(camera.position);
  if(gameState==='play'&&!freeze&&thumperCount<3){
    thumpRegenT+=dt;
    if(thumpRegenT>40){ thumpRegenT=0; thumperCount++; showMsg('THUMPER RECOVERED — PRESS E',2); }
  } else if(thumperCount>=3) thumpRegenT=0;
  updateHUD(rdt);
  updateAudio();
  if(gameState==='dead'&&!overShown&&now-deathReal>deathOverlayMs){
    overShown=true;
    $('over').classList.remove('hidden');
    document.body.classList.add('cinema');
  }
  /* graphics hook: lens flare position + composer render path */
  if(window.updateGraphics) window.updateGraphics(rdt);
  if(window.renderScene) window.renderScene();
  else renderer.render(scene,camera);
}
addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
  particleUniforms.uViewportH.value=innerHeight;
  /* keep post-processing render targets in sync */
  if(window.resizeGraphics) window.resizeGraphics(innerWidth, innerHeight);
});
carRoot.position.copy(player.pos);
carRoot.quaternion.setFromEuler(_e.set(0, player.heading, 0, 'YXZ'));
loop();
