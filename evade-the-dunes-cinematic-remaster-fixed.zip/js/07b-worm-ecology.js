/* Worm ecology: small curious worms, roaming giants, and the spawn director */
/* Loaded after 07-worms.js — relies on its globals (Worm, wormHideTex, swell, etc.). */

/* ---- pale & red hide variants for the small species ----
   Same weathered grey hide set as the default worms (02-textures.js),
   re-tinted. These are the clone sources, so they carry the normal and
   roughness maps, the baked vertex colours and the double-sided flags. */
const paleSkinMat=new THREE.MeshPhysicalMaterial({color:0xcfc7b6, map:wormHideTex,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.25,1.25),
  roughness:1.0, roughnessMap:wormHideMaps.rmap, sheen:0.12, sheenColor:new THREE.Color(0xcfc3ab),
  sheenRoughness:0.92, clearcoat:0.06, clearcoatRoughness:0.94, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.45});
const paleHeadMat=new THREE.MeshPhysicalMaterial({color:0xc5bba4, map:wormHideTex,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.35,1.35),
  roughness:1.0, roughnessMap:wormHideMaps.rmap, sheen:0.14, sheenColor:new THREE.Color(0xcfc3ab),
  sheenRoughness:0.9, clearcoat:0.08, clearcoatRoughness:0.92, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.5});
const redSkinMat =new THREE.MeshPhysicalMaterial({color:0x6e1d12, map:wormHideTex,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.25,1.25),
  roughness:1.0, roughnessMap:wormHideMaps.rmap, sheen:0.10, sheenColor:new THREE.Color(0xff9a6a),
  sheenRoughness:0.92, clearcoat:0.08, clearcoatRoughness:0.92, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.5});
const redHeadMat =new THREE.MeshPhysicalMaterial({color:0x5f180d, map:wormHideTex,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.35,1.35),
  roughness:1.0, roughnessMap:wormHideMaps.rmap, sheen:0.12, sheenColor:new THREE.Color(0xff9a6a),
  sheenRoughness:0.9, clearcoat:0.10, clearcoatRoughness:0.9, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.55});

/* per-worm variants: fresh clones of the source materials with a brightness
   jitter, so every worm of a species gets its own tint (the clones are the
   materials actually mounted on the geometry at construction time). */
function smallMats(aggro, hv){
  const skin=(aggro?redSkinMat:paleSkinMat).clone();
  const head=(aggro?redHeadMat:paleHeadMat).clone();
  skin.color.multiplyScalar(hv); head.color.multiplyScalar(hv);
  return { skin, head, brush:brushMat,
           plate:wormPlateMat, ridge:wormRidgeMat, maw:mawMat, throat:throatMat, tooth:toothMat };
}
function giantMats(hv){
  const skin=wormSkinMat.clone(), head=wormHeadMat.clone();
  skin.color.setHex(0x857e70).multiplyScalar(hv);
  head.color.setHex(0x7d766a).multiplyScalar(hv);
  return { skin, head, brush:brushMat,
           plate:wormPlateMat, ridge:wormRidgeMat, maw:mawMat, throat:throatMat, tooth:toothMat };
}

/* Shared tail of the per-frame body work (mirrors the end of Worm.update) —
   motion vector, head orientation, trail, body placement, sand contact FX,
   ground shadow and the proximity contribution used by audio/HUD. */
function commonWormTail(w, dt, act){
  _v5.copy(w.pos).sub(w.prevPos);
  if(_v5.lengthSq()>1e-6) w.moveDir.copy(_v5).normalize();
  w.prevPos.copy(w.pos);
  /* damped head look direction so the head doesn't snap or jitter */
  if(!w.headLook) w.headLook = new THREE.Vector3(w.dir.x, 0, w.dir.z).normalize();
  const tgt = _v7.set(w.moveDir.x, clamp(w.moveDir.y,-0.97,0.97), w.moveDir.z);
  if(!w.inAir) tgt.y=clamp(tgt.y,-0.85,0.85);
  if(tgt.lengthSq()<1e-4) tgt.set(w.dir.x,0,w.dir.z);
  tgt.normalize();
  w.headLook.lerp(tgt, Math.min(1, 8*dt)).normalize();
  _v6.copy(w.headLook);
  w.head.position.copy(w.pos);
  w.head.lookAt(_v6.add(w.pos));
  w.head.rotateZ(w.headSpin||0);
  const td=w.head.userData;
  if(td.brush){
    td.brush.rotation.z+=dt*(0.22+0.10*Math.sin(elapsed*0.7+w.phase));
    const brB=1+Math.sin(elapsed*2.6+w.phase)*0.02;
    td.brush.scale.set(brB,brB,1);
  }

  const T=w.trail, h0=T[0];
  if(!h0 || (h0.x-w.pos.x)**2+(h0.y-w.pos.y)**2+(h0.z-w.pos.z)**2>2.0){
    T.unshift({x:w.pos.x,y:w.pos.y,z:w.pos.z});
    if(T.length>420) T.pop();
  }
  w.placeBody(dt);
  w.plowSand(dt);
  w.updateSwell(dt);
  w.swimWall(dt);
  if(w._pd===undefined) w._pd=w.depth;
  const dRate=Math.abs(w.depth-w._pd)/Math.max(dt,1e-3);
  if(dRate>4&&w.spd>3&&!w.inAir) w.depthSplash(Math.min(dRate,28));
  w._pd=w.depth;

  const gY=terrainH(w.pos.x,w.pos.z);
  const depthRatio=clamp(1-w.depth/(w.headR*2.8),0,1);
  const showShadow=depthRatio>0.05;
  w.shadowGroup.visible=showShadow;
  if(showShadow){
    w.shadowGroup.position.set(w.pos.x, gY+0.11, w.pos.z);
    w.shadowGroup.rotation.y=Math.atan2(w.dir.x,w.dir.z);
    const s=w.headR*(1.1+0.9*depthRatio);
    w.shadowMesh.scale.set(s*0.9, s*2.4, 1);
    w.shadowMesh.material.opacity=0.6*depthRatio;
  }
  const prox=clamp(1-horizDist(w.pos,player.pos)/330,0,1);
  const dv=clamp(1-w.depth/(w.headR*4.3),0,1);
  w.nearContrib=prox*act*(0.25+0.75*dv);
  w.swimLvl=act*(0.25+0.75*dv);
}
/* boost check without touching player internals */
function P_boosting(){ return player.boost>0; }

/* ================================================================
   SMALL WORMS - wildlife, not hunters (mostly)
   Pale ones are curious: they surface and watch the jeep when it is
   quiet, and dive away the moment it becomes threatening. The dark-
   red variant belongs to an aggressive species that strikes from
   below once it has worked up the nerve to approach.
   ================================================================ */
class SmallWorm extends Worm{
  constructor(idx, aggro){
    const hv = 0.88 + Math.random()*0.24;      // per-worm tint, applied at build time
    super(idx, {S:0.30, N:16, mats:smallMats(aggro, hv)});
    this.tier='small'; this.aggro=!!aggro;
    this.headLook = new THREE.Vector3(this.dir.x, 0, this.dir.z).normalize();
  }
  reset(dist){
    const a=Math.random()*Math.PI*2;
    this.pos.set(player.pos.x+Math.cos(a)*dist, 0, player.pos.z+Math.sin(a)*dist);
    this.dir.set(-Math.cos(a),0,-Math.sin(a)); this.moveDir.copy(this.dir);
    this.depth=this.headR*8; this.spd=6; this.state='lurk'; this.stateT=0;
    this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
    this.trail.length=0;
    for(let k=120;k>=0;k--){
      const bx=this.pos.x-this.dir.x*k*0.9, bz=this.pos.z-this.dir.z*k*0.9;
      this.trail.unshift({x:bx, y:terrainH(bx,bz)-this.depth, z:bz});
    }
    this.prevPos.copy(this.pos);
    this.nearContrib=0; this.segDust.fill(0); this._pd=this.depth;
    this.wallAcc=0; this.plowAcc3=0;
    if(this.group) this.group.visible=false;
    if(this.shadowGroup) this.shadowGroup.visible=false;
  }
  update(dt){
    this.stateT+=dt;
    const dP=horizDist(this.pos,player.pos);
    const quiet=attention<0.30 && noiseLevel<0.5;

    if(this.state==='lurk'){
      this.clearSwell();
      this.group.visible=false; this.shadowGroup.visible=false;
      this.spd+=(4-this.spd)*Math.min(1,dt);
      this.wanderT=(this.wanderT||0)-dt;
      if(this.wanderT<=0){
        this.wanderT=4+Math.random()*4;
        const a=Math.random()*Math.PI*2;
        this.wander.set(player.pos.x+Math.cos(a)*(dP*0.9), 0, player.pos.z+Math.sin(a)*(dP*0.9));
      }
      this.steerToward(this.wander,0.5,dt,0.2);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      if(alpha.active || activeGiant()){ this.removeMe=true; return; }
      if(quiet && this.stateT>4 && dP<170 && Math.random()<dt*0.5){
        this.state='curious'; this.stateT=0;
        this.group.visible=true;
        this.depthSplash(8);
      }
      this.nearContrib=0; return;
    }

    if(this.state==='curious'){
      /* rise so the head breaks the sand, then creep closer and watch */
      this.depth+=(this.headR*0.55-this.depth)*Math.min(1,2.2*dt);
      this.spd+=(7-this.spd)*Math.min(1,1.5*dt);
      if(dP>26){
        _v3.set(player.pos.x,0,player.pos.z);
        this.steerToward(_v3,0.7,dt,0.35);
      } else {
        /* respectful circling: it keeps its distance and watches */
        _v3.set(-this.dir.z,0,this.dir.x);
        if((this.phase|0)%2) _v3.negate();
        this.dir.lerp(_v3,Math.min(1,0.25*dt)).normalize();
      }
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,6,0.5);
      const scared = attention>0.42 || noiseLevel>0.55 || dP<12 || P_boosting();
      const aggressiveNow = this.aggro && dP<30 && attention>0.3;
      if(aggressiveNow){
        this.state='strike'; this.stateT=0;
        /* the red species keeps its hair-trigger, but now warns with one small,
           high, positional pressure tick from its real position */
        spawnRing(this.pos,this.headR*1.4,0.5);
        wormPressureSfx(this.pos,0.55,(this.voicePitch||1)*1.2);
      }
      else if(scared || alpha.active || activeGiant() || this.stateT>26){
        this.state='retreat'; this.stateT=0;
        this.diveFunnel();
      }
    }
    else if(this.state==='strike'){
      /* the red species: a fast rush, then a breach beneath the jeep */
      const tx=player.pos.x+player.vel.x*0.7, tz=player.pos.z+player.vel.z*0.7;
      this.depth+=(this.headR*1.1-this.depth)*Math.min(1,3*dt);
      this.spd+=(30-this.spd)*Math.min(1,2.5*dt);
      _v3.set(tx,0,tz);
      this.steerToward(_v3,2.2,dt,0.1);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,16,0.6);
      const dd=horizDist(this.pos,player.pos);
      if(dd<this.headR+2.6 || this.stateT>2.6){
        this.pos.set(player.pos.x+(Math.random()-0.5)*3, 0, player.pos.z+(Math.random()-0.5)*3);
        this.pos.y=terrainH(this.pos.x,this.pos.z);
        this.depthSplash(20);
        addDeform(this.pos.x,this.pos.z,this.headR*4,0.9);
        spawnGroundShockwave(this.pos.x,this.pos.z,this.headR*6,0.7);
        burstDustClassic(this.pos,20,7);
        shake=Math.max(shake,0.28);
        wobble=Math.max(wobble,0.7*clamp(1-horizDist(this.pos,player.pos)/90,0.15,1));
        if(horizDist(this.pos,player.pos)<this.headR+3 && player.alive) hitPlayer(9,this.pos,'lesser');
        this.state='retreat'; this.stateT=0; this.diveFunnel();
      }
    }
    else if(this.state==='retreat'){
      /* dive away: small funnel of collapsed sand where it went down */
      this.depth+=(this.headR*8-this.depth)*Math.min(1,1.8*dt);
      _v3.set(this.pos.x-player.pos.x,0,this.pos.z-player.pos.z);
      if(_v3.lengthSq()<1) _v3.set(1,0,0);
      this.dir.lerp(_v3.normalize(),Math.min(1,1.2*dt)).normalize();
      this.spd+=(24-this.spd)*Math.min(1,1.5*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,10,0.5);
      if(this.stateT>3){ this.removeMe=true; return; }
    }

    commonWormTail(this, dt, this.state==='curious'?0.6:0.3);
  }
  /* tiny collapse crater + dust where it dives */
  diveFunnel(){
    addDeform(this.pos.x,this.pos.z,this.headR*5,0.7);
    spawnRing(this.pos,this.headR*4,0.6);
    burstDustClassic(this.pos,10,4);
  }
}

/* ================================================================
   GIANT WORMS - a roaming force of nature, ~430 m of muscle
   persona 'swim': surfaces with ~60% of its maw exposed and swims a
     lazy, independent line that only loosely bends toward the jeep.
     After 20-25 s it leaves, collapsing a funnel of sand behind it.
   persona 'jump': hunts deep underground with enormous deformations,
     erupting beneath the jeep up to three times before retreating.
   ================================================================ */
class GiantWorm extends Worm{
  constructor(idx, persona){
    const hv = 0.85 + Math.random()*0.3;
    super(idx, {S:6.5, N:28, mats:giantMats(hv)});
    this.tier='giant'; this.persona=persona;
    this.headLook = new THREE.Vector3(this.dir.x, 0, this.dir.z).normalize();
  }
  reset(dist){
    const a=Math.random()*Math.PI*2;
    this.pos.set(player.pos.x+Math.cos(a)*dist, 0, player.pos.z+Math.sin(a)*dist);
    this.dir.set(-Math.cos(a),0,-Math.sin(a)); this.moveDir.copy(this.dir);
    this.depth=this.headR*7; this.spd=35; this.state='approachG'; this.stateT=0;
    this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
    this.trail.length=0;
    for(let k=300;k>=0;k--){
      const bx=this.pos.x-this.dir.x*k*1.5, bz=this.pos.z-this.dir.z*k*1.5;
      this.trail.unshift({x:bx, y:terrainH(bx,bz)-this.depth, z:bz});
    }
    this.prevPos.copy(this.pos);
    this.nearContrib=0; this.segDust.fill(0); this._pd=this.depth;
    this.wallAcc=0; this.plowAcc3=0;
    this.group.visible=false; this.shadowGroup.visible=false;
    this.breachCount=0; this.defT=0; this.gWanderT=0;
    this.wakeAcc=0; this.gDist=0; this.gYaw0=null;
    if(this.persona==='swim'){ this.swimDur=20+Math.random()*5; }
    else { this.huntDur=13; this.breachT=2.2+Math.random(); }
  }
  update(dt){
    this.stateT+=dt;
    const dP=horizDist(this.pos,player.pos);

    /* the alpha outranks everything: giants go quiet and sink away */
    if(alpha.active && this.state!=='leaveG' && this.state!=='approachG'){
      this.state='leaveG'; this.stateT=0;
    }

    if(this.state==='approachG'){
      /* still deep, closing distance; a distant swell announces it */
      /* underground it is a little slower than the jeep */
      this.spd+=(GIANT_DIG_SPD-this.spd)*Math.min(1,dt);
      _v3.set(player.pos.x,0,player.pos.z);
      this.steerToward(_v3,0.5,dt,0.4);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,8,3);
      this.giantWake(dt,'deep');
      if(dP<300 || this.stateT>14){
        this.group.visible=true;
        this.state = this.persona==='swim' ? 'swim' : 'stalk';
        this.stateT=0; this.gDist=0; this.gYaw0=Math.atan2(this.dir.x,this.dir.z);
        this.depthSplash(30);
        roar(horizDist(this.pos,player.pos), true, GIANT_PITCH);
        showMsg(this.persona==='swim' ? 'SOMETHING VAST IS SWIMMING NEAR' : 'THE GROUND REMEMBERS ITS WEIGHT',2.6);
      }
      commonWormTail(this, dt, 0.3); return;
    }

    if(this.state==='swim'){
      /* ~60% of the maw rides above the sand; lazy independent wandering
         with only a loose drift toward the jeep - wildlife, not a missile */
      /* swimming it is a little slower than the jeep. Heading and depth follow the
         distance travelled (not the clock), so the body, which retraces the head's path,
         rolls through long smooth S-bends and low swells instead of wobbling */
      const hr=this.headR;
      this.spd+=(GIANT_SWIM_SPD-this.spd)*Math.min(1,0.6*dt);
      this.gDist+=this.spd*dt;
      const ph=this.gDist/hr;
      /* the base heading drifts lazily toward the jeep (a few degrees a second), never locks on */
      _v4.set(player.pos.x-this.pos.x,0,player.pos.z-this.pos.z);
      const pd=_v4.length();
      let want=Math.atan2(_v4.x,_v4.z);
      if(pd<70) want+=Math.PI*0.5*Math.sign(Math.sin(this.phase)||1);   // too close: slide past
      let dy=want-this.gYaw0; dy=Math.atan2(Math.sin(dy),Math.cos(dy));
      this.gYaw0+=clamp(dy,-1,1)*(pd>140?0.09:0.03)*dt;
      const yaw=this.gYaw0+0.32*Math.sin(ph*2*Math.PI/22+this.phase)+0.08*Math.sin(ph*2*Math.PI/7.5+1.7);
      _v3.set(Math.sin(yaw),0,Math.cos(yaw));
      this.dir.lerp(_v3,Math.min(1,1.4*dt)).normalize();
      const dT=hr*(0.40+0.09*Math.sin(ph*2*Math.PI/14+this.phase)+0.03*Math.sin(ph*2*Math.PI/5.2));
      this.depth+=(dT-this.depth)*Math.min(1,1.3*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yT=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yT-this.pos.y)*Math.min(1,4*dt);
      /* a permanent wake: banks of sand shoved up on both flanks, a trough between */
      this.giantWake(dt,'swim');
      this.emitDust(dt,20,2.6);
      wobble=Math.max(wobble,0.16*clamp(1-dP/420,0,1));
      if(this.stateT>this.swimDur){ this.giantExit(); return; }
    }
    else if(this.state==='stalk'){
      /* the jumping weight: deep, fast, and the dunes roar about it */
      this.depth+=(this.headR*1.6-this.depth)*Math.min(1,1.8*dt);
      this.spd+=(GIANT_DIG_SPD-this.spd)*Math.min(1,1.4*dt);
      _v3.set(player.pos.x+player.vel.x*1.6,0,player.pos.z+player.vel.z*1.6);
      this.steerToward(_v3,1.5,dt,0.15);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yS=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yS-this.pos.y)*Math.min(1,5*dt);
      this.giantWake(dt,'stalk');
      this.emitDust(dt,24,2.4);
      wobble=Math.max(wobble,0.18*clamp(1-dP/380,0,1));
      this.breachT-=dt;
      if((this.breachT<=0 && dP<120) || this.stateT>this.huntDur || this.breachCount>=3){
        if(this.breachCount<3 && dP<130 && this.stateT<=this.huntDur){
          this.state='breach'; this.stateT=0; this.breachDone=false;
          this.jx=player.pos.x+player.vel.x*0.6; this.jz=player.pos.z+player.vel.z*0.6;
          if(!this.jv) this.jv=new THREE.Vector3();
        } else { this.state='leaveG'; this.stateT=0; this.diveFunnelG(); return; }
      }
    }
    else if(this.state==='breach'){
      /* It rushes up under where the jeep is heading, bursts out and leaps clean out of the
         sand at a steep angle (~75°), arcs over and plunges back in. The body pours out of
         the same hole after the head, so it really looks like it jumped off the floor. */
      const hr=this.headR;
      if(!this.breachDone){
        this.pos.x+=(this.jx-this.pos.x)*Math.min(1,6*dt);
        this.pos.z+=(this.jz-this.pos.z)*Math.min(1,6*dt);
        this.depth-=Math.max(60, this.depth*3)*dt;               // rising nearly straight up
        this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
        this.emitDust(dt,40,2.2);
        wobble=Math.max(wobble,0.4*clamp(1-dP/200,0,1));
        if(this.depth<=hr*0.15 || this.stateT>1.2){
          this.breachDone=true; this.breachCount++; this.inAir=true; this.jumpHit=false;
          const hs=14+Math.random()*5, vy=58+Math.random()*10;
          this.jv.set(this.dir.x*hs, vy, this.dir.z*hs);
          addDeform(this.pos.x,this.pos.z,hr*2.6,5.5);
          spawnGroundShockwave(this.pos.x,this.pos.z,hr*3.4,1.3);
          burstDustClassic(this.pos,140,28);
          spawnCloudCluster(_v1.set(this.pos.x,terrainH(this.pos.x,this.pos.z)+2,this.pos.z), 16, hr*1.1, 4, 10, 2.6, 4.4, 0.55, true);
          this.depthSplash(32);
          splashSfx(horizDist(this.pos,player.pos), this.pos, GIANT_PITCH, 1.25);
          shake=Math.max(shake,0.8);
          wobble=Math.max(wobble,1.0*clamp(1-horizDist(this.pos,player.pos)/200,0.12,1));
          if(horizDist(this.pos,player.pos)<hr*0.75+4 && player.alive){ hitPlayer(16,this.pos,'giant'); this.jumpHit=true; }
          else if(player.alive && dP<70) showMsg('IT IS BENEATH YOU',1.6);
        }
      } else {
        this.jv.y-=34*dt;
        this.pos.addScaledVector(this.jv,dt);
        const gy=terrainH(this.pos.x,this.pos.z);
        this.depth=gy-this.pos.y;
        if(this.depth>-hr*1.5) this.emitDust(dt,30,2.2);
        if(!this.jumpHit && player.alive && this.pos.distanceTo(player.pos)<hr+3){ this.jumpHit=true; hitPlayer(16,this.pos,'giant'); }
        if(this.jv.y<0 && this.depth>hr*0.7){
          /* back into the sand head-first */
          this.inAir=false;
          addDeform(this.pos.x,this.pos.z,hr*2.0,3.5);
          burstDustClassic(this.pos,90,22);
          spawnCloudCluster(_v1.set(this.pos.x,gy+1.5,this.pos.z), 12, hr*0.9, 3.5, 9, 2.2, 3.6, 0.5, false);
          this.depthSplash(28);
          splashSfx(horizDist(this.pos,player.pos), this.pos, GIANT_PITCH*0.95, 1.0);
          shake=Math.max(shake,0.5*clamp(1-dP/300,0,1));
          wobble=Math.max(wobble,0.7*clamp(1-horizDist(this.pos,player.pos)/180,0.12,1));
          if(this.breachCount>=3){ this.state='leaveG'; this.stateT=0; this.diveFunnelG(); return; }
          this.state='stalk'; this.stateT=Math.min(this.stateT,this.huntDur-4); this.breachT=3.6+Math.random();
        }
      }
    }
    else if(this.state==='leaveG'){
      /* sinks away with a last broad swell, then gone for good */
      /* eases down (no snap), the body following the head into the sand */
      this.depth+=(this.headR*8-this.depth)*Math.min(1,0.8*dt);
      this.spd+=(GIANT_DIG_SPD-this.spd)*Math.min(1,1.2*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yL=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yL-this.pos.y)*Math.min(1,4*dt);
      this.emitDust(dt,18,2);
      if(this.stateT>4.2){ this.removeMe=true; return; }
    }

    commonWormTail(this, dt, this.state==='swim'?1:0.8);
  }
  /* The giant reshapes the dunes continuously instead of stamping craters: every few metres
     it lays permanent wake bumps (shared spatial-hash layer with the alpha's wake).
     swim: banks on both flanks + a trough. stalk: a long raised ridge over its back.
     deep: a faint ridge while it closes in. */
  giantWake(dt, mode){
    const hr=this.headR;
    const step = mode==='swim' ? hr*0.7 : hr*0.85;
    this.wakeAcc=(this.wakeAcc||0)+this.spd*dt;
    if(this.wakeAcc<step) return;
    this.wakeAcc-=step;
    const T=this.trail, back=T[Math.min(T.length-1,Math.round(hr*1.1/1.41))]||this.pos;   // just behind the head
    const x=back.x, z=back.z, dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx;
    const v=0.85+0.3*Math.random();
    if(mode==='swim'){
      addWake(x, z, hr*1.05, -2.2*v);
      for(const sd of [-1,1]) addWake(x+px*sd*hr*1.45, z+pz*sd*hr*1.45, hr*1.1, 2.4*v);
      this.apron=!this.apron;
      if(this.apron) for(const sd of [-1,1]) addWake(x+px*sd*hr*2.6, z+pz*sd*hr*2.6, hr*1.5, 0.9*v);   // soft outer apron
      invalidateChunksNear(x,z,hr*4.2);
    } else if(mode==='stalk'){
      addWake(x, z, hr*1.9, 2.0*v);
      for(const sd of [-1,1]) addWake(x+px*sd*hr*2.4, z+pz*sd*hr*2.4, hr*1.3, -0.7*v);
      invalidateChunksNear(x,z,hr*4);
    } else {
      addWake(x, z, hr*1.7, 0.9*v);
      invalidateChunksNear(x,z,hr*2);
    }
  }
  /* the swimmer's goodbye: a broad funnel of collapsing sand */
  giantExit(){
    const x=this.pos.x, z=this.pos.z;
    const df=addBigDeform(x,z,this.headR*2.6,0); setBigDeformDepth(df,26);
    const rim=addBigDeform(x,z,this.headR*3.8,0); setBigDeformDepth(rim,-9);
    invalidateChunksNear(x,z,this.headR*4.5);
    spawnCloudCluster(_v1.set(x,terrainH(x,z)+3,z), 16, 6*this.S, 5, 13, 2.6, 4.4, 0.55, true);
    spawnCloudCluster(_v1.set(x,terrainH(x,z)+1,z), 10, 5*this.S, 4, 10, 2.2, 3.4, 0.46, false);
    burstDustClassic(this.pos,120,28);
    spawnGroundShockwave(x,z,this.headR*4,1.6);
    splashSfx(horizDist(this.pos,player.pos), this.pos, GIANT_PITCH, 1.25);
    shake=Math.max(shake,0.8);
    wobble=Math.max(wobble,0.9*clamp(1-horizDist(this.pos,player.pos)/220,0.1,1));
    this.state='leaveG'; this.stateT=0;
  }
  diveFunnelG(){
    const df=addBigDeform(this.pos.x,this.pos.z,this.headR*1.9,0); setBigDeformDepth(df,16);
    invalidateChunksNear(this.pos.x,this.pos.z,this.headR*3);
    burstDustClassic(this.pos,70,20);
    spawnGroundShockwave(this.pos.x,this.pos.z,this.headR*2.6,1.2);
  }
}

/* ================================================================
   ECOLOGY DIRECTOR - keeps the desert inhabited
   ================================================================ */
let ecoT=0, giantOut=false;
/* Pacing. Most of a run is spent escaping the regular worms; a giant is an occasional
   event (first one after ~2.5–3.5 min, then one every ~4–7 min); small worms are a rare
   sighting (first after 2–5 min, then every ~7–12 min). The alpha is rarer still. */
let giantNextT=0, smallNextT=0;
function resetEcology(){
  ecoT=0; giantOut=false;
  giantNextT=150+Math.random()*60;
  smallNextT=120+Math.random()*180;
}
resetEcology();
/* the giant: a little slower than the jeep, both swimming and underground */
const GIANT_SWIM_SPD=VMAX*0.87, GIANT_DIG_SPD=VMAX*0.93;     // slower than the jeep both ways
const GIANT_PITCH=0.62;                            // its sounds are pitched way down
function updateEcology(dt){
  if(gameState!=='play') return;
  ecoT-=dt;
  if(ecoT>0) return;
  ecoT=1;
  let smalls=0, giants=0;
  for(const w of worms){ if(w.tier==='small'&&!w.removeMe) smalls++; else if(w.tier==='giant'&&!w.removeMe) giants++; }
  const smallCap = giants>0 ? 0 : 1;              // while a giant is out, only the bravest worm stays
  /* the giant has gone: the others come back, and it's a good while before the next */
  if(giants===0 && giantOut){
    giantOut=false;
    giantNextT=elapsed+240+Math.random()*180;
    if(!alpha.active && !wormsHeldBack()) recallWorms();
  }
  if(smalls<smallCap && !alpha.active && !wormsHeldBack() && elapsed>smallNextT){
    const w=new SmallWorm(worms.length, Math.random()<0.25);
    w.reset(80+Math.random()*90);
    worms.push(w);
    smallNextT=elapsed+420+Math.random()*300;
  }
  if(giants<1 && !alpha.active && !wormsHeldBack() && elapsed>giantNextT){
    const w=new GiantWorm(worms.length, Math.random()<0.5?'swim':'jump');
    w.reset(420+Math.random()*160);
    worms.push(w);
    giantOut=true;
    /* only one worm keeps hunting: the bravest (closest) of the lesser worms */
    let bravest=null, bd=1e9;
    for(const o of worms){
      if(o.tier || o.removeMe || o.state==='gone' || o.state==='dead' || o.state==='flee') continue;
      o.brave=false;
      const d=horizDist(o.pos,player.pos);
      if(d<bd){ bd=d; bravest=o; }
    }
    if(bravest) bravest.brave=true;
  }
}
