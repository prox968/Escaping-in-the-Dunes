/* Particle system, volumetric dust clouds, ground shockwaves */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- particles ----------------
   Pool size scales with graphics mode: Performance ships ~45% of the
   dust to keep fill rate low on integrated GPUs; Normal and High both
   use the full pool (High still benefits because the bigger sand sheet
   hides the lower per-particle detail). */
const PMAX=Math.max(1500, Math.round(8000 * GRAPHICS.particleMul));
const pPos=new Float32Array(PMAX*3), pCol=new Float32Array(PMAX*3), pSize=new Float32Array(PMAX),
      pAlpha=new Float32Array(PMAX), pVel=new Float32Array(PMAX*3), pLife=new Float32Array(PMAX),
      pMax=new Float32Array(PMAX), pGrav=new Float32Array(PMAX), pDrag=new Float32Array(PMAX),
      pRot =new Float32Array(PMAX), pRotSpd=new Float32Array(PMAX),
      pSeed=new Float32Array(PMAX), pAge=new Float32Array(PMAX),
      pType=new Float32Array(PMAX), pSz0=new Float32Array(PMAX);
let pCount=0;

/* ================================================================
   OWNERSHIP — per-owner particle / cloud budgets
   ---------------------------------------------------------------
   Every worm, the jeep and the alpha tag the particles they spawn
   (setPOwner) so one huge eruption can't starve everyone else out
   of the shared pool. Owner 0 = unowned (thumper, digger, spice…).
   ================================================================ */
const P_JEEP = 1, P_ALPHA = 2;
const POWN_MAX = 256;
const pOwn     = new Uint8Array(PMAX);
const pOwnCnt  = new Int32Array(POWN_MAX);
const cOwnCnt  = new Int32Array(POWN_MAX);
let _pOwner = 0, _pOwnW = 1, _pOwnNext = 3;

function newPOwnerId(){
  const id = _pOwnNext++;
  if(_pOwnNext >= POWN_MAX) _pOwnNext = 3;     // recycle; counts decay as particles die
  return id;
}
function setPOwner(id, weight){
  _pOwner = id|0;
  _pOwnW  = (weight===undefined) ? 1 : weight;
}
function _pOwnerFull(){
  return _pOwner !== 0 && pOwnCnt[_pOwner] >= PMAX * 0.125 * _pOwnW;
}

/* ================================================================
   PARTICLE TYPES
   ---------------------------------------------------------------
   Every particle has a type that picks BOTH its look (fragment
   shader) and its behaviour (update loop). spawnP's optional last
   argument selects it; omitted = PT_DUST, so old call sites still
   behave exactly as before.

     PT_DUST    soft lit puff            generic dust, the original look
     PT_GRAIN   hard sand grains         ballistic, velocity-streaked, bounce
                                         off the dunes and kick up a puff
     PT_TRAIL   flat soft wake           hugs the ground, drags to a halt,
                                         lingers behind the car / worms
     PT_BILLOW  swirling rising plume    buoyant, big, slow, self-shadowed,
                                         rim-lit when backlit
     PT_SPARK   glowing emissive motes   additive, unlit, flickering:
                                         spice, thumper and blast embers
     PT_SPRAY   fine thrown dust         small soft puffs, lightly streaked,
                                          disperse and thin out fast: the
                                          sand a swimming worm shoves aside
     PT_FLAME   fire lick                 emissive, additive, rises fast,
                                          blackbody ramp white→orange→red as
                                          it ages and licks away
     PT_OIL     dark droplet             ballistic, streaks along motion,
                                          splashes a burning puddle on impact
     PT_SMOKE   dark buoyant plume       the black column boiling off a wreck
   ================================================================ */
const PT_DUST=0, PT_GRAIN=1, PT_TRAIL=2, PT_BILLOW=3, PT_SPARK=4, PT_SPRAY=5,
      PT_FLAME=6, PT_OIL=7, PT_SMOKE=8;
let _carGrainAcc = 0, _carSparkAcc = 0;      // fractional spawn accumulators for the car
const PT = [
  /* turb   g0   g1   cap  fadeIn fadeOut peak lift */
  { turb:1.00, g0:1.4, g1:0.35, cap:45,  fin:9,  fout:0.60, peak:0.88, lift:0.0, legacy:true },  // DUST
  { turb:0.00, g0:0.0, g1:0.00, cap:0,   fin:40, fout:0.35, peak:0.96, lift:0.0 },               // GRAIN
  { turb:0.35, g0:0.9, g1:0.30, cap:16,  fin:7,  fout:1.10, peak:0.62, lift:0.0 },               // TRAIL
  { turb:1.70, g0:2.4, g1:0.30, cap:110, fin:5,  fout:0.45, peak:0.92, lift:3.2 },               // BILLOW
  { turb:0.45, g0:0.0, g1:0.00, cap:0,   fin:30, fout:1.60, peak:1.00, lift:0.6 },               // SPARK
  { turb:0.60, g0:0.5, g1:0.50, cap:10,  fin:14, fout:0.85, peak:0.60, lift:0.0 },               // SPRAY
  { turb:1.25, g0:0.0, g1:0.00, cap:0,   fin:24, fout:2.30, peak:1.00, lift:7.5 },               // FLAME
  { turb:0.00, g0:0.0, g1:0.00, cap:0,   fin:60, fout:1.00, peak:1.00, lift:0.0 },               // OIL
  { turb:1.50, g0:2.6, g1:0.22, cap:120, fin:4,  fout:0.55, peak:0.82, lift:3.6 }                // SMOKE
];

/* ================================================================
   GEOMETRY — instanced billboard quads
   ---------------------------------------------------------------
   Replaces gl_PointSize sprites. Point sprites are capped by the
   driver (often 64–256 px), can't rotate, and can't carry an
   impostor normal. Instanced quads fix all three and cost almost
   nothing extra: 4 verts × 8000 = 32k verts.
   ================================================================ */
const _quad = new THREE.PlaneGeometry(1,1);
const pGeo  = new THREE.InstancedBufferGeometry();
pGeo.setIndex(_quad.getIndex());
pGeo.setAttribute('position', _quad.getAttribute('position'));
pGeo.setAttribute('uv',       _quad.getAttribute('uv'));

function _instAttr(arr, n){
  const a = new THREE.InstancedBufferAttribute(arr, n);
  a.setUsage(THREE.DynamicDrawUsage);
  return a;
}
pGeo.setAttribute('iPos',   _instAttr(pPos,   3));
pGeo.setAttribute('iVel',   _instAttr(pVel,   3));
pGeo.setAttribute('iColor', _instAttr(pCol,   3));
pGeo.setAttribute('iSize',  _instAttr(pSize,  1));
pGeo.setAttribute('iAlpha', _instAttr(pAlpha, 1));
pGeo.setAttribute('iRot',   _instAttr(pRot,   1));
pGeo.setAttribute('iAge',   _instAttr(pAge,   1));
pGeo.setAttribute('iType',  _instAttr(pType,  1));
pGeo.instanceCount = 0;

/* ================================================================
   LIGHTING — mirror the scene's real lights so dust is lit like terrain
   ---------------------------------------------------------------
   Terrain is a MeshStandardMaterial, so its diffuse radiance is
   albedo * lightColor * intensity / PI. We feed the shader the same
   numbers. Direction comes from the global `sunDir` (the directional
   light's *position* is sunDir*300 + player, NOT a direction).
   ================================================================ */
let _sunDirWorld = new THREE.Vector3(-0.55, 0.40, -0.42).normalize();
let _sunOverride = false;
let _sunLight = null, _hemiLight = null;
const _INV_PI = 1/Math.PI;

function setParticleSun(dir, color){
  _sunDirWorld.copy(dir).normalize();
  if (color) particleUniforms.uSunColor.value.copy(color);
  _sunOverride = true;
}

function _syncLights(){
  if (!_sunLight || !_hemiLight){
    scene.traverse(o=>{
      if (!_sunLight  && o.isDirectionalLight) _sunLight  = o;
      if (!_hemiLight && o.isHemisphereLight)  _hemiLight = o;
    });
  }
  if (!_sunOverride){
    if (typeof sunDir !== 'undefined') _sunDirWorld.copy(sunDir).normalize();
    if (_sunLight) particleUniforms.uSunColor.value.copy(_sunLight.color).multiplyScalar(_sunLight.intensity * _INV_PI);
  }
  if (_hemiLight){
    particleUniforms.uSkyColor.value.copy(_hemiLight.color).multiplyScalar(_hemiLight.intensity * _INV_PI);
    particleUniforms.uGroundColor.value.copy(_hemiLight.groundColor).multiplyScalar(_hemiLight.intensity * _INV_PI);
  }
  /* fog: three applies it after tone-mapping, in OUTPUT colour space */
  if (scene.fog){
    scene.fog.color.getRGB(particleUniforms.uFogColor.value, THREE.SRGBColorSpace);
    particleUniforms.uFogNear.value = scene.fog.near;
    particleUniforms.uFogFar.value  = scene.fog.far;
  }
}

/* ================================================================
   TERRAIN COLOUR — same ramp as fillChunkGeo, cached per 40 m cell
   ================================================================ */
const _tcCache = new Map(), _tcTmp = new THREE.Color();
let _tcAge = 0;
function terrainSandColor(x, z, out){
  const kx = Math.floor(x/40), kz = Math.floor(z/40), key = kx*100003 + kz;
  let c = _tcCache.get(key);
  if (!c){
    const dfm = deformOffset(x,z), h = baseTerrainH(x,z) + dfm;
    _tcTmp.copy(C_LOW).lerp(C_HIGH, sstep(h-dfm*0.8, 1.5, 23));
    if (dfm>2) _tcTmp.lerp(C_HIGH, clamp(dfm/160,0,0.18));
    _tcTmp.lerp(C_RED, clamp((noise2(x*0.012+41, z*0.012+17)-0.5)*0.8, 0, 0.35));
    c = [_tcTmp.r, _tcTmp.g, _tcTmp.b];
    if (_tcCache.size > 3000) _tcCache.clear();
    _tcCache.set(key, c);
  }
  return out.setRGB(c[0], c[1], c[2]);
}
const _s2l = c => c <= 0.04045 ? c/12.92 : Math.pow((c+0.055)/1.055, 2.4);
const _spCol = new THREE.Color();

/* ================================================================
   MATERIAL
   ================================================================ */
const particleUniforms = {
  uTex:         { value: fbmCloudTex },
  uTexB:        { value: fbmCloudTexB },
  uPuff:        { value: dustPuffTex },
  uSoft:        { value: plumeTex },
  uSunDirView:  { value: new THREE.Vector3(-0.55, 0.40, -0.42).normalize() },
  uSunColor:    { value: new THREE.Color(1.0, 0.94, 0.82) },
  uSkyColor:    { value: new THREE.Color(0.55, 0.64, 0.78) },
  uGroundColor: { value: new THREE.Color(0.34, 0.28, 0.22) },
  uFogColor:    { value: new THREE.Color(0xecd6b0) },
  uFogNear:     { value: 55 },
  uFogFar:      { value: 470 },
  uStretch:     { value: 0.055 },
  uFar:         { value: 500 },
  /* ---- close-up overdraw guard ----
     uViewportH: framebuffer height in px (kept in sync on resize).
     uMaxFrac:   the largest fraction of the viewport height a single billboard
                 may cover — caps the fragment (overdraw) cost of one particle.
     uNear:      (start,end) metres; a billboard shrinks toward a point and fades
                 as it enters this range, so a cloud you drive into collapses
                 instead of paying for a full-screen alpha pass. */
  uViewportH:   { value: (typeof window !== 'undefined' ? window.innerHeight : 800) },
  uMaxFrac:     { value: 0.5 },
  uNear:        { value: new THREE.Vector2(1.0, 5.5) }
};

const points = new THREE.Mesh(pGeo, new THREE.ShaderMaterial({
  transparent: true,
  depthWrite:  false,
  premultipliedAlpha: true,          // blend factors become (ONE, ONE_MINUS_SRC_ALPHA)
  uniforms: particleUniforms,

  vertexShader: /* glsl */`
    attribute vec3  iPos;
    attribute vec3  iVel;
    attribute vec3  iColor;
    attribute float iSize;
    attribute float iAlpha;
    attribute float iRot;
    attribute float iAge;
    attribute float iType;

    uniform vec3  uSunDirView;
    uniform float uStretch;
    uniform float uFar;
    uniform float uViewportH;
    uniform float uMaxFrac;
    uniform vec2  uNear;

    varying vec2  vUv;
    varying vec3  vColor;
    varying float vAlpha;
    varying float vAge;
    varying float vType;
    varying vec3  vNormalV;
    varying vec3  vViewPos;

    void main(){
      int   T    = int(iType + 0.5);
      vec4  mv   = modelViewMatrix * vec4(iPos, 1.0);
      float dist = max(0.001, -mv.z);

      /* ---- square billboard corner in [-1,1] ---- */
      vec2 corner = position.xy * 2.0;

      /* ---- velocity stretch along screen-space motion ---- */
      vec3  vv    = (modelViewMatrix * vec4(iVel, 0.0)).xyz;
      float vlen  = length(vv.xy);
      vec2  sdir  = (vlen > 1e-4) ? (vv.xy / vlen) : vec2(1.0, 0.0);
      vec2  sperp = vec2(-sdir.y, sdir.x);
      /* per-type streaking: grains/sparks smear along motion, plumes barely */
      float sk = 1.0, thin = 1.0;
      if      (T == 1){ sk = 3.4; thin = 0.70; }
      else if (T == 2){ sk = 0.45; }
      else if (T == 3){ sk = 0.10; }
      else if (T == 4){ sk = 2.2; thin = 0.55; }
      else if (T == 5){ sk = 1.4; thin = 0.88; }
      else if (T == 6){ sk = 0.9; thin = 0.82; }
      else if (T == 7){ sk = 3.0; thin = 0.62; }
      else if (T == 8){ sk = 0.10; }
      float stretch = min(1.0 + vlen * uStretch * sk, 7.0);
      vec2  cpos = sdir * dot(corner, sdir) * stretch + sperp * dot(corner, sperp) * thin;

      /* ---- close-up overdraw guard (two independent clamps) ----
         (1) screen-size clamp: cap the projected size so one particle can never
             cover more than uMaxFrac of the viewport height. Distant particles
             are unaffected; only huge, near ones are trimmed.
         (2) near shrink: collapse the billboard toward a point and fade it as it
             enters the near range, so driving through a cloud costs ~nothing. */
      float ps      = projectionMatrix[1][1] * (uViewportH * 0.5);      // px per world unit at 1 m
      float maxSize = uMaxFrac * uViewportH * dist / max(ps, 1.0);      // world size that hits the cap
      float nf      = smoothstep(uNear.x, uNear.y, dist);
      float sz      = min(iSize, maxSize) * nf;
      mv.xy += cpos * sz * 0.5;

      /* ---- rotate the cloud texture inside the quad ---- */
      float s = sin(iRot), c = cos(iRot);
      vec2  uvc = uv - 0.5;
      vUv = vec2(uvc.x * c - uvc.y * s, uvc.x * s + uvc.y * c);

      /* ---- squashed-sphere impostor normal (view space) ---- */
      vec3 n = vec3(corner, 0.0);
      n.z = sqrt(max(0.0, 1.0 - min(1.0, dot(corner, corner))));
      n.z *= 0.55;                      // flatten → soft, dusty shading
      vNormalV = normalize(n);

      vColor   = iColor;
      vViewPos = mv.xyz;
      vAge     = iAge;
      vType    = iType;

      float fadeFar  = 1.0 - smoothstep(uFar * 0.55, uFar, dist);
      float fadeNear = smoothstep(0.0, 2.0, dist) * nf;
      vAlpha = iAlpha * fadeFar * fadeNear;

      gl_Position = projectionMatrix * mv;
    }`,

  fragmentShader: /* glsl */`
    uniform sampler2D uTex;
    uniform sampler2D uTexB;
    uniform sampler2D uPuff;
    uniform sampler2D uSoft;
    uniform vec3 uSunDirView;
    uniform vec3 uSunColor;
    uniform vec3 uSkyColor;
    uniform vec3 uGroundColor;
    uniform vec3 uFogColor;
    uniform float uFogNear;
    uniform float uFogFar;

    varying vec2  vUv;
    varying vec3  vColor;
    varying float vAlpha;
    varying float vAge;
    varying float vType;
    varying vec3  vNormalV;
    varying vec3  vViewPos;

    void main(){
      int  T   = int(vType + 0.5);
      vec2 uvA = vUv + 0.5;
      float r  = length(vUv) * 2.0;

      vec3 N = normalize(vNormalV);
      vec3 L = uSunDirView;
      float ndl   = dot(N, L);
      float phase = pow(max(dot(normalize(vViewPos), L), 0.0), 3.0);
      vec3  amb   = mix(uGroundColor, uSkyColor, N.y * 0.5 + 0.5);

      float a;
      vec3  col;

      if (T == 1){
        /* ---- GRAIN: crisp little sand chunks, directional light, no glow ---- */
        vec4 g = texture2D(uTex, uvA * 1.7);
        a = (1.0 - smoothstep(0.55, 0.95, r)) * (0.70 + g.a * 0.60);
        a = clamp(a, 0.0, 1.0) * vAlpha;
        vec3 albedo = vColor * (0.70 + g.r * 0.55);
        vec3 lit = uSunColor * (max(ndl, 0.0) * 1.15 + 0.10) + amb;
        col = albedo * lit;

      } else if (T == 2){
        /* ---- TRAIL: low-contrast, ambient-heavy wake dust ---- */
        vec4 tP = texture2D(uPuff, uvA * 1.08);
        vec4 tA = texture2D(uTex,  uvA * 0.97);
        vec4 tB = texture2D(uTexB, uvA * 1.3 + vec2(0.17, 0.41));
        a = (tP.a * 0.66 + tA.a * 0.20 + tB.a * 0.36) * (1.0 - smoothstep(0.78, 1.0, r)) * vAlpha;
        vec3 albedo = vColor * (tP.rgb * 0.64 + tA.rgb * 0.26 + tB.rgb * 0.28) * 1.05;
        float wrap = ndl * 0.5 + 0.5;
        vec3 lit = uSunColor * (wrap * 0.55 + phase * 0.55) + amb * 1.05;
        col = albedo * lit + albedo * 0.05;

      } else if (T == 3){
        /* ---- BILLOW: swirling cauliflower plume, self-shadowed, rim-lit ---- */
        float sw = vAge * 1.4, cs = cos(sw), sn = sin(sw);
        vec2  q  = uvA - 0.5;
        q = vec2(q.x * cs - q.y * sn, q.x * sn + q.y * cs) + 0.5;
        vec4 tA = texture2D(uTex,  uvA);
        vec4 tB = texture2D(uTexB, q * 1.2 - 0.1);
        a = (pow(tA.a, 0.85) * 0.70 + tB.a * 0.60) * (1.0 - smoothstep(0.80, 1.0, r)) * vAlpha;
        vec3 albedo = vColor * (tA.rgb * 0.50 + tB.rgb * 0.60);
        float wrap  = ndl * 0.5 + 0.5;
        float back  = pow(max(-ndl, 0.0), 1.6);
        float rim   = smoothstep(0.35, 0.95, r) * phase;
        float shade = 0.68 + 0.42 * (N.y * 0.5 + 0.5);          // dark underside
        vec3 lit = uSunColor * ((pow(wrap, 1.5) * 0.95 + back * 0.30 + phase * 1.00 + rim * 0.9) * shade)
                 + amb * 0.85;
        col = albedo * lit + albedo * 0.05;

      } else if (T == 4){
        /* ---- SPARK: emissive hot core, unlit ---- */
        float core = pow(max(1.0 - r, 0.0), 2.0);
        a   = core * vAlpha;
        col = vColor * (1.4 + core * 2.6);

      } else if (T == 6){
        /* ---- FLAME: emissive fire lick. A hot radial core rides a puffy fbm
             body, and the colour cools with age: white-yellow → orange → deep red.
             Unlit and (near) additive, so it glows over dust instead of shading. ---- */
        vec4  fB   = texture2D(uTexB, uvA * 1.30);
        float core = texture2D(uSoft, uvA).a;
        float body = fB.a * 0.72 + core * 0.95;
        a   = body * (1.0 - smoothstep(0.86, 1.0, r)) * vAlpha;
        float ag = clamp(vAge, 0.0, 1.0);
        vec3  heat = mix(vec3(1.85, 1.28, 0.55), vec3(1.55, 0.46, 0.06), smoothstep(0.02, 0.46, ag));
        heat       = mix(heat, vec3(0.42, 0.05, 0.015), smoothstep(0.50, 1.0, ag));
        col = heat * vColor * (0.85 + core * 1.9);

      } else if (T == 7){
        /* ---- OIL: dark wet droplet, lit like a little bead ---- */
        vec4 g = texture2D(uTexB, uvA * 1.55);
        a = (1.0 - smoothstep(0.5, 0.95, r)) * (0.55 + g.a * 0.45) * vAlpha;
        vec3 albedo = vColor * (0.65 + g.r * 0.35);
        float wrap = ndl * 0.5 + 0.5;
        col = albedo * (uSunColor * (wrap * 0.75 + 0.10) + amb * 0.6);

      } else if (T == 8){
        /* ---- SMOKE: dark buoyant plume (BILLOW shading, near-black albedo) ---- */
        float sw = vAge * 1.4, cs = cos(sw), sn = sin(sw);
        vec2  q  = uvA - 0.5;
        q = vec2(q.x * cs - q.y * sn, q.x * sn + q.y * cs) + 0.5;
        vec4 tA = texture2D(uTex,  uvA);
        vec4 tB = texture2D(uTexB, q * 1.2 - 0.1);
        a = (pow(tA.a, 0.85) * 0.70 + tB.a * 0.60) * (1.0 - smoothstep(0.80, 1.0, r)) * vAlpha;
        vec3 albedo = vColor * (tA.rgb * 0.35 + tB.rgb * 0.35);
        float wrap  = ndl * 0.5 + 0.5;
        float back  = pow(max(-ndl, 0.0), 1.6);
        float shade = 0.60 + 0.40 * (N.y * 0.5 + 0.5);
        col = albedo * (uSunColor * ((pow(wrap, 1.5) * 0.65 + back * 0.25 + phase * 0.7) * shade) + amb * 0.5);

      } else {
        /* ---- DUST: granular lit puff ---- */
        vec4 tP = texture2D(uPuff, uvA);
        vec4 tA = texture2D(uTex,  uvA);
        vec4 tB = texture2D(uTexB, uvA * 1.07 + 0.03);
        a = tP.a * 0.68 + tA.a * 0.24 + tB.a * 0.28;
        a *= 1.0 - smoothstep(0.80, 1.0, r);
        a *= vAlpha;
        if (T == 5) a *= 0.80;                       // spray: lighter, more see-through

        float wrap = ndl * 0.5 + 0.5;
        float diff = pow(wrap, 1.5);
        float back = pow(max(-ndl, 0.0), 1.6);
        vec3 lit = uSunColor * (diff * 0.95 + back * 0.22 + phase * 0.85) + amb;

        vec3 albedo = vColor * (tP.rgb * 0.62 + tA.rgb * 0.26 + tB.rgb * 0.28);
        albedo *= mix(1.25, 1.0, smoothstep(0.0, 0.35, vAge));  // fresh dust is hotter
        col = albedo * lit + albedo * 0.05;
      }

      if (a < 0.0035) discard;

      /* same output pipeline as the terrain: tone-map -> sRGB -> fog */
      gl_FragColor = vec4(col, a);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      float fogF = smoothstep(uFogNear, uFogFar, -vViewPos.z);
      gl_FragColor.rgb = mix(gl_FragColor.rgb, uFogColor, fogF);

      /* premultiplied "over"; sparks & flame are ~additive (alpha channel mostly
         dropped) and fade out in fog instead of turning into fog-coloured glow */
      float oa = gl_FragColor.a;
      if (T == 4 || T == 6){ oa *= (1.0 - fogF); gl_FragColor.rgb *= oa; gl_FragColor.a = oa * (T == 6 ? 0.06 : 0.10); }
      else       { gl_FragColor.rgb *= oa; }
    }`
}));
points.frustumCulled = false;
scene.add(points);

/* ================================================================
   SPAWN / KILL
   ================================================================ */
function spawnP(x,y,z, vx,vy,vz, life, size, r,g,b, grav, drag, type){
  if(pCount>=PMAX || _pOwnerFull()) return;
  const i=pCount++, i3=i*3;
  pOwn[i]=_pOwner; if(_pOwner) pOwnCnt[_pOwner]++;
  pPos[i3]=x;pPos[i3+1]=y;pPos[i3+2]=z;
  pVel[i3]=vx;pVel[i3+1]=vy;pVel[i3+2]=vz;
  pLife[i]=pMax[i]=life; pSize[i]=size;
  type = type|0;
  pType[i]=type; pSz0[i]=size;
  if (type === PT_SPARK || type === PT_FLAME || type === PT_OIL || type === PT_SMOKE){
    /* emissive fire/embers and dark oil/smoke: keep the caller's colour verbatim */
    pCol[i3]=_s2l(r); pCol[i3+1]=_s2l(g); pCol[i3+2]=_s2l(b);
  } else {
    terrainSandColor(x, z, _spCol);
    pCol[i3]  =_s2l(r)*0.42 + _spCol.r*1.15*0.58;
    pCol[i3+1]=_s2l(g)*0.42 + _spCol.g*1.15*0.58;
    pCol[i3+2]=_s2l(b)*0.42 + _spCol.b*1.15*0.58;
  }
  pGrav[i]=grav; pDrag[i]=drag;
  pAlpha[i]=0; pAge[i]=0;                         // fade in
  pRot[i]=Math.random()*6.28318; pRotSpd[i]=(Math.random()-0.5)*1.6;
  pSeed[i]=Math.random()*100;
}
function killP(i){
  if(pOwn[i]) pOwnCnt[pOwn[i]]--;
  const l=--pCount, a=i*3, b=l*3;
  if(i!==l){
    pOwn[i]=pOwn[l]; pType[i]=pType[l]; pSz0[i]=pSz0[l];
    for(let k=0;k<3;k++){ pPos[a+k]=pPos[b+k]; pVel[a+k]=pVel[b+k]; pCol[a+k]=pCol[b+k]; }
    pLife[i]=pLife[l]; pMax[i]=pMax[l]; pSize[i]=pSize[l]; pAlpha[i]=pAlpha[l];
    pGrav[i]=pGrav[l]; pDrag[i]=pDrag[l];
    pRot[i]=pRot[l]; pRotSpd[i]=pRotSpd[l];
    pSeed[i]=pSeed[l]; pAge[i]=pAge[l];
  }
}

/* ================================================================
   UPDATE
   ================================================================ */
let _pTime = 0;

function updateParticles(dt){
  _pTime += dt;
  _syncLights();
  _tcAge += dt; if (_tcAge > 3){ _tcAge = 0; _tcCache.clear(); }

  for(let i=0;i<pCount;i++){
    pLife[i]-=dt;
    if(pLife[i]<=0){ killP(i); i--; continue; }

    const i3  = i*3;
    const lf  = pLife[i]/pMax[i];      // 1 → 0
    const age = 1.0 - lf;
    const T   = pType[i]|0, TP = PT[T];

    /* ---- buoyancy / gravity ---- */
    pVel[i3+1] -= pGrav[i] * dt;
    if (TP.lift) pVel[i3+1] += TP.lift * lf * dt;      // plumes & embers rise

    /* ---- cheap curl-ish turbulence (sines of position + per-particle seed) ---- */
    if (TP.turb > 0){
      const sd = pSeed[i], t = _pTime;
      const px = pPos[i3], py = pPos[i3+1], pz = pPos[i3+2];
      const TURB = 1.9 * TP.turb;
      pVel[i3]   += (Math.sin(py*0.55 + t*1.1 + sd) + Math.sin(pz*0.37 - t*0.8 + sd*1.7)*0.7) * TURB * dt;
      pVel[i3+1] += (Math.sin(pz*0.45 + t*0.7 + sd*2.1)*0.6) * TURB * dt;
      pVel[i3+2] += (Math.sin(px*0.52 - t*0.6 + sd*1.3) + Math.sin(py*0.33 + t*0.9 + sd)*0.7) * TURB * dt;
    }

    /* ---- exponential drag ---- */
    const dr = Math.exp(-pDrag[i]*dt);
    pVel[i3]*=dr; pVel[i3+1]*=dr; pVel[i3+2]*=dr;

    /* ---- integrate ---- */
    pPos[i3]   += pVel[i3]   * dt;
    pPos[i3+1] += pVel[i3+1] * dt;
    pPos[i3+2] += pVel[i3+2] * dt;

    /* ---- ground interaction ---- */
    if (T === PT_GRAIN){
      const gy = terrainH(pPos[i3], pPos[i3+2]);
      if (pPos[i3+1] < gy + 0.04 && pVel[i3+1] < 0){
        const sp = -pVel[i3+1];
        pPos[i3+1] = gy + 0.04;
        pVel[i3+1] = sp * 0.26;
        pVel[i3] *= 0.55; pVel[i3+2] *= 0.55;
        /* hard landings kick up a tiny puff */
        if (sp > 6 && Math.random() < 0.16 && pCount < PMAX-1){
          spawnP(pPos[i3], gy+0.15, pPos[i3+2], pVel[i3]*0.25, 0.7, pVel[i3+2]*0.25,
                 0.5+Math.random()*0.5, 0.5+pSz0[i]*2.2, 0.80,0.64,0.44, 0.3, 1.6, PT_TRAIL);
        }
        if (sp < 2.2){ pVel[i3]=pVel[i3+1]=pVel[i3+2]=0; pLife[i] = Math.min(pLife[i], 0.22); }
      }
    } else if (T === PT_TRAIL || T === PT_SPRAY){
      const gy = terrainH(pPos[i3], pPos[i3+2]) + 0.12;
      if (pPos[i3+1] < gy){ pPos[i3+1] = gy; if (pVel[i3+1] < 0) pVel[i3+1] *= 0.2; }
    } else if (T === PT_OIL){
      /* a droplet that reaches the sand is spent: it splashes a burning puddle */
      const gy = terrainH(pPos[i3], pPos[i3+2]);
      if (pPos[i3+1] < gy + 0.06 && pVel[i3+1] < 0.6){
        pPos[i3+1] = gy + 0.06;
        pVel[i3]=0; pVel[i3+1]=0; pVel[i3+2]=0;
        pLife[i] = Math.min(pLife[i], 0.05);
        if (pCount < PMAX-4){
          for(let q=0, nq=2+((Math.random()*2)|0); q<nq; q++)
            spawnP(pPos[i3]+(Math.random()-0.5)*0.7, gy+0.12, pPos[i3+2]+(Math.random()-0.5)*0.7,
              (Math.random()-0.5)*1.6, 1.4+Math.random()*2.6, (Math.random()-0.5)*1.6,
              0.30+Math.random()*0.45, 0.9+Math.random()*1.5,
              1.0,0.52,0.14, 0, 2.0, PT_FLAME);
        }
      }
    }

    /* ---- fade in / out ---- */
    const fadeIn = Math.min(1.0, age * TP.fin);
    let al;
    if (T === PT_GRAIN || T === PT_OIL) al = fadeIn * Math.min(1.0, lf*4.0) * TP.peak;   // opaque until the end
    else if (T === PT_SPARK) al = fadeIn * Math.pow(lf, TP.fout) * (0.65 + 0.35*Math.sin(_pTime*34 + pSeed[i]*3.0)) * TP.peak;  // flicker
    else if (T === PT_FLAME) al = fadeIn * Math.pow(lf, TP.fout) * (0.82 + 0.18*Math.sin(_pTime*46 + pSeed[i]*5.0)) * TP.peak;  // licking flicker
    else                     al = fadeIn * Math.pow(lf, TP.fout) * TP.peak;
    pAlpha[i] = al;

    /* ---- rotation ---- */
    pRot[i] += pRotSpd[i]*dt;

    /* ---- size: dispersion for gas types, shrink for solids & fire ---- */
    if (T === PT_GRAIN || T === PT_SPARK || T === PT_FLAME || T === PT_OIL){
      const f = T === PT_SPARK ? (0.45 + 0.55*lf)
              : T === PT_FLAME ? (0.35 + 0.65*lf)
              : T === PT_OIL   ? (0.62 + 0.38*lf)
              :                  (0.75 + 0.25*lf);
      pSize[i] = pSz0[i] * f;
    } else {
      pSize[i] += dt * (TP.g0 + pSize[i] * TP.g1);
      const cap = TP.legacy ? TP.cap : Math.max(TP.cap, pSz0[i]);
      if (pSize[i] > cap) pSize[i] = cap;
    }

    pAge[i] = age;
  }

  /* ---- sun direction in view space ---- */
  if (typeof camera !== 'undefined' && camera){
    particleUniforms.uSunDirView.value
      .copy(_sunDirWorld)
      .transformDirection(camera.matrixWorldInverse);
  }

  pGeo.attributes.iPos.needsUpdate   = true;
  pGeo.attributes.iVel.needsUpdate   = true;
  pGeo.attributes.iColor.needsUpdate = true;
  pGeo.attributes.iSize.needsUpdate  = true;
  pGeo.attributes.iAlpha.needsUpdate = true;
  pGeo.attributes.iRot.needsUpdate   = true;
  pGeo.attributes.iAge.needsUpdate   = true;
  pGeo.attributes.iType.needsUpdate  = true;
  pGeo.instanceCount = pCount;
}

function burstDust(pos, n, spd){
  const gy = terrainH(pos.x, pos.z);
  const baseY = Math.max(pos.y, gy);

  /* 1. the soft dust body (unchanged) */
  for(let k=0;k<n;k++){
    const a  = Math.random()*Math.PI*2;
    const up = 1.2 + Math.random()*spd*0.55;
    const hs = (0.15 + Math.pow(Math.random(),0.65)*0.85)*spd;
    const j  = 0.85 + Math.random()*0.3;
    const sz = 3.0 + Math.pow(Math.random(),1.5)*5.0;
    spawnP(
      pos.x + (Math.random()-0.5)*4,
      baseY + 0.4 + Math.random()*0.8,
      pos.z + (Math.random()-0.5)*4,
      Math.cos(a)*hs, up, Math.sin(a)*hs,
      1.4 + Math.random()*1.6, sz,
      0.76*j, 0.60*j, 0.42*j,
      2.0, 1.0, PT_DUST
    );
  }

  /* 2. ballistic grains: fast, hard-edged, streaked, they bounce off the dunes */
  const ng = Math.min(170, Math.round(n*0.6));
  for(let k=0;k<ng;k++){
    const a  = Math.random()*Math.PI*2;
    const el = 0.25 + Math.random()*1.15;                 // launch elevation (rad)
    const sp = spd*(0.45 + Math.random()*1.15);
    const j  = 0.80 + Math.random()*0.35;
    spawnP(
      pos.x + (Math.random()-0.5)*3,
      baseY + 0.4 + Math.random()*0.6,
      pos.z + (Math.random()-0.5)*3,
      Math.cos(a)*Math.cos(el)*sp, 2 + Math.sin(el)*sp, Math.sin(a)*Math.cos(el)*sp,
      0.9 + Math.random()*1.2, 0.30 + Math.random()*Math.random()*0.9,
      0.74*j, 0.58*j, 0.40*j,
      15, 0.10, PT_GRAIN
    );
  }

  /* 2b. sideways skirt: grains blown out flat along the ground ahead of the
     upward rooster tail, so the impact spreads instead of only climbing */
  const nk = Math.min(90, Math.round(n*0.8));
  for(let k=0;k<nk;k++){
    const a  = Math.random()*Math.PI*2;
    const el = 0.05 + Math.random()*0.45;
    const sp = spd*(0.5 + Math.random()*1.0);
    const j  = 0.80 + Math.random()*0.35;
    spawnP(
      pos.x + Math.cos(a)*Math.random()*2,
      baseY + 0.06 + Math.random()*0.4,
      pos.z + Math.sin(a)*Math.random()*2,
      Math.cos(a)*Math.cos(el)*sp, Math.sin(el)*sp*0.9, Math.sin(a)*Math.cos(el)*sp,
      0.9 + Math.random()*1.1, 0.30 + Math.random()*Math.random()*0.9,
      0.74*j, 0.58*j, 0.40*j,
      15, 0.10, PT_GRAIN
    );
  }

  /* 3. big blasts also push up a slow, swirling billow stem */
  if (n >= 60){
    const nb = Math.min(24, Math.round(n*0.10));
    for(let k=0;k<nb;k++){
      const a = Math.random()*Math.PI*2, hs = Math.random()*spd*0.18;
      const j = 0.85 + Math.random()*0.25;
      spawnP(
        pos.x + (Math.random()-0.5)*3,
        baseY + 0.8 + Math.random()*1.5,
        pos.z + (Math.random()-0.5)*3,
        Math.cos(a)*hs, 5 + Math.random()*spd*0.30, Math.sin(a)*hs,
        2.2 + Math.random()*1.8, 4 + Math.random()*5,
        0.78*j, 0.62*j, 0.43*j,
        0.6, 0.55, PT_BILLOW
      );
    }
  }
}

/* ================================================================
   WORM IMPACT — what a mass of flesh and sand does to a dune
   ---------------------------------------------------------------
   Worm jumps, landings and surfacings all use this. It is stacked
   from five layers so the hit reads genuinely physical:

     1. soft dust body   the billowing centre of the blast
     2. SIDEWAYS sand    a ring of grains blasted OUT flat along the
                         ground — this is the sideways explosion; the
                         grains arc over, bounce and rain back down
     3. low spray fan    fine sand skimming out across the surface
     4. upward column    buoyant billows climbing straight up
     5. wake ring        lingering trail dust hugging the sand while
                         the shock front races outward

   Power scales with n and spd, so a small worm still reads as a
   small plop and a giant's landing shakes the whole dune.
   ================================================================ */
function burstDustClassic(pos, n, spd){
  const gy = terrainH(pos.x, pos.z);
  const baseY = Math.max(pos.y, gy);
  const pw = clamp(0.6 + spd*0.5, 1, 44);            // radial blast power

  /* ---- 1. soft dust body: the billowing centre ---- */
  for(let k=0;k<n;k++){
    const a  = Math.random()*Math.PI*2;
    const up = 1.2 + Math.random()*spd*0.55;
    const hs = (0.15 + Math.pow(Math.random(),0.65)*0.85)*spd;
    const j  = 0.85 + Math.random()*0.3;
    const sz = 3.0 + Math.pow(Math.random(),1.5)*5.0;
    spawnP(
      pos.x + (Math.random()-0.5)*4,
      baseY + 0.4 + Math.random()*0.8,
      pos.z + (Math.random()-0.5)*4,
      Math.cos(a)*hs, up, Math.sin(a)*hs,
      1.4 + Math.random()*1.6, sz,
      0.76*j, 0.60*j, 0.42*j,
      2.0, 1.0, PT_DUST
    );
  }

  /* ---- 2. SIDEWAYS SAND: a ring of grains blasted out flat.
     Low launch elevation + high horizontal speed = the dune is
     blown apart sideways rather than straight up. Heavy gravity
     and a bounce put real weight behind every grain. ---- */
  const ng = Math.min(280, Math.round(n*1.1 + spd*2.2));
  for(let k=0;k<ng;k++){
    const a  = Math.random()*Math.PI*2;
    const el = 0.05 + Math.random()*0.55;
    const sp = pw*(0.60 + Math.random()*1.10);
    const j  = 0.80 + Math.random()*0.34;
    const r0 = Math.random()*1.8;
    spawnP(
      pos.x + Math.cos(a)*r0,
      gy + 0.05 + Math.random()*0.55,
      pos.z + Math.sin(a)*r0,
      Math.cos(a)*Math.cos(el)*sp, Math.sin(el)*sp*0.95, Math.sin(a)*Math.cos(el)*sp,
      0.9 + Math.random()*1.1, 0.30 + Math.random()*Math.random()*0.9,
      0.76*j, 0.60*j, 0.42*j,
      15, 0.095, PT_GRAIN
    );
  }

  /* ---- 3. low spray fan: fine sand skimming across the ground ---- */
  const nsp = Math.min(180, Math.round(n*0.75 + spd*1.6));
  for(let k=0;k<nsp;k++){
    const a  = Math.random()*Math.PI*2;
    const sp = pw*(0.42 + Math.random()*0.85);
    const j  = 0.88 + Math.random()*0.22;
    const r0 = Math.random()*2.4;
    spawnP(
      pos.x + Math.cos(a)*r0, gy + 0.04 + Math.random()*0.18, pos.z + Math.sin(a)*r0,
      Math.cos(a)*sp, 0.4 + Math.random()*1.3, Math.sin(a)*sp,
      1.0 + Math.random()*1.0, 1.6 + Math.random()*2.2,
      0.86*j, 0.72*j, 0.52*j,
      3.0, 1.15, PT_SPRAY
    );
  }

  /* ---- 4. upward column: buoyant billows climbing the blast ---- */
  const nb = Math.min(54, Math.round(n*0.24 + spd*0.6));
  for(let k=0;k<nb;k++){
    const a  = Math.random()*Math.PI*2, hs = Math.random()*pw*0.20;
    const j  = 0.85 + Math.random()*0.25;
    spawnP(
      pos.x + (Math.random()-0.5)*3,
      baseY + 0.8 + Math.random()*(1.5 + pw*0.25),
      pos.z + (Math.random()-0.5)*3,
      Math.cos(a)*hs, pw*(0.32 + Math.random()*0.48), Math.sin(a)*hs,
      2.2 + Math.random()*1.8, 3.5 + Math.random()*5,
      0.78*j, 0.62*j, 0.43*j,
      0.6, 0.55, PT_BILLOW
    );
  }

  /* ---- 5. lingering wake ring: dust that hugs the sand and spreads ---- */
  const nw = Math.min(70, Math.round(n*0.32));
  for(let k=0;k<nw;k++){
    const a  = Math.random()*Math.PI*2, sp = pw*(0.28 + Math.random()*0.55);
    const j  = 0.85 + Math.random()*0.25;
    spawnP(
      pos.x + (Math.random()-0.5)*3, gy + 0.12, pos.z + (Math.random()-0.5)*3,
      Math.cos(a)*sp, 0.4 + Math.random()*0.9, Math.sin(a)*sp,
      1.4 + Math.random()*1.4, 1.2 + Math.random()*1.6,
      0.82*j, 0.66*j, 0.45*j, 0.25, 1.5, PT_TRAIL
    );
  }
}

/* ================================================================
   VOLUMETRIC DUST CLOUDS
   ================================================================ */
const dustClouds=[];
const DUST_CLOUD_CAP = 450;

/* cloud budget: global cap + per-owner cap (same owner as particles) */
function cloudSlot(){
  if(dustClouds.length >= DUST_CLOUD_CAP) return false;
  if(_pOwner !== 0 && cOwnCnt[_pOwner] >= DUST_CLOUD_CAP * 0.125 * _pOwnW) return false;
  return true;
}
function pushCloud(c){
  if(!c.baseColor) c.baseColor = c.sprite.material.color.clone();
  c.owner = _pOwner;
  if(_pOwner) cOwnCnt[_pOwner]++;
  dustClouds.push(c);
}
function _releaseCloud(c){
  if(c.owner) cOwnCnt[c.owner] = Math.max(0, cOwnCnt[c.owner]-1);
  scene.remove(c.sprite); c.sprite.material.dispose();
}

const _cloudToCam = new THREE.Vector3();
const _cloudTint  = new THREE.Color();

/* Proximity cost guard. An emitter sitting right on top of the camera (e.g. the
   burning wreck you are dying in) would otherwise dump its full particle budget
   into the frame for no visual gain. This returns a scale in [0.45, 1] that damps
   spawn counts for effects within ~14 m of the lens — close effects still read,
   they just don't max out the pool. */
function nearCamScale(x, z){
  if(typeof camera==='undefined' || !camera) return 1;
  const dx=x-camera.position.x, dz=z-camera.position.z;
  return clamp(Math.sqrt(dx*dx+dz*dz)/14, 0.45, 1);
}

function spawnCloud(pos, maxScale, dur, opacity, color){
  if(!cloudSlot()) return;
  const tex = maxScale < 5 ? dustPuffTex : ((Math.random()<0.5) ? fbmCloudTex : fbmCloudTexB);
  const baseColor = new THREE.Color(color || 0xd0a56a);
  const mat = new THREE.SpriteMaterial({
    map: tex, color: baseColor.clone(), transparent:true, opacity:0,
    depthWrite:false, blending: THREE.NormalBlending,
    rotation: Math.random()*6.28318
  });
  const sprite=new THREE.Sprite(mat);
  sprite.position.copy(pos);
  sprite.scale.set(2,1.6,1);
  scene.add(sprite);
  pushCloud({
    sprite, baseColor, t:0, dur, maxScale, baseOpacity:opacity,
    rotSpeed:(Math.random()-0.5)*0.35,
    riseSpeed: 0.25 + Math.random()*0.75,
    driftX:(Math.random()-0.5)*0.7,
    driftZ:(Math.random()-0.5)*0.7
  });
}

function spawnCloudCluster(center, count, spread, sizeMin, sizeMax, lifeMin, lifeMax, baseOpacity, tall){
  for(let i=0;i<count;i++){
    if(!cloudSlot()) break;
    const a    = Math.random()*Math.PI*2;
    const elev = Math.random()*0.9;
    const r    = Math.random()*spread;
    const cx   = center.x + Math.cos(a)*r;
    const cz   = center.z + Math.sin(a)*r;
    const cy   = center.y + elev*spread*(tall?1.3:0.55) + Math.random()*spread*0.25;

    const tex     = (Math.random()<0.5) ? fbmCloudTex : fbmCloudTexB;
    const opacity = baseOpacity * (0.55 + Math.random()*0.45);
    const jitter  = 0.9 + Math.random()*0.2;
    terrainSandColor(cx, cz, _spCol);
    const baseColor = new THREE.Color(_spCol.r*0.95*jitter, _spCol.g*0.95*jitter, _spCol.b*0.95*jitter);

    const mat = new THREE.SpriteMaterial({
      map: tex, color: baseColor.clone(), transparent:true, opacity:0,
      depthWrite:false, blending: THREE.NormalBlending,
      rotation: Math.random()*6.28318
    });
    const sprite = new THREE.Sprite(mat);
    sprite.position.set(cx, cy, cz);
    const sc = sizeMin + Math.random()*(sizeMax-sizeMin);
    sprite.scale.set(sc, sc*0.8, 1);
    scene.add(sprite);
    pushCloud({
      sprite, baseColor, t:0,
      dur: lifeMin + Math.random()*(lifeMax-lifeMin),
      maxScale: sc * (1.7 + Math.random()*1.3),
      baseOpacity: opacity,
      rotSpeed: (Math.random()-0.5)*0.4,
      riseSpeed: 0.4 + Math.random()*1.1,
      driftX: (Math.random()-0.5)*0.9,
      driftZ: (Math.random()-0.5)*0.9
    });
  }
}

function updateClouds(dt){
  const cam = (typeof camera !== 'undefined') ? camera : null;

  for(let i=dustClouds.length-1;i>=0;i--){
    const c=dustClouds[i];
    c.t+=dt;
    const k=c.t/c.dur;
    if(k>=1){
      _releaseCloud(c);
      dustClouds.splice(i,1); continue;
    }

    /* expansion — fast at first, then eased out; shrunk near the lens so a
       cloud the camera is inside stops being a full-screen alpha pass */
    let dc = 1e9;
    if (cam) dc = Math.hypot(cam.position.x-c.sprite.position.x, cam.position.y-c.sprite.position.y, cam.position.z-c.sprite.position.z);
    if (dc < 0.7){ _releaseCloud(c); dustClouds.splice(i,1); continue; }
    const near   = clamp(dc/16, 0, 1);
    const shrink = 0.22 + 0.78*near;
    const s = lerp(2, c.maxScale, Math.pow(k, 0.5)) * shrink;
    c.sprite.scale.set(s, s*0.8, 1);

    /* fade in then out */
    const fadeIn = Math.min(1, k*12);
    let op = c.baseOpacity * fadeIn * Math.pow(1-k, 1.5) * (0.12 + 0.88*near);
    c.sprite.material.opacity = op;

    /* drift / rise / rotate */
    c.sprite.material.rotation += c.rotSpeed * dt;
    c.sprite.position.y += c.riseSpeed * dt;
    c.sprite.position.x += c.driftX * dt;
    c.sprite.position.z += c.driftZ * dt;

    /* forward-scatter brightening when the cloud is backlit */
    if (cam){
      _cloudToCam.copy(cam.position).sub(c.sprite.position).normalize();
      const back = Math.max(0, _cloudToCam.dot(_sunDirWorld));
      _cloudTint.copy(c.baseColor).multiplyScalar(0.72 + back*back*0.75);
      c.sprite.material.color.copy(_cloudTint);
    }
  }
}

/* ================================================================
   GROUND SHOCKWAVE
   ================================================================ */
const shockwaves=[];
function spawnGroundShockwave(x, z, maxR, dur){
  const gy = terrainH(x,z);
  const mat = new THREE.MeshBasicMaterial({
    map: dustRingTex, transparent:true, opacity:0, depthWrite:false,
    blending: THREE.NormalBlending
  });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1,1), mat);
  m.rotation.x = -Math.PI/2;
  m.position.set(x, gy + 0.18, z);
  scene.add(m);
  shockwaves.push({m, t:0, dur, maxR});
}
function updateShockwaves(dt){
  for(let i=shockwaves.length-1;i>=0;i--){
    const s=shockwaves[i];
    s.t+=dt;
    const k=s.t/s.dur;
    if(k>=1){ scene.remove(s.m); s.m.geometry.dispose(); s.m.material.dispose(); shockwaves.splice(i,1); continue; }
    const r = lerp(1, s.maxR, Math.pow(k, 0.55));
    s.m.scale.set(r, r, 1);
    s.m.material.opacity = 0.85 * Math.min(1, k*10) * Math.pow(1-k, 1.35);
  }
}

/* expanding ground rings (thin wireframe ring accent) */
const rings=[];
const ringGeo=new THREE.RingGeometry(0.9,1.15,48);
function spawnRing(pos, maxS, dur){
  let r = rings.find(r=>!r.on);
  if(!r){
    if(rings.length>=10) return;
    r={mesh:new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({color:0xd8b078,transparent:true,depthWrite:false})),on:false};
    r.mesh.rotation.x=-Math.PI/2; scene.add(r.mesh); rings.push(r);
  }
  r.on=true; r.t=0; r.dur=dur; r.maxS=maxS;
  r.mesh.position.set(pos.x, terrainH(pos.x,pos.z)+0.3, pos.z);
  r.mesh.visible=true;
}
function updateRings(dt){
  for(const r of rings){
    if(!r.on) continue;
    r.t+=dt;
    const k=r.t/r.dur;
    if(k>=1){ r.on=false; r.mesh.visible=false; continue; }
    const s=lerp(3,r.maxS,1-Math.pow(1-k,2));
    r.mesh.scale.set(s,s,s);
    r.mesh.material.opacity=(1-k)*0.75;
  }
}