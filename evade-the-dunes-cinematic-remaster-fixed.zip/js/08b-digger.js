/* Digger Thumpers: underground travelling decoys (standard 350 m / explosive 80 m).
   Reuses the terrain swell machinery for surface ripples, the deformation layer for
   furrows and craters, the particle/cloud/shockwave systems for effects, and the
   WebAudio engine for rumble + detonation synthesis. */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- digger thumpers ---------------- */
let diggerCount=1, expDiggerCount=0;
const DIG_SPEED=22, DIG_DEPTH=2.4;
const digger={
  active:false, explosive:false, state:'off',
  pos:new THREE.Vector3(), dir:new THREE.Vector3(0,0,1),
  heading:0, traveled:0, dist:350, spd:DIG_SPEED, depth:DIG_DEPTH,
  ph:0, nextDeform:0, rippleT:0, rumbleT:0, swellT:0, armT:0, armAcc:0,
  swell:{x:0,z:0,R2:0,items:[]}
};
swellGroups.push(digger.swell);
let digRumble=0;
/* reusable detonation flash */
const boomLight=new THREE.PointLight(0xff9a40,0,120,2);
scene.add(boomLight);

function rebuildDiggerSwell(){
  const sg=digger.swell, dx=digger.dir.x, dz=digger.dir.z, px=-dz, pz=dx;
  const it=[]; const add=(x,z,r,h)=>it.push({x,z,r2:r*r,h});
  add(digger.pos.x, digger.pos.z, 3.4, 0.5);                                  // bulge riding above the digger
  add(digger.pos.x-dx*3.2, digger.pos.z-dz*3.2, 2.6, -0.3);                   // furrow closing behind it
  for(const sd of [-1,1]) add(digger.pos.x+px*sd*2.6, digger.pos.z+pz*sd*2.6, 2.2, 0.22);  // side ripples
  let R=0; for(const q of it){ const d=Math.hypot(q.x-digger.pos.x,q.z-digger.pos.z)+Math.sqrt(q.r2); if(d>R)R=d; }
  if(sg.R2>0) invalidateChunksNear(sg.x, sg.z, Math.sqrt(sg.R2)+4);
  sg.items=it; sg.x=digger.pos.x; sg.z=digger.pos.z; sg.R2=R*R;
  invalidateChunksNear(digger.pos.x, digger.pos.z, R+4);
}
function clearDiggerSwell(){
  const sg=digger.swell;
  if(sg.R2>0){ invalidateChunksNear(sg.x, sg.z, Math.sqrt(sg.R2)+4); sg.items.length=0; sg.R2=0; }
}
function resetDigger(){
  clearDiggerSwell();
  digger.active=false; digger.state='off'; digRumble=0;
  boomLight.intensity=0;
}

function deployDigger(explosive){
  if(gameState!=='play'||!player.alive) return;
  if(digger.active){ showMsg('A DIGGER IS ALREADY RUNNING',1.6); return; }
  if(explosive){
    if(expDiggerCount<=0){ showMsg('NO EXPLOSIVE DIGGER — FIND ONE OUT THERE',1.9); return; }
    expDiggerCount--;
  } else {
    if(diggerCount<=0){ showMsg('NO DIGGER THUMPERS LEFT',1.8); return; }
    diggerCount--;
  }
  _v1.set(Math.sin(player.heading),0,Math.cos(player.heading));
  digger.heading=player.heading;
  digger.pos.copy(player.pos).addScaledVector(_v1,5);
  digger.pos.y=terrainH(digger.pos.x,digger.pos.z)-DIG_DEPTH;
  digger.dir.copy(_v1);
  digger.active=true; digger.explosive=!!explosive; digger.state='run';
  digger.traveled=0; digger.dist=explosive?80:350;
  digger.spd=DIG_SPEED; digger.depth=DIG_DEPTH; digger.ph=Math.random()*9;
  digger.nextDeform=20; digger.rippleT=0; digger.rumbleT=0.25; digger.swellT=0; digger.armT=0; digger.armAcc=0;
  showMsg(explosive?'EXPLOSIVE DIGGER IN THE SAND — 80 M':'DIGGER RELEASED — 350 M OF RHYTHM',2.4);
  playSfx('thumperPlant',0.55,0.72,0);
  diggerRumbleSfx(digger.pos,1.3);
}

function updateDigger(dt){
  /* detonation flash decays */
  if(boomLight.intensity>0){ boomLight.intensity*=Math.exp(-4.5*dt); if(boomLight.intensity<0.01) boomLight.intensity=0; }
  if(!digger.active) return;

  if(digger.state==='arming'){
    digger.armT-=dt; digger.armAcc-=dt;
    if(digger.armAcc<=0){
      digger.armAcc=0.13;
      diggerRumbleSfx(digger.pos,1.5);
      burstDust(digger.pos,5,6);
    }
    digRumble=clamp(1-horizDist(digger.pos,player.pos)/240,0,1)*1.5;
    if(digger.armT<=0){ digger.active=false; digger.state='off'; detonateDigger(); }
    return;
  }

  digger.traveled+=digger.spd*dt;
  if(digger.traveled>=digger.dist){
    clearDiggerSwell();
    if(digger.explosive){
      digger.state='arming'; digger.armT=0.55; digger.armAcc=0;
      diggerRumbleSfx(digger.pos,1.1);
      showMsg('THE GROUND TREMBLES...',1.4);
    } else {
      digger.active=false; digger.state='off'; digRumble=0;
      burstDust(digger.pos,14,7); spawnRing(digger.pos,7,0.6);
      showMsg('DIGGER SPENT — SIGNAL LOST',1.8);
    }
    return;
  }

  /* underground travel: follows the terrain, gentle serpentine so the path reads organic */
  const wob=Math.sin(elapsed*0.55+digger.ph)*0.17;
  _v1.set(Math.sin(digger.heading+wob),0,Math.cos(digger.heading+wob));
  digger.pos.addScaledVector(_v1,digger.spd*dt);
  digger.pos.y=terrainH(digger.pos.x,digger.pos.z)-digger.depth;
  digger.dir.copy(_v1);

  /* shallow permanent furrow along the path (existing deform layer, FIFO-capped) */
  digger.nextDeform-=digger.spd*dt;
  if(digger.nextDeform<=0){ digger.nextDeform=26; addDeform(digger.pos.x,digger.pos.z,6,0.5); }

  /* sand spray + ripples above the device */
  digger.rippleT-=dt;
  if(digger.rippleT<=0){
    digger.rippleT=0.12;
    const gy=terrainH(digger.pos.x,digger.pos.z);
    for(let k=0;k<2;k++){
      const a=Math.random()*Math.PI*2, r=1.5+Math.random()*2.5;
      spawnP(digger.pos.x+Math.cos(a)*r, gy+0.15, digger.pos.z+Math.sin(a)*r,
        Math.cos(a)*2.5, 1.6+Math.random()*2.2, Math.sin(a)*2.5,
        0.8+Math.random()*0.7, 1.4+Math.random()*1.6, 0.82,0.66,0.45, 2.2, 1.1);
    }
    if(Math.random()<0.35)
      spawnCloud(_v1.set(digger.pos.x, gy+0.7, digger.pos.z), 2.4, 0.8, 0.3, 0xc9a06a);
  }
  /* positional rumble */
  digger.rumbleT-=dt;
  if(digger.rumbleT<=0){ digger.rumbleT=0.55+Math.random()*0.35; diggerRumbleSfx(digger.pos,1); }

  /* moving surface swell */
  digger.swellT-=dt;
  if(digger.swellT<=0){ digger.swellT=0.09; rebuildDiggerSwell(); }

  digRumble=clamp(1-horizDist(digger.pos,player.pos)/240,0,1);
}

/* ---------------- explosive detonation ---------------- */
function detonateDigger(){
  const px=digger.pos.x, pz=digger.pos.z, gy=terrainH(px,pz);
  digRumble=0; clearDiggerSwell();

  /* 1-2: the blast — Explosion sample (synth fallback), then physical impact */
  boomSfx(horizDist(digger.pos,player.pos), digger.pos);
  impactSfx();
  shake=Math.max(shake, clamp(1-horizDist(digger.pos,player.pos)/260,0.25,1));

  /* 3: sand erupts outward */
  burstDust(digger.pos,130,26);
  spawnGroundShockwave(px,pz,58,1.2);
  spawnCloudCluster(_v1.set(px,gy+1.5,pz), 18, 8, 4, 12, 2.2, 3.6, 0.55, true);
  spawnCloudCluster(_v1.set(px,gy+0.6,pz), 10, 6, 3, 9, 1.8, 3.0, 0.45, false);
  spawnRing(digger.pos,30,0.9);

  /* 4: brief fire at the core — embers + hot clouds + flash light, all self-fading */
  for(let k=0;k<34;k++){
    const a=Math.random()*Math.PI*2, sp=4+Math.random()*16;
    spawnP(px+(Math.random()-0.5)*3, gy+0.5+Math.random()*1.5, pz+(Math.random()-0.5)*3,
      Math.cos(a)*sp, 5+Math.random()*14, Math.sin(a)*sp,
      0.4+Math.random()*0.7, 1.2+Math.random()*2.2,
      1, 0.42+Math.random()*0.3, 0.1+Math.random()*0.12, -2.5, 1.6, PT_SPARK);
  }
  for(let k=0;k<4;k++)
    spawnCloud(_v1.set(px+(Math.random()-0.5)*3, gy+1+Math.random()*2.5, pz+(Math.random()-0.5)*3),
      4.5+Math.random()*3, 0.55+Math.random()*0.35, 0.75, 0xff7a30);
  boomLight.position.set(px,gy+3,pz);
  boomLight.intensity=26;

  /* 5: real terrain deformation — a blended Gaussian crater (no seams, no holes) */
  addBigDeform(px,pz,16,4.2);

  /* 6: worms caught in the blast — up to two kills, survivors scarred and scattered */
  const cand=[];
  for(const w of worms){
    if(w.state==='gone'||w.state==='dead') continue;
    const d=horizDist(w.pos,digger.pos);
    if(d<30) cand.push([d,w]);
  }
  cand.sort((a,b)=>a[0]-b[0]);
  let killed=0;
  for(let i=0;i<cand.length&&killed<2;i++){
    const w=cand[i][1];
    _v1.set(w.pos.x-px,0,w.pos.z-pz); if(_v1.lengthSq()<1) _v1.set(1,0,0);
    w.die(_v1);
    digBonus+=800;   /* awarded once per worm — the dead state can never re-award */
    killed++;
  }
  for(const w of worms){
    if(w.state==='gone'||w.state==='dead') continue;
    const d=horizDist(w.pos,digger.pos);
    if(d<55){
      scarWorm(w,1+((Math.random()*2)|0));
      if(w.state==='roam'||w.state==='hunt'||w.state==='cool'){
        w.state='cool'; w.cool=3+Math.random()*2;
        w.dir.set(w.pos.x-px,0,w.pos.z-pz).normalize();
      }
    }
  }
  if(alpha.active && horizDist(alpha.head.position,digger.pos)<70) scarWorm(alpha,2);

  /* the blast does not spare the buggy if you dug it in too close */
  if(horizDist(player.pos,digger.pos)<32 && player.alive) hitPlayer(35,digger.pos,'explosion');

  if(killed>0) showMsg((killed>1?'TWIN KILL':'WORM DESTROYED')+' · +'+(800*killed),2.4);
  else showMsg('DETONATION — THE DUNES FELL SILENT',2);
}
