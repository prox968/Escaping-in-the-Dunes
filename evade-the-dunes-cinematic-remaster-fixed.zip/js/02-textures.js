/* Procedural canvas textures: sand PBR, fBm clouds, vehicle materials */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- canvas textures ---------------- */
function makeBandTexture(){
  const s=128, cv=document.createElement('canvas'); cv.width=cv.height=s;
  const g=cv.getContext('2d');
  g.fillStyle='#93826c'; g.fillRect(0,0,s,s);
  for(let y=0;y<s;y+=8){
    g.fillStyle='rgba(50,40,30,0.5)'; g.fillRect(0,y,s,3);
    g.fillStyle='rgba(225,210,185,0.16)'; g.fillRect(0,y+3,s,1);
  }
  for(let i=0;i<1200;i++){
    g.fillStyle=`rgba(40,32,24,${Math.random()*0.16})`;
    g.fillRect(Math.random()*s, Math.random()*s, 1.5, 1.5);
  }
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makePlumeTexture(){
  const cv=document.createElement('canvas'); cv.width=cv.height=64;
  const g=cv.getContext('2d');
  const gr=g.createRadialGradient(32,32,2,32,32,30);
  gr.addColorStop(0,'rgba(255,255,255,0.9)'); gr.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=gr; g.fillRect(0,0,64,64);
  const t=new THREE.CanvasTexture(cv); t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeSoftShadowTexture(){
  const S=128, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const gr=g.createRadialGradient(S/2,S/2,2,S/2,S/2,S/2);
  gr.addColorStop(0,   'rgba(0,0,0,0.65)');
  gr.addColorStop(0.35,'rgba(0,0,0,0.42)');
  gr.addColorStop(0.7, 'rgba(0,0,0,0.14)');
  gr.addColorStop(1,   'rgba(0,0,0,0)');
  g.fillStyle=gr; g.fillRect(0,0,S,S);
  const t=new THREE.CanvasTexture(cv); t.colorSpace=THREE.SRGBColorSpace;
  return t;
}

/* ================================================================
   fBm CLOUD TEXTURE  — this is what makes particles look volumetric
   Generates a proper multi-octave puffy cloud sprite with bright
   top-lit crowns and dark crevices. Screenshot-a-grade upgrade over
   a plain radial gradient.
   ================================================================ */
function makeFbmCloudTexture(S, seed){
  S = S||192;
  const cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const img=g.createImageData(S,S), d=img.data;
  const sd = (seed|0) || 17;

  function h(ix,iz){
    let n = Math.imul(ix|0, 374761393) + Math.imul(iz|0, 668265263) + sd;
    n = Math.imul(n ^ (n>>>13), 1274126177);
    n ^= n>>>16;
    return (n>>>0)/4294967295;
  }
  function vn(x,z){
    const ix=Math.floor(x), iz=Math.floor(z), fx=x-ix, fz=z-iz;
    const ux=fx*fx*(3-2*fx), uz=fz*fz*(3-2*fz);
    const a=h(ix,iz), b=h(ix+1,iz), c=h(ix,iz+1), dd=h(ix+1,iz+1);
    return a+(b-a)*ux+(c-a)*uz+(a-b-c+dd)*ux*uz;
  }
  function fbm(x,z,oct){
    let v=0, amp=0.5, fr=1, tot=0;
    for(let i=0;i<oct;i++){ v += vn(x*fr, z*fr)*amp; tot += amp; fr*=2; amp*=0.5; }
    return v/tot;
  }
  const c=S/2;
  for(let y=0;y<S;y++){
    for(let x=0;x<S;x++){
      const nx=(x-c)/c, ny=(y-c)/c;
      const r=Math.sqrt(nx*nx+ny*ny);
      /* steeper falloff: alpha reaches zero inside the sprite corners (r=0.707),
         so rotated point sprites and cloud quads never show square edges */
      const falloff = Math.max(0, 1 - r*1.45);
      const falloff2 = Math.pow(falloff, 1.55);
      const n = fbm(x*0.055, y*0.055, 5);
      const n2 = fbm(x*0.11+13.7, y*0.11+7.3, 4);
      let a = falloff2 * (0.35 + 0.85*n) * (0.65 + 0.55*n2);
      if(a<0) a=0; else if(a>1) a=1;
      const lightY = 1 - y/S;              // brighter toward top
      const bright = 0.65 + 0.45*lightY + 0.15*n;
      const i=(y*S+x)*4;
      d[i]   = clamp(245*bright, 0, 255);
      d[i+1] = clamp(232*bright, 0, 255);
      d[i+2] = clamp(210*bright, 0, 255);
      d[i+3] = (a*255)|0;
    }
  }
  g.putImageData(img,0,0);
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  t.anisotropy=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}
/* Ring-shaped dust texture for ground shockwaves */
function makeDustRingTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const img=g.createImageData(S,S), d=img.data;
  const sd=91;
  function h(ix,iz){
    let n = Math.imul(ix|0,374761393)+Math.imul(iz|0,668265263)+sd;
    n = Math.imul(n^(n>>>13),1274126177); n ^= n>>>16;
    return (n>>>0)/4294967295;
  }
  function vn(x,z){
    const ix=Math.floor(x),iz=Math.floor(z),fx=x-ix,fz=z-iz;
    const ux=fx*fx*(3-2*fx),uz=fz*fz*(3-2*fz);
    const a=h(ix,iz),b=h(ix+1,iz),c=h(ix,iz+1),dd=h(ix+1,iz+1);
    return a+(b-a)*ux+(c-a)*uz+(a-b-c+dd)*ux*uz;
  }
  function fbm(x,z,oct){let v=0,amp=0.5,fr=1;for(let i=0;i<oct;i++){v+=vn(x*fr,z*fr)*amp;fr*=2;amp*=0.5;}return v;}
  const c=S/2;
  for(let y=0;y<S;y++){
    for(let x=0;x<S;x++){
      const nx=(x-c)/c, ny=(y-c)/c;
      const r=Math.sqrt(nx*nx+ny*ny);
      const ring = Math.exp(-Math.pow((r-0.52)/0.24, 2));
      const inner = Math.max(0, 1 - r*1.05);
      const n = fbm(x*0.06, y*0.06, 4);
      let a = ring * inner * (0.5 + 0.75*n);
      if(a<0) a=0; else if(a>1) a=1;
      const i=(y*S+x)*4;
      d[i]=232; d[i+1]=206; d[i+2]=168; d[i+3]=(a*255)|0;
    }
  }
  g.putImageData(img,0,0);
  const t=new THREE.CanvasTexture(cv); t.colorSpace=THREE.SRGBColorSpace;
  return t;
}

const bandTex = makeBandTexture(), plumeTex = makePlumeTexture();
const shadowTex = makeSoftShadowTexture();
const fbmCloudTex = makeFbmCloudTexture(192, 17);
const fbmCloudTexB = makeFbmCloudTexture(160, 43);
const dustRingTex = makeDustRingTexture();
/* very soft cloud puff: peak alpha stays low, so a sprite can never read as a solid dot */
function makePuffTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const base=g.createRadialGradient(S/2,S/2,0,S/2,S/2,S*0.5);
  base.addColorStop(0,'rgba(255,255,255,0.55)');
  base.addColorStop(0.45,'rgba(255,255,255,0.34)');
  base.addColorStop(0.8,'rgba(255,255,255,0.12)');
  base.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=base; g.fillRect(0,0,S,S);
  /* subtle lumps so the silhouette is irregular, not a perfect circle */
  for(let i=0;i<7;i++){
    const a=Math.random()*6.284, rr=Math.random()*0.18*S;
    const x=S/2+Math.cos(a)*rr, y=S/2+Math.sin(a)*rr*0.8;
    const r=(0.16+Math.random()*0.16)*S;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,'rgba(255,255,255,0.22)');
    gr.addColorStop(1,'rgba(255,255,255,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* faint granular specks for dusty texture */
  for(let i=0;i<500;i++){
    const x=Math.random()*S, y=Math.random()*S;
    if(Math.hypot(x-S/2,y-S/2)>0.44*S) continue;
    g.fillStyle=Math.random()<0.4?'rgba(0,0,0,0.10)':'rgba(255,255,255,0.16)';
    g.fillRect(x,y,1.6,1.6);
  }
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
const puffTex = makePuffTexture();
/* granular sand-dust puff: built from thousands of powder specks + clumps with
   eroded wispy edges — has visible grain structure at any sprite size, so it
   never reads as a smooth disc/dot */
function makeDustPuffTexture(){
  const S=512, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const c=S/2;
  /* soft volumetric body — gives the puff mass */
  for(let i=0;i<26;i++){
    const a=Math.random()*6.284, rr=Math.random()*0.30*S;
    const x=c+Math.cos(a)*rr, y=c+Math.sin(a)*rr*0.85 - S*0.05;
    const r=(0.10+Math.random()*0.14)*S;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,'rgba(255,250,238,0.18)');
    gr.addColorStop(1,'rgba(255,250,238,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* medium clumps — the visible cloud structure */
  for(let i=0;i<70;i++){
    const a=Math.random()*6.284, rr=(0.05+Math.random()*0.34)*S;
    const x=c+Math.cos(a)*rr, y=c+Math.sin(a)*rr*0.85 - S*0.05;
    const r=(0.02+Math.random()*0.05)*S;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,`rgba(246,236,214,${0.28+Math.random()*0.30})`);
    gr.addColorStop(1,'rgba(246,236,214,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* fine powder specks — the grain that sells it as sand dust */
  for(let i=0;i<2200;i++){
    const a=Math.random()*6.284, rr=Math.pow(Math.random(),0.6)*0.42*S;
    const x=c+Math.cos(a)*rr, y=c+Math.sin(a)*rr*0.9 - S*0.04;
    const s2=1+Math.random()*3.2;
    const light=Math.random()<0.62;
    g.fillStyle=`rgba(${light?'244,232,204':'150,128,94'},${0.16+Math.random()*0.38})`;
    g.fillRect(x,y,s2,s2);
  }
  /* erode the rim: punch transparent bites so the edge is wispy, never circular */
  g.globalCompositeOperation='destination-out';
  for(let i=0;i<26;i++){
    const a=Math.random()*6.284, rr=(0.34+Math.random()*0.12)*S;
    const x=c+Math.cos(a)*rr, y=c+Math.sin(a)*rr*0.9;
    const r=(0.03+Math.random()*0.07)*S;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,'rgba(0,0,0,0.85)');
    gr.addColorStop(1,'rgba(0,0,0,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  g.globalCompositeOperation='source-over';
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  t.anisotropy=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}
const dustPuffTex = makeDustPuffTexture();
/* Wind-sculpted sand ripples as a normal map: rides the dune surface (tangent space),
   costs one texture — no extra geometry. The pattern is fully TILEABLE (all wave
   frequencies are whole cycles per tile, warps use wrap-around value noise) and
   organic (noise-warped ridge phases), so no straight stripes or seam lines. */
function makeRippleNormalTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  const img=g.createImageData(S,S), d=img.data;
  /* tileable smooth value noise on an f×f lattice (wraps via modulo) */
  const W=(i,m)=>((i%m)+m)%m;
  const tnT=(u,v,f)=>{
    const x=u*f, y=v*f, ix=Math.floor(x), iy=Math.floor(y), fx=x-ix, fy=y-iy;
    const sx=fx*fx*(3-2*fx), sy=fy*fy*(3-2*fy);
    const a=noise2(W(ix,f),W(iy,f)), b=noise2(W(ix+1,f),W(iy,f)),
          c=noise2(W(ix,f),W(iy+1,f)), e=noise2(W(ix+1,f),W(iy+1,f));
    return a+(b-a)*sx+(c-a)*sy+(a-b-c+e)*sx*sy;
  };
  for(let y=0;y<S;y++) for(let x=0;x<S;x++){
    const u=x/S, v=y/S;
    const n1=tnT(u,v,3), n2=tnT(u,v,2), n3=tnT(u,v,7);
    let hgt=Math.sin((u*5 + n1*0.9)*6.2832)*0.55;      // 5 wavy wind-ridge systems per tile
    hgt+=Math.sin((u*11 + n2*1.4)*6.2832)*0.20;        // secondary fine ridges
    hgt+=(n3-0.5)*0.7;                                  // large-scale organic variation
    const i=(y*S+x)*4, val=(hgt*0.5+0.5)*255;
    d[i]=d[i+1]=d[i+2]=val; d[i+3]=255;
  }
  g.putImageData(img,0,0);
  const t=new THREE.CanvasTexture(heightToNormal(cv, 1.6));
  t.wrapS=t.wrapT=THREE.RepeatWrapping;
  t.repeat.set(9,9);
  t.anisotropy=Math.min(4, renderer.capabilities.getMaxAnisotropy());
  return t;
}
const rippleNormalTex = makeRippleNormalTexture();

/* ================================================================
   DESERT SAND — full PBR material set (albedo / normal / roughness)
   ---------------------------------------------------------------
   One tileable 768² sheet holding every scale the dune surface shows:
     • two wavy wind-ripple systems (coarse + fine), domain-warped so
       there are no straight stripes
     • wind-carved undulation underneath, saltation streaks along the
       wind, and dark compacted patches where the sand is old and packed
     • clustered coarse grit plus true per-pixel sand-grain speckle
     • a loose/packed roughness split: hollows duller, packed ground
       and polished crests a touch slicker
   The albedo is bright and near-neutral on purpose — the dune palette
   comes from the terrain's vertex colours, this only multiplies.
   Height is normalised, then baked to a tileable normal map with the
   shared heightToNormal(). The three sheets are tiled at different
   world scales and angles by the caller, so the desert never shows an
   obvious repeating grid.
   ================================================================ */
function makeSandPBR(){
  const S=GRAPHICS.sandTexSize, H=new Float32Array(S*S);
  const hashI=(x,y,p,q)=>{ x=((x%p)+p)%p; y=((y%q)+q)%q;
    let h=Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(p*31+q,69069);
    h=Math.imul(h^(h>>>13),1274126177); h^=h>>>16; return (h>>>0)/4294967296; };
  const vn=(x,y,p,q)=>{ const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const a=hashI(xi,yi,p,q), b=hashI(xi+1,yi,p,q), c=hashI(xi,yi+1,p,q), d=hashI(xi+1,yi+1,p,q);
    return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v; };
  const fbm=(x,y,p,q,o)=>{ let s=0,a=0.5,f=1,n=0; for(let i=0;i<o;i++){ s+=vn(x*f,y*f,p*f,q*f)*a; n+=a; f*=2; a*=0.5; } return s/n; };

  const cv=document.createElement('canvas'); cv.width=cv.height=S;
  const cg=cv.getContext('2d'), cimg=cg.createImageData(S,S), cd=cimg.data;
  const rc=document.createElement('canvas'); rc.width=rc.height=S;
  const rg=rc.getContext('2d'), rimg=rg.createImageData(S,S), rd=rimg.data;
  const hc=document.createElement('canvas'); hc.width=hc.height=S;
  const hg=hc.getContext('2d'), himg=hg.createImageData(S,S), hd=himg.data;

  for(let py=0;py<S;py++){
    const ny=py/S;
    for(let px=0;px<S;px++){
      const nx=px/S;
      /* warped fields, all lattice-aligned so the sheet tiles exactly
         (integer offsets only — a fractional phase would break the tile) */
      const big =fbm(nx*3,ny*3,3,3,3);                 // broad drift / compaction
      const med =fbm(nx*7+3,ny*7+5,7,7,2);             // mid mottling
      const stre=fbm(nx*29,ny*5+2,29,5,2);             // saltation streaks (along wind)
      const grit=fbm(nx*61+7,ny*61+11,61,61,2);        // clustered coarse grit
      const hs=hashI(px,py,S,S);                       // per-pixel sand grain

      /* ---- two wavy wind-ripple systems ---- */
      const ph1=(ny*13 + (big-0.5)*2.4 + (med-0.5)*1.2)*Math.PI*2;
      let r1=0.5+0.5*Math.sin(ph1); r1=r1*r1*(3-2*r1); r1=Math.pow(r1,1.35);
      const ph2=(ny*34 + (r1-0.5)*2.2 + (grit-0.5)*1.6)*Math.PI*2;
      const r2=0.5+0.5*Math.sin(ph2);

      /* ---- height (normalised below so the normal map fills its range) ---- */
      H[py*S+px]=0.52*r1 + 0.14*r2 + 0.26*(big-0.5) + 0.10*(med-0.5) + 0.06*(grit-0.5) + 0.05*(hs-0.5);

      /* ---- albedo: bright near-neutral sand (vertex colours add the hue) ---- */
      const tone=1 + (big-0.5)*0.20 + (med-0.5)*0.10;
      let r=0.97*tone, g=0.955*tone, b=0.925*tone;
      const st=(stre-0.5);
      r+=st*0.10; g+=st*0.09; b+=st*0.07;                      // pale wind streaks
      if(big>0.58){ const k=Math.min(1,(big-0.58)*3.0);        // dark compacted patches
        r*=1-k*0.14; g*=1-k*0.16; b*=1-k*0.18; }
      const sp=(hs-0.5)*0.11 + (grit-0.5)*0.10;                // grain + grit speckle
      r+=sp; g+=sp*0.95; b+=sp*0.88;
      const o=(py*S+px)*4;
      cd[o]=clamp(r,0,1)*255; cd[o+1]=clamp(g,0,1)*255; cd[o+2]=clamp(b,0,1)*255; cd[o+3]=255;

      /* ---- roughness: hollows dull, packed patches and crests slicker ---- */
      let rough=0.90 - 0.11*Math.max(0,r1-0.55)*2.2 + 0.05*(grit-0.5);
      if(big>0.58) rough-=Math.min(1,(big-0.58)*3.0)*0.10;
      const rv=(clamp(rough,0.62,1.0)*255)|0;
      rd[o]=rd[o+1]=rd[o+2]=rv; rd[o+3]=255;
    }
  }
  /* normalise the height field, then bake the normal map */
  let mn=1e9,mx=-1e9;
  for(let i=0;i<S*S;i++){ const h=H[i]; if(h<mn)mn=h; if(h>mx)mx=h; }
  const inv=1/Math.max(1e-6,mx-mn);
  for(let i=0;i<S*S;i++){
    const hv=clamp((H[i]-mn)*inv*255,0,255)|0, o=i*4;
    hd[o]=hd[o+1]=hd[o+2]=hv; hd[o+3]=255;
  }
  cg.putImageData(cimg,0,0);
  rg.putImageData(rimg,0,0);
  hg.putImageData(himg,0,0);

  const an=Math.min(GRAPHICS.sandAniso, renderer.capabilities.getMaxAnisotropy());
  const map=new THREE.CanvasTexture(cv); map.colorSpace=THREE.SRGBColorSpace;
  const nmap=new THREE.CanvasTexture(heightToNormal(hc, 4.6));
  const rmap=GRAPHICS.sandRoughnessMap ? new THREE.CanvasTexture(rc) : null;
  const texList = rmap ? [map,nmap,rmap] : [map,nmap];
  for(const t of texList){ t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=an; }
  /* independent per-texture transforms (three r152+): each sheet tiles at
     its own world scale and angle, so repetition is hard to spot */
  nmap.repeat.set(1.47,1.47); nmap.rotation=0.55; nmap.offset.set(0.13,0.42);
  if(rmap){ rmap.repeat.set(0.61,0.61); rmap.rotation=2.10; rmap.offset.set(0.31,0.17); }
  return { map, nmap, rmap };
}
const sandPBR = makeSandPBR();

/* ---------------- vehicle textures ---------------- */
function heightToNormal(srcCanvas, strength){
  const w=srcCanvas.width, h=srcCanvas.height;
  const src=srcCanvas.getContext('2d').getImageData(0,0,w,h).data;
  const out=document.createElement('canvas'); out.width=w; out.height=h;
  const ctx=out.getContext('2d');
  const img=ctx.createImageData(w,h), d=img.data;
  const H=(x,y)=>{
    x=((x%w)+w)%w; y=((y%h)+h)%h;
    const i=(y*w+x)*4;
    return (src[i]*0.299+src[i+1]*0.587+src[i+2]*0.114)/255;
  };
  for(let y=0;y<h;y++) for(let x=0;x<w;x++){
    const dx=(H(x+1,y)-H(x-1,y))*strength;
    const dy=(H(x,y+1)-H(x,y-1))*strength;
    let nx=-dx, ny=dy, nz=1;
    const l=Math.hypot(nx,ny,nz); nx/=l; ny/=l; nz/=l;
    const i=(y*w+x)*4;
    d[i]=(nx*0.5+0.5)*255; d[i+1]=(ny*0.5+0.5)*255; d[i+2]=(nz*0.5+0.5)*255; d[i+3]=255;
  }
  ctx.putImageData(img,0,0);
  return out;
}
function makeBodyTexture(){
  const S=1024, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  /* dark desert-beige paint: warm gradient, grain, dust and wear */
  const bg=g.createLinearGradient(0,0,0,S);
  bg.addColorStop(0,'#c2ad83');
  bg.addColorStop(0.45,'#b39c6f');
  bg.addColorStop(1,'#8f7a52');
  g.fillStyle=bg; g.fillRect(0,0,S,S);
  /* fine grain */
  for(let i=0;i<2600;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'236,222,190':'96,80,52'},${0.05+Math.random()*0.09})`;
    g.fillRect(Math.random()*S,Math.random()*S,1.4,1.4);
  }
  /* soft tonal clouds */
  for(let i=0;i<46;i++){
    const x=Math.random()*S,y=Math.random()*S,r=40+Math.random()*130;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    const dark=Math.random()<0.5;
    gr.addColorStop(0, dark?'rgba(92,76,48,0.07)':'rgba(232,216,180,0.07)');
    gr.addColorStop(1,'rgba(0,0,0,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* brushed streaks */
  for(let i=0;i<90;i++){
    const y=Math.random()*S, w=60+Math.random()*300;
    g.strokeStyle=`rgba(${Math.random()<0.5?'110,92,60':'220,204,168'},${0.03+Math.random()*0.05})`;
    g.lineWidth=0.8+Math.random()*1.6;
    const x=Math.random()*S;
    g.beginPath(); g.moveTo(x-w/2,y); g.lineTo(x+w/2,y+(Math.random()-0.5)*6); g.stroke();
  }
  /* sand speckle clusters */
  for(let i=0;i<1300;i++){
    const x=Math.random()*S,y=Math.random()*S;
    g.fillStyle=`rgba(${Math.random()<0.5?'228,210,172':'120,100,64'},${0.10+Math.random()*0.15})`;
    g.fillRect(x,y,1+Math.random()*1.6,1+Math.random()*1.6);
  }
  /* faint scratches */
  for(let i=0;i<60;i++){
    const x=Math.random()*S,y=Math.random()*S,a=Math.random()*6.284,l=8+Math.random()*60;
    g.strokeStyle=`rgba(${Math.random()<0.5?'70,58,36':'210,192,156'},${0.05+Math.random()*0.09})`;
    g.lineWidth=0.6+Math.random();
    g.beginPath(); g.moveTo(x,y); g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l); g.stroke();
  }
  /* heavy dust film toward the bottom */
  const dg=g.createLinearGradient(0,S*0.55,0,S);
  dg.addColorStop(0,'rgba(150,128,88,0)');
  dg.addColorStop(1,'rgba(150,128,88,0.35)');
  g.fillStyle=dg; g.fillRect(0,0,S,S);
  /* very light speckle to keep it from banding */
  for(let i=0;i<2400;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'120,98,64':'244,234,210'},${0.03+Math.random()*0.06})`;
    g.fillRect(Math.random()*S,Math.random()*S,Math.random()*2+0.5,Math.random()*2+0.5);
  }
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2,2);
  t.colorSpace=THREE.SRGBColorSpace;
  t.anisotropy=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}
function makeBodyRoughness(){
  const S=512, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  g.fillStyle='#8f8f8f'; g.fillRect(0,0,S,S);   /* dusty satin base for the clearcoat */
  for(let i=0;i<900;i++){
    const v=Math.random()<0.5?108:168;
    g.fillStyle=`rgba(${v},${v},${v},${0.05+Math.random()*0.10})`;
    g.beginPath(); g.arc(Math.random()*S,Math.random()*S,6+Math.random()*30,0,6.284); g.fill();
  }
  /* streaky roughness bands (dust wear) */
  for(let i=0;i<70;i++){
    const y=Math.random()*S, w=60+Math.random()*260;
    g.fillStyle=`rgba(${Math.random()<0.5?100:170},${Math.random()<0.5?100:170},${Math.random()<0.5?100:170},${0.06+Math.random()*0.08})`;
    g.fillRect(Math.random()*S,y,w,2+Math.random()*5);
  }
  const dg=g.createLinearGradient(0,0,0,S);
  dg.addColorStop(0,'rgba(112,112,112,0)');
  dg.addColorStop(1,'rgba(165,165,165,0.55)');
  g.fillStyle=dg; g.fillRect(0,0,S,S);
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2,2);
  return t;
}
function makeTireTextures(){
  const W=512,H=256;
  const cv=document.createElement('canvas'); cv.width=W; cv.height=H;
  const g=cv.getContext('2d');
  const hc=document.createElement('canvas'); hc.width=W; hc.height=H;
  const hg=hc.getContext('2d');
  g.fillStyle='#191714'; g.fillRect(0,0,W,H);
  hg.fillStyle='#404040'; hg.fillRect(0,0,W,H);
  /* four rows of staggered tread blocks with siping */
  const rows=[[4,52],[70,54],[140,52],[206,46]];
  const cols=26, cw=W/cols;
  for(let i=0;i<cols;i++){
    const off=(i%2)?cw/2:0;
    for(let r=0;r<rows.length;r++){
      const [by,bh]=rows[r];
      const j=(Math.imul(i*7+r,2654435761)>>>0)%9;
      const x=i*cw+off, yy=by+(j%3)*2-2;
      g.fillStyle = j%2 ? '#26231f' : '#211e1a';
      g.fillRect(x+2, yy, cw-5, bh);
      g.fillStyle='rgba(255,255,255,0.06)'; g.fillRect(x+2, yy, cw-5, 3);
      g.fillStyle='rgba(0,0,0,0.55)';       g.fillRect(x+2, yy+bh-3, cw-5, 3);
      hg.fillStyle = j%2 ? '#cccccc' : '#b6b6b6';
      hg.fillRect(x+2, yy, cw-5, bh);
      /* siping */
      g.strokeStyle='rgba(0,0,0,0.55)'; g.lineWidth=2;
      hg.strokeStyle='#242424'; hg.lineWidth=2;
      for(let s=0;s<3;s++){
        const sx=x+4+s*(cw-8)/2.5;
        g.beginPath(); g.moveTo(sx,yy+4); g.lineTo(sx+5,yy+bh-4); g.stroke();
        hg.beginPath(); hg.moveTo(sx,yy+4); hg.lineTo(sx+5,yy+bh-4); hg.stroke();
      }
    }
  }
  /* three circumferential grooves between the rows */
  for(const gy of [62,132,200]){
    g.fillStyle='#0a0908'; g.fillRect(0,gy-4,W,8);
    g.fillStyle='rgba(255,255,255,0.05)'; g.fillRect(0,gy-4,W,1.5); g.fillRect(0,gy+2.5,W,1.5);
    hg.fillStyle='#161616'; hg.fillRect(0,gy-4,W,8);
  }
  /* wear noise */
  for(let i=0;i<5200;i++){
    const dark=Math.random()<0.5;
    g.fillStyle=`rgba(${dark?'0,0,0':'150,145,135'},${Math.random()*0.08})`;
    g.fillRect(Math.random()*W,Math.random()*H,1.5,1.5);
    hg.fillStyle=`rgba(${dark?'60,60,60':'170,170,170'},${Math.random()*0.25})`;
    hg.fillRect(Math.random()*W,Math.random()*H,1.5,1.5);
  }
  const map=new THREE.CanvasTexture(cv);
  map.colorSpace=THREE.SRGBColorSpace;
  map.wrapS=map.wrapT=THREE.RepeatWrapping;
  map.anisotropy=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const normalMap=new THREE.CanvasTexture(heightToNormal(hc, 3.0));
  normalMap.wrapS=normalMap.wrapT=THREE.RepeatWrapping;
  return {map, normalMap};
}
function makeSidewallTexture(){
  const S=512, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  g.fillStyle='#181613'; g.fillRect(0,0,S,S);
  const gr=g.createRadialGradient(S/2,S/2,10,S/2,S/2,S/2);
  gr.addColorStop(0,'#2e2b26'); gr.addColorStop(0.62,'#211e1a'); gr.addColorStop(1,'#0f0e0c');
  g.fillStyle=gr; g.beginPath(); g.arc(S/2,S/2,S/2,0,6.284); g.fill();
  /* moulding rings */
  g.strokeStyle='rgba(160,150,130,0.10)'; g.lineWidth=1.5;
  for(let r=42;r<S/2-36;r+=13){ g.beginPath(); g.arc(S/2,S/2,r,0,6.284); g.stroke(); }
  /* shoulder serrations near the rim of the sidewall */
  g.strokeStyle='rgba(0,0,0,0.5)'; g.lineWidth=3;
  for(let i=0;i<72;i++){
    const a=i/72*Math.PI*2;
    g.beginPath();
    g.moveTo(S/2+Math.cos(a)*(S/2-14), S/2+Math.sin(a)*(S/2-14));
    g.lineTo(S/2+Math.cos(a)*(S/2-30), S/2+Math.sin(a)*(S/2-30));
    g.stroke();
  }
  /* curved raised lettering */
  g.font='bold 25px monospace'; g.textAlign='center'; g.textBaseline='middle';
  const msg='SHAI-HULUD · 4X4 · RADIAL GT';
  const R=S*0.335, step=0.105;
  let a0=-step*(msg.length-1)/2 - Math.PI/2;
  for(const ch of msg){
    g.save();
    g.translate(S/2+Math.cos(a0)*R, S/2+Math.sin(a0)*R);
    g.rotate(a0+Math.PI/2);
    g.fillStyle='rgba(0,0,0,0.55)';      g.fillText(ch,1.5,1.5);
    g.fillStyle='rgba(198,190,170,0.78)'; g.fillText(ch,0,0);
    g.restore();
    a0+=step;
  }
  for(let i=0;i<900;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'0,0,0':'140,130,110'},${Math.random()*0.12})`;
    g.fillRect(Math.random()*S,Math.random()*S,1.5,1.5);
  }
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeMetalTexture(){
  const S=512, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  g.fillStyle='#6a665e'; g.fillRect(0,0,S,S);
  for(let i=0;i<600;i++){
    const v=Math.random()<0.5?30:130;
    g.fillStyle=`rgba(${v},${v-2},${v-6},${0.05+Math.random()*0.12})`;
    g.beginPath(); g.arc(Math.random()*S,Math.random()*S,3+Math.random()*26,0,6.284); g.fill();
  }
  /* fine vertical brush */
  g.strokeStyle='rgba(255,255,255,0.035)'; g.lineWidth=1;
  for(let x=0;x<S;x+=3){ g.beginPath(); g.moveTo(x,0); g.lineTo(x,S); g.stroke(); }
  for(let i=0;i<260;i++){
    g.strokeStyle=`rgba(${Math.random()<0.5?'190,184,170':'20,18,16'},${0.05+Math.random()*0.12})`;
    g.lineWidth=0.6+Math.random();
    const x=Math.random()*S,y=Math.random()*S,a=Math.random()*6.284,l=4+Math.random()*44;
    g.beginPath(); g.moveTo(x,y); g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l); g.stroke();
  }
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(2,2);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeSeatTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  g.fillStyle='#1d1913'; g.fillRect(0,0,S,S);
  /* coarse warm-brown woven pattern */
  for(let y=0;y<S;y+=6){
    for(let x=0;x<S;x+=6){
      const v=28+Math.random()*14;
      g.fillStyle=`rgb(${v|0},${(v-3)|0},${(v-8)|0})`;
      g.fillRect(x+((y/6)%2?3:0),y,4,2);
    }
  }
  for(let i=0;i<800;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'0,0,0':'122,100,72'},${Math.random()*0.10})`;
    g.fillRect(Math.random()*S,Math.random()*S,1.5,1.5);
  }
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(3,3);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeGrilleTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  g.fillStyle='#0e0e0d'; g.fillRect(0,0,S,S);
  g.strokeStyle='#43423d'; g.lineWidth=3;
  for(let i=0;i<=S;i+=16){
    g.beginPath(); g.moveTo(i,0); g.lineTo(i,S); g.stroke();
    g.beginPath(); g.moveTo(0,i); g.lineTo(S,i); g.stroke();
  }
  g.strokeStyle='rgba(255,255,255,0.05)'; g.lineWidth=1;
  for(let i=8;i<=S;i+=16){
    g.beginPath(); g.moveTo(i,0); g.lineTo(i,S); g.stroke();
    g.beginPath(); g.moveTo(0,i); g.lineTo(S,i); g.stroke();
  }
  const vg=g.createRadialGradient(S/2,S/2,20,S/2,S/2,S*0.72);
  vg.addColorStop(0,'rgba(0,0,0,0)'); vg.addColorStop(1,'rgba(0,0,0,0.55)');
  g.fillStyle=vg; g.fillRect(0,0,S,S);
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(5,2);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeDecalTexture(){
  const W=1024,H=512, cv=document.createElement('canvas'); cv.width=W; cv.height=H;
  const g=cv.getContext('2d');
  /* RZR-style graphics on a transparent background */
  g.save();
  g.translate(W/2,H*0.34);
  g.transform(1,0,-0.24,1,0,0);
  g.font='bold 190px "Arial Black", Arial, sans-serif';
  g.textAlign='center'; g.textBaseline='middle';
  g.lineWidth=10; g.strokeStyle='rgba(60,52,40,0.85)'; g.strokeText('RZR',0,4);
  g.fillStyle='rgba(246,242,232,0.96)'; g.fillText('RZR',0,4);
  g.restore();
  g.font='bold 88px Arial, sans-serif';
  g.textAlign='left'; g.textBaseline='middle';
  g.fillStyle='rgba(84,76,62,0.92)';
  g.fillText('BOOST', W*0.28, H*0.66);
  g.font='bold 38px Arial, sans-serif';
  g.fillStyle='rgba(178,60,32,0.9)';
  g.fillText('PRO R', W*0.285, H*0.80);
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  t.anisotropy=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}
function makeDustRingTexture(){
  const W=256,H=128, cv=document.createElement('canvas'); cv.width=W; cv.height=H;
  const g=cv.getContext('2d');
  /* transparent base — sandy mottling that reads as accumulated dust */
  for(let i=0;i<420;i++){
    const x=Math.random()*W, y=Math.random()*H, r=3+Math.random()*14;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    const tone=Math.random()<0.5?'196,178,142':'150,130,96';
    gr.addColorStop(0,`rgba(${tone},${0.25+Math.random()*0.4})`);
    gr.addColorStop(1,`rgba(${tone},0)`);
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* dust clumps and streaks along the tread */
  for(let i=0;i<260;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'210,192,154':'118,100,70'},${0.15+Math.random()*0.35})`;
    g.fillRect(Math.random()*W,Math.random()*H,2+Math.random()*5,1+Math.random()*2.5);
  }
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(6,1);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeScratchTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  /* thin bright gouges with dark shadows on a transparent background */
  for(let i=0;i<7;i++){
    const x0=20+Math.random()*(S-40), y0=20+Math.random()*(S-40);
    const a=(Math.random()-0.5)*1.6, l=50+Math.random()*150;
    g.strokeStyle='rgba(30,26,20,0.55)'; g.lineWidth=1.6+Math.random()*1.6;
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x0+Math.cos(a)*l,y0+Math.sin(a)*l); g.stroke();
    g.strokeStyle='rgba(236,222,190,0.75)'; g.lineWidth=0.8+Math.random()*1.2;
    g.beginPath(); g.moveTo(x0+1,y0+1); g.lineTo(x0+Math.cos(a)*l+1,y0+Math.sin(a)*l+1); g.stroke();
  }
  for(let i=0;i<26;i++){
    g.fillStyle=`rgba(40,34,26,${0.25+Math.random()*0.4})`;
    g.fillRect(Math.random()*S,Math.random()*S,1+Math.random()*3,1+Math.random()*3);
  }
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeScuffTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  /* soft dark grime smudges */
  for(let i=0;i<9;i++){
    const x=Math.random()*S,y=Math.random()*S,r=18+Math.random()*46;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,`rgba(52,44,32,${0.18+Math.random()*0.22})`);
    gr.addColorStop(1,'rgba(52,44,32,0)');
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  /* micro scratch cluster */
  for(let i=0;i<18;i++){
    const x=Math.random()*S,y=Math.random()*S,a=Math.random()*6.284,l=6+Math.random()*26;
    g.strokeStyle=`rgba(200,184,150,${0.2+Math.random()*0.3})`;
    g.lineWidth=0.7;
    g.beginPath(); g.moveTo(x,y); g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l); g.stroke();
  }
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}
function makeDustFilmTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d');
  for(let i=0;i<120;i++){
    const x=Math.random()*S, y=Math.random()*S, r=8+Math.random()*38;
    const gr=g.createRadialGradient(x,y,0,x,y,r);
    const tone=Math.random()<0.45?'198,172,126':'146,118,78';
    gr.addColorStop(0,`rgba(${tone},${0.16+Math.random()*0.30})`);
    gr.addColorStop(1,`rgba(${tone},0)`);
    g.fillStyle=gr; g.beginPath(); g.arc(x,y,r,0,6.284); g.fill();
  }
  for(let i=0;i<180;i++){
    g.fillStyle=`rgba(${Math.random()<0.5?'186,160,114':'112,90,58'},${0.12+Math.random()*0.28})`;
    g.fillRect(Math.random()*S,Math.random()*S,1+Math.random()*3,1+Math.random()*7);
  }
  for(let i=0;i<24;i++){
    const x=Math.random()*S,y=Math.random()*S,a=Math.random()*6.284,l=12+Math.random()*46;
    g.strokeStyle=`rgba(166,140,98,${0.10+Math.random()*0.20})`;
    g.lineWidth=1+Math.random()*3;
    g.beginPath(); g.moveTo(x,y); g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l); g.stroke();
  }
  g.globalCompositeOperation='destination-in';
  const fade=g.createRadialGradient(S/2,S/2,S*0.12,S/2,S/2,S*0.52);
  fade.addColorStop(0,'rgba(0,0,0,1)');
  fade.addColorStop(0.72,'rgba(0,0,0,0.9)');
  fade.addColorStop(1,'rgba(0,0,0,0)');
  g.fillStyle=fade; g.fillRect(0,0,S,S);
  g.globalCompositeOperation='source-over';
  const t=new THREE.CanvasTexture(cv);
  t.colorSpace=THREE.SRGBColorSpace;
  return t;
}

/* ================================================================
   WORM HIDE — weathered grey hide (albedo / normal / roughness)
   ---------------------------------------------------------------
   Matches the sculpted plate look in 07-worms.js: the ring bands are
   geometry now, so this is purely the surface — a sun-bleached,
   wind-carved hide:
     • soft wavy grain flowing around the body, crossed by a second
       finer set of waves (weather-polished stone/leather)
     • large mottling, small crisp ripples, speckle and pock marks
     • a sparse network of shallow cracks, dark down in the seams
     • pale polished crowns where the wind scours, grime in the lows
   Height is derived once and turned into a matching normal map via
   the shared heightToNormal() helper, so the grain is lit for real.
   ================================================================ */
function makeWormHideMaps(){
  const S=512, H=new Float32Array(S*S);
  const hashI=(x,y,p,q)=>{ x=((x%p)+p)%p; y=((y%q)+q)%q;
    let h=Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(p*31+q,69069);
    h=Math.imul(h^(h>>>13),1274126177); h^=h>>>16; return (h>>>0)/4294967296; };
  const vn=(x,y,p,q)=>{ const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const a=hashI(xi,yi,p,q), b=hashI(xi+1,yi,p,q), c=hashI(xi,yi+1,p,q), d=hashI(xi+1,yi+1,p,q);
    return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v; };
  const fbm=(x,y,p,q,o)=>{ let s=0,a=0.5,f=1,n=0; for(let i=0;i<o;i++){ s+=vn(x*f,y*f,p*f,q*f)*a; n+=a; f*=2; a*=0.5; } return s/n; };

  const GX=9, GY=9;                          // sparse crack cells, square and open
  const fp=new Float32Array(GX*GY*2);
  for(let j=0;j<GY;j++) for(let i=0;i<GX;i++){ fp[(j*GX+i)*2]=hashI(i,j,GX,GY+7); fp[(j*GX+i)*2+1]=hashI(i+11,j+5,GX,GY+7); }

  const cv=document.createElement('canvas'); cv.width=cv.height=S;
  const cg=cv.getContext('2d'), cimg=cg.createImageData(S,S), cd=cimg.data;
  const rc=document.createElement('canvas'); rc.width=rc.height=S;
  const rg=rc.getContext('2d'), rimg=rg.createImageData(S,S), rd=rimg.data;
  const hc=document.createElement('canvas'); hc.width=hc.height=S;
  const hg=hc.getContext('2d'), himg=hg.createImageData(S,S), hd=himg.data;

  for(let py=0;py<S;py++){
    const ny=py/S;
    for(let px=0;px<S;px++){
      const nx=px/S;
      const big  =fbm(nx*4,ny*4,4,4,4);                       // broad mottling / polish
      const mote =fbm(nx*9+4.2,ny*9+2.6,9,9,3);               // mid patches
      const war  =fbm(nx*2.6+1.7,ny*2.6+0.9,3,3,3);           // domain warp for the grain lines
      const grain =0.5+0.5*Math.sin((ny*22+war*3.1)*Math.PI*2);
      const grain2=0.5+0.5*Math.sin((ny*41+war*4.4+0.31)*Math.PI*2);
      const wav  =fbm(nx*30+8.0,ny*30+3.0,30,30,2);           // small crisp ripples
      const wrk  =fbm(nx*64,ny*8,64,8,2);                     // faint streaks along the ring
      const peb  =fbm(nx*120,ny*120,120,120,2);               // pock marks
      /* sparse cracks: distance to the cellular edges */
      const cx=nx*GX+(mote-0.5)*1.2, cy=ny*GY+(big-0.5)*1.2, ci=Math.floor(cx), cj=Math.floor(cy);
      let F1=9, F2=9, id=0;
      for(let dj=-1;dj<=1;dj++) for(let di=-1;di<=1;di++){
        const ii=ci+di, jj=cj+dj, wi=((ii%GX)+GX)%GX, wj=((jj%GY)+GY)%GY, k=(wj*GX+wi)*2;
        const dx=ii+0.15+fp[k]*0.7-cx, dy=jj+0.15+fp[k+1]*0.7-cy;
        const d=dx*dx+dy*dy;
        if(d<F1){ F2=F1; F1=d; id=wj*GX+wi; } else if(d<F2) F2=d;
      }
      const edge=Math.sqrt(F2)-Math.sqrt(F1);
      const crack=1-Math.min(1,edge/0.06), cc=crack*crack;
      const crease=0.5+0.5*Math.cos((big*6.0+ny*3.0)*Math.PI);   // long wandering creases

      /* ---- height (normalised below so the normal map keeps full strength) ---- */
      H[py*S+px]=0.34*grain+0.20*grain2+0.30*big+0.10*mote+0.10*peb-0.10*wav-0.55*cc-0.10*wrk-0.22*crease;

      /* ---- colour: grey hide with a sandy cast, grime in the lows ---- */
      const tone=0.86+0.28*hashI(id,7,GX,GY+3)+(big-0.5)*0.34+(mote-0.5)*0.18;
      let r=0.545*tone, g=0.522*tone, b=0.482*tone;
      const pol=Math.max(0,big-0.52)*1.8*(1-cc);                 // wind-polished crowns
      r+=pol*0.20; g+=pol*0.19; b+=pol*0.16;
      const vein=Math.pow(grain,3)*0.11+Math.pow(grain2,4)*0.07+Math.pow(crease,2)*0.06;
      r*=1-vein; g*=1-vein*0.97; b*=1-vein*0.92;                 // dark wavy grain lines
      r=lerp(r,0.14,cc*0.85); g=lerp(g,0.13,cc*0.85); b=lerp(b,0.115,cc*0.85);   // dark cracks
      const st=Math.max(0,Math.min(1,(wrk-0.58)/0.28)), sk=0.22*st;
      r*=1-sk; g*=1-sk*0.97; b*=1-sk*0.9;                        // worn streaks
      if(mote>0.66){ const k=(mote-0.66)*1.4; r*=1-k*0.24; g*=1-k*0.23; b*=1-k*0.20; }
      const sp=(peb-0.5)*0.10; r+=sp; g+=sp*0.96; b+=sp*0.88;    // fine pock speckle
      const o=(py*S+px)*4;
      cd[o]=clamp(r,0,1)*255; cd[o+1]=clamp(g,0,1)*255; cd[o+2]=clamp(b,0,1)*255; cd[o+3]=255;

      /* ---- roughness (0=smooth, 1=rough) ---- */
      const rough=0.80 +0.16*cc -0.16*Math.max(0,big-0.5) +0.08*wav +0.15*vein +(peb-0.5)*0.06;
      const rv=(clamp(rough,0.42,1.0)*255)|0;
      rd[o]=rd[o+1]=rd[o+2]=rv; rd[o+3]=255;
    }
  }
  /* normalise the height field before baking the normal map */
  let mn=1e9,mx=-1e9;
  for(let i=0;i<S*S;i++){ const h=H[i]; if(h<mn)mn=h; if(h>mx)mx=h; }
  const inv=1/Math.max(1e-6,mx-mn);
  for(let i=0;i<S*S;i++){
    const hv=clamp((H[i]-mn)*inv*255,0,255)|0, o=i*4;
    hd[o]=hd[o+1]=hd[o+2]=hv; hd[o+3]=255;
  }
  cg.putImageData(cimg,0,0);
  rg.putImageData(rimg,0,0);
  hg.putImageData(himg,0,0);

  const an=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const map=new THREE.CanvasTexture(cv);
  map.colorSpace=THREE.SRGBColorSpace;
  const nmap=new THREE.CanvasTexture(heightToNormal(hc, 4.0));
  const rmap=new THREE.CanvasTexture(rc);
  for(const t of [map,nmap,rmap]){ t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=an; }
  return { map, nmap, rmap };
}
const wormHideMaps = makeWormHideMaps();

