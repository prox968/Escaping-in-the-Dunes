let gfxComposer = null;
let gfxBloomPass = null;
let gfxGodRayPass = null;  // screen-space volumetric shafts
let gfxGhostPass = null;
let gfxGradePass = null;   // final pass: exposure -> ACES -> grade -> sRGB
let gfxReady = false;
let gfxAddonFailed = false;
let gfxAddonPromise = null;

const gfxState = {
  composer: null,
  bloomPass: null,
  godRayPass: null,
  ghostPass: null,
  gradePass: null,
  skyExcluded: true,
  ready: false,
  mode: GRAPHICS.mode,
};

const _ghostSun = new THREE.Vector3();
const _ghostNdc = new THREE.Vector3();
const _ghostFwd = new THREE.Vector3();
const _ghostTmp = new THREE.Vector3();

const _lensGhostShader = {
  uniforms: {
    tDiffuse:   { value: null },
    uSunUV:     { value: new THREE.Vector2(0.5, 0.5) },
    uAspect:    { value: 1 },
    uVis:       { value: 0 },
    uStrength:  { value: 0.95 },
    uThreshold: { value: 1.35 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main(){
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform vec2 uSunUV;
    uniform float uAspect;
    uniform float uVis;
    uniform float uStrength;
    uniform float uThreshold;
    varying vec2 vUv;

    float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

    /* Soft bright-pass gate: 0 below uThreshold, gentle knee above.
       Multiplicative on the COLOR (not additive on the excess), so an HDR
       sun contributes bounded energy no matter how bright it is. */
    vec3 ghostTap(vec2 uv){
      vec3 c = texture2D(tDiffuse, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
      float w = smoothstep(uThreshold, uThreshold + 0.35, luma(c));
      return c * w;
    }

    /* One lens-ghost element: ring-blurred bright sample around p,
       per-element energy cap, tinted. */
    vec3 ghostElement(vec2 p, float size, vec3 tint){
      vec3 acc = vec3(0.0);
      for(int i = 0; i < 8; i++){
        float a = float(i) * 0.785398;
        vec2 d = vec2(cos(a) / max(uAspect, 0.001), sin(a)) * size;
        acc += ghostTap(p + d);
      }
      acc *= 0.125 * tint;
      float l = luma(acc);
      if(l > 1.0) acc *= 1.0 / l;           /* per-element HDR cap */
      return acc;
    }

    /* spatial falloff for a ghost disc centred at p */
    float ghostMask(vec2 p, float size){
      vec2 d = (vUv - p) * vec2(uAspect, 1.0);
      float r = length(d);
      return 1.0 - smoothstep(size * 0.30, size * 1.60, r);
    }

    void main(){
      vec4 base = texture2D(tDiffuse, vUv);
      if(uVis <= 0.001){
        gl_FragColor = base;
        return;
      }

      vec2 mirror = vec2(1.0) - uSunUV;
      float s = 0.016;

      vec3 t1 = vec3(0.56, 0.73, 1.00);
      vec3 t2 = vec3(1.00, 0.62, 0.32);
      vec3 t3 = vec3(0.58, 1.00, 0.70);
      vec3 t4 = vec3(0.80, 0.68, 1.00);

      vec2 p1 = mix(uSunUV, mirror, 0.42);
      vec2 p2 = mix(uSunUV, mirror, 0.73);
      vec2 p3 = mix(uSunUV, mirror, 1.04);
      vec2 p4 = mix(uSunUV, mirror, 1.31);

      /* Each ghost artifact is LOCAL: ring-blurred bright sample at its own
         mirror point, faded out by that point's mask. (The old version added
         one global g to every pixel on screen - with the sun centred all four
         points collapsed onto the HDR sun disc and the whole frame jumped
         ~+3.2 luma -> white-out.) */
      vec3 g = vec3(0.0);
      g += ghostElement(p1, s * 1.5, t1) * ghostMask(p1, s * 1.9);
      g += ghostElement(p2, s * 2.2, t2) * ghostMask(p2, s * 2.6);
      g += ghostElement(p3, s * 3.0, t3) * ghostMask(p3, s * 3.4);
      g += ghostElement(p4, s * 4.0, t4) * ghostMask(p4, s * 4.4);

      /* combined cap: all four elements together may never add much */
      float gt = luma(g);
      if(gt > 0.6) g *= 0.6 / gt;

      vec3 col = base.rgb;
      col += g * uVis * uStrength * 0.9;

      /* faint tinted haze on the ghost discs (kept subtle and additive) */
      float k = 0.45 * uStrength * uVis;
      col += ( t1 * ghostMask(p1, s * 2.6)
             + t2 * ghostMask(p2, s * 3.4)
             + t3 * ghostMask(p3, s * 4.4)
             + t4 * ghostMask(p4, s * 5.2) ) * (0.018 * k);

      /* hard safety bound: this pass can never lift a pixel more than this
         over what bloom produced - no white-out is possible, period */
      col = min(col, base.rgb + vec3(0.65));
      gl_FragColor = vec4(col, base.a);
    }
  `,
};

/* ----------------------------------------------------------------
   GOD RAYS PASS — screen-space volumetric light shafts.
   ----------------------------------------------------------------
   Marches toward the projected sun, accumulating the HDR bright-pass
   with exponential decay. The HDR sun disc in the scattering sky is
   the emitter; terrain and worm occlusion break the shafts naturally
   because occluded pixels are not bright. One pass, 20 taps. */
const _godRayShader = {
  uniforms: {
    tDiffuse:   { value: null },
    uSunUV:     { value: new THREE.Vector2(0.5, 0.5) },
    uAspect:    { value: 1 },
    uVis:       { value: 0 },
    uStrength:  { value: 0.42 },
    uDecay:     { value: 0.935 },
    uDensity:   { value: 0.55 },
    uThreshold: { value: 1.35 },
    uFalloff:   { value: 1.9 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main(){
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform vec2  uSunUV;
    uniform float uAspect;
    uniform float uVis;
    uniform float uStrength;
    uniform float uDecay;
    uniform float uDensity;
    uniform float uThreshold;
    uniform float uFalloff;
    varying vec2 vUv;

    float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

    void main(){
      vec4 base = texture2D(tDiffuse, vUv);
      if(uVis <= 0.001){
        gl_FragColor = base;
        return;
      }

      /* radial march toward the sun, bright-passed + decayed */
      vec2 dir  = (uSunUV - vUv);
      vec2 stepV = dir * (uDensity / 20.0);
      vec2 uv = vUv;
      float illum = 1.0, wsum = 0.0;
      vec3 acc = vec3(0.0);
      for(int i = 0; i < 20; i++){
        uv += stepV;
        vec3 s = texture2D(tDiffuse, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
        float w = smoothstep(uThreshold, uThreshold + 0.9, luma(s));
        acc += s * w * illum;
        wsum += illum;
        illum *= uDecay;
      }
      acc /= max(wsum, 0.0001);

      /* shafts live around the sun and fade with angular distance */
      vec2 d = (vUv - uSunUV) * vec2(uAspect, 1.0);
      float fade = exp(-length(d) * uFalloff);

      vec3 col = base.rgb + acc * (uStrength * uVis * fade);
      gl_FragColor = vec4(col, base.a);
    }
  `,
};

/* ----------------------------------------------------------------
   FINAL GRADE PASS — the cinematic remaster.
   ----------------------------------------------------------------
   three r160 skips tone mapping AND the output color-space encode when
   rendering into EffectComposer's render targets, so the display
   transform is done here explicitly, in HDR linear:
     1. heat shimmer — screen-space refraction band at the horizon
     2. speed radial blur — wind rush that grows with velocity
     3. chromatic aberration — radial R/B split (real lens behaviour)
     4. unsharp mask — optical crispness recovered from blur taps
     5. exposure
     6. ACES filmic tone map — highlights roll off like film
     7. saturation + subtle split-tone (cool shadow air, warm highs)
     8. animated film grain (display-referred, shadow-weighted)
     9. gentle lens vignette
    10. linear -> sRGB encode
   ---------------------------------------------------------------- */
const _gradeShader = {
  uniforms: {
    tDiffuse:  { value: null },
    uExposure: { value: 1.12 },
    uSat:      { value: 0.93 },
    uVignette: { value: 0.22 },
    uGrade:    { value: 1.0 },
    uTime:     { value: 0 },
    uCA:       { value: 2.4 },     /* chromatic aberration, px at corners */
    uGrain:    { value: 0.030 },   /* film grain amount */
    uSharp:    { value: 0.30 },    /* unsharp mask amount */
    uSpeedBlur:{ value: 0.0 },     /* radial blur from velocity, 0..1 */
    uHeat:     { value: 1.0 },     /* heat shimmer amplitude */
    uHorizonY: { value: 0.5 },     /* projected horizon line, uv space */
    uAspect:   { value: 1.78 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main(){
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float uExposure;
    uniform float uSat;
    uniform float uVignette;
    uniform float uGrade;
    uniform float uTime;
    uniform float uCA;
    uniform float uGrain;
    uniform float uSharp;
    uniform float uSpeedBlur;
    uniform float uHeat;
    uniform float uHorizonY;
    uniform float uAspect;
    varying vec2 vUv;

    float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

    vec3 acesFilm(vec3 x){
      return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
    }

    float h21(vec2 p){
      p = fract(p * vec2(443.897, 441.423));
      p += dot(p, p + 19.19);
      return fract(p.x * p.y);
    }
    float vnoise(vec2 p){
      vec2 i = floor(p), f = fract(p);
      vec2 u = f*f*(3.0-2.0*f);
      float a = h21(i), b = h21(i+vec2(1.0,0.0)), c = h21(i+vec2(0.0,1.0)), d = h21(i+vec2(1.0,1.0));
      return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
    }

    void main(){
      /* ---- 1. heat shimmer: refraction band around the horizon ---- */
      vec2 uv0 = vUv;
      {
        float ndcY = (vUv.y - 0.5) * 2.0;
        float hNdc = (uHorizonY * 2.0 - 1.0);
        float db = (ndcY - hNdc) * 5.5;
        float band = exp(-db * db) * uHeat;
        if(band > 0.002){
          vec2 np = vec2(vUv.x * 26.0, vUv.y * 13.0 + uTime * 0.55);
          float n1 = vnoise(np) - 0.5;
          float n2 = vnoise(np * 1.9 + vec2(uTime * 0.8, 0.0)) - 0.5;
          uv0 += vec2(n1, n2 * 0.6) * band * 0.0042;
        }
      }

      /* ---- 2+3+4. radial speed blur + aberration + unsharp ---- */
      vec2 cDir = uv0 - 0.5;
      float r2 = dot(cDir, cDir);
      vec2 caOff   = cDir * r2 * (uCA / 960.0);
      vec2 blurDir = cDir * uSpeedBlur * 0.12;
      vec2 sb = blurDir / 4.0;

      vec3 c0 = texture2D(tDiffuse, uv0).rgb;
      vec3 avg = c0;
      {
        vec2 uv = uv0;
        for(int i = 1; i <= 4; i++){
          uv += sb;
          avg += texture2D(tDiffuse, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
        }
        avg *= 0.2;
      }
      vec3 colR = texture2D(tDiffuse, clamp(uv0 + caOff + blurDir, vec2(0.001), vec2(0.999))).rgb;
      vec3 colB = texture2D(tDiffuse, clamp(uv0 - caOff + blurDir, vec2(0.001), vec2(0.999))).rgb;
      vec3 col = vec3(colR.r, avg.g, colB.b);
      col += (c0 - avg) * uSharp;                      /* optical crispness */

      /* ---- 5+6. exposure + ACES filmic ---- */
      col = acesFilm(col * uExposure);

      /* ---- 7. saturation + split-tone ---- */
      float l = luma(col);
      col = mix(vec3(l), col, mix(1.0, uSat, uGrade));
      float sw = (1.0 - smoothstep(0.10, 0.62, l)) * 0.55 * uGrade;
      float hw = smoothstep(0.55, 0.95, l) * 0.50 * uGrade;
      col += sw * vec3(-0.020, -0.006,  0.036);
      col += hw * vec3( 0.036,  0.014, -0.026);
      col = clamp(col, 0.0, 1.0);

      /* ---- 8. animated film grain (display-referred) ---- */
      if(uGrain > 0.0005){
        float g = h21(vUv * vec2(1280.0, 720.0) + fract(uTime * 61.7) * 100.0) - 0.5;
        col += g * uGrain * (0.45 + 0.55 * (1.0 - l));
      }

      /* ---- 9. soft lens falloff toward the corners ---- */
      vec2 q = vUv - 0.5;
      col *= 1.0 - uVignette * uGrade * dot(q, q) * 1.35;

      /* ---- 10. linear -> sRGB display encode ---- */
      vec3 lo = col * 12.92;
      vec3 hi = 1.055 * pow(max(col, vec3(1e-5)), vec3(1.0 / 2.4)) - 0.055;
      vec3 s = mix(lo, hi, step(vec3(0.0031308), col));
      gl_FragColor = vec4(s, 1.0);
    }
  `,
};

function _ensureAddons(){
  if(gfxAddonPromise) return gfxAddonPromise;
  if(gfxAddonFailed) return Promise.resolve(null);
  if(window._gfxAddons) return Promise.resolve(window._gfxAddons);
  gfxAddonPromise = Promise.all([
    import('three/addons/postprocessing/EffectComposer.js'),
    import('three/addons/postprocessing/RenderPass.js'),
    import('three/addons/postprocessing/UnrealBloomPass.js'),
    import('three/addons/postprocessing/ShaderPass.js'),
  ]).then(([ec, rp, ubp, sp]) => {
    const A = {
      EffectComposer: ec.EffectComposer,
      RenderPass: rp.RenderPass,
      UnrealBloomPass: ubp.UnrealBloomPass,
      ShaderPass: sp.ShaderPass,
    };
    window._gfxAddons = A;
    return A;
  }).catch(err => {
    console.warn('[graphics] post-processing addons failed to load - using direct render.', err);
    gfxAddonFailed = true;
    gfxReady = false;
    gfxState.ready = true;
    return null;
  });
  return gfxAddonPromise;
}

function _syncPasses(){
  if(gfxBloomPass) gfxBloomPass.enabled = !!GRAPHICS.postFX;
  if(gfxGodRayPass) gfxGodRayPass.enabled = !!GRAPHICS.godRays;
  if(gfxGhostPass) gfxGhostPass.enabled = !!GRAPHICS.lensFlare;
  if(gfxGradePass){
    gfxGradePass.uniforms.uCA.value    = (GRAPHICS.caAmount == null)  ? 2.4  : GRAPHICS.caAmount;
    gfxGradePass.uniforms.uGrain.value = (GRAPHICS.filmGrain == null) ? 0.03 : GRAPHICS.filmGrain;
    gfxGradePass.uniforms.uHeat.value  = (GRAPHICS.heatShimmer == null) ? 1.0 : GRAPHICS.heatShimmer;
  }
}

function _wantsComposer(){
  return !!(GRAPHICS.postFX || GRAPHICS.lensFlare);
}

function _disposeComposer(){
  if(gfxComposer){
    try{ gfxComposer.dispose(); }catch(e){}
    gfxComposer = null;
  }
  gfxBloomPass = null;
  gfxGodRayPass = null;
  gfxGhostPass = null;
  gfxGradePass = null;
  gfxState.composer = null;
  gfxState.bloomPass = null;
  gfxState.godRayPass = null;
  gfxState.ghostPass = null;
  gfxState.gradePass = null;
}

function _buildComposer(){
  const A = window._gfxAddons;
  if(!A || gfxComposer) return;
  try{
    gfxComposer = new A.EffectComposer(renderer);
    gfxComposer.addPass(new A.RenderPass(scene, camera));

    const res = new THREE.Vector2(innerWidth, innerHeight);
    const bloom = new A.UnrealBloomPass(
      res,
      GRAPHICS.bloomStrength,
      GRAPHICS.bloomRadius,
      GRAPHICS.bloomSky ? 0.45 : GRAPHICS.bloomThreshold
    );
    gfxComposer.addPass(bloom);
    gfxBloomPass = bloom;

    const godray = new A.ShaderPass(_godRayShader);
    godray.uniforms.uAspect.value = innerWidth / Math.max(1, innerHeight);
    godray.uniforms.uThreshold.value = GRAPHICS.bloomThreshold;
    godray.uniforms.uStrength.value = (GRAPHICS.godRayStrength == null) ? 0.42 : GRAPHICS.godRayStrength;
    gfxComposer.addPass(godray);
    gfxGodRayPass = godray;

    const ghost = new A.ShaderPass(_lensGhostShader);
    ghost.uniforms.uAspect.value = innerWidth / Math.max(1, innerHeight);
    ghost.uniforms.uThreshold.value = GRAPHICS.bloomThreshold;
    gfxComposer.addPass(ghost);
    gfxGhostPass = ghost;

    const grade = new A.ShaderPass(_gradeShader);
    grade.uniforms.uExposure.value = GRAPHICS.toneExposure || 1.0;
    grade.uniforms.uSat.value      = (GRAPHICS.gradeSat == null) ? 1.0 : GRAPHICS.gradeSat;
    grade.uniforms.uVignette.value = (GRAPHICS.gradeVignette == null) ? 0.15 : GRAPHICS.gradeVignette;
    grade.uniforms.uGrade.value    = (GRAPHICS.gradeStrength == null) ? 1.0 : GRAPHICS.gradeStrength;
    gfxComposer.addPass(grade);
    gfxGradePass = grade;

    gfxState.composer = gfxComposer;
    gfxState.bloomPass = bloom;
    gfxState.godRayPass = godray;
    gfxState.ghostPass = ghost;
    gfxState.gradePass = grade;
    _syncPasses();
  }catch(err){
    console.warn('[graphics] EffectComposer setup failed - using direct render.', err);
    _disposeComposer();
  }
}

function _buildHighMode(){
  if(window._gfxAddons && _wantsComposer() && !gfxComposer) _buildComposer();
  gfxReady = !!gfxComposer;
  gfxState.ready = true;
  gfxState.mode = GRAPHICS.mode;
  _syncPasses();
}

function _refreshBloomLayer(){}

function _updateGhostSun(){
  if((!gfxGhostPass || !gfxGhostPass.enabled) && (!gfxGodRayPass || !gfxGodRayPass.enabled)) return;

  camera.updateMatrixWorld();
  camera.matrixWorldInverse.copy(camera.matrixWorld).invert();
  _ghostSun.copy(player.pos).addScaledVector(sunDir, 1500);
  _ghostNdc.copy(_ghostSun).project(camera);

  _ghostFwd.set(0, 0, -1).applyQuaternion(camera.quaternion);
  const facing = _ghostFwd.dot(sunDir);
  const ux = _ghostNdc.x * 0.5 + 0.5;
  const uy = _ghostNdc.y * 0.5 + 0.5;
  const edge = clamp(Math.min(ux, 1 - ux, uy, 1 - uy) * 6.0, 0, 1);
  let vis = _ghostNdc.z < 1 ? 1 : 0;
  vis *= clamp((facing - 0.02) / 0.32, 0, 1);
  vis *= edge;

  if(gfxGhostPass){
    gfxGhostPass.uniforms.uSunUV.value.set(ux, uy);
    gfxGhostPass.uniforms.uVis.value = vis;
  }
  if(gfxGodRayPass){
    gfxGodRayPass.uniforms.uSunUV.value.set(ux, uy);
    gfxGodRayPass.uniforms.uVis.value = vis;
  }
}

/* per-frame driver for the remaster passes: time, speed blur, shimmer
   horizon, sky animation and the terrain glitter clocks. */
const _gfxFwd = new THREE.Vector3();
function _updateGradeDynamics(rdt){
  if(!gfxGradePass) return;
  const t = performance.now() / 1000;
  const U = gfxGradePass.uniforms;
  U.uTime.value = t;
  U.uCA.value        = (GRAPHICS.caAmount == null)  ? 2.4  : GRAPHICS.caAmount;
  U.uGrain.value     = (GRAPHICS.filmGrain == null) ? 0.03 : GRAPHICS.filmGrain;
  U.uHeat.value      = (GRAPHICS.heatShimmer == null) ? 1.0 : GRAPHICS.heatShimmer;
  /* radial wind rush from velocity */
  let spd = 0;
  try{ spd = clamp(player.vel.length() / 42, 0, 1); }catch(e){}
  U.uSpeedBlur.value += (spd - U.uSpeedBlur.value) * Math.min(1, 4 * rdt);
  /* project the true horizon (camera forward flattened) for the shimmer band */
  try{
    camera.getWorldDirection(_gfxFwd);
    _gfxFwd.y = 0; _gfxFwd.normalize();
    _pv.copy(camera.position).addScaledVector(_gfxFwd, 3000).project(camera);
    U.uHorizonY.value = clamp(_pv.y * 0.5 + 0.5, -0.2, 1.2);
  }catch(e){}
  /* animate the sky dust + sand glitter */
  if(typeof skyUniforms !== 'undefined' && skyUniforms) skyUniforms.uTime.value = t;
  try{
    const mats = [terrainMat, farGround.material];
    for(const m of mats){
      const sh = m && m.userData && m.userData.realismShader;
      if(sh){ sh.uniforms.uGlintTime.value = t; sh.uniforms.uSunDirW.value.copy(sunDir); }
    }
  }catch(e){}
}

function updateGraphics(dt){
  _updateGhostSun();
  _updateGradeDynamics(dt);
}

function renderScene(){
  if(gfxComposer) gfxComposer.render();
  else renderer.render(scene, camera);
}

function resizeGraphics(w, h){
  if(gfxComposer){
    try{ gfxComposer.setSize(w, h); }catch(e){}
  }
  if(gfxGhostPass){
    gfxGhostPass.uniforms.uAspect.value = w / Math.max(1, h);
  }
  if(gfxGodRayPass){
    gfxGodRayPass.uniforms.uAspect.value = w / Math.max(1, h);
  }
  if(gfxGradePass){
    gfxGradePass.uniforms.uAspect.value = w / Math.max(1, h);
  }
}

function onGraphicsLiveChange(key, value){
  if(window.__onRealismLive) window.__onRealismLive(key, value);   // realism layer
  if(key === 'sunIntensity'){
    if(typeof sun !== 'undefined' && sun) sun.intensity = value;
    return;
  }
  if(key === 'hemiIntensity'){
    if(typeof hemiLight !== 'undefined' && hemiLight) hemiLight.intensity = value;
    return;
  }
  if(key === 'fogNear' || key === 'fogFar'){
    if(typeof scene !== 'undefined' && scene.fog){
      scene.fog.near = GRAPHICS.fogNear;
      scene.fog.far  = GRAPHICS.fogFar;
    }
    return;
  }
  if(key === 'envMapIntensity'){
    if(typeof terrainMat !== 'undefined' && terrainMat){
      terrainMat.envMapIntensity = value;
    }
    return;
  }
  if(key === 'postFX' || key === 'lensFlare'){
    if(_wantsComposer()){
      if(!gfxComposer){
        gfxState.ready = false;
        _ensureAddons().then(() => _buildHighMode());
      }else{
        _syncPasses();
      }
    }else{
      _disposeComposer();
      gfxReady = false;
      gfxState.ready = true;
    }
    return;
  }
  if(key === 'bloomStrength' || key === 'bloomRadius' || key === 'bloomThreshold'){
    if(gfxBloomPass){
      gfxBloomPass.strength  = GRAPHICS.bloomStrength;
      gfxBloomPass.radius    = GRAPHICS.bloomRadius;
      gfxBloomPass.threshold = GRAPHICS.bloomSky ? 0.45 : GRAPHICS.bloomThreshold;
    }
    if(gfxGhostPass) gfxGhostPass.uniforms.uThreshold.value = GRAPHICS.bloomThreshold;
    return;
  }
  if(key === 'bloomSky'){
    if(gfxBloomPass){
      gfxBloomPass.threshold = value ? 0.45 : GRAPHICS.bloomThreshold;
    }
    return;
  }
  if(key === 'godRays'){
    if(gfxGodRayPass) gfxGodRayPass.enabled = !!value;
    return;
  }
  if(key === 'godRayStrength'){
    if(gfxGodRayPass) gfxGodRayPass.uniforms.uStrength.value = value;
    return;
  }
  if(key === 'caAmount' || key === 'filmGrain' || key === 'heatShimmer'){
    if(gfxGradePass){
      if(key === 'caAmount')     gfxGradePass.uniforms.uCA.value    = value;
      if(key === 'filmGrain')    gfxGradePass.uniforms.uGrain.value = value;
      if(key === 'heatShimmer')  gfxGradePass.uniforms.uHeat.value  = value;
    }
    return;
  }
  if(key === 'toneExposure' || key === 'gradeSat' || key === 'gradeVignette' || key === 'gradeStrength'){
    if(gfxGradePass){
      gfxGradePass.uniforms.uExposure.value = GRAPHICS.toneExposure || 1.0;
      gfxGradePass.uniforms.uSat.value      = (GRAPHICS.gradeSat == null) ? 1.0 : GRAPHICS.gradeSat;
      gfxGradePass.uniforms.uVignette.value = (GRAPHICS.gradeVignette == null) ? 0.15 : GRAPHICS.gradeVignette;
      gfxGradePass.uniforms.uGrade.value    = (GRAPHICS.gradeStrength == null) ? 1.0 : GRAPHICS.gradeStrength;
    }
    return;
  }
}

function _bootGraphics(){
  if(_wantsComposer()){
    gfxState.ready = false;
    _ensureAddons().then(() => _buildHighMode());
  }else{
    gfxReady = false;
    gfxState.ready = true;
  }
}
_bootGraphics();

window.renderScene = renderScene;
window.updateGraphics = updateGraphics;
window.resizeGraphics = resizeGraphics;
window.onGraphicsLiveChange = onGraphicsLiveChange;
window.gfxState = gfxState;
window._refreshBloomLayer = _refreshBloomLayer;
window._gfxAddonReady = () => gfxReady;

function _initGraphicsUI(){
  const wrap = document.getElementById('gfxSel');
  if(!wrap) return;
  const buttons = wrap.querySelectorAll('button');
  buttons.forEach(btn => {
    const mode = btn.getAttribute('data-mode');
    if(mode === GRAPHICS_MODE) btn.classList.add('active');
    btn.addEventListener('click', () => {
      if(btn.classList.contains('confirm')){
        setGraphicsMode(mode);
        return;
      }
      buttons.forEach(b => b.classList.remove('confirm'));
      btn.classList.add('confirm');
      btn.focus();
      clearTimeout(_initGraphicsUI._t);
      _initGraphicsUI._t = setTimeout(() => btn.classList.remove('confirm'), 3000);
    });
  });
}
window._initGraphicsUI = _initGraphicsUI;
if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', _initGraphicsUI);
}else{
  _initGraphicsUI();
}
