/* ==================================================================
   20-pause-menu.js — ESC pause overlay with Resume / Settings / End Run
   ------------------------------------------------------------------
   Press ESC while playing to open the pause menu. The pause overlay
   is built statically in index.html (so it loads before this script
   boots) and is shown/hidden by toggling .hidden on #pause.

   Three buttons:
     • RESUME       — closes the pause menu, game loop resumes
     • SETTINGS     — opens the Settings panel on top of the pause
                      menu; closing Settings returns to the pause menu
     • END RUN      — kills the run and shows the game-over screen

   The pause sets window.paused = true, which 16-main.js reads every
   frame to freeze the simulation (the same flag the Settings panel
   uses via window.settingsOpen — both share the same gating logic).
   ================================================================== */

(function(){
  /* ---- state ---- */
  let open = false;

  /* ---- DOM helpers ---- */
  function _el(id){ return document.getElementById(id); }

  /* ---- open / close ---- */
  function openPause(){
    if(open) return;
    /* only allow pause during active play (not title, not dead) */
    if(typeof gameState === 'undefined' || gameState !== 'play') return;
    open = true;
    window.paused = true;
    playUiOpenCloseSfx();
    const p = _el('pause');
    if(p) p.classList.remove('hidden');
    /* blur the active element so WASD doesn't drive the jeep while paused */
    if(document.activeElement && document.activeElement.blur) document.activeElement.blur();
    /* clear any held keys so the jeep doesn't lurch when resumed */
    if(typeof keys !== 'undefined'){
      for(const k in keys) keys[k] = false;
    }
    /* small sand puff on the pause card for feedback */
    if(window.uiParticles){
      const card = _el('pause') ? _el('pause').querySelector('.pause-card') : null;
      if(card){
        const r = card.getBoundingClientRect();
        window.uiParticles.puff(r.left + r.width/2, r.top + 30, 18);
      }
    }
  }
  function closePause(){
    if(!open) return;
    open = false;
    window.paused = false;
    playUiOpenCloseSfx();
    const p = _el('pause');
    if(p) p.classList.add('hidden');
    /* sand puff on close */
    if(window.uiParticles){
      const btn = _el('pauseResume');
      if(btn){
        const r = btn.getBoundingClientRect();
        window.uiParticles.puff(r.left + r.width/2, r.top + r.height/2, 12);
      }
    }
  }
  function togglePause(){
    if(open) closePause();
    else openPause();
  }
  /* expose for the buttons + key handler */
  window.openPause = openPause;
  window.closePause = closePause;
  window.togglePause = togglePause;
  window.isPauseOpen = ()=>open;

  /* ---- wire the buttons ---- */
  function _wireButtons(){
    const resume = _el('pauseResume');
    const settings = _el('pauseSettings');
    const end = _el('pauseEnd');
    if(resume) resume.addEventListener('click', ()=>{
      closePause();
    });
    if(settings) settings.addEventListener('click', ()=>{
      /* open the Settings panel on top of the pause menu; closing
         Settings returns to the pause menu, not to the game */
      if(window.openSettings) window.openSettings();
    });
    if(end) end.addEventListener('click', ()=>{
      /* end the run: trigger the death sequence (or just go to game-over
         if the death system isn't available) */
      closePause();
      _endRun();
    });
  }

  /* ---- end the run ----
     Uses the existing die() function from 12-alpha-worm.js, which
     triggers the proper death sequence (slow-mo, explosion, game-over
     screen). If die() isn't reachable for some reason, falls back to
     a direct game-over screen. */
  function _endRun(){
    if(typeof die === 'function'){
      try{ die('abandoned', null); }catch(e){}
      return;
    }
    /* fallback: drop the player's HP to 0 and let the natural death
       flow take over (this works because updateDeathFx + updateHUD
       handle the rest). If that path is also unavailable, just jump
       to the game-over screen. */
    try{
      if(typeof player !== 'undefined'){
        player.hp = 0;
        player.alive = false;
      }
    }catch(e){}
    /* if after a moment we're still not dead, force the game-over screen */
    setTimeout(()=>{
      if(typeof gameState !== 'undefined' && gameState !== 'dead'){
        if(typeof overShown !== 'undefined') overShown = true;
        if(typeof deathReal !== 'undefined') deathReal = performance.now();
        const over = _el('over');
        if(over) over.classList.remove('hidden');
        document.body.classList.add('cinema');
        if(typeof gameState !== 'undefined') gameState = 'dead';
      }
    }, 200);
  }

  /* ---- ESC key handler ----
     Only opens the pause menu when:
       • no other overlay (Settings panel) is open
       • the game is in 'play' state
       • the user isn't aiming a thumper (E held) */
  function _wireKey(){
    addEventListener('keydown', e=>{
      if(e.code !== 'Escape') return;
      /* if the Settings panel is open, ESC closes THAT, not pause */
      if(window.settingsOpen) return;
      if(open){
        e.preventDefault();
        closePause();
        return;
      }
      /* only open pause during active play */
      if(typeof gameState !== 'undefined' && gameState === 'play'){
        e.preventDefault();
        openPause();
      }
    }, {passive:false});
  }

  /* ---- close the Settings panel back into pause, not into the game ----
     We monkey-patch closeSettings so that when Settings is closed while
     the pause menu is open underneath, we don't accidentally resume the
     game. window.settingsOpen already controls the game-loop freeze,
     and we keep pause's window.paused separate so both can be active. */
  function _patchSettingsClose(){
    if(!window.closeSettings) return;
    if(window.closeSettings._pausePatched) return;
    const orig = window.closeSettings;
    window.closeSettings = function(){
      orig.apply(this, arguments);
      /* if the pause menu is open underneath, we just leave pause open —
         the user is still paused. If pause is NOT open, then the
         settings panel was opened from the title or game-over screen,
         so we don't need to do anything extra. */
    };
    window.closeSettings._pausePatched = true;
  }

  /* ---- boot ---- */
  function boot(){
    _wireButtons();
    _wireKey();
    _patchSettingsClose();
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  }else{
    boot();
  }
})();
