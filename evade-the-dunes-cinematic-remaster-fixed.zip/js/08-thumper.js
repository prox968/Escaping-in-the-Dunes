/* Thumper: deploy, aim & throw, scattered salvage pickups */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- thumper ---------------- */
const thumperDark=new THREE.MeshStandardMaterial({color:0x2a2622, roughness:0.85});
const thumperAcc =new THREE.MeshStandardMaterial({color:0x2f4a38, roughness:0.6});
function buildThumperMesh(){
  const g=new THREE.Group();
  const stake=new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.1,2.2,8), thumperDark);
  stake.position.y=1.1; stake.castShadow=true; g.add(stake);
  const band=new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.09,0.18,8), thumperAcc);
  band.position.y=1.75; g.add(band);
  const armPivot=new THREE.Group(); armPivot.position.y=2.0;
  const arm=new THREE.Mesh(new THREE.BoxGeometry(0.1,1.1,0.1), thumperDark);
  arm.position.y=-0.5; arm.castShadow=true; armPivot.add(arm);
  const weight=new THREE.Mesh(new THREE.SphereGeometry(0.2,10,8), thumperDark);
  weight.position.y=-1.0; armPivot.add(weight);
  g.add(armPivot);
  g.userData.armPivot=armPivot;
  return g;
}
const thumper={active:false, pos:new THREE.Vector3(), timer:0, arm:null, thumpT:0, takenBy:new Set()};
/* a thumper is only silenced once EVERY worm out there has struck it; each worm that has
   taken it is sated and leaves it (and you) alone while it keeps pounding */
function wormsInPlay(){ let n=0; for(const w of worms) if(w.state!=='gone') n++; return n; }
function wormsLeftForThumper(){ let n=0; for(const w of worms) if(w.state!=='gone' && !thumper.takenBy.has(w)) n++; return n; }
function strikeThumper(w, inAir){
  if(thumper.takenBy.has(w)) return false;
  thumper.takenBy.add(w);
  const left=wormsLeftForThumper();
  if(left<=0){
    if(inAir){ proj.flying=false; thumper.pos.copy(proj.pos); }
    destroyThumper(true);
    if(inAir) showMsg('SNATCHED FROM THE AIR',2);
    return true;
  }
  const at=inAir?proj.pos:thumper.pos;
  burstDust(at,30,8); spawnRing(at,10,0.5); impactSfx();
  const tot=wormsInPlay();
  showMsg((inAir?'STRUCK IN THE AIR':'THUMPER STRUCK')+' · '+(tot-left)+'/'+tot+' — STILL POUNDING',2);
  return false;
}
thumper.mesh=buildThumperMesh();
thumper.mesh.visible=false;
thumper.arm=thumper.mesh.userData.armPivot;
scene.add(thumper.mesh);

function deployThumper(){
  if(gameState!=='play'||!player.alive) return;
  if(thumper.active){ showMsg('THUMPER ALREADY POUNDING',1.6); return; }
  if(thumperCount<=0){ showMsg('NO THUMPERS LEFT — SALVAGE ONE',1.8); return; }
  thumperCount--;
  _v1.set(Math.sin(player.heading),0,Math.cos(player.heading));
  thumper.pos.copy(player.pos).addScaledVector(_v1,4);
  thumper.pos.y=terrainH(thumper.pos.x,thumper.pos.z);
  thumper.mesh.position.copy(thumper.pos);
  thumper.mesh.rotation.set(0,player.heading,0);
  thumper.mesh.visible=true;
  thumper.active=true; thumper.timer=10; thumper.thumpT=0; thumper.takenBy.clear();
  showMsg('THUMPER DEPLOYED — IT COMES',2.4);
  playSfx('thumperPlant',0.8,0.94+Math.random()*0.12,0,{pos:{x:thumper.pos.x,z:thumper.pos.z},ref:22});
  thumpSfx(thumper.pos);
}
/* ---------- thumper throw: tap E = drop at your wheels, hold E = aim & throw ---------- */
const THROW_G=26, THROW_HOLD=0.17, THROW_CHARGE=1.05, THROW_FULL=THROW_HOLD+THROW_CHARGE, THROW_DOTS=26;
const aim={held:false, t:0, power:0, show:0, phase:0, maxed:false};
const proj={flying:false, pos:new THREE.Vector3(), vel:new THREE.Vector3(), spin:0, spinAx:new THREE.Vector3(1,0,0), t:0};
const _tv0=new THREE.Vector3(), _tp0=new THREE.Vector3(), _tq=new THREE.Quaternion(), _tn=new THREE.Vector3();
const arcPts=[]; for(let i=0;i<=120;i++) arcPts.push(new THREE.Vector3());
let arcN=0, arcTLand=0;
/* minimal preview: a sparse trail of small dots + one thin ring where it lands */
const aimDotMat=new THREE.MeshBasicMaterial({color:0xfff1d6, transparent:true, opacity:0.8, depthWrite:false, fog:false});
const aimDots=new THREE.InstancedMesh(new THREE.SphereGeometry(0.1,8,6), aimDotMat, THROW_DOTS);
aimDots.frustumCulled=false; aimDots.renderOrder=5; aimDots.visible=false; scene.add(aimDots);
const aimMark=new THREE.Group();
{
  const mk=(r0,r1,op)=>{ const m=new THREE.Mesh(new THREE.RingGeometry(r0,r1,64),
      new THREE.MeshBasicMaterial({color:0xfff1d6, transparent:true, opacity:op, side:THREE.DoubleSide, depthWrite:false, depthTest:false, fog:false}));
    m.rotation.x=-Math.PI/2; m.renderOrder=6; m.userData.op=op; return m; };
  aimMark.add(mk(1.55,1.72,0.75), mk(0.0,0.16,0.75));
}
aimMark.visible=false; scene.add(aimMark);
/* mouse aim: cursor ray -> point on the dunes */
const mouseNDC=new THREE.Vector2(); let mouseSeen=false;
const aimRay=new THREE.Raycaster(), aimTarget=new THREE.Vector3(); let aimTargetOk=false;
addEventListener('mousemove',e=>{ mouseNDC.set(e.clientX/innerWidth*2-1, -(e.clientY/innerHeight)*2+1); mouseSeen=true; });
function updateMouseTarget(){
  aimTargetOk=false; if(!mouseSeen) return;
  aimRay.setFromCamera(mouseNDC,camera);
  const o=aimRay.ray.origin, d=aimRay.ray.direction;
  let tPrev=0, t=0, step=2;
  while(t<900){
    t+=step; step=Math.min(step*1.08,12);
    const x=o.x+d.x*t, y=o.y+d.y*t, z=o.z+d.z*t;
    if(y<=terrainH(x,z)){
      let a=tPrev,b=t;
      for(let k=0;k<8;k++){ const m=(a+b)/2; if(o.y+d.y*m<=terrainH(o.x+d.x*m,o.z+d.z*m)) b=m; else a=m; }
      aimTarget.copy(o).addScaledVector(d,b); aimTargetOk=true; return;
    }
    tPrev=t;
  }
  /* aiming at the sky: keep the cursor's compass direction */
  aimTarget.set(o.x+d.x*400, 0, o.z+d.z*400); aimTargetOk=true;
}
const _dm=new THREE.Matrix4(), _ds=new THREE.Vector3(), _dq=new THREE.Quaternion();

function thumperReady(say){
  if(gameState!=='play'||!player.alive) return false;
  if(proj.flying){ if(say) showMsg('THUMPER IN FLIGHT',1.2); return false; }
  if(thumper.active){ if(say) showMsg('THUMPER ALREADY POUNDING',1.6); return false; }
  if(thumperCount<=0){ if(say) showMsg('NO THUMPERS LEFT — SALVAGE ONE',1.8); return false; }
  return true;
}
/* throw along the buggy's nose — or straight back over the tailgate while Q (look back) is held */
function throwAimDir(out){
  const sg=lookBackAmt>0.5?-1:1;
  return out.set(Math.sin(player.heading)*sg,0,Math.cos(player.heading)*sg);
}
/* horizontal launch direction so the throw (incl. inherited buggy momentum) heads straight at the cursor */
function throwDirFor(h,out){
  let tx,tz;
  if(aimTargetOk){ tx=aimTarget.x-player.pos.x; tz=aimTarget.z-player.pos.z; }
  const tl=aimTargetOk?Math.hypot(tx,tz):0;
  if(tl<0.5){ throwAimDir(out); return out; }
  tx/=tl; tz/=tl;
  const ux=player.vel.x*0.85, uz=player.vel.z*0.85;
  const along=ux*tx+uz*tz, px=ux-along*tx, pz=uz-along*tz;
  const cx=-px/h, cz=-pz/h, c2=Math.min(0.81, cx*cx+cz*cz), k=Math.sqrt(c2/Math.max(1e-6,cx*cx+cz*cz));
  const a=Math.sqrt(1-c2);
  return out.set(tx*a+cx*k, 0, tz*a+cz*k).normalize();
}
/* launch state for a given power (0..1): thrown from the buggy's roof, carries the buggy's momentum */
function throwLaunch(p, pos0, vel0){
  const h=15+47*p, vy=8+11*p;
  throwDirFor(h,_tn);
  pos0.copy(player.pos).addScaledVector(_tn,1.6); pos0.y+=2.3;
  vel0.set(_tn.x*h + player.vel.x*0.85, vy, _tn.z*h + player.vel.z*0.85);
}
/* predict the arc until it meets the dunes (same integration as the real flight) */
function predictArc(p){
  throwLaunch(p,_tp0,_tv0);
  const dt=1/30; let x=_tp0.x,y=_tp0.y,z=_tp0.z, vx=_tv0.x,vy=_tv0.y,vz=_tv0.z, t=0;
  arcPts[0].set(x,y,z); arcN=1;
  while(arcN<arcPts.length){
    const nx=x+vx*dt, nz=z+vz*dt, ny=y+vy*dt-0.5*THROW_G*dt*dt; vy-=THROW_G*dt; t+=dt;
    const gy=terrainH(nx,nz);
    if(ny<=gy){
      /* refine the touchdown point */
      let a=0,b=1;
      for(let k=0;k<6;k++){ const m=(a+b)/2, my=y+(ny-y)*m, mx=x+(nx-x)*m, mz=z+(nz-z)*m;
        if(my<=terrainH(mx,mz)) b=m; else a=m; }
      const fx=x+(nx-x)*b, fz=z+(nz-z)*b;
      arcPts[arcN++].set(fx, terrainH(fx,fz), fz); arcTLand=t-dt*(1-b); return true;
    }
    x=nx;y=ny;z=nz; arcPts[arcN++].set(x,y,z);
  }
  arcTLand=t; return false;
}
function arcAt(u,out){                 // u in 0..1 along the predicted points
  const f=u*(arcN-1), i=Math.min(arcN-2,Math.floor(f)), k=f-i;
  return out.copy(arcPts[i]).lerp(arcPts[i+1],k);
}
function beginAim(){
  if(!thumperReady(true)) return;
  aim.held=true; aim.t=0; aim.power=0; aim.maxed=false;
}
function releaseAim(){
  if(!aim.held) return;
  aim.held=false;
  if(!thumperReady(false)) return;
  if(aim.t<THROW_HOLD) deployThumper(); else throwThumper(aim.power);
}
function cancelAim(){ aim.held=false; aim.t=0; aim.power=0; aim.maxed=false; }
function flashThrowMax(){
  const el=document.getElementById('throwMax');
  if(!el) return;
  el.classList.remove('on');
  void el.offsetWidth;
  el.classList.add('on');
}
function throwThumper(p){
  thumperCount--;
  playSfx('thumperThrow',0.72,0.94+Math.random()*0.12,0);
  throwLaunch(p, proj.pos, proj.vel);
  proj.flying=true; proj.t=0; proj.spin=0; thumper.takenBy.clear();
  proj.spinAx.set(-proj.vel.z,0,proj.vel.x).normalize();
  thumper.mesh.visible=true; thumper.mesh.position.copy(proj.pos);
  thumper.arm.rotation.x=-0.9;
  throwSfx(p);
  showMsg(p>0.8?'THUMPER — LONG THROW':'THUMPER AWAY',1.2);
}
function plantThumper(x,z){
  proj.flying=false;
  thumper.pos.set(x,terrainH(x,z),z);
  thumper.mesh.position.copy(thumper.pos);
  thumper.mesh.quaternion.identity();
  thumper.mesh.rotation.set(0,Math.atan2(proj.vel.x,proj.vel.z),0);
  thumper.active=true; thumper.timer=10; thumper.thumpT=0.25;
  burstDust(thumper.pos,26,7); spawnRing(thumper.pos,9,0.5);
  spawnCloudCluster(_v1.copy(thumper.pos).setY(thumper.pos.y+0.8), 4, 2.4, 2, 4, 1.2, 2, 0.35, false);
  landSfx(thumper.pos);
  const d=horizDist(thumper.pos,player.pos);
  showMsg('THUMPER PLANTED · '+Math.round(d)+' M — IT COMES',2.2);
}
function updateThrow(dt, rdt){
  /* aiming (real time, so it feels the same during slow-mo) */
  if(aim.held && !thumperReady(false)) cancelAim();
  if(aim.held){
    aim.t+=rdt;
    const c=clamp((aim.t-THROW_HOLD)/THROW_CHARGE,0,1);
    aim.power=1-(1-c)*(1-c);                       // ease-out charge
    if(!aim.maxed && aim.t>=THROW_FULL){
      aim.maxed=true;
      playSfx('thumperMax',0.62,1,0);
      flashThrowMax();
    }
  }
  const want=(aim.held&&aim.t>=THROW_HOLD)?1:0;
  aim.show+=(want-aim.show)*Math.min(1,(want?14:9)*rdt);
  const showing=aim.show>0.02;
  aimDots.visible=aimMark.visible=showing;
  if(showing){
    updateMouseTarget();
    const landed=predictArc(aim.power);
    aim.phase=(aim.phase+rdt*0.9)%1;
    for(let i=0;i<THROW_DOTS;i++){
      const u=Math.min(1,((i+aim.phase)/THROW_DOTS));
      arcAt(u,_ds);
      /* small even dots, fading in at the start and out near the target */
      const fade=Math.min(1,u*8)*(1-0.55*u);
      const sc=fade*aim.show*(i===0?aim.phase:1)*Math.max(1,camera.position.distanceTo(_ds)/26);
      _dm.compose(_ds,_dq.identity(),_v2.set(sc,sc,sc));
      aimDots.setMatrixAt(i,_dm);
    }
    aimDots.instanceMatrix.needsUpdate=true;
    aimDotMat.opacity=0.8*aim.show*(landed?1:0.5);
    const L=arcPts[arcN-1];
    aimMark.position.set(L.x,L.y+0.12,L.z);
    /* lie flat on the dune slope */
    const e=1.5, hx=terrainH(L.x+e,L.z)-terrainH(L.x-e,L.z), hz=terrainH(L.x,L.z+e)-terrainH(L.x,L.z-e);
    _tn.set(-hx,2*e,-hz).normalize();
    aimMark.quaternion.setFromUnitVectors(_v2.set(0,1,0),_tn);
    aimMark.scale.setScalar(aim.show*Math.max(1,camera.position.distanceTo(aimMark.position)/24));
    for(const c of aimMark.children) c.material.opacity=c.userData.op*aim.show*(landed?1:0.4);
  }
  updateHUDThrow();
  /* flight */
  if(proj.flying){
    proj.t+=dt;
    proj.pos.addScaledVector(proj.vel,dt); proj.pos.y-=0.5*THROW_G*dt*dt; proj.vel.y-=THROW_G*dt;
    proj.spin+=dt*11;
    thumper.mesh.position.copy(proj.pos);
    thumper.mesh.quaternion.setFromAxisAngle(proj.spinAx,proj.spin);
    if(Math.random()<0.5) spawnP(proj.pos.x,proj.pos.y,proj.pos.z, 0,0.4,0, 0.5,0.7, 0.85,0.7,0.5, 0.6,0.4, PT_TRAIL);
    /* snatched out of the air by a breaching worm */
    for(const w of worms){
      if((w.state==='lunge'||w.state==='dive') && !thumper.takenBy.has(w) && w.pos.distanceTo(proj.pos)<w.headR+2.5){
        if(strikeThumper(w,true)) return;
        /* knocked about but still flying */
        proj.vel.x+=w.dir.x*6; proj.vel.z+=w.dir.z*6; proj.vel.y=Math.max(proj.vel.y,4);
      }
    }
    const gy=terrainH(proj.pos.x,proj.pos.z);
    if(proj.pos.y<=gy || proj.t>8) plantThumper(proj.pos.x,proj.pos.z);
  }
}
function updateHUDThrow(){
  const el=$('thumpPow'); if(!el) return;
  el.style.opacity=aim.show.toFixed(2);
  el.firstElementChild.style.width=(aim.power*100).toFixed(1)+'%';
}
function destroyThumper(byWorm){
  thumper.active=false; thumper.mesh.visible=false;
  burstDust(thumper.pos,40,9); spawnRing(thumper.pos,12,0.6);
  spawnCloudCluster(_v1.copy(thumper.pos).setY(thumper.pos.y+1.0), 6, 3, 2.5, 5, 1.4, 2.2, 0.4, false);
  impactSfx();
  if(byWorm) showMsg('THUMPER SILENCED',2);
  attention=Math.min(attention,0.45);
}
function updateThumper(dt){
  if(!thumper.active) return;
  thumper.timer-=dt;
  thumper.arm.rotation.x=-0.15-Math.abs(Math.sin(elapsed*10))*1.0;
  thumper.thumpT-=dt;
  if(thumper.thumpT<=0){
    thumper.thumpT=0.45;
    thumpSfx(thumper.pos);
    for(let k=0;k<5;k++){
      const a=Math.random()*Math.PI*2;
      spawnP(thumper.pos.x+Math.cos(a)*0.4, thumper.pos.y+0.3, thumper.pos.z+Math.sin(a)*0.4,
        Math.cos(a)*3, 2.5+Math.random()*2, Math.sin(a)*3, 0.9, 1.6, 0.8,0.64,0.44, 2, 1.2);
    }
    spawnCloud(_v1.set(thumper.pos.x, thumper.pos.y+0.6, thumper.pos.z), 3.5, 0.9, 0.35, 0xc9a06a);
  }
  if(thumper.timer<=0) destroyThumper(false);
}

/* ------- scattered salvage thumpers ------- */
const PICKUP_N=5;                      // fewer salvage pickups out at once (was 7)
const thumperPickups=[];
const beaconMat=new THREE.SpriteMaterial({map:plumeTex, color:0x8fe0b0, transparent:true, opacity:0.28, depthWrite:false});
function placeThumperPickup(p){
  const a=Math.random()*Math.PI*2, d=130+Math.random()*330;
  p.x=player.pos.x+Math.cos(a)*d; p.z=player.pos.z+Math.sin(a)*d;
  p.y=terrainH(p.x,p.z);
  p.active=true; p.warned=false;
  /* rare variant rolls: ~2.5% explosive digger, ~8% standard digger, else salvage thumper */
  p.kind = Math.random()<0.025 ? 'exp' : (Math.random()<0.085 ? 'digger' : 'thumper');
  const kc = p.kind==='exp'?0xff5030 : (p.kind==='digger'?0xffc46a:0x8fe0b0);
  p.beacon.material.color.setHex(kc);
  p.ring.material.color.setHex(kc);
  p.mesh.visible=true;  p.mesh.position.set(p.x,p.y,p.z);
  p.mesh.rotation.y=Math.random()*Math.PI*2;
  p.beacon.visible=true; p.beacon.position.set(p.x,p.y+3.0,p.z);
  p.ring.visible=true;   p.ring.position.set(p.x,p.y+0.15,p.z);
}
function makePickup(){
  const mesh=buildThumperMesh();
  scene.add(mesh);
  const beacon=new THREE.Sprite(beaconMat.clone());
  beacon.scale.set(4,12,1); scene.add(beacon);
  const ring=new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({
    color:0x8fe0b0, transparent:true, opacity:0.45, depthWrite:false, side:THREE.DoubleSide}));
  ring.rotation.x=-Math.PI/2; scene.add(ring);
  const p={mesh, beacon, ring, active:false, respawnT:0, ph:Math.random()*9, warned:false, x:0,y:0,z:0};
  thumperPickups.push(p);
  return p;
}
for(let i=0;i<PICKUP_N;i++) placeThumperPickup(makePickup());
const PK_COL={exp:0xff5030, digger:0xffc46a, thumper:0x8fe0b0};
/* ALPHA REWARD: a cache of mixed thumpers spilled together in the crater beside the jeep.
   They don't respawn; they stay until collected (or until you drive far away). */
function spawnRewardCache(cx, cz){
  clearRewardCache();
  const kinds=['thumper','digger','thumper','exp','thumper','digger','thumper','thumper'];
  kinds.forEach((kind,i)=>{
    const p=makePickup(); p.reward=true;
    const a=i===0?0:(i-1)/(kinds.length-1)*Math.PI*2+Math.random()*0.3, d=i===0?0:8+Math.random()*3;
    p.x=cx+Math.cos(a)*d; p.z=cz+Math.sin(a)*d; p.y=terrainH(p.x,p.z);
    p.kind=kind; p.active=true; p.warned=false;
    p.beacon.material.color.setHex(PK_COL[kind]); p.ring.material.color.setHex(PK_COL[kind]);
    p.beacon.scale.set(5,22,1);
    p.mesh.visible=true; p.mesh.position.set(p.x,p.y,p.z); p.mesh.rotation.y=Math.random()*Math.PI*2;
    p.beacon.visible=true; p.beacon.position.set(p.x,p.y+4,p.z);
    p.ring.visible=true; p.ring.position.set(p.x,p.y+0.15,p.z);
    for(let k=0;k<14;k++) spawnP(p.x,p.y+1,p.z,(Math.random()-0.5)*8,4+Math.random()*6,(Math.random()-0.5)*8,1.2,1.4,0.82,0.68,0.48,3,1);
  });
}
function dropPickup(p){
  scene.remove(p.mesh); scene.remove(p.beacon); scene.remove(p.ring);
  p.beacon.material.dispose(); p.ring.material.dispose();
  const i=thumperPickups.indexOf(p); if(i>=0) thumperPickups.splice(i,1);
}
function clearRewardCache(){
  for(const p of thumperPickups.filter(q=>q.reward)) dropPickup(p);
}
function updateThumperPickups(dt){
  for(let pi=thumperPickups.length-1; pi>=0; pi--){
    const p=thumperPickups[pi];
    if(p.reward){
      if(!p.active || horizDist(p,player.pos)>1500){ dropPickup(p); continue; }
      /* the crater keeps settling under them */
      const gy=terrainH(p.x,p.z); p.y=gy;
      p.mesh.position.y=gy; p.beacon.position.y=gy+4; p.ring.position.y=gy+0.15;
    }
    if(!p.active){
      p.respawnT-=dt;
      if(p.respawnT<=0) placeThumperPickup(p);
      continue;
    }
    p.mesh.userData.armPivot.rotation.x=-0.15-Math.abs(Math.sin(elapsed*3.4+p.ph))*0.6;
    p.ring.rotation.z+=dt*0.7;
    const rs=1+Math.sin(elapsed*2.1+p.ph)*0.07;
    p.ring.scale.set(rs,rs,rs);
    p.beacon.material.opacity=0.2+0.1*Math.sin(elapsed*2.4+p.ph);
    const d=horizDist(p,player.pos);
    if(d>900 && !p.reward){ placeThumperPickup(p); continue; }
    if(d>9) p.warned=false;
    if(gameState==='play' && player.alive && d<6.5){
      let msg;
      if(p.kind==='digger'){
        if(diggerCount>=2){ if(!p.warned){ p.warned=true; showMsg('DIGGER SATCHEL FULL',1.8); } continue; }
        diggerCount++; msg='DIGGER THUMPER SECURED — PRESS F';
      } else if(p.kind==='exp'){
        if(expDiggerCount>=1){ if(!p.warned){ p.warned=true; showMsg('YOU CARRY AN EXPLOSIVE DIGGER (G)',2); } continue; }
        expDiggerCount=1; msg='EXPLOSIVE DIGGER ACQUIRED — PRESS G';
      } else {
        if(thumperCount>=3){ if(!p.warned){ p.warned=true; showMsg('THUMPER RACK FULL — DEPLOY ONE (E)',1.8); } continue; }
        thumperCount=Math.min(3,thumperCount+1); msg='SALVAGED THUMPER — RACK '+thumperCount+'/3';
      }
      p.active=false;
      p.mesh.visible=false; p.beacon.visible=false; p.ring.visible=false;
      p.respawnT=40+Math.random()*30;
      showMsg(msg,2);
      playSfx('thumperCollect',0.72,0.95+Math.random()*0.1,0);
      pickupSfx();
      for(let k=0;k<20;k++){
        const a=Math.random()*Math.PI*2;
        spawnP(p.x, p.y+0.8, p.z, Math.cos(a)*4, 3+Math.random()*4, Math.sin(a)*4,
          0.7, 1.0, 0.62,0.86,0.66, 1.5, 1, PT_SPARK);
      }
    }
  }
}

