/* Input, player physics, suspension, antenna, worm wrapper */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- input ---------------- */
const keys={};
/* Do not steal native keyboard controls from UI elements. In particular,
   range sliders need arrow keys, and buttons need Space/Enter to activate.
   The game still listens to drive keys while a button retains focus after
   an overlay closes; only native-default prevention and the duplicate
   Enter-to-start shortcut are suppressed for interactive targets. */
const _isGameUIKeyTarget = target => {
  const el = target instanceof Element ? target : null;
  return !!(el && el.closest('input, textarea, select, button, [role="button"], [role="switch"], [contenteditable="true"]'));
};
addEventListener('keydown',e=>{
  const uiTarget = _isGameUIKeyTarget(e.target);
  if(!uiTarget && ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)) e.preventDefault();
  keys[e.code]=true;
  /* When the Settings panel OR the pause menu is open, swallow game
     inputs so the jeep doesn't keep driving while the user is tuning
     sliders or paused. */
  if(window.settingsOpen || window.paused){
    return;
  }
  if(e.code==='KeyE'&&!e.repeat) beginAim();
  if(e.code==='KeyR'&&gameState==='dead'&&overShown) startGame();
  /* A focused DRIVE button already starts via its native click on Enter.
     Avoid starting/resetting the run a second time from this global shortcut. */
  if(e.code==='Enter'&&gameState==='title'&&!uiTarget) startGame();
  if(e.code==='KeyF'&&!e.repeat) deployDigger(false);
  if(e.code==='KeyG'&&!e.repeat) deployDigger(true);
  if(e.code==='KeyV'&&!e.repeat) cycleCamMode(1);
  if(!e.repeat && /^Digit[1-8]$/.test(e.code)) setCamModeIndex(+e.code.slice(5)-1);
});
addEventListener('keyup',e=>{ keys[e.code]=false; if(e.code==='KeyE') releaseAim(); });
addEventListener('blur',()=>{ for(const k in keys) keys[k]=false; cancelAim(); showMsg('CLICK THE GAME TO REGAIN CONTROLS',3); });

/* settings panel: P opens it (in-game + title), ESC closes (handled in
   18-settings-panel.js) and also opens the pause menu (20-pause-menu.js).
   Initialize the global flags here so 16-main.js can read them from
   the first frame. */
if(window.settingsOpen === undefined) window.settingsOpen = false;
if(window.paused === undefined) window.paused = false;

/* ---------------- player physics ---------------- */
let dustAcc=0, _carCloudAcc=0;
function updatePlayer(dt){
  const P=player;
  let th=0, st=0, hb=false;
  if(P.alive){
    th=((keys.KeyW||keys.ArrowUp)?1:0)-((keys.KeyS||keys.ArrowDown)?1:0);
    st=((keys.KeyA||keys.ArrowLeft)?1:0)-((keys.KeyD||keys.ArrowRight)?1:0);   // +heading turns toward screen-left
    hb=!!keys.Space;
  }
  P.throttleIn=th; P.handbrake=hb; P.steer=st;

  /* SHIFT overdrive: hold to burn harder and run faster (the desert hears it) */
  const od = P.alive && !!(keys.ShiftLeft || keys.ShiftRight);
  P.overdrive = od;

  const fwd=_v1.set(Math.sin(P.heading),0,Math.cos(P.heading));
  const rv =_v2.set(Math.cos(P.heading),0,-Math.sin(P.heading));
  let vf=P.vel.dot(fwd);
  let vl=P.vel.dot(rv);
  const spd=Math.abs(vf);
  const bst=P.boost>0;
  /* chained spice: every spice grabbed while the boost still burns stacks +35 km/h */
  const chain = bst ? P.boostChain : 0;
  /* diminishing tiers: 2nd pickup +20 km/h, 3rd +15 km/h, nothing beyond the cap */
  const cap = VMAX + (bst ? 16 + (chain===1?5.56:chain===2?4.17:0) : 0) + (od ? 11 : 0);

  /* ---- traction budget from the live suspension ---- */
  let loadSum=0;
  for(const w of wheels) loadSum += (w.load!==undefined?w.load:1);
  const traction=clamp(loadSum/4, 0.25, 1.12)*(P.grounded?1:0.10);   // wheels in the air don't bite

  /* ---- longitudinal ---- */
  if(th>0){
    const curve=1.06-0.30*clamp(vf/cap,0,1.3);            // torque falls off up top
    vf += 40*dt*(bst?1.5:1)*(od?1.45:1)*curve*traction*(1-Math.max(vf,0)/cap);
  } else if(th<0){
    if(vf>0.5) vf -= 48*dt*traction;                      // brakes
    else vf = Math.max(vf-16*dt, -12);                    // reverse
  } else if(P.grounded){
    vf -= Math.sign(vf)*Math.min(Math.abs(vf), 5.5*dt);   // engine braking (ground only)
  }
  if(bst&&th>=0) vf += (18+(chain===1?8:chain===2?5:0))*dt*traction;
  if(P.grounded){
    vf -= vf*0.35*dt;                                     // aero / rolling (ground only)
    vf -= Math.sign(vf)*Math.min(Math.abs(vf),1.2*dt);
  } else {
    vf -= vf*0.05*dt;                                     // thin air — momentum is king mid-jump
  }
  if(hb) vf -= vf*0.62*dt;                                // locked rear axle
  if(P.grounded){                                 // no ground to push against mid-air
    const slope=(terrainH(P.pos.x+fwd.x*3,P.pos.z+fwd.z*3)-terrainH(P.pos.x-fwd.x*3,P.pos.z-fwd.z*3))/6;
    vf -= slope*16*dt;
  }
  if(vf>cap) vf-=(vf-cap)*2.5*dt;
  vf=clamp(vf,-12,cap+12);

  /* ---- steering: bicycle model with speed-sensitive lock ---- */
  const steerMax=0.52/(1+spd*0.085);
  P.steerAngle=lerp(P.steerAngle, st*steerMax, Math.min(1, 9*dt));
  let yawRate=Math.tan(P.steerAngle)*vf/CAR.wheelbase;
  yawRate += vl*0.0085*clamp(spd/14,0,1);                 // self-aligning
  if(hb) yawRate += P.steerAngle*vf*0.30;                 // tail steps out
  yawRate=clamp(yawRate,-3.2,3.2);
  if(!P.grounded) yawRate*=0.06;                  // the car keeps its heading through a jump
  P.heading+=yawRate*dt;

  /* ---- lateral: grip scales with wheel load & falls off at big slip ---- */
  const grip=P.grounded
    ? (hb?1.7:8.5)*clamp(traction,0.5,1.1)*(1-clamp(Math.abs(vl)/30,0,0.45))
    : 0.4;                                        // airborne: sideways momentum is preserved
  vl*=Math.exp(-grip*dt);

  fwd.set(Math.sin(P.heading),0,Math.cos(P.heading));
  rv.set(Math.cos(P.heading),0,-Math.sin(P.heading));
  P.vel.copy(fwd).multiplyScalar(vf).addScaledVector(rv, vl);
  P.pos.addScaledVector(P.vel,dt);

  P.speedF=vf; P.yawRate=yawRate;
  P.latSlip=Math.abs(vl);
  P.accel=clamp(dt>0?(vf-P.prevVf)/dt:0,-40,40);
  P.prevVf=vf;

  const drift=Math.min(P.latSlip/9,1.6);
  if((spd>5||drift>0.25)&&P.grounded){            // no rooster tails while flying
    const cosH=Math.cos(P.heading), sinH=Math.sin(P.heading);
    /* Pick the real world-space contact patch of a wheel (same maths as the
       suspension pass), so every puff leaves the sand from exactly under a tyre. */
    const wheelSpot=(w,out)=>{ out.x=P.pos.x + w.lx*cosH + w.lz*sinH;
                               out.z=P.pos.z - w.lx*sinH + w.lz*cosH; return out; };
    if(!P._rear){ P._rear = wheels.filter(w=>!w.front); if(!P._rear.length) P._rear = wheels; }

    /* 1. wake: soft, ground-hugging dust fed from ALL FOUR contact patches;
          it barely moves in world space, so it hangs behind the car as a ribbon.
          A touch of outward velocity per side makes the pair of streams read. */
    dustAcc+=(16*spd/VMAX+drift*30+(P.boost>0?40:0))*dt;
    let n=dustAcc|0; dustAcc-=n;
    while(n-->0){
      const w=wheels[(Math.random()*wheels.length)|0];
      const spot=wheelSpot(w,_v5), gy=terrainH(spot.x,spot.z);
      const j=0.9+Math.random()*0.2;
      const sd=Math.sign(w.lx)||1;
      const out=sd*(0.4+Math.random()*(1.2+drift*3.0));
      spawnP(spot.x+(Math.random()-0.5)*0.35, gy+0.06+Math.random()*0.14, spot.z+(Math.random()-0.5)*0.35,
        rv.x*out-P.vel.x*0.10+(Math.random()-0.5)*0.8, 0.5+Math.random()*1.4, rv.z*out-P.vel.z*0.10+(Math.random()-0.5)*0.8,
        1.3+Math.random()*1.3, 0.9+Math.random()*1.3+drift*0.9, 0.82*j,0.66*j,0.45*j, 0.25, 1.5, PT_TRAIL);
    }
    /* 1b. little volumetric puffs right at the contact patches — the small
           clouds that bloom out of the tyres and trail the car */
    _carCloudAcc+=(spd/VMAX*9+drift*16+(P.boost>0?12:0))*dt;
    let nc=_carCloudAcc|0; _carCloudAcc-=nc;
    while(nc-->0){
      const w=wheels[(Math.random()*wheels.length)|0];
      const spot=wheelSpot(w,_v5), gy=terrainH(spot.x,spot.z);
      const sd=Math.sign(w.lx)||1;
      spawnCloud(_v1.set(spot.x+rv.x*sd*0.25, gy+0.30+Math.random()*0.35, spot.z+rv.z*sd*0.25),
                 0.8+Math.random()*1.5, 0.7+Math.random()*0.7, 0.28+Math.random()*0.18, 0xb9905f);
    }
    /* 2. rooster tail: crisp grains flung up and sideways by the spinning rear tyres */
    _carGrainAcc+=(spd/VMAX*24+drift*40+(P.boost>0?30:0))*dt;
    let ng=_carGrainAcc|0; _carGrainAcc-=ng;
    while(ng-->0){
      const w=P._rear[(Math.random()*P._rear.length)|0];
      const spot=wheelSpot(w,_v5), gy=terrainH(spot.x,spot.z);
      const sd=Math.sign(w.lx)||1, j=0.85+Math.random()*0.3;
      const kick=2+Math.random()*4, side=sd*(1+Math.random()*3+drift*5);
      spawnP(spot.x, gy+0.10, spot.z,
        P.vel.x*0.3-fwd.x*kick+rv.x*side, 3+Math.random()*5+drift*2, P.vel.z*0.3-fwd.z*kick+rv.z*side,
        0.7+Math.random()*0.8, 0.25+Math.random()*Math.random()*0.7, 0.78*j,0.62*j,0.42*j, 16, 0.12, PT_GRAIN);
    }
    /* 3. spice boost: glowing embers streaming off the back */
    if(P.boost>0){
      _carSparkAcc+=55*dt;
      let ns=_carSparkAcc|0; _carSparkAcc-=ns;
      while(ns-->0){
        const sd=(Math.random()-0.5)*1.2;
        spawnP(P.pos.x-fwd.x*1.9+rv.x*sd, P.pos.y+0.5+Math.random()*0.3, P.pos.z-fwd.z*1.9+rv.z*sd,
          P.vel.x*0.4-fwd.x*(3+Math.random()*5)+(Math.random()-0.5)*2, 0.5+Math.random()*2.2, P.vel.z*0.4-fwd.z*(3+Math.random()*5)+(Math.random()-0.5)*2,
          0.35+Math.random()*0.4, 0.45+Math.random()*0.5, 1,0.55+Math.random()*0.25,0.14, 0, 0.8, PT_SPARK);
      }
    }
    if(spd>20 && Math.random() < dt*3){
      spawnCloudCluster(
        _v3.copy(P.pos).addScaledVector(fwd,-2.2).setY(P.pos.y+0.4),
        3, 1.6, 2, 4, 0.9, 1.4, 0.32, false
      );
    }
  }
  const spN=spd/VMAX;
  noiseLevel=spN*0.85+Math.min(P.latSlip/10,1)*0.4+Math.abs(st)*spN*0.2;
  if(od) noiseLevel+=0.10;                        // the worms can hear the overdrive
  if(spd<1.5) noiseLevel=0;
  attention+=((noiseLevel>0.28?(noiseLevel-0.28)*0.9:-0.26))*dt;
  attention=clamp(attention,0,1);

  P.invuln=Math.max(0,P.invuln-dt); P.boost=Math.max(0,P.boost-dt); if(P.boost<=0) P.boostChain=0;
  P.jumpCd=Math.max(0,(P.jumpCd||0)-dt);
}

/* ---------------- suspension (anti-clip + terrain follow) ---------------- */
function updateSuspension(dt){
  const P=player;
  const cosH=Math.cos(P.heading), sinH=Math.sin(P.heading);

  P.susMaxV=0; P.susClunk=0;
  const wheelData=[];
  let sumG=0, minCarY=-Infinity;
  for(let wi=0; wi<wheels.length; wi++){
    const w=wheels[wi];
    const wx = P.pos.x + w.lx*cosH + w.lz*sinH;
    const wz = P.pos.z - w.lx*sinH + w.lz*cosH;
    const g  = terrainH(wx, wz);
    wheelData.push({w, g, wx, wz, wi});
    sumG += g;
    const reqMin = g + CAR.wheelR - (CAR.restY + CAR.maxExt);
    if(reqMin > minCarY) minCarY = reqMin;
  }

  const avgCarY = (sumG/4) + CAR.wheelR - CAR.restY;
  let targetY = Math.max(avgCarY, minCarY);

  /* ---- vertical: terrain-following with scripted dune jumps ----
     The buggy is glued to the sand by the ride-height spring, exactly like the
     base game — there is NO ambient gravity. Fake gravity exists ONLY inside a
     scripted jump: when a fast car crests a steep lip carrying real climb
     momentum, the jump fires and a short ballistic arc takes over until the
     wheels find the sand again. Small dunes and slow driving never trigger it. */
  const gVy = (P.targetYPrev===null || dt<=0) ? 0 : (targetY - P.targetYPrev)/dt;   // ground vertical speed
  P.targetYPrev = targetY;

  if(P.jumping){
    /* airborne: the fake-gravity arc — a real launch upward, fast fall on the way
       down, and a gentle gap-limiter so jumps never feel unrealistically huge */
    P.grounded=false;
    P.airT+=dt;
    const gap=Math.max(0,P.pos.y-targetY);
    P.vy-=((P.vy<0?52:26)+Math.max(0,gap-4.5)*22)*dt;
    P.pos.y+=P.vy*dt;
    if(P.pos.y<=targetY || P.airT>1.5){
      const impact=Math.max(0,-(P.vy-gVy));
      P.pos.y=targetY; if(P.pos.y<minCarY)P.pos.y=minCarY;
      P.vy=0; P.grounded=true; P.jumping=false; P.jumpCd=0.5;
      if(gameState==='play'&&P.alive){
        if(impact>2.5){
          burstDust(P.pos, Math.min(40, 8+impact*2.2|0), Math.min(18, 5+impact*0.8));
          addDeform(P.pos.x,P.pos.z, Math.min(12, 7+impact*0.25), Math.min(2, impact*0.11));
          shake=Math.max(shake, clamp(impact*0.03, 0.1, 0.5));
        }
        if(impact>8) playSfx('hardLand', 0.35+Math.min(0.4,impact*0.02), 0.88+Math.random()*0.2, 0);
        if(impact>4 && window.addImpactDamage) window.addImpactDamage(impact);
      }
    }
  } else {
    /* grounded: glued to the sand — no gravity, just the ride-height spring */
    P.grounded=true; P.airT=0;
    const currentTooLow = (P.pos.y < minCarY - 0.02);
    const k = currentTooLow ? 22 : 12;
    const springFrom = P.pos.y;
    P.pos.y += (targetY - P.pos.y) * Math.min(1, k*dt);
    if(P.pos.y < minCarY) P.pos.y = minCarY;
    /* climb momentum = the live vertical speed of the spring tracking the terrain */
    const instVy = dt>0 ? (P.pos.y - springFrom)/dt : 0;
    P.climb=lerp(P.climb||0, instVy, Math.min(1,10*dt));
    /* a real car keeps its upward momentum for a beat after the lip: hold the
       recent peak climb with a gentle decay — this is what converts into the arc */
    P.climbMem=Math.max(P.climb, (P.climbMem||0)-14*dt);
    P.vy = instVy;
    /* jump trigger, predictive. Measured on the real terrain along the actual direction of
       travel (not the lagging ride-height spring): the car carries the vertical speed of the
       slope it is climbing; if the arc that speed would fly, under the jump's gravity, clears
       the sand ahead, the car leaves the lip right now. The ground climb is held for a beat,
       so a crest passed between two frames at very high speed still launches. */
    let hv=Math.hypot(P.vel.x,P.vel.z), mx=sinH, mz=cosH;
    if(hv>1){ mx=P.vel.x/hv; mz=P.vel.z/hv; }
    const h0=terrainH(P.pos.x,P.pos.z), Lb=1.6+hv*0.03;
    const gClimb=(h0-terrainH(P.pos.x-mx*Lb,P.pos.z-mz*Lb))/Lb*hv;    // ground vertical speed under us
    P.gClimbMem=Math.max(gClimb,(P.gClimbMem||0)-20*dt);
    /* is this a REAL dune ramp? The sand must have risen steadily over the last ~11 m
       (a long, steep face), not just a ripple: a lumpy bump never sets this flag.
       It's held for a beat so a crest crossed between two frames still counts. */
    const RB=11, rise=h0-terrainH(P.pos.x-mx*RB,P.pos.z-mz*RB);
    const isRamp = hv>1 && gClimb/hv>0.19 && rise>2.6 && rise/RB>0.23;
    P.rampMem = isRamp ? 0.14 : Math.max(0,(P.rampMem||0)-dt);
    if(gameState==='play' && P.alive && P.jumpCd<=0){
      const spF=Math.abs(P.speedF);
      const vC=P.gClimbMem;
      let gap=0;
      /* only at the lip: the ground just ahead must already be bending away from the
         vertical speed we carry (no launching early off the up-slope) */
      const Lf=Math.max(2,hv*0.06);
      const vAhead=(terrainH(P.pos.x+mx*Lf,P.pos.z+mz*Lf)-h0)/Lf*hv;
      if(spF>26 && P.rampMem>0 && vC>8 && vAhead<vC*0.4){
        for(const t of [0.12,0.24,0.36,0.5]){
          const x=hv*t, carY=h0+vC*t-13*t*t;
          gap=Math.max(gap, carY-terrainH(P.pos.x+mx*x,P.pos.z+mz*x));
        }
      }
      if(gap>2.2){
        P.jumping=true; P.grounded=false; P.airT=0;
        P.vy=clamp(vC*0.95+1.5, 6.5, 13);
        P.gClimbMem=0; P.rampMem=0;
        /* launch: dig the lip, throw sand upward and backward */
        addDeform(P.pos.x,P.pos.z,8,0.8);
        burstDust(P.pos,22,12);
        for(let k2=0;k2<8;k2++){
          spawnP(P.pos.x+(Math.random()-0.5)*2.4, P.pos.y+0.3, P.pos.z+(Math.random()-0.5)*2.4,
            (Math.random()-0.5)*6-P.vel.x*0.25, 3+Math.random()*5, (Math.random()-0.5)*6-P.vel.z*0.25,
            0.9+Math.random()*0.8, 1.6+Math.random()*2.4, 0.84,0.68,0.46, 2.4, 1.1, PT_BILLOW);
        }
        playSfx('suspension',0.2,1.25+Math.random()*0.2,0);
        wobble=Math.max(wobble,0.25);            // the pop of leaving the lip
      }
    }
  }

  let frontG=0, rearG=0, rightG=0, leftG=0, susF=0, susR=0, susRt=0, susLt=0, sum=0;
  for(const wd of wheelData){
    const w = wd.w;
    let tgt = wd.g + CAR.wheelR - P.pos.y;
    tgt = clamp(tgt, CAR.restY - CAR.maxComp, CAR.restY + CAR.maxExt);

    w.vel += ((tgt - w.y)*w.k - w.vel*w.c)*dt;
    w.y   += w.vel*dt;
    const lo = CAR.restY - CAR.maxComp - 0.05;
    const hi = CAR.restY + CAR.maxExt + 0.05;
    if(w.y < lo){ w.y = lo; if(w.vel < 0) w.vel *= -0.18; }
    if(w.y > hi){ w.y = hi; if(w.vel > 0) w.vel *= -0.18; }
    w.susp.position.y = w.y;

    /* ---- suspension events: slams drive creaks/clunks (audio) and camera shake ---- */
    const av=Math.abs(w.vel);
    if(av>P.susMaxV) P.susMaxV=av;
    if(w.hitCd===undefined) w.hitCd=0;
    else if(w.hitCd>0) w.hitCd-=dt;
    if(((w.y<=lo+0.002&&w.vel<-1.4)||(w.y>=hi-0.002&&w.vel>1.4)) && w.hitCd<=0){
      w.hitCd=0.45;
      P.susClunk=Math.max(P.susClunk, Math.min(3.2,av));
      shake=Math.max(shake, clamp(av*0.05, 0.05, 0.3));
    }

    /* live wheel load — drives traction, wheelspin and rut strength */
    w.load = clamp(1 + (CAR.restY - w.y)*1.6, 0, 1.3);

    sum += w.y;
    /* accumulate the true ground heights → real terrain angle for the body */
    if(w.front) frontG += wd.g*0.5; else rearG += wd.g*0.5;
    if(w.lx > 0) rightG += wd.g*0.5; else leftG += wd.g*0.5;
    if(w.front) susF += w.y*0.5; else susR += w.y*0.5;
    if(w.lx > 0) susRt += w.y*0.5; else susLt += w.y*0.5;

    /* ---- press a 3D rut into the sand ---- */
    const tr = tireTrails[wd.wi];
    if(tr && gameState==='play' && P.alive){
      if(!P.grounded || w.load < 0.06){
        tr.lift();                                   // wheel is off the sand: end the track (no ribbon through the air)
      } else {
        const slip = clamp(P.latSlip/8, 0, 1.2);
        const lock = (P.handbrake && !w.front) ? 0.35 : 0;
        const str  = clamp(0.28 + slip*0.6 + Math.min(Math.abs(P.speedF)/VMAX,1)*0.42 + lock, 0, 1.25);
        /* how hard this tyre is sliding: sideways drift, wheelspin / locked wheel (surface speed != ground speed) */
        const lngS  = clamp(Math.abs((w.spinVel||0)*CAR.wheelR - P.speedF) / Math.max(6, Math.abs(P.speedF)), 0, 1);
        const slide = clamp(Math.max(slip*0.85, lngS, (P.handbrake && !w.front) ? 0.8 : 0), 0, 1);
        const added = tr.push(wd.wx, wd.g, wd.wz, cosH, -sinH, str, slide, Math.abs(P.speedF), w.load);
        /* a sliding tyre shoves sand out sideways: clods + a soft puff at the edge of the new track */
        if(added && slide > 0.35){
          const side = Math.sign(w.lx) || 1, j = 0.85 + Math.random()*0.3;
          const ex = wd.wx + cosH*side*0.24, ez = wd.wz - sinH*side*0.24;
          if(Math.random() < slide*0.6){
            const out = side*(1.2 + Math.random()*2.6);
            spawnP(ex, wd.g+0.10, ez,
              cosH*out + P.vel.x*0.35, 1.0+Math.random()*2.2, -sinH*out + P.vel.z*0.35,
              0.5+Math.random()*0.5, 0.12+Math.random()*0.2, 0.80*j,0.64*j,0.44*j, 12, 0.2, PT_GRAIN);
          }
          if(Math.random() < slide*0.3){
            spawnP(ex, wd.g+0.06, ez,
              cosH*side*0.8 + P.vel.x*0.15, 0.5+Math.random()*0.8, -sinH*side*0.8 + P.vel.z*0.15,
              0.7+Math.random()*0.6, 0.5+Math.random()*0.6, 0.84*j,0.70*j,0.50*j, 3, 1.4, PT_SPRAY);
          }
        }
      }
    }
  }

  /* ---- body attitude: terrain plane on the ground, ballistic arc in the air ---- */
  let pitchT, rollT;
  if(P.grounded){
    pitchT = -Math.atan2(frontG - rearG, CAR.wheelbase);   // uphill → nose up
    rollT  =  Math.atan2(rightG - leftG, CAR.track);        // side slope → lean into it
  } else {
    /* airborne: the nose follows the flight arc; the bank holds and levels slowly.
       (Sampling the terrain under airborne wheels would wrench the body around.) */
    pitchT = clamp(-Math.atan2(P.vy, Math.max(10, Math.abs(P.speedF)))*0.4, -0.32, 0.32);
    rollT  = P.roll*0.98;
  }

  const pitchDyn = clamp(-P.accel*0.0045, -0.055, 0.075);
  const rollDyn  = clamp(-P.speedF*P.yawRate*0.014, -0.10, 0.10);

  const lerpK = Math.min(1, P.grounded ? 14*dt : 5*dt);
  P.pitch += ((pitchT + pitchDyn) - P.pitch)*lerpK;
  P.roll  += ((rollT  + rollDyn ) - P.roll )*lerpK;
  P.pitch = clamp(P.pitch, -0.75, 0.75);
  P.roll  = clamp(P.roll , -0.75, 0.75);

  _e.set(P.pitch, P.heading, P.roll, 'YXZ');
  carRoot.quaternion.setFromEuler(_e);
  carRoot.position.copy(P.pos);

  const heave = (sum/4) - CAR.restY;
  P.heave += (heave - P.heave)*Math.min(1, 14*dt);
  const spd = Math.abs(P.speedF);
  const vib = Math.sin(elapsed*47)*0.0022 + Math.sin(elapsed*31.3)*0.0016;
  P.bounce = Math.sin(elapsed*13)*0.010*Math.min(spd/20,1) + vib*(1+spd*0.06);
  carBody.position.y = -clamp(P.heave,-0.22,0.22)*0.5 + P.bounce;

  for(const w of wheels){
    if(w.spinVel===undefined) w.spinVel=0;
    const locked = P.handbrake && !w.front;
    if(locked){
      w.spinVel = lerp(w.spinVel, 0, Math.min(1,18*dt));       // rear axle locks
    } else {
      const tgt = P.speedF/CAR.wheelR;
      const rate = (w.load>0.12) ? 13 : 2.4;                    // airborne wheels free-spin
      w.spinVel = lerp(w.spinVel, tgt, Math.min(1, rate*dt));
      if(!w.front && P.throttleIn>0){
        w.spinVel += (1-clamp(w.load,0,1))*P.throttleIn*12*dt;  // power wheelspin
      }
    }
    w.spin.rotation.x += w.spinVel*dt;
    if(w.front) w.steer.rotation.y = lerp(w.steer.rotation.y, P.steerAngle*1.05, Math.min(1,12*dt));
  }

  if(!P.alive){
    carBody.rotation.x += deathSpin.x*dt;
    carBody.rotation.y += deathSpin.y*dt;
    carBody.rotation.z += deathSpin.z*dt;
  } else {
    /* the sprung body articulates over the suspension instead of rigidly following the terrain */
    const susPitch=-Math.atan2(susF-susR, CAR.wheelbase);
    const susRoll = Math.atan2(susRt-susLt, CAR.track);
    carBody.rotation.x = lerp(carBody.rotation.x, susPitch*0.55, Math.min(1,10*dt));
    carBody.rotation.y = lerp(carBody.rotation.y, 0, Math.min(1,6*dt));
    carBody.rotation.z = lerp(carBody.rotation.z, susRoll*0.55, Math.min(1,10*dt));
  }

  for(const t of tireTrails) t.update();
}

/* ---------------- antenna (damped, no wild bending) ---------------- */
const _aprev = new THREE.Vector3();
let _afirst = true;
function updateAntenna(dt){
  if(!antenna) return;
  const P=player;
  if(_afirst){ _aprev.copy(P.vel); _afirst=false; }

  const ax_w = dt>0 ? (P.vel.x - _aprev.x)/dt : 0;
  const az_w = dt>0 ? (P.vel.z - _aprev.z)/dt : 0;
  _aprev.copy(P.vel);

  const cosH=Math.cos(P.heading), sinH=Math.sin(P.heading);
  const aFwd   = ax_w*sinH + az_w*cosH;
  const aRight = ax_w*cosH - az_w*sinH;

  const spd = Math.abs(P.speedF);
  const gust = 0.25 + Math.min(spd/VMAX, 1)*0.55;

  const sensF = 0.007;
  const sensR = 0.002;

  for(let i=0;i<antenna.joints.length;i++){
    const j=antenna.joints[i];
    const t=(i+1)/antenna.joints.length;
    const falloff = 0.25 + 0.75*t;
    const tx = clamp(-aFwd*sensF, -0.13, 0.13)*falloff + Math.sin(elapsed*6.1 + j.ph)*0.013*gust;
    const tz = clamp( aRight*sensR, -0.09, 0.09)*falloff + Math.cos(elapsed*5.3 + j.ph*1.7)*0.011*gust;
    j.vx += ((tx - j.x)*j.k - j.vx*j.c)*dt;
    j.vz += ((tz - j.z)*j.k - j.vz*j.c)*dt;
    j.x += j.vx*dt; j.z += j.vz*dt;
    j.x = clamp(j.x, -0.20, 0.20);
    j.z = clamp(j.z, -0.16, 0.16);
    j.g.rotation.set(j.x, 0, j.z);
  }

  if(flagGeo && flagBase){
    const pos=flagGeo.attributes.position;
    const amp=0.035+Math.min(spd*0.0055,0.15);
    const t=elapsed;
    for(let i=0;i<pos.count;i++){
      const bx=flagBase[i*3], by=flagBase[i*3+1];
      const k=clamp(bx/0.74,0,1);
      pos.setZ(i, Math.sin(bx*10.5 - t*17)*amp*k + Math.sin(by*8 + t*11)*amp*0.45*k);
      pos.setY(i, by + Math.sin(bx*6.2 - t*12.5)*0.028*k);
    }
    pos.needsUpdate=true;
    flagGeo.computeVertexNormals();
  }
}

/* ---------------- worm wrapper ---------------- */
function updateWorms(dt){
  wormNear=0; wormSeis=0; wormAttack=0;
  let seisMix=0, atkMax=0;
  for(const w of worms){
    /* each worm owns its particles, so the shared pool can be divided fairly */
    if(!w.pid) w.pid=newPOwnerId();
    setPOwner(w.pid, w.tier==='giant'?2.2 : w.tier==='small'?0.6 : 1);
    w.update(dt); wormNear=Math.max(wormNear,w.nearContrib);

    /* seismograph feed: proximity + buried depth (nearContrib) fused with a
       state pulse, then smoothed so leaving worms fade instead of snapping */
    const st=w.state;
    let attack=0;
    if(st==='coil') attack=0.55+0.45*clamp(w.stateT/0.55,0,1);
    else if(st==='lunge'||st==='dive') attack=1;
    else if(st==='emerge') attack=0.5+0.5*clamp(w.stateT/0.9,0,1);
    else if(st==='dig') attack=w.digWarned?0.45:0.10*clamp(1-horizDist(w.pos,player.pos)/240,0,1);
    else if(st==='strike') attack=0.55;
    else if(st==='breach') attack=0.85;
    else if(st==='stalk') attack=0.15;
    else if(st==='hunt') attack=0.08;
    const threat=clamp(w.nearContrib||0,0,1.1);
    const target=clamp(Math.max(threat*0.92,attack),0,1.1);
    const prev=w.seisLvl||0;
    w.seisLvl=prev+(target-prev)*Math.min(1,(target>prev?5:1.25)*dt);
    const sl=clamp(w.seisLvl*0.8,0,0.96);
    seisMix=1-(1-seisMix)*(1-sl);
    atkMax=Math.max(atkMax,attack);
  }
  setPOwner(0);
  /* corpses that finished sinking are removed; the spawn queue backfills them */
  for(let i=worms.length-1;i>=0;i--){
    const w=worms[i];
    if(!w.removeMe) continue;
    w.dropSwell();
    const v=swimVoices.get(w);
    if(v){ try{ v.s.stop(); }catch(e){} v.sp.dispose(); swimVoices.delete(w); }
    scene.remove(w.group); scene.remove(w.shadowGroup);
    if(w.shadowMesh) w.shadowMesh.material.dispose();
    worms.splice(i,1);
  }
  /* the alpha: very rare roll, once per second, once enough time has passed */
  if(gameState==='play' && !alpha.active && elapsed>ALPHA_MIN_T && elapsed-alphaLast>ALPHA_GAP){
    alphaRollT+=dt;
    if(alphaRollT>=1){ alphaRollT=0; if(Math.random()<ALPHA_CHANCE) alpha.summon(); }
  }
  setPOwner(P_ALPHA, 5);
  alpha.update(dt);
  setPOwner(0);
  wormNear=Math.max(wormNear, alpha.nearContrib);
  if(alpha.active){
    const al=clamp((alpha.nearContrib||0)*0.75,0,0.95);
    seisMix=1-(1-seisMix)*(1-al);
    if(alpha.state==='heave'||alpha.state==='lunge'||alpha.state==='emerge') atkMax=Math.max(atkMax,1);
    else if(alpha.state==='approach'||alpha.state==='settle'||alpha.state==='colossalSwim') atkMax=Math.max(atkMax,0.35);
  }
  wormSeis=clamp(seisMix,0,1.15); wormAttack=clamp(atkMax,0,1);
  const fogT = alpha.active ? 1 : 0;
  alphaFog += (fogT-alphaFog)*Math.min(1, 0.5*dt);
  if(wormNear>0.05&&(gameState==='play')) shake=Math.max(shake,0.05*wormNear);
  updateWormRecall();
  if(gameState==='play' && (alpha.active || activeGiant() || wormsHeldBack())){
    for(const q of spawnQueue) q.t+=dt;          // no new worms while the alpha or a giant is out
  } else if(gameState==='play'){
    while(spawnQueue.length&&elapsed>=spawnQueue[0].t){
      spawnQueue.shift(); spawnWorm();
      showMsg('ANOTHER WORM ANSWERS THE CALL',3);
      roar(180,true);
    }
  }
}

