/* Chase / drone camera, camera shake and alpha cinematic framing */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- camera ---------------- */
const alphaCamDir=new THREE.Vector3(), alphaLook=new THREE.Vector3();
/* smoothed crane state: the shot glides instead of snapping to the worm's jumping focus */
const alphaCamF=new THREE.Vector3(), alphaCamPos=new THREE.Vector3(), alphaLookS=new THREE.Vector3();
let alphaCamExt=0, alphaCineLin=0, alphaCamInit=false;
const ALPHA_CAM_RISE=3.0, ALPHA_CAM_FALL=5.0;   // seconds for the crane to climb / settle back
let camRoll=0, camRollV=0;         /* damped-spring camera roll state */
let camRollTarget=0;               /* roll the active driving mode wants this frame */

/* ================================================================
   CAMERA MODES — tap V to cycle, press 1-8 to jump straight to one.
   The choice persists between sessions. Cinematics ignore the mode.

     drone   cinematic spring rig that trails the jeep (default)
     chase   tight, snappy classic follow
     hood    mounted on the bonnet — rides every suspension bump
     bumper  low at the front bumper — raw sense of speed
     cockpit driver's eye level, sees the dash and steering wheel
     drift   swings to the outside of a slide and reads the corner
     free    orbit + zoom the jeep with the mouse
     rear    persistent rear-facing view
   ================================================================ */
const CAM_MODES=[
  {id:'drone',  label:'CINEMATIC CHASE', fov:62, rush:34},
  {id:'chase',  label:'CHASE CAM',       fov:60, rush:30},
  {id:'hood',   label:'HOOD CAM',        fov:70, rush:26},
  {id:'bumper', label:'BUMPER CAM',      fov:74, rush:24},
  {id:'cockpit',label:'COCKPIT CAM',     fov:68, rush:22},
  {id:'drift',  label:'DRIFT CAM',       fov:64, rush:30},
  {id:'free',   label:'FREE CAM',        fov:55, rush:0},
  {id:'rear',   label:'REAR VIEW',       fov:62, rush:30}
];
let camIndex=0;
try {
  const s=localStorage.getItem('etd_cam2');
  if(s!==null) camIndex=Math.max(0,Math.min(CAM_MODES.length-1, parseInt(s,10)||0));
  else if(localStorage.getItem('etd_cam')==='classic') camIndex=1;    // migrate the old toggle
} catch(e){}
let camMode = CAM_MODES[camIndex].id;

/* drone rig state (world space) */
const dronePos=new THREE.Vector3(), droneVel=new THREE.Vector3();
const droneAim=new THREE.Vector3(), droneAimV=new THREE.Vector3();
let droneInit=false, droneT=0;

/* drift rig state */
let driftYaw=0, driftInit=false;

/* free-cam state */
let freeYaw=2.4, freePitch=0.34, freeDist=9.5, freeDrag=false, freeLX=0, freeLY=0;

const _camQ=new THREE.Quaternion(), _camE=new THREE.Euler();

function setCamModeIndex(i, quiet){
  camIndex=(i%CAM_MODES.length+CAM_MODES.length)%CAM_MODES.length;
  camMode=CAM_MODES[camIndex].id;
  droneInit=false; driftInit=false;
  try { localStorage.setItem('etd_cam2', String(camIndex)); } catch(e){}
  if(!quiet) showMsg(CAM_MODES[camIndex].label, 1.4);
}
function cycleCamMode(dir){ setCamModeIndex(camIndex + (dir||1)); }
function toggleCamMode(){ cycleCamMode(1); }   /* kept for older callers */

/* free cam input: drag to orbit, wheel to zoom (no other mouse bindings exist) */
addEventListener('mousedown',e=>{ if(e.button===0&&camMode==='free'&&gameState!=='title'){ freeDrag=true; freeLX=e.clientX; freeLY=e.clientY; } });
addEventListener('mouseup',()=>{ freeDrag=false; });
addEventListener('mousemove',e=>{
  if(!freeDrag||camMode!=='free') return;
  freeYaw  -= (e.clientX-freeLX)*0.006;
  freePitch = clamp(freePitch + (e.clientY-freeLY)*0.005, -0.35, 1.30);
  freeLX=e.clientX; freeLY=e.clientY;
});
addEventListener('wheel',e=>{
  if(camMode==='free'&&gameState!=='title'){ e.preventDefault(); freeDist=clamp(freeDist*(1+Math.sign(e.deltaY)*0.12), 3.0, 32); }
},{passive:false});

function updateCamera(rdt){
  const wantBack=((gameState!=='title')&&(camMode==='rear'||keys.KeyQ||keys.KeyC))?1:0;
  /* lookBack transition speed is multiplied by CAMERA_SETTINGS.lookBack
     so the user can make the Q-look-back snap or slow down. */
  const lbMul = (typeof CAMERA_SETTINGS !== 'undefined' && CAMERA_SETTINGS.lookBack!=null) ? CAMERA_SETTINGS.lookBack : 1;
  lookBackAmt+=(wantBack-lookBackAmt)*Math.min(1,6*rdt*lbMul);
  const spd = Math.abs(player.speedF);
  const spdN= Math.min(spd/VMAX, 1.55);   // wider FOV rush at overdrive / chained-boost speeds
  camRollTarget = 0;

  if(gameState==='title'){
    const a=performance.now()*0.00012;
    _v1.set(player.pos.x+Math.cos(a)*16,0,player.pos.z+Math.sin(a)*16);
    _v1.y=terrainH(_v1.x,_v1.z)+5;
    camPos.lerp(_v1,Math.min(1,1.5*rdt));
    _v2.copy(player.pos); _v2.y+=1.8;
    camLook.lerp(_v2,Math.min(1,2*rdt));
  } else if(gameState==='dead' && deathFx && deathFx.type==='burn') {
    /* death crane: climb and pull back over the slow-motion wreck so we can
       watch every piece fly and hit the sand */
    const s = deathFx;
    s.camK = Math.min(1, (s.camK||0) + rdt/1.3);
    const k = s.camK*s.camK*(3-2*s.camK);
    const fx = Math.sin(player.heading), fz = Math.cos(player.heading);
    _v3.set(player.pos.x - fx*(8.5 + 8.0*k), 0, player.pos.z - fz*(8.5 + 8.0*k));
    _v3.y = terrainH(_v3.x, _v3.z) + 3.1 + 7.2*k;
    camPos.lerp(_v3, 1-Math.exp(-3.0*rdt));
    _v4.set(player.pos.x, player.pos.y + 2.4, player.pos.z);
    camLook.lerp(_v4, 1-Math.exp(-3.5*rdt));
  } else if(!player.eaten) {
    switch(camMode){
      case 'chase':   classicCam(rdt, spd, spdN); break;
      case 'hood':    rigidCam(rdt,  0.00, 1.10,  1.45, 0.55, 0.30, 0.10); break;
      case 'bumper':  rigidCam(rdt,  0.00, 0.60,  2.55, 0.45, 0.22, 0.12); break;
      case 'cockpit': rigidCam(rdt, -0.42, 1.30, -0.06, 0.60, 0.45, 0.10); break;
      case 'drift':   driftCam(rdt, spd, spdN); break;
      case 'free':    freeCam(rdt); break;
      default:        droneCam(rdt, spd, spdN); break;    // drone + rear
    }
  }

  /* if the jeep is being swallowed, pull the shot back and up to watch it go */
  if(player.eaten && deathFx && deathFx.type==='swallow'){
    const maw = swallowMaw();
    _v5.set(maw.x, Math.max(maw.y, player.pos.y), maw.z);
    camLook.lerp(_v5, 1-Math.exp(-1.6*rdt));
    const d = Math.hypot(maw.x-player.pos.x, maw.z-player.pos.z);
    _v6.copy(player.pos).addScaledVector(_v5.sub(player.pos).setY(0).normalize(), -Math.min(760, 70+d*0.5));
    _v6.y = terrainH(_v6.x,_v6.z) + Math.min(280, 70+d*0.35);
    camPos.lerp(_v6, 1-Math.exp(-1.2*rdt));
  }

  /* cinematic crane shot: the camera climbs high behind the jeep, on the far
     side from the alpha, until the whole visible colossus fits in frame */
  let cineT=0;
  const alphaF = alpha.state==='heave' ? alpha.C : (alpha.camF && alpha.camF.lengthSq()>0 ? alpha.camF : alpha.focus);
  if(alpha.active && !player.eaten && gameState!=='title' && horizDist(alphaF,player.pos)<3800){
    cineT = alpha.cineTarget||0;
    if(alpha.cine) cineT = Math.max(cineT, alpha.state==='heave' ? 0.55 : 1);
  }
  /* constant-rate progress, then a smootherstep curve: it takes exactly ALPHA_CAM_RISE
     seconds to reach the top, with zero speed at both ends — no lurch, no overshoot */
  if(cineT>alphaCineLin) alphaCineLin=Math.min(cineT, alphaCineLin+rdt/ALPHA_CAM_RISE);
  else alphaCineLin=Math.max(cineT, alphaCineLin-rdt/ALPHA_CAM_FALL);
  { const x=alphaCineLin; alphaCineW = x*x*x*(x*(x*6-15)+10); }

  camera.position.copy(camPos);

  if(alphaCineW>0.001 && !player.eaten){
    const extRaw = alpha.state==='heave' ? alpha.mouthR*3 : (alpha.camExt||Math.max(alpha.extent, alpha.headR*2));
    if(!alphaCamInit){ alphaCamF.copy(alphaF); alphaCamExt=extRaw; alphaCamInit=true; }
    /* the framing target drifts after the worm instead of jumping with it */
    alphaCamF.lerp(alphaF, 1-Math.exp(-0.9*rdt));
    alphaCamExt += (extRaw-alphaCamExt)*(1-Math.exp(-0.6*rdt));
    const F=alphaCamF, ext=alphaCamExt;
    _v5.set(F.x-player.pos.x,0,F.z-player.pos.z);
    if(_v5.lengthSq()<1) _v5.set(Math.sin(player.heading),0,Math.cos(player.heading));
    _v5.normalize();
    if(alphaCamDir.lengthSq()<0.5) alphaCamDir.copy(_v5);
    alphaCamDir.lerp(_v5, 1-Math.exp(-0.5*rdt)).normalize();
    const back=60+ext*0.2, up=50+ext*0.2+Math.max(0,F.y-player.pos.y)*0.22;
    _v6.copy(player.pos).addScaledVector(alphaCamDir,-back); _v6.y=player.pos.y+up;
    const cg=terrainH(_v6.x,_v6.z)+8; if(_v6.y<cg) _v6.y=cg;
    /* the crane offset itself is damped too, so a jolt of the jeep doesn't whip the shot */
    _v7.copy(_v6).sub(player.pos);
    if(alphaCamPos.lengthSq()<1e-6) alphaCamPos.copy(_v7);
    alphaCamPos.lerp(_v7, 1-Math.exp(-1.4*rdt));
    _v6.copy(player.pos).add(alphaCamPos);
    camera.position.lerp(_v6, alphaCineW);
    const chh=terrainH(camera.position.x,camera.position.z)+2;
    if(camera.position.y<chh) camera.position.y=chh;
    /* aim between the jeep and the worm so both stay in shot */
    _v7.copy(player.pos).lerp(_v5.set(F.x, Math.max(F.y, player.pos.y), F.z), 0.5);
    if(alphaLookS.lengthSq()<1e-6) alphaLookS.copy(_v7);
    alphaLookS.lerp(_v7, 1-Math.exp(-1.2*rdt));
    alphaLook.copy(alphaLookS);
  } else {
    alphaCamInit=false; alphaCamPos.set(0,0,0); alphaLookS.set(0,0,0);
  }

  /* keep the shot above the dunes before we aim, so the aim stays correct */
  resolveCameraTerrain();

  if(alphaCineW>0.001 && !player.eaten){
    const w=alphaCineW;
    _v6.copy(camLook).lerp(alphaLook, w);
    camera.lookAt(_v6);
  } else camera.lookAt(camLook);

  /* damped spring toward the target roll: smooth in, smooth out, no snapping.
     Multiplied by CAMERA_SETTINGS.roll so the user can dial the bank up/down. */
  const rollMul = (typeof CAMERA_SETTINGS !== 'undefined' && CAMERA_SETTINGS.roll!=null) ? CAMERA_SETTINGS.roll : 1;
  camRollV += (camRollTarget-camRoll)*44*rdt - camRollV*9.5*rdt;
  camRoll  += camRollV*rdt;
  camera.rotateZ(camRoll * rollMul);
  /* camera shake, applied last in world axes (positional + a touch of roll).
     Scaled by CAMERA_SETTINGS.shake so the user can mute or boost it. */
  const shkMul = (typeof CAMERA_SETTINGS !== 'undefined' && CAMERA_SETTINGS.shake!=null) ? CAMERA_SETTINGS.shake : 1;
  if(shkMul !== 1){ /* save originals + restore below — see applyCameraShake */ }
  applyCameraShake(rdt, shkMul);
  /* final safety net: never let the shake/wobble itself dip the shot under the ground */
  const gh=terrainH(camera.position.x, camera.position.z)+0.45;
  if(camera.position.y<gh) camera.position.y=gh;

  const M=CAM_MODES.find(m=>m.id===camMode)||CAM_MODES[0];
  /* FOV: CAMERA_SETTINGS.fovBase=0 means "use the cam-mode default",
     otherwise it overrides. The rush multiplier scales the speed-based
     FOV widening. */
  const cs = (typeof CAMERA_SETTINGS !== 'undefined') ? CAMERA_SETTINGS : null;
  const fovBaseOverride = cs ? cs.fovBase : 0;
  const fovRushMul      = cs ? cs.fovRush : 1;
  const baseFov = (fovBaseOverride>0 ? fovBaseOverride : M.fov)
                + spdN*M.rush*fovRushMul
                + (player.boost>0 ? 3 : 0);
  const tf = lerp(baseFov * (1 - lookBackAmt*0.06), 74, alphaCineW);
  camera.fov += (tf - camera.fov)*Math.min(1, 5*rdt);
  camera.updateProjectionMatrix();
}

/* ----------------------------------------------------------------
   terrain collision: keep the shot out of the dunes. First make sure the
   camera is never under the ground at its own (x,z); then, for the close
   driving shots only, lift it enough to see over any ridge that would sit
   between the jeep and the camera.
   ---------------------------------------------------------------- */
function resolveCameraTerrain(){
  const m=0.7;
  const h=terrainH(camera.position.x, camera.position.z);
  if(camera.position.y < h+m) camera.position.y = h+m;
  /* cine / title shots are already high and far — leave them alone */
  if(player.eaten || gameState==='title' || alphaCineW>0.5) return;
  const ax=player.pos.x, ay=player.pos.y+1.6, az=player.pos.z;
  const bx=camera.position.x, by=camera.position.y, bz=camera.position.z;
  const d=Math.hypot(bx-ax,bz-az);
  if(d>45 || d<0.6) return;
  let need=by;
  for(let i=1;i<=7;i++){
    const t=i/7;
    const px=ax+(bx-ax)*t, pz=az+(bz-az)*t;
    const th=terrainH(px,pz)+0.4;
    const lin=ay+(by-ay)*t;
    if(lin<th) need=Math.max(need, ay+(th-ay)/t);   // height that makes the line clear here
  }
  /* only ever raise, and never by more than a sane amount */
  if(need>by) camera.position.y=Math.min(need, by+8);
}

/* ----------------------------------------------------------------
   shake: the classic simple jolt — a world-axis positional wobble plus
   a whisper of roll. Event-driven only (no idle/engine rumble) so the
   shot is dead still unless something actually hits.
   wobble: a slower, more visible sway (roll + bob) reserved for landings,
   nearby worm swimming and nearby worm impacts — never ambient.
   ---------------------------------------------------------------- */
function applyCameraShake(rdt, shkMul){
  shkMul = shkMul==null ? 1 : shkMul;
  if(shkMul === 0) { shake = 0; wobble = 0; return; }
  const t=performance.now()*0.001;

  if(shake>0.001){
    const s=shake * shkMul;
    camera.position.x += (Math.sin(t*44.0)*0.55 + (Math.random()-0.5)*0.9)*s;
    camera.position.y += (Math.sin(t*57.3+1.3)*0.55 + (Math.random()-0.5)*0.9)*s;
    camera.position.z += (Math.sin(t*39.7+2.1)*0.55 + (Math.random()-0.5)*0.9)*s;
    camera.rotateZ(Math.sin(t*52.0)*0.055*s);
    shake *= Math.exp(-4.0*rdt); if(shake<0.001) shake=0;
  }

  /* the wobble: a slow readable sway, only when something earned it */
  if(wobble>0.001){
    const w=wobble * shkMul, wt=t*2*Math.PI*1.9;
    camera.rotateZ(Math.sin(wt)*0.065*w);
    camera.position.y += Math.sin(wt+1.1)*0.24*w;
    _v7.set(1,0,0).applyQuaternion(camera.quaternion);   // camera-right in world
    camera.position.addScaledVector(_v7, Math.sin(wt*0.73+0.5)*0.15*w);
    wobble *= Math.exp(-2.3*rdt); if(wobble<0.001) wobble=0;
  }
}

/* ----------------------------------------------------------------
   classic chase cam — tight, snappy, predictable
   ---------------------------------------------------------------- */
function classicCam(rdt, spd, spdN){
  /* distance + height multipliers from the Settings panel (default 1.0) */
  const cs = (typeof CAMERA_SETTINGS !== 'undefined') ? CAMERA_SETTINGS : null;
  const dMul = cs ? cs.distance : 1;
  const hMul = cs ? cs.height   : 1;
  const smMul = cs ? cs.smoothing : 1;
  const airW = clamp((player.airT||0)/0.25, 0, 1);   // ramps in shortly after launch
  const sgn=1-2*lookBackAmt;
  const fwd=_v1.set(Math.sin(player.heading)*sgn,0,Math.cos(player.heading)*sgn);
  const right=_v2.set(Math.cos(player.heading),0,-Math.sin(player.heading));

  const d=((8.0 + spd*0.10) * (1 + lookBackAmt*0.10)) * dMul;
  const slipOffset = clamp(player.latSlip*0.24, 0, 1.4) * (1 - lookBackAmt);
  _v3.copy(player.pos).addScaledVector(fwd,-d).addScaledVector(right, -slipOffset);
  _v3.y += (3.1 + spdN*1.7 + lookBackAmt*1.25 + airW*1.1) * hMul;
  /* aim cam: while E is held, rise up and pull back to read the throw arc */
  const aimW=aim.show*aim.show*(3-2*aim.show);
  if(aimW>0.001){ _v3.addScaledVector(fwd,-aimW*(4+5*aim.power)); _v3.y+=aimW*(3+4.5*aim.power); }
  const ch=terrainH(_v3.x,_v3.z)+1.4;
  if(_v3.y<ch) _v3.y=ch;
  camPos.lerp(_v3, 1-Math.exp(-(6.0 + lookBackAmt*2.0)*smMul*rdt));

  _v4.copy(player.pos).addScaledVector(fwd, 6.0*(1+lookBackAmt*0.7));
  _v4.y += 1.75 + airW*clamp(player.vy*0.18, -1.0, 2.4);
  if(aimW>0.001) _v4.addScaledVector(fwd, aimW*(6+26*aim.power));
  camLook.lerp(_v4, 1-Math.exp(-9*smMul*rdt));

  camRollTarget = (-(player.steer*0.06*Math.min(spd/VMAX,1)) - clamp(player.latSlip*0.008,-0.05,0.05)) * (1 - lookBackAmt*0.5);
}

/* ----------------------------------------------------------------
   body-mounted cams (hood / bumper / cockpit)
   The rig is bolted to the sprung body so every suspension bump, heave
   and body roll is felt. The aim is stabilised (yaw + a fraction of
   pitch, no body roll) and led by the car's velocity, which keeps the
   view readable instead of sickening.
   Local frame: +z forward, y = height above the ground.
   ---------------------------------------------------------------- */
function bodyPoint(out, lx, ly, lz){
  out.set(lx,ly,lz).applyQuaternion(carBody.quaternion).add(carBody.position);
  out.applyQuaternion(carRoot.quaternion).add(carRoot.position);
  return out;
}
function stabFwd(out, pitchFrac){
  _camE.set(player.pitch*(pitchFrac===undefined?0.5:pitchFrac), player.heading, 0, 'YXZ');
  _camQ.setFromEuler(_camE);
  return out.set(0,0,1).applyQuaternion(_camQ);
}
function rigidCam(rdt, lx, ly, lz, pitchFrac, rollFrac, lead){
  bodyPoint(camPos, lx, ly, lz);
  stabFwd(_v1, pitchFrac);
  camLook.copy(camPos).addScaledVector(_v1, 30).addScaledVector(player.vel, lead);
  camRollTarget = clamp(player.roll*rollFrac + player.steer*0.020*Math.min(Math.abs(player.speedF)/VMAX,1), -0.13, 0.13);
}

/* ----------------------------------------------------------------
   drift cam — the shot swings to the outside of the slide and looks
   along the direction of travel, so the jeep reads sideways through
   the corner. Fully gripped it behaves like a chase cam.
   ---------------------------------------------------------------- */
function driftCam(rdt, spd, spdN){
  const slip=clamp(player.latSlip,-13,13);
  const vlen=Math.hypot(player.vel.x,player.vel.z);
  const velYaw = vlen>3 ? Math.atan2(player.vel.x,player.vel.z) : player.heading;
  const slide = clamp(Math.abs(slip)/9,0,1) * clamp(spd/12,0,1);
  const want  = lerp(player.heading, velYaw, slide*0.85);
  if(!driftInit){ driftYaw=want; driftInit=true; }
  driftYaw += Math.atan2(Math.sin(want-driftYaw),Math.cos(want-driftYaw)) * Math.min(1,(2.4+slide*5.0)*rdt);

  const fwd=_v1.set(Math.sin(driftYaw),0,Math.cos(driftYaw));
  const dist = 9.0 + spd*0.075 + spdN*1.2 + slide*3.4 + lookBackAmt*0.6;
  const height = 3.1 + spdN*1.4 + slide*1.1;
  _v3.copy(player.pos).addScaledVector(fwd,-dist); _v3.y+=height;
  const cg=terrainH(_v3.x,_v3.z)+1.7; if(_v3.y<cg) _v3.y=cg;
  camPos.lerp(_v3, 1-Math.exp(-7.5*rdt));

  /* keep the nose framed as it slips sideways */
  _v2.set(Math.sin(player.heading),0,Math.cos(player.heading));
  _v4.copy(player.pos).addScaledVector(_v2, 3.0+spd*0.05); _v4.y+=1.8;
  camLook.lerp(_v4, 1-Math.exp(-9*rdt));

  camRollTarget = clamp(-slip*0.012 - player.steer*0.05*Math.min(spd/VMAX,1), -0.22, 0.22);
}

/* ----------------------------------------------------------------
   free cam — orbits the jeep. Drag the mouse to swing around, the
   wheel to zoom. It stays a car-photo rig even while you drive.
   ---------------------------------------------------------------- */
function freeCam(rdt){
  _v3.copy(player.pos); _v3.y+=1.1;
  const cp=Math.cos(freePitch), sp=Math.sin(freePitch);
  _v4.set(Math.sin(freeYaw)*cp, sp, Math.cos(freeYaw)*cp).multiplyScalar(freeDist).add(_v3);
  const cg=terrainH(_v4.x,_v4.z)+0.6; if(_v4.y<cg) _v4.y=cg;
  camPos.lerp(_v4, 1-Math.exp(-16*rdt));
  camLook.lerp(_v3, 1-Math.exp(-16*rdt));
  camRollTarget=0;
}

/* ----------------------------------------------------------------
   drone cam — a gimbal rig that stays glued to the jeep.
   Responsive: the rig position springs fast and near-critically so it
   never falls behind in a corner and never wobbles. Cinematic: the
   aim is a slower, velocity-led gimbal, so the shot stays composed and
   looks into the corner a beat before the car gets there.
   ---------------------------------------------------------------- */
function droneCam(rdt, spd, spdN){
  /* distance + height + smoothing multipliers from the Settings panel */
  const cs = (typeof CAMERA_SETTINGS !== 'undefined') ? CAMERA_SETTINGS : null;
  const dMul = cs ? cs.distance : 1;
  const hMul = cs ? cs.height   : 1;
  const smMul = cs ? cs.smoothing : 1;
  droneT += rdt;
  const airW  = clamp((player.airT||0)/0.28, 0, 1);
  const lookH = player.heading + lookBackAmt*Math.PI;    // rotate the rig around for look-back
  const fwd   = _v1.set(Math.sin(lookH),0,Math.cos(lookH));
  const right = _v2.set(Math.cos(lookH),0,-Math.sin(lookH));
  const aimW  = aim.show*aim.show*(3-2*aim.show);
  const first = !droneInit;
  const yaw   = clamp(player.yawRate||0, -3, 3);         // rad/s, for offset feed-forward

  /* ---- where the rig wants to be: just behind and above ---- */
  const dist   = (8.2 + spd*0.055 + spdN*0.8 + lookBackAmt*0.6 + aimW*(4+5*aim.power)) * dMul;
  const latOff = clamp(player.latSlip*0.15, -1.3, 1.3) * (1-lookBackAmt*0.75);
  const height = (3.0 + spdN*1.5 + airW*2.0 + lookBackAmt*0.7 + aimW*(3+4.5*aim.power)) * hMul;
  _v3.copy(player.pos).addScaledVector(fwd,-dist).addScaledVector(right, latOff);
  _v3.y += height;
  const cg = terrainH(_v3.x,_v3.z)+1.6; if(_v3.y<cg) _v3.y=cg;

  /* the target's own velocity (car velocity + the offset swinging round with it):
     feeding this forward is what keeps the rig responsive at speed instead of
     trailing behind — the spring only has to soak up changes, not chase distance */
  _v5.set(_v3.x-player.pos.x, 0, _v3.z-player.pos.z);
  const tvx=player.vel.x+yaw*_v5.z, tvy=player.vel.y, tvz=player.vel.z-yaw*_v5.x;

  if(first){ dronePos.copy(_v3); droneVel.set(tvx,tvy,tvz); droneInit=true; }
  /* position spring: fast, ~0.9 damped → tracks immediately, glides, no wobble.
     The spring stiffness is scaled by smMul so the Settings panel can dial
     snappiness up/down without breaking stability. */
  const kp=90*smMul, cp=2*Math.sqrt(kp)*0.9;
  _v7.copy(_v3).sub(dronePos).multiplyScalar(kp);
  _v7.x-=cp*(droneVel.x-tvx); _v7.y-=cp*(droneVel.y-tvy); _v7.z-=cp*(droneVel.z-tvz);
  droneVel.addScaledVector(_v7, rdt); dronePos.addScaledVector(droneVel, rdt);

  /* ---- gimbal aim: leads by the car's real velocity so it reads the corner
     ahead, and settles a touch softer than the rig for cinematic weight ---- */
  _v4.copy(player.pos).addScaledVector(fwd, 6.0 + spd*0.04 + aimW*(6+26*aim.power));
  _v4.addScaledVector(player.vel, 0.10);
  _v4.y += 1.8 + airW*clamp(player.vy*0.2, -1.0, 2.6);
  _v5.set(_v4.x-player.pos.x, 0, _v4.z-player.pos.z);
  const avx=player.vel.x+yaw*_v5.z, avy=player.vel.y, avz=player.vel.z-yaw*_v5.x;
  if(first){ droneAim.copy(_v4); droneAimV.set(avx,avy,avz); }
  const ka=25.0*smMul, ca=2*Math.sqrt(ka)*1.0;
  _v7.copy(_v4).sub(droneAim).multiplyScalar(ka);
  _v7.x-=ca*(droneAimV.x-avx); _v7.y-=ca*(droneAimV.y-avy); _v7.z-=ca*(droneAimV.z-avz);
  droneAimV.addScaledVector(_v7, rdt); droneAim.addScaledVector(droneAimV, rdt);

  /* ---- faint slow hover so it never feels welded to the chassis ---- */
  const hovY = Math.sin(droneT*1.7)*0.05 + Math.sin(droneT*0.9+1.2)*0.03;
  const hovX = Math.sin(droneT*1.25+0.4)*0.035;
  camPos.set(dronePos.x + right.x*hovX, dronePos.y + hovY, dronePos.z + right.z*hovX);
  camLook.copy(droneAim);

  /* ---- bank smoothly into the corner and the slide ---- */
  const latG = player.steer*Math.min(spd/VMAX,1) + clamp(player.latSlip*0.05,-0.5,0.5);
  camRollTarget = clamp(-latG*0.10, -0.16, 0.16) * (1 - lookBackAmt*0.5);
}
