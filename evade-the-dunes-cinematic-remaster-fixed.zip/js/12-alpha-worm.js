/* THE ALPHA WORM - the Old Man of the Desert: high-detail model and AI */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ================================================================
   THE ALPHA WORM — "the Old Man of the Desert"
   ---------------------------------------------------------------
   Very rare, and not a monster so much as a natural disaster.
   ~48x a normal worm: its maw is ~630 m across and its body runs
   for kilometres. It doesn't leap — the horizon itself swells,
   heaves up into a mountain, splits open, and the colossus rolls
   slowly out of the earth in a low breach before sinking back in,
   collapsing the desert into kilometre-wide craters.
   Append #alpha to the URL to force it early (for testing).
   ================================================================ */
const ALPHA_S = 135;                // normal worm: 2.8 (previous alpha: 15)
const ALPHA_FORCE = /alpha/i.test(location.hash);
/* the alpha is the rarest event of all: never before 7 minutes, then ~1-in-900 per second
   (on average ~15 more minutes), and at least 20 minutes between visits */
const ALPHA_MIN_T  = ALPHA_FORCE ? 6 : 420;     // earliest appearance (s)
const ALPHA_CHANCE = ALPHA_FORCE ? 1 : 1/900;   // roll once per second
const ALPHA_GAP    = ALPHA_FORCE ? 60 : 1200;   // min seconds between visits
let alphaLast=-1e9, alphaRollT=0, alphaFog=0, alphaBonus=0, alphaCineW=0;
const ALPHA_CAM_LEAD = 3;     // the crane shot starts climbing this many seconds before the breach
const ALPHA_CAM_HOLD = 9;     // …and stays up this long into the swim before easing back down
const ALPHA_CRUISE   = 0.5;   // swim depth of the head centre, in head radii (top ~200 m above the sand)

const alphaMats = {
  skin:  new THREE.MeshStandardMaterial({color:0x7d6a52, map:bandTex, roughness:0.97}),
  head:  new THREE.MeshStandardMaterial({color:0x6b5844, roughness:0.92}),
  plate: new THREE.MeshStandardMaterial({color:0x3e332a, roughness:0.8, metalness:0.2, flatShading:true}),
  ridge: new THREE.MeshStandardMaterial({color:0x584837, roughness:0.95}),
  maw:   mawMat,
  throat:new THREE.MeshStandardMaterial({color:0x2a0c05, emissive:0xff4a12, emissiveIntensity:1.2, roughness:0.9}),
  tooth: new THREE.MeshStandardMaterial({color:0xcdb994, roughness:0.75}),
};

/* ================================================================
   ALPHA WORM — HIGH-DETAIL MODEL
   The regular worm is a chain of low-poly spheres; scaled ×48 every
   facet becomes a 100 m flat cliff. The alpha instead gets:
   • one continuous swept-tube body (Catmull-Rom spline through the
     segment chain, ~480 rings × 128 sides) rebuilt every frame
   • armoured, overlapping body bands with grooves, fine ridges,
     per-band irregularity and ambient-occluded creases
   • a 1024² procedural skin (cracked scales, wrinkles, pebbling,
     sand caught in the cracks) with a matching normal map
   • a sculpted folded lip, a deep ribbed glowing throat and the same
     dense bristle maw-brush the lesser worms have
   ================================================================ */
function makeAlphaSkinTextures(){
  const S=1024, H=new Float32Array(S*S);
  const col=document.createElement('canvas'); col.width=col.height=S;
  const cg=col.getContext('2d'), cimg=cg.createImageData(S,S), cd=cimg.data;
  const hashI=(x,y,p,q)=>{ x=((x%p)+p)%p; y=((y%q)+q)%q;
    let h=Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(p*31+q,69069);
    h=Math.imul(h^(h>>>13),1274126177); h^=h>>>16; return (h>>>0)/4294967296; };
  const vn=(x,y,p,q)=>{ const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const a=hashI(xi,yi,p,q), b=hashI(xi+1,yi,p,q), c=hashI(xi,yi+1,p,q), d=hashI(xi+1,yi+1,p,q);
    return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v; };
  const fbm=(x,y,p,q,o)=>{ let s=0,a=0.5,f=1,n=0; for(let i=0;i<o;i++){ s+=vn(x*f,y*f,p*f,q*f)*a; n+=a; f*=2; a*=0.5; } return s/n; };
  const GX=30, GY=16;                         // scale cells (wider across the body)
  const fp=new Float32Array(GX*GY*2);
  for(let j=0;j<GY;j++) for(let i=0;i<GX;i++){ fp[(j*GX+i)*2]=hashI(i,j,GX,GY+7); fp[(j*GX+i)*2+1]=hashI(i+11,j+5,GX,GY+7); }
  for(let py=0;py<S;py++){
    const ny=py/S;
    for(let px=0;px<S;px++){
      const nx=px/S;
      /* domain-warped cellular scales */
      const wx=(fbm(nx*6,ny*6,6,6,3)-0.5)*0.9, wy=(fbm(nx*6+3.1,ny*6+1.7,6,6,3)-0.5)*0.9;
      const cx=nx*GX+wx, cy=ny*GY+wy, ci=Math.floor(cx), cj=Math.floor(cy);
      let F1=9, F2=9, id=0;
      for(let dj=-1;dj<=1;dj++) for(let di=-1;di<=1;di++){
        const ii=ci+di, jj=cj+dj, wi=((ii%GX)+GX)%GX, wj=((jj%GY)+GY)%GY, k=(wj*GX+wi)*2;
        const dx=ii+0.15+fp[k]*0.7-cx, dy=(jj+0.15+fp[k+1]*0.7-cy)*1.25;
        const d=dx*dx+dy*dy;
        if(d<F1){ F2=F1; F1=d; id=wj*GX+wi; } else if(d<F2) F2=d;
      }
      const edge=Math.sqrt(F2)-Math.sqrt(F1);           // 0 on the crack
      const crack=1-Math.min(1,edge/0.09);
      const dome=Math.min(1,edge/0.35);
      const big=fbm(nx*4,ny*4,4,4,4);
      const peb=fbm(nx*96,ny*96,96,96,2);
      const wrk=Math.sin((ny*48+big*3.0)*Math.PI*2)*0.5+0.5;  // fine wrinkles across the body
      const h=0.36*Math.sqrt(dome) - 0.42*crack*crack + 0.10*peb + 0.07*wrk*(0.4+big) + 0.25*big;
      H[py*S+px]=h;
      /* colour */
      const tone=0.86+0.26*hashI(id,7,GX*GY,1)+(big-0.5)*0.35;
      let r=0.50*tone, g=0.42*tone, b=0.32*tone;
      const pol=Math.max(0,dome-0.55)*0.5;                     // wind-polished crowns
      r+=pol*0.30; g+=pol*0.26; b+=pol*0.20;
      const sandy=fbm(nx*10+5,ny*10,10,10,2)>0.52;            // sand packed into some cracks
      const cc=crack*crack;
      if(sandy){ r=lerp(r,0.80,cc*0.85); g=lerp(g,0.64,cc*0.85); b=lerp(b,0.43,cc*0.85); }
      else     { r=lerp(r,0.16,cc*0.8);  g=lerp(g,0.12,cc*0.8);  b=lerp(b,0.09,cc*0.8); }
      const sp=(peb-0.5)*0.12; r+=sp; g+=sp; b+=sp;
      const scar=fbm(nx*3+9,ny*3+2,3,3,3);                     // old dark scarring
      if(scar>0.6){ const k=(scar-0.6)*1.6; r*=1-k*0.35; g*=1-k*0.38; b*=1-k*0.4; }
      const o=(py*S+px)*4;
      cd[o]=clamp(r,0,1)*255; cd[o+1]=clamp(g,0,1)*255; cd[o+2]=clamp(b,0,1)*255; cd[o+3]=255;
    }
  }
  cg.putImageData(cimg,0,0);
  const nrm=document.createElement('canvas'); nrm.width=nrm.height=S;
  const ng=nrm.getContext('2d'), nimg=ng.createImageData(S,S), nd=nimg.data, STR=7.5;
  for(let y=0;y<S;y++) for(let x=0;x<S;x++){
    const xl=(x+S-1)%S, xr=(x+1)%S, yu=(y+S-1)%S, ydn=(y+1)%S;
    const dx=(H[y*S+xr]-H[y*S+xl])*STR, dy=(H[ydn*S+x]-H[yu*S+x])*STR;
    let vx=-dx, vy=dy, vz=1; const l=Math.hypot(vx,vy,vz); vx/=l; vy/=l; vz/=l;
    const o=(y*S+x)*4;
    nd[o]=(vx*0.5+0.5)*255; nd[o+1]=(vy*0.5+0.5)*255; nd[o+2]=(vz*0.5+0.5)*255; nd[o+3]=255;
  }
  ng.putImageData(nimg,0,0);
  const an=Math.min(8, renderer.capabilities.getMaxAnisotropy());
  const map=new THREE.CanvasTexture(col); map.colorSpace=THREE.SRGBColorSpace;
  const nmap=new THREE.CanvasTexture(nrm);
  for(const t of [map,nmap]){ t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=an; }
  return {map, nmap};
}
const alphaSkin = makeAlphaSkinTextures();
function cloneTex(t, rx, ry){ const c=t.clone(); c.repeat.set(rx,ry); c.needsUpdate=true; return c; }

/* glowing gradient for the inside of the throat (v=0 deep → v=1 at the lips) */
function makeThroatGlowTex(){
  const cv=document.createElement('canvas'); cv.width=8; cv.height=512;
  const g=cv.getContext('2d');
  for(let y=0;y<512;y++){
    const v=1-y/512;                                   // flipY: canvas top = v 1
    const deep=Math.pow(1-sstep(v,0.05,0.85),1.6);
    const rib=0.55+0.45*Math.pow(Math.abs(Math.sin(v*Math.PI*22)),3);
    const k=clamp(deep*rib,0,1);
    g.fillStyle=`rgb(${(k*255)|0},${(k*k*205)|0},${(k*k*k*150)|0})`; g.fillRect(0,y,8,1);
  }
  const t=new THREE.CanvasTexture(cv); t.colorSpace=THREE.SRGBColorSpace; return t;
}

alphaMats.skin = new THREE.MeshStandardMaterial({color:0xffffff, map:alphaSkin.map, normalMap:alphaSkin.nmap,
  normalScale:new THREE.Vector2(1.6,1.6), roughness:0.9, metalness:0.0, vertexColors:true});
/* the lip uses the body's own skin at the body's own scale (6 tiles around, about one band
   along) and the same neutral tint the body has at its collar, so head and body read as one */
alphaMats.lip = new THREE.MeshStandardMaterial({color:0xffffff, map:cloneTex(alphaSkin.map,6,0.75),
  normalMap:cloneTex(alphaSkin.nmap,6,0.75), normalScale:new THREE.Vector2(1.6,1.6), roughness:0.9, side:THREE.DoubleSide});
/* the body's vertex colours add sand settled on its back and a darker belly; give the lip
   exactly the same tint (from its world-space normal) so the two can't drift apart */
alphaMats.lip.onBeforeCompile=(sh)=>{
  sh.fragmentShader=sh.fragmentShader.replace('#include <map_fragment>',
`#include <map_fragment>
{ vec3 wUp=normalize((viewMatrix*vec4(0.0,1.0,0.0,0.0)).xyz);
  float upd=dot(normalize(vNormal),wUp);
  float dst=smoothstep(0.25,0.95,upd)*0.22, bel=smoothstep(0.2,1.0,-upd)*0.22;
  diffuseColor.rgb*=vec3(1.0+dst*1.15-bel, 1.0+dst*0.95-bel, 1.0+dst*0.6-bel); }`);
};
alphaMats.throat = new THREE.MeshStandardMaterial({color:0x6a2a1c, map:cloneTex(alphaSkin.map,10,5),
  normalMap:cloneTex(alphaSkin.nmap,10,5), normalScale:new THREE.Vector2(2.2,2.2),
  emissive:0xff5a1a, emissiveMap:makeThroatGlowTex(), emissiveIntensity:1.6, roughness:0.7, side:THREE.DoubleSide});
/* throat wall radius (head units, mouth faces +z) */
const throatR = z => 0.45+1.75*Math.pow(sstep(z,-2.7,1.3),0.75) - 0.06*Math.pow(0.5+0.5*Math.cos(z*7.5),3);

function buildAlphaHead(){
  const g=new THREE.Group();
  /* ribbed throat tunnel, closing far down in the dark */
  /* kept short (≈1 head-radius deep) so it never pokes out of the bending body */
  const tp=[new THREE.Vector2(0.02,-2.85)];
  for(let i=0;i<=90;i++){ const z=-2.75+i/90*(1.3+2.75); tp.push(new THREE.Vector2(throatR(z), z)); }
  const throatG=new THREE.LatheGeometry(tp,160); throatG.rotateX(Math.PI/2);
  const throat=new THREE.Mesh(throatG, alphaMats.throat); g.add(throat);
  /* the lip: a thick fleshy rim with radial folds, rolling back into the body */
  const lp=new THREE.SplineCurve([
    [2.16,1.24],[2.22,1.52],[2.31,1.74],[2.44,1.88],[2.60,1.94],[2.76,1.88],[2.88,1.71],
    [2.96,1.45],[3.0,1.12],[3.01,0.78],[3.0,0.4],[2.98,0.0],[2.96,-0.6]].map(a=>new THREE.Vector2(a[0],a[1]))).getPoints(72);
  const lipG=new THREE.LatheGeometry(lp,240); lipG.rotateX(Math.PI/2);
  { const p=lipG.attributes.position, uv=lipG.attributes.uv;
    for(let i=0;i<p.count;i++){
      const x=p.getX(i), y=p.getY(i), z=p.getZ(i), v=uv.getY(i);
      const a=Math.atan2(y,x), r=Math.hypot(x,y);
      const w=Math.exp(-Math.pow((v-0.33)/0.2,2));          // folds strongest on the crest
      const fold=0.045*Math.sin(a*18)+0.022*Math.sin(a*43+1.1)+0.011*Math.sin(a*97+2.3);
      const rr=r*(1+w*fold);
      p.setXYZ(i, Math.cos(a)*rr, Math.sin(a)*rr, z+w*0.07*Math.sin(a*18+0.6));
    }
    lipG.computeVertexNormals(); }
  const lip=new THREE.Mesh(lipG, alphaMats.lip); lip.castShadow=true; g.add(lip);
  /* the same dense bristle "brush" the lesser worms have, filling the maw */
  const brush=new THREE.Mesh(brushGeo, brushMat);
  brush.position.z=0.06;
  g.add(brush);
  g.userData.brush=brush;
  g.userData.throat=throat;
  return g;
}

/* continuous swept body */
const AB_K=16, AB_M=128, AB_CAP=7;
/* A huge billboard of dust with explicit motion. */
function spawnBigCloud(x,y,z, scale, dur, opacity, rise, dx, dz, color){
  if(!cloudSlot()) return;
  const mat = new THREE.SpriteMaterial({
    map:(Math.random()<0.5)?fbmCloudTex:fbmCloudTexB, color:color||0xc49a64,
    transparent:true, opacity, depthWrite:false, rotation:Math.random()*6.284
  });
  const sprite=new THREE.Sprite(mat);
  sprite.position.set(x,y,z); sprite.scale.set(scale*0.3,scale*0.24,1);
  scene.add(sprite);
  pushCloud({sprite, t:0, dur, maxScale:scale, baseOpacity:opacity,
    rotSpeed:(Math.random()-0.5)*0.15, riseSpeed:rise, driftX:dx, driftZ:dz});
}

/* The cataclysmic sand explosion used for both the emergence and the re-dive. */
function alphaSandExplosion(x, z, mouthR, isDive){
  const gy=terrainH(x,z);
  const d=Math.hypot(player.pos.x-x, player.pos.z-z);
  /* 1. ballistic sand — a wall of grains thrown hundreds of metres up and out */
  for(let k=0;k<1400;k++){
    const a=Math.random()*Math.PI*2, rr=Math.sqrt(Math.random())*mouthR*1.3;
    const out=30+Math.random()*120, up=60+Math.random()*190*(rr<mouthR?1:0.55);
    const j=0.82+Math.random()*0.26;
    spawnP(x+Math.cos(a)*rr, gy+5+Math.random()*30, z+Math.sin(a)*rr,
      Math.cos(a)*out, up, Math.sin(a)*out,
      6+Math.random()*6, 70+Math.random()*140, 0.78*j,0.60*j,0.40*j, 22, 0.35);
  }
  /* 2. rim geysers — towering jets of sand blasting skyward around the rift */
  for(let g=0; g<28; g++){
    const a=g/28*Math.PI*2+Math.random()*0.2, rr=mouthR*(1.0+Math.random()*0.45);
    const gx=x+Math.cos(a)*rr, gz=z+Math.sin(a)*rr;
    for(let k=0;k<26;k++){
      const j=0.85+Math.random()*0.2;
      spawnP(gx+(Math.random()-0.5)*40, gy+5, gz+(Math.random()-0.5)*40,
        Math.cos(a)*(10+Math.random()*30), 120+Math.random()*170, Math.sin(a)*(10+Math.random()*30),
        5+Math.random()*4, 50+Math.random()*80, 0.82*j,0.66*j,0.45*j, 24, 0.3);
    }
  }
  /* 3. a mushroom column of dust that climbs into the sky */
  for(let k=0;k<70;k++){
    const a=Math.random()*Math.PI*2, rr=Math.random()*mouthR*1.1, h=Math.random();
    spawnBigCloud(x+Math.cos(a)*rr, gy+40+h*900, z+Math.sin(a)*rr,
      350+Math.random()*450+h*300, 12+Math.random()*8, 0.5+Math.random()*0.3,
      25+Math.random()*35, Math.cos(a)*8, Math.sin(a)*8);
  }
  /* 4. pyroclastic-style base surge racing outward across the desert */
  for(let k=0;k<70;k++){
    const a=k/70*Math.PI*2+Math.random()*0.15, rr=mouthR*(0.9+Math.random()*1.3);
    const sp=45+Math.random()*60;
    spawnBigCloud(x+Math.cos(a)*rr, gy+30+Math.random()*80, z+Math.sin(a)*rr,
      260+Math.random()*300, 10+Math.random()*6, 0.5+Math.random()*0.2,
      3+Math.random()*6, Math.cos(a)*sp, Math.sin(a)*sp, 0xbf9460);
  }
  /* 5. ground-hugging sand surge */
  for(let k=0;k<600;k++){
    const a=Math.random()*Math.PI*2, rr=mouthR*(1.4+Math.random()*1.2), sp=60+Math.random()*90, j=0.85+Math.random()*0.2;
    const sx=x+Math.cos(a)*rr, sz=z+Math.sin(a)*rr;
    spawnP(sx, terrainH(sx,sz)+10+Math.random()*20, sz, Math.cos(a)*sp, 4+Math.random()*14, Math.sin(a)*sp,
      4+Math.random()*3, 60+Math.random()*80, 0.8*j,0.64*j,0.44*j, 1.5, 0.5);
  }
  shake=Math.max(shake, 3.2*clamp(1-d/3500, 0.35, 1));
  alphaRoar(d, isDive, true, {x, z});
  /* anything sitting on the blown-out ground is gone */
  const R=mouthR*3;
  for(const p of patches) if(p.alive && Math.hypot(p.x-x,p.z-z)<R) placePatch(p);
  for(const p of thumperPickups) if(p.active && !p.reward && Math.hypot(p.x-x,p.z-z)<R) placeThumperPickup(p);
  for(const rp of rockPos) if(Math.hypot(rp.x-x,rp.z-z)<R) rp.x+=1e5;
  if(thumper.active && Math.hypot(thumper.pos.x-x,thumper.pos.z-z)<R) destroyThumper(true);
}

const ALPHA_SPATIAL={model:'equalpower', ref:700, rolloff:0.35, spread:0.45, air:2600};
function alphaRoar(dist, dive, real=true, pos=null){
  if(real && playSfx('alphaErupt', 1.0, dive?0.88:1, 0, pos?{...ALPHA_SPATIAL, pos}:{rawDist:true})){
    /* keep a soft synthetic sub-bass tail under the real eruption */
    alphaSub(dist, dive, 0.45); return;
  }
  playSfx('roar', 1.0, 0.35, dist*0.1);
  alphaSub(dist, dive, 1);
}
function alphaSub(dist, dive, amt){
  if(!AC) return;
  const t0=AC.currentTime, g=clamp(1-dist/4000,0.35,1)*amt;
  const lp=AC.createBiquadFilter(); lp.type='lowpass';
  lp.frequency.setValueAtTime(260,t0); lp.frequency.exponentialRampToValueAtTime(55,t0+6);
  const gn=AC.createGain();
  gn.gain.setValueAtTime(0.0001,t0);
  gn.gain.linearRampToValueAtTime(g*0.5,t0+0.6);
  gn.gain.exponentialRampToValueAtTime(0.0001,t0+7);
  lp.connect(gn).connect(master);
  for(const f0 of (dive?[34,36.5,17]:[42,44.5,21])){
    const o=AC.createOscillator(); o.type='sawtooth';
    o.frequency.setValueAtTime(f0,t0); o.frequency.exponentialRampToValueAtTime(f0*0.45,t0+6);
    o.connect(lp); o.start(t0); o.stop(t0+7.2);
  }
  const n=AC.createBufferSource(); n.buffer=noiseBuf; n.loop=true;
  const nf=AC.createBiquadFilter(); nf.type='lowpass'; nf.frequency.value=110;
  const ng=AC.createGain();
  ng.gain.setValueAtTime(0.0001,t0);
  ng.gain.linearRampToValueAtTime(g*1.0,t0+0.15);
  ng.gain.exponentialRampToValueAtTime(0.0001,t0+8);
  n.connect(nf).connect(ng).connect(master); n.start(t0); n.stop(t0+8.2);
}

class AlphaWorm extends Worm{
  constructor(){
    /* 14 body segments ≈ 6 km: long enough that the tail never shows during the swim,
       short enough that the whole body can pour back into the dive hole */
    super(99, {S:ALPHA_S, N:14, mats:alphaMats});
    this.mouthR=2.35*this.S;                     // ~317 m radius → ~630 m maw
    this.trailStep=this.headR*0.12;              // body samples every ~50 m
    this.C=new THREE.Vector3(); this.arcDir=new THREE.Vector3(); this.dive3=new THREE.Vector3();
    this.anims=[]; this.holes=[]; this.animT=0;
    /* the sphere chain is kept only as invisible skeleton/collision markers */
    for(const m of this.segs){ m.visible=false; m.castShadow=false; }
    this.ridge.visible=false;
    this.focus=new THREE.Vector3(); this.extent=0;
    this.camF=new THREE.Vector3(); this.camExt=0; this.cineTarget=0;
    this.E=new THREE.Vector3(); this.settleDur=10; this.emergeDur=6;
    this.wakeAcc=0; this.bulge=null;
    /* continuous dust emitters (head, tail, contact points) */
    this._ct=[]; this.ccT=0; this.headDAcc=0; this.tailDAcc=0; this.tailPAcc=0;
    this.buildBodyMesh();
  }
  buildHead(){ return buildAlphaHead(); }
  buildBodyMesh(){
    const spans=this.N+1, rings=spans*AB_K+1+AB_CAP, M1=AB_M+1;     // +1: the neck span
    this.abRings=rings;
    const g=new THREE.BufferGeometry();
    this.abPos=new Float32Array(rings*M1*3); this.abNor=new Float32Array(rings*M1*3);
    this.abCol=new Float32Array(rings*M1*3); this.abUV=new Float32Array(rings*M1*2);
    g.setAttribute('position', new THREE.BufferAttribute(this.abPos,3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('normal',   new THREE.BufferAttribute(this.abNor,3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color',    new THREE.BufferAttribute(this.abCol,3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('uv',       new THREE.BufferAttribute(this.abUV,2).setUsage(THREE.DynamicDrawUsage));
    const idx=new Uint32Array((rings-1)*AB_M*6); let o=0;
    for(let j=0;j<rings-1;j++) for(let i=0;i<AB_M;i++){
      const a=j*M1+i, b=a+M1;
      idx[o++]=a; idx[o++]=b; idx[o++]=a+1; idx[o++]=a+1; idx[o++]=b; idx[o++]=b+1;
    }
    g.setIndex(new THREE.BufferAttribute(idx,1));
    this.body=new THREE.Mesh(g, alphaMats.skin);
    this.body.frustumCulled=false; this.body.castShadow=true; this.body.receiveShadow=false;
    this.group.add(this.body);
    /* per-ring scratch */
    this.rC=new Float32Array(rings*3); this.rT=new Float32Array(rings*3);
    this.rR=new Float32Array(rings); this.rS=new Float32Array(rings); this.rB=new Float32Array(rings);
    this.rAO=new Float32Array(rings); this.rDR=new Float32Array(rings);
    this.Q=[]; for(let i=0;i<=this.N+1;i++) this.Q.push(new THREE.Vector3());
    this.QR=new Float32Array(this.N+2); this.rNear=new Float32Array(rings);
    /* fixed angular tables */
    this.cosT=new Float32Array(M1); this.sinT=new Float32Array(M1);
    for(let i=0;i<=AB_M;i++){ const t=i/AB_M*Math.PI*2; this.cosT[i]=Math.cos(t); this.sinT[i]=Math.sin(t); }
  }
  placeBody(dt){
    this.segDust.fill(1e9);              // the alpha does its own, much bigger body dust
    super.placeBody(dt);
    this.buildTube();
    this.alphaBodyDust(dt);
    this.alphaLivingDust(dt);
  }
  /* Sand thrown off both flanks wherever the body cuts through the surface, along the
     whole exposed length, dragged along with each part of the body as it moves. */
  alphaBodyDust(dt){
    const N=this.N;
    if(!this.segPrev){ this.segPrev=new Float32Array(N*3); this._ct=[]; this.segPrevOk=false; }
    const sp3=this.segPrev, idt=1/Math.max(dt,1e-3);
    this.bdT=(this.bdT||0)-dt;
    const emit=this.bdT<=0 && this.group.visible && this.segPrevOk;
    if(emit) this.bdT=0.07;
    const ct=this._ct; ct.length=0;
    for(let i=0;i<N;i++){
      const p=this.segs[i].position, o=i*3;
      const vx=(p.x-sp3[o])*idt, vz=(p.z-sp3[o+2])*idt;
      sp3[o]=p.x; sp3[o+1]=p.y; sp3[o+2]=p.z;
      if(!emit) continue;
      const r=this.rad(i), gy=terrainH(p.x,p.z), cl=gy-p.y;      // height of the sand above the axis
      if(cl>r*0.96 || cl<-r*0.96) continue;                       // not cutting the surface here
      const v=Math.hypot(vx,vz); if(v>600) continue;              // teleported this frame
      let dx=this.dir.x, dz=this.dir.z; if(v>2){ dx=vx/v; dz=vz/v; }
      const px=-dz, pz=dx, hw=Math.sqrt(Math.max(0,r*r-cl*cl));  // half-width at the surface
      ct.push({x:p.x, z:p.z, r, dx, dz, px, pz, hw, vx, vz});
      for(const sd of [-1,1]){
        const al=(Math.random()-0.5)*r*1.6;
        const cx=p.x+px*sd*hw*(0.9+Math.random()*0.2)+dx*al, cz=p.z+pz*sd*hw*(0.9+Math.random()*0.2)+dz*al;
        const cgy=terrainH(cx,cz), j=0.85+Math.random()*0.25;
        for(let k=0;k<2;k++){
          const out=20+Math.random()*50;
          spawnP(cx, cgy+4+Math.random()*25, cz, vx*0.45+px*sd*out, 22+Math.random()*60, vz*0.45+pz*sd*out,
            3.5+Math.random()*3, 150+Math.random()*190, 0.76*j,0.61*j,0.42*j, 9, 0.55);
        }
      }
    }
    /* giant clouds at the surface contact points, at a steady, never-ending rate */
    if(emit && ct.length){
      this.ccT-=dt;
      if(this.ccT<=0){
        this.ccT=1/(6+7*Math.min(1,this.spd/90));
        const c=ct[(Math.random()*ct.length)|0], sd=Math.random()<0.5?-1:1;
        const cx=c.x+c.px*sd*c.hw*(0.88+Math.random()*0.24), cz=c.z+c.pz*sd*c.hw*(0.88+Math.random()*0.24);
        const cgy=terrainH(cx,cz);
        spawnBigCloud(cx, cgy+c.r*0.14+Math.random()*c.r*0.42, cz, c.r*(3.6+Math.random()*2.4),
          9+Math.random()*6, 0.5+Math.random()*0.2, 10+Math.random()*16,
          c.vx*0.35+c.px*sd*18, c.vz*0.35+c.pz*sd*18, 0xb98a55);
      }
    }
    this.segPrevOk=true;
  }
  /* Giant clouds that keep pouring off the colossus for as long as any part of it is
     above the sand: the maw shouldering a wall of sand aside, the tail dragging a
     boiling plume behind it. */
  alphaLivingDust(dt){
    const st=this.state;
    if(st!=='lunge'&&st!=='leave'&&st!=='emerge'&&st!=='colossalSwim'&&st!=='finalDive') return;
    if(!this.group.visible) return;
    const hr=this.headR;
    /* --- head: a wall of sand rolled up ahead of the maw, plus a crown over it --- */
    const d=this.depth;
    if(d<hr*1.45){
      const s=clamp((hr*1.45-d)/(hr*1.0),0,1);
      this.headDAcc+=dt*(3.5+7*s);
      let n=this.headDAcc|0; this.headDAcc-=n; if(n>6) n=6;
      const dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx, sp=this.spd;
      while(n-->0){
        const f=Math.random()<0.62?0.5+Math.random()*2.0:-0.5+Math.random()*1.1;
        const lat=(Math.random()-0.5)*2.6;
        const x=this.pos.x+dx*hr*f+px*hr*lat, z=this.pos.z+dz*hr*f+pz*hr*lat;
        const gy=terrainH(x,z);
        spawnBigCloud(x, gy+hr*(0.12+Math.random()*0.55), z,
          hr*(2.8+Math.random()*2.6)*(0.65+0.55*s), 8+Math.random()*5,
          0.40+Math.random()*0.22, 12+Math.random()*22,
          dx*sp*(0.22+Math.random()*0.3)+px*lat*5, dz*sp*(0.22+Math.random()*0.3)+pz*lat*5,
          Math.random()<0.5?0xbf9460:0xc49a64);
      }
    }
    /* --- tail: the last of the body keeps the dunes boiling in its wake --- */
    const N=this.N, tp=this.segs[N-1].position, tr=this.rad(N-1);
    const gy=terrainH(tp.x,tp.z);
    if(tp.y+tr>gy-12){
      const s=clamp((gy-(tp.y-tr))/(tr*2.2),0,1);
      this.tailDAcc+=dt*(3.5+6*s);
      let n=this.tailDAcc|0; this.tailDAcc-=n; if(n>6) n=6;
      const dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx, sp=this.spd;
      while(n-->0){
        const i=Math.max(0,N-1-(Math.random()*2|0));
        const seg=this.segs[i].position, rr=this.rad(i);
        const lat=(Math.random()-0.5)*2.0;
        const x=seg.x+px*hr*lat-dx*hr*(0.1+Math.random()*1.0);
        const z=seg.z+pz*hr*lat-dz*hr*(0.1+Math.random()*1.0);
        const xgy=terrainH(x,z);
        spawnBigCloud(x, Math.max(xgy+hr*0.12, seg.y-rr*0.15)+Math.random()*hr*0.4, z,
          hr*(2.4+Math.random()*2.4), 7+Math.random()*5, 0.38+Math.random()*0.2,
          8+Math.random()*18, -dx*sp*0.22+(Math.random()-0.5)*9, -dz*sp*0.22+(Math.random()-0.5)*9,
          Math.random()<0.5?0xb98a55:0xc49a64);
      }
      /* sand still spitting off the tail */
      this.tailPAcc+=dt*(7+11*s);
      let m=this.tailPAcc|0; this.tailPAcc-=m; if(m>8) m=8;
      while(m-->0){
        const a=Math.random()*Math.PI*2, j=0.85+Math.random()*0.2, out=15+Math.random()*40;
        spawnP(tp.x+(Math.random()-0.5)*tr, Math.max(gy+4,tp.y)+6+Math.random()*tr*0.4, tp.z+(Math.random()-0.5)*tr,
          Math.cos(a)*out-dx*sp*0.2, 16+Math.random()*40, Math.sin(a)*out-dz*sp*0.2,
          3+Math.random()*3, 90+Math.random()*120, 0.8*j,0.64*j,0.44*j, 9, 0.55);
      }
    }
  }
  /* armoured band profile: f∈[0,1) within one body band */
  bandMul(f, bi){
    const h1=hash2(bi,17), h2=hash2(bi,53);
    const dep=(0.85+0.5*h1)*(bi<3?1.5:1.15);
    let m=1 - 0.065*dep*(1-sstep(f,0,0.1)) - 0.03*sstep(f,0.3,0.9) - 0.05*dep*sstep(f,0.9,1);
    m+=0.006*Math.sin(f*Math.PI*10)*sstep(f,0.12,0.3)*(1-sstep(f,0.85,0.95));
    return m*(1+0.014*(h2-0.5));
  }
  buildTube(){
    const N=this.N, Q=this.Q, QR=this.QR;
    /* control points: the throat rim, then every body segment */
    _v1.set(0,0,1).applyQuaternion(this.head.quaternion);
    Q[0].copy(this.head.position).addScaledVector(_v1, 0.2*this.S);
    QR[0]=this.rad(0)*0.985;
    /* the neck: a control point straight behind the head along its own axis, so the tube
       leaves the lip exactly the way the head faces and only then bends toward the body */
    Q[1].copy(this.head.position).addScaledVector(_v1, -this.headR*0.55);
    QR[1]=this.rad(0)*0.99;
    for(let i=0;i<N;i++){ Q[i+2].copy(this.segs[i].position); QR[i+2]=this.rad(i); }
    const rC=this.rC, rT=this.rT, rR=this.rR, rS=this.rS, rB=this.rB, rAO=this.rAO, rDR=this.rDR, rNear=this.rNear;
    let j=0, sAcc=0, px=Q[0].x, py=Q[0].y, pz=Q[0].z;
    let tx=_v1.x, ty=_v1.y, tz=_v1.z;
    const last=N+1; // index of last control point
    for(let i=0;i<last;i++){
      const P0=Q[Math.max(0,i-1)], P1=Q[i], P2=Q[i+1], P3=Q[Math.min(last,i+2)];
      const kEnd=(i===last-1)?AB_K:AB_K-1;
      for(let k=0;k<=kEnd;k++){
        const t=k/AB_K, t2=t*t, t3=t2*t;
        const cx=0.5*(2*P1.x+(-P0.x+P2.x)*t+(2*P0.x-5*P1.x+4*P2.x-P3.x)*t2+(-P0.x+3*P1.x-3*P2.x+P3.x)*t3);
        const cy=0.5*(2*P1.y+(-P0.y+P2.y)*t+(2*P0.y-5*P1.y+4*P2.y-P3.y)*t2+(-P0.y+3*P1.y-3*P2.y+P3.y)*t3);
        const cz=0.5*(2*P1.z+(-P0.z+P2.z)*t+(2*P0.z-5*P1.z+4*P2.z-P3.z)*t2+(-P0.z+3*P1.z-3*P2.z+P3.z)*t3);
        let dx=0.5*((-P0.x+P2.x)+2*(2*P0.x-5*P1.x+4*P2.x-P3.x)*t+3*(-P0.x+3*P1.x-3*P2.x+P3.x)*t2);
        let dy=0.5*((-P0.y+P2.y)+2*(2*P0.y-5*P1.y+4*P2.y-P3.y)*t+3*(-P0.y+3*P1.y-3*P2.y+P3.y)*t2);
        let dz=0.5*((-P0.z+P2.z)+2*(2*P0.z-5*P1.z+4*P2.z-P3.z)*t+3*(-P0.z+3*P1.z-3*P2.z+P3.z)*t2);
        const dl=Math.hypot(dx,dy,dz);
        /* tangent points from tail toward head (= outward through the mouth) */
        if(dl>1e-4){ tx=-dx/dl; ty=-dy/dl; tz=-dz/dl; }
        if(j>0) sAcc+=Math.hypot(cx-px,cy-py,cz-pz);
        px=cx; py=cy; pz=cz;
        rC[j*3]=cx; rC[j*3+1]=cy; rC[j*3+2]=cz; rT[j*3]=tx; rT[j*3+1]=ty; rT[j*3+2]=tz;
        const u=i+t, base=QR[i]+(QR[i+1]-QR[i])*sstep(t,0,1);
        const b=u-0.5, bi=Math.floor(b), fr=b-bi;
        const near=sstep(u,0.5,1.7);                          // smooth, unbanded throat collar + neck
        rR[j]=base*lerp(1, this.bandMul(fr,bi), near);
        rAO[j]=lerp(1, 0.6+0.4*sstep(fr,0,0.13)*(1-0.85*sstep(fr,0.88,1)), near);
        rNear[j]=near;
        rS[j]=sAcc; rB[j]=b;
        j++;
      }
    }
    /* rounded tail cap */
    const ej=j-1, er=rR[ej];
    for(let k=1;k<=AB_CAP;k++){
      const q=k/AB_CAP;
      rC[j*3]=rC[ej*3]-rT[ej*3]*er*q*0.9; rC[j*3+1]=rC[ej*3+1]-rT[ej*3+1]*er*q*0.9; rC[j*3+2]=rC[ej*3+2]-rT[ej*3+2]*er*q*0.9;
      rT[j*3]=rT[ej*3]; rT[j*3+1]=rT[ej*3+1]; rT[j*3+2]=rT[ej*3+2];
      rR[j]=Math.max(er*Math.sqrt(1-q*q),er*0.02); rAO[j]=rAO[ej]; rS[j]=rS[ej]+er*q*0.9; rB[j]=rB[ej]+q*0.4; rNear[j]=1;
      j++;
    }
    const R=j;
    for(let k=0;k<R;k++){
      const a=Math.max(0,k-1), b=Math.min(R-1,k+1), ds=rS[b]-rS[a];
      rDR[k]=ds>1e-3?(rR[b]-rR[a])/ds:0;
    }
    /* parallel-transport frames, seeded from the head's up vector */
    _v2.set(0,1,0).applyQuaternion(this.head.quaternion);
    let nx=_v2.x, ny=_v2.y, nz=_v2.z;
    const P=this.abPos, Nn=this.abNor, Cc=this.abCol, UVa=this.abUV, cosT=this.cosT, sinT=this.sinT, M1=AB_M+1;
    for(let k=0;k<R;k++){
      const Tx=rT[k*3], Ty=rT[k*3+1], Tz=rT[k*3+2];
      const d=nx*Tx+ny*Ty+nz*Tz; nx-=Tx*d; ny-=Ty*d; nz-=Tz*d;
      let nl=Math.hypot(nx,ny,nz);
      if(nl<1e-5){ nx=Math.abs(Ty)<0.9?0:1; ny=Math.abs(Ty)<0.9?1:0; nz=0; const d2=nx*Tx+ny*Ty+nz*Tz; nx-=Tx*d2; ny-=Ty*d2; nz-=Tz*d2; nl=Math.hypot(nx,ny,nz); }
      nx/=nl; ny/=nl; nz/=nl;
      const bx=Ty*nz-Tz*ny, by=Tz*nx-Tx*nz, bz=Tx*ny-Ty*nx;
      const cx=rC[k*3], cy=rC[k*3+1], cz=rC[k*3+2], Rs=rR[k], dRs=rDR[k], ao=rAO[k], bb=rB[k], nr=rNear[k];
      const ph=hash2(Math.floor(bb),91)*6.28, v=bb;
      for(let i=0;i<=AB_M;i++){
        const ct=cosT[i], st=sinT[i], th=i/AB_M*Math.PI*2;
        /* longitudinal creases & wrinkle folds around the circumference */
        const ang=0.010*Math.sin(th*22+ph)+0.006*Math.sin(th*9+ph*1.7)+0.003*Math.sin(th*57+ph*0.3);
        const dang=0.22*Math.cos(th*22+ph)+0.054*Math.cos(th*9+ph*1.7)+0.171*Math.cos(th*57+ph*0.3);
        const r=Rs*(1+ang);
        const rx=ct*nx+st*bx, ry=ct*ny+st*by, rz=ct*nz+st*bz;      // radial
        const gx=-st*nx+ct*bx, gy=-st*ny+ct*by, gz=-st*nz+ct*bz;   // around
        const o=(k*M1+i)*3;
        P[o]=cx+rx*r; P[o+1]=cy+ry*r; P[o+2]=cz+rz*r;
        /* analytic normal: radial tilted by the slope along and around the body
           (s grows toward the tail, T points to the head → +dRs tilts forward) */
        let qx=rx+dRs*Tx-dang/(1+ang)*gx, qy=ry+dRs*Ty-dang/(1+ang)*gy, qz=rz+dRs*Tz-dang/(1+ang)*gz;
        const ql=Math.hypot(qx,qy,qz); qx/=ql; qy/=ql; qz/=ql;
        Nn[o]=qx; Nn[o+1]=qy; Nn[o+2]=qz;
        /* colour: crease occlusion, sand settled on the back, darker belly */
        /* (fades to neutral at the collar so the body meets the lip in the same colour) */
        const up=qy, dust=sstep(up,0.25,0.95)*0.22, belly=sstep(-up,0.2,1)*0.22;
        const cr=ao*(1+dust*1.15-belly), cg2=ao*(1+dust*0.95-belly), cb=ao*(1+dust*0.6-belly);
        Cc[o]=cr; Cc[o+1]=cg2; Cc[o+2]=cb;
        const ou=(k*M1+i)*2; UVa[ou]=i/AB_M*6; UVa[ou+1]=v;
      }
    }
    const geo=this.body.geometry;
    geo.attributes.position.needsUpdate=geo.attributes.normal.needsUpdate=true;
    geo.attributes.color.needsUpdate=geo.attributes.uv.needsUpdate=true;
    /* what part of the colossus is above ground? (used to frame it with the camera) */
    let fx=0,fy=0,fz=0,n=0;
    const add=(p,r)=>{ if(p.y+r>terrainH(p.x,p.z)-r*0.2){ fx+=p.x; fy+=p.y; fz+=p.z; n++; } };
    add(this.head.position,this.headR);
    for(let i=1;i<N;i+=2) add(this.segs[i].position,this.rad(i));
    this.exposed=n/(1+Math.ceil((N-1)/2));          // share of the body still above the sand
    if(n){
      this.focus.set(fx/n,fy/n,fz/n);
      let e=0;
      const ext=(p,r)=>{ if(p.y+r>terrainH(p.x,p.z)-r*0.2) e=Math.max(e,horizDist(p,this.focus)+r); };
      ext(this.head.position,this.headR);
      for(let i=1;i<N;i+=2) ext(this.segs[i].position,this.rad(i));
      this.extent=e;
    } else { this.focus.copy(this.head.position); this.extent=this.headR; }
  }
  /* fat for most of its length, tapering only toward the tail */
  rad(i){ return this.headR*(0.98-0.62*Math.pow(Math.min(i,this.N-1)/(this.N-1),1.6)); }
  reset(){
    this.state='dormant'; this.active=false; this.nearContrib=0; this.cine=false;
    if(this.group) this.group.visible=false;
    if(this.shadowGroup) this.shadowGroup.visible=false;
    if(this.mound) this.mound.visible=false;
    this.trail.length=0;
    if(this.anims) this.anims.length=0;
    if(this.holes) this.holes.length=0;
    this.segDust.fill(0);
    this.cineTarget=0; this.bulge=null; this.wakeAcc=0; this.breachCue=false;
    if(this.swell) this.clearSwell();
    if(typeof alphaSwimStop==='function') alphaSwimStop(0.3);
  }
  /* pick where it will break the surface: off to one side ahead of the jeep, ~1.1 km out,
     then move it there deep underground with its whole body trailing back down into the dark */
  prepareEmergence(){
    const hr=this.headR;
    const lead=this.settleDur;
    const px=player.pos.x+player.vel.x*lead*0.8, pz=player.pos.z+player.vel.z*lead*0.8;
    const ang=player.heading+(Math.random()<0.5?-1:1)*(0.55+Math.random()*0.45);
    this.E.set(px+Math.sin(ang)*1150, 0, pz+Math.cos(ang)*1150);
    this.E.y=baseTerrainH(this.E.x,this.E.z);
    /* swim back past the jeep, crossing its path at a shallow angle */
    const back=player.heading+Math.PI+(ang>player.heading?-0.25:0.25);
    this.dir.set(Math.sin(back),0,Math.cos(back)); this.moveDir.copy(this.dir);
    const run=70*this.settleDur*0.92;
    this.pos.set(this.E.x-this.dir.x*run, 0, this.E.z-this.dir.z*run);
    this.depth=hr*2.6; this.spd=70;
    this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
    this.trail.length=0;
    for(let k=0;k<470;k++){
      const s=k*this.trailStep;
      const bx=this.pos.x-this.dir.x*s, bz=this.pos.z-this.dir.z*s;
      this.trail.push({x:bx, y:baseTerrainH(bx,bz)-this.depth-Math.min(s*0.45, hr*4), z:bz});
    }
    this.prevPos.copy(this.pos);
    this.clearSwell();
    this.bulge=null; this.wakeAcc=0; this.headFwd=null; this.segPrevOk=false;
    this.breachCue=false;
    this.state='settle'; this.stateT=0;
    this.settlePos.copy(this.E);
    /* the pre-eruption roar starts a full 10 s before it breaks out (settleDur) */
    if(playSfx('alphaPreRoar', 1.0, 1, 0, {...ALPHA_SPATIAL, pos:{x:this.E.x,z:this.E.z}, long:true})) alphaSub(1200,false,0.45);
    else alphaRoar(1200,true,false);
    showMsg('THE GROUND IS RISING — TURN AWAY',3.2,'alpha');
  }
  startEmerge(){
    const E=this.E;
    this.state='emerge'; this.stateT=0;
    /* the swollen hill splits: a crater rips open where it breaks out */
    if(this.bulge) this.animDeform(this.bulge, 60, 2.6);
    const rim=addBigDeform(E.x,E.z,this.mouthR*3.0,0,true); this.animDeform(rim,-22,3.0);
    tireTrails.forEach(t=>t.clear());
    alphaSandExplosion(E.x,E.z,this.mouthR,false);     // plays the eruption roar (the only time it plays)
    this.holes.push({x:E.x,z:E.z,t:0});
    this.blastCheck(E.x,E.z);
    if(!alphaSwimV) alphaSwimStart();
    showMsg('ALPHA WORM',3.6,'alpha');
  }
  /* true once every part of the body has slipped back under the sand */
  bodyBuried(){
    for(let i=0;i<this.N;i+=2){
      const p=this.segs[i].position;
      if(p.y+this.rad(i) > baseTerrainH(p.x,p.z)-8) return false;
    }
    return true;
  }
  /* The desert itself moves: a bow wave of sand tens of metres high is shoved ahead of
     the maw, shoulders of sand pile up against both flanks, and when it's still buried a
     whole hill rolls along above it. Rebuilt a few times a second and baked into terrain. */
  alphaSwell(dt){
    const sg=this.swell, hr=this.headR, st=this.state;
    this.swellT-=dt; if(this.swellT>0) return;
    this.swellT=0.17;
    const it=[]; const add=(x,z,r,h)=>{ if(Math.abs(h)>0.4) it.push({x,z,r2:r*r,h}); };
    const dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx;
    const lead=this.spd*0.18;                       // run ahead: the chunk refresh lags a little
    const hx=this.pos.x+dx*lead, hz=this.pos.z+dz*lead, d=this.depth;
    if(d>hr*1.25){
      const s=clamp((hr*3.6-d)/(hr*2.2),0,1);
      add(hx,hz,hr*2.1,hr*0.075*s);                               // rolling hill over the buried colossus
      add(hx+dx*hr*1.7,hz+dz*hr*1.7,hr*1.4,hr*0.035*s);
    } else {
      const s=clamp((hr*1.35-d)/(hr*0.6),0,1)*clamp(0.55+this.spd/110,0.6,1.25);
      add(hx+dx*hr*1.25, hz+dz*hr*1.25, hr*1.9, hr*0.17*s);       // bow wave in front of the maw (~70 m)
      add(hx+dx*hr*2.7,  hz+dz*hr*2.7,  hr*1.3, hr*0.05*s);       // sand avalanching ahead of the wave
      for(const sd of [-1,1]){
        add(hx+px*sd*hr*1.35+dx*hr*0.45, hz+pz*sd*hr*1.35+dz*hr*0.45, hr*1.15, hr*0.11*s);  // shoulders
        add(hx+px*sd*hr*1.6-dx*hr*0.9,   hz+pz*sd*hr*1.6-dz*hr*0.9,   hr*1.0,  hr*0.07*s);
      }
    }
    if(!it.length){ if(sg.items.length) this.clearSwell(); return; }
    let R=0;
    for(const q of it){ const e=Math.hypot(q.x-hx,q.z-hz)+Math.sqrt(q.r2); if(e>R) R=e; }
    /* only re-mesh chunks whose height actually changes noticeably (the swell is
       kilometres wide; its outer skirt barely moves between updates) */
    const old={x:sg.x, z:sg.z, R2:sg.R2, items:sg.items};
    const nw={x:hx, z:hz, R2:R*R, items:it};
    const oR=old.R2>0?Math.sqrt(old.R2):0;
    const xMin=Math.min(hx-R, oR?old.x-oR:hx-R), xMax=Math.max(hx+R, oR?old.x+oR:hx+R);
    const zMin=Math.min(hz-R, oR?old.z-oR:hz-R), zMax=Math.max(hz+R, oR?old.z+oR:hz+R);
    const H=CHUNK*0.5;
    for(let cx=Math.floor(xMin/CHUNK); cx<=Math.floor(xMax/CHUNK); cx++)
      for(let cz=Math.floor(zMin/CHUNK); cz<=Math.floor(zMax/CHUNK); cz++){
        const k=cx+','+cz; if(!chunks.has(k)) continue;
        const mx=cx*CHUNK+H, mz=cz*CHUNK+H;
        let dMax=0;
        for(let a=-1;a<=1;a++) for(let b=-1;b<=1;b++){
          const x=mx+a*H, z=mz+b*H;
          const dd=Math.abs(swellGroupOffset(nw,x,z)-swellGroupOffset(old,x,z));
          if(dd>dMax) dMax=dd;
        }
        if(dMax>0.4) chunkRefreshQ.add(k);
      }
    sg.items=it; sg.x=hx; sg.z=hz; sg.R2=R*R;
  }
  /* permanent scar: banks of sand on both flanks and a trough down the middle, laid down
     just behind the head (under its moving shoulders, so they never pop in) */
  depositWake(dt){
    const hr=this.headR, d=this.depth;
    if(d>hr*1.2 || this.state==='cinematic'||this.state==='distantJump'||this.state==='settle') return;
    this.wakeAcc+=this.spd*dt;
    if(this.wakeAcc<hr*0.18) return;          // close spacing: banks read as one smooth ridge
    this.wakeAcc=0;
    const s=clamp((hr*1.2-d)/(hr*0.6),0,1);
    const x=this.pos.x-this.dir.x*hr*0.7, z=this.pos.z-this.dir.z*hr*0.7;
    const px=-this.dir.z, pz=this.dir.x;
    const r0=this.rad(1), w=Math.sqrt(Math.max(0,r0*r0-d*d));    // half-width where the body cuts the sand
    const L=Math.max(w,hr*0.45);
    addWake(x, z, L*0.95, -hr*0.045*s*0.72, true);                            // trough
    for(const sd of [-1,1]){
      addWake(x+px*sd*(L+hr*0.3), z+pz*sd*(L+hr*0.3), hr*0.62, hr*0.065*s*0.72, true);    // shoved-up banks (~40 m)
      addWake(x+px*sd*(L+hr*0.95), z+pz*sd*(L+hr*0.95), hr*0.7, hr*0.015*s*0.72, true); // outer apron
    }
    invalidateChunksNear(x, z, L+hr*1.7);
  }
  /* sand thrown off the bow wave and pouring off the back in sheets */
  alphaPlow(dt){
    const hr=this.headR, d=this.depth;
    if(d>hr*1.3||this.spd<5) return;
    const s=clamp((hr*1.3-d)/(hr*0.6),0,1);
    const dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx, sp=this.spd;
    this.plowAcc=(this.plowAcc||0)+dt*90*s;
    let n=this.plowAcc|0; this.plowAcc-=n;
    while(n-->0){
      const side=Math.random()<0.5?-1:1, f=0.6+Math.random()*1.2, lat=hr*(0.3+Math.random()*1.4)*side;
      const x=this.pos.x+dx*hr*f+px*lat, z=this.pos.z+dz*hr*f+pz*lat, gy=terrainH(x,z), j=0.85+Math.random()*0.22;
      const out=12+Math.random()*30;
      spawnP(x, gy+2+Math.random()*12, z, px*side*out+dx*sp*(0.6+Math.random()*0.5), 10+Math.random()*28, pz*side*out+dz*sp*(0.6+Math.random()*0.5),
        3+Math.random()*3, 40+Math.random()*70, 0.82*j,0.66*j,0.46*j, 14, 0.5);
    }
    this.plowCl=(this.plowCl||0)+dt*5*s;
    let c=this.plowCl|0; this.plowCl-=c; if(c>3) c=3;
    while(c-->0){
      const side=Math.random()<0.5?-1:1, f=Math.random()*2.2-0.4, lat=hr*(0.7+Math.random()*1.1)*side;
      const x=this.pos.x+dx*hr*f+px*lat, z=this.pos.z+dz*hr*f+pz*lat, gy=terrainH(x,z);
      spawnBigCloud(x, gy+30+Math.random()*hr*0.25, z, hr*(0.6+Math.random()*0.7), 7+Math.random()*4, 0.42+Math.random()*0.15,
        6+Math.random()*10, px*side*12+dx*sp*0.35, pz*side*12+dz*sp*0.35, 0xbf9460);
    }
  }
  summon(){
    const a=Math.random()*Math.PI*2, dist=2600;
    this.pos.set(player.pos.x+Math.cos(a)*dist, 0, player.pos.z+Math.sin(a)*dist);
    this.dir.set(-Math.cos(a),0,-Math.sin(a)); this.moveDir.copy(this.dir);
    this.depth=this.headR*3.2; this.spd=110;
    this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
    this.trail.length=0;
    for(let k=0;k<470;k++){
      const bx=this.pos.x-this.dir.x*k*this.trailStep, bz=this.pos.z-this.dir.z*k*this.trailStep;
      this.trail.push({x:bx, y:terrainH(bx,bz)-this.depth, z:bz});
    }
    this.prevPos.copy(this.pos);
    this.state='cinematic'; this.stateT=0; this.active=true; this.group.visible=true; this.cine=false; this.cineTarget=0;
    this.clearSwell(); this.wakeAcc=0;   // older alpha scars stay in the desert this.bulge=null; this.swellT=0;
    /* the approach is silent — no music, no buried roar. The first sign is the swarm
       fleeing, then 10 s out the pre-eruption roar, then 1 s out the breach itself */
    this.headFwd=null;
    this.ripT=0; this.diveDone=false; this.anims.length=0; this.holes.length=0;
    this.cineDist=0; this.cineDir=new THREE.Vector3(); this.swimTarget=null;
    this.settlePos=new THREE.Vector3();
    alphaLast=elapsed;
    const fleeing=worms.some(w=>w.state!=='gone');
    showMsg(fleeing?'THE WORMS ARE FLEEING…':'THE DESERT GOES QUIET…',3);
    setTimeout(()=>{ if(this.state==='cinematic') showMsg('THE DESERT GOES QUIET…',3); },3200);
    setTimeout(()=>{ if(this.state==='cinematic'||this.state==='distantJump') showMsg('SEISMIC EVENT — MAGNITUDE OFF THE SCALE',3.4,'alpha'); },6400);
  }
  animDeform(df, to, dur){ this.anims.push({df, from:df.depth, to, t:0, dur}); }
  stepAnims(dt){
    this.animT-=dt;
    for(let i=this.anims.length-1;i>=0;i--){
      const A=this.anims[i]; A.t+=dt;
      const k=Math.min(1,A.t/A.dur), e=k*k*(3-2*k);
      A.df.depth=lerp(A.from,A.to,e);
      if(k>=1){ setBigDeformDepth(A.df,A.to); this.anims.splice(i,1); }
    }
    if(this.anims.length && this.animT<=0){
      this.animT=0.15;
      for(const A of this.anims) invalidateChunksNear(A.df.x, A.df.z, A.df.r);
    }
  }
  /* the earth collapses into a kilometre-wide crater with a raised rim */
  carveCrater(x,z, bulgeDf){
    const R=this.mouthR*2.6;                      // ~820 m crater
    tireTrails.forEach(t=>t.clear());
    if(bulgeDf){ this.animDeform(bulgeDf, 120, 3.2); }
    else{ const df=addBigDeform(x,z,R,0,true); this.animDeform(df, 120, 3.2); }
    const rim=addBigDeform(x,z,R*1.6,0,true); this.animDeform(rim,-34,3.6);
  }
  eatPlayer(){
    if(!player.alive) return;
    player.eaten=true; player.invuln=0;
    player.hp=0; dmgFlash=1;
    deathWatchPos=this.head.position;          // drag the jeep up into the maw
    die('alphaMouth', this.head.position);     // swallow sequence owns hiding the car
    const ov=$('over');
    ov.querySelector('.kicker').textContent='THE ALPHA FEEDS';
    ov.querySelector('h1').textContent='SWALLOWED WHOLE';
    showMsg('SWALLOWED BY THE ALPHA',3,'alpha');
  }
  blastCheck(x,z){
    if(!player.alive || gameState!=='play') return;
    const d=Math.hypot(player.pos.x-x, player.pos.z-z);
    if(d<this.mouthR) this.eatPlayer();
    else if(d<this.mouthR*1.4){ player.invuln=0; hitPlayer(45, _v1.set(x,player.pos.y,z), 'alphaBody'); }
    else if(d<this.mouthR*2.2){ player.invuln=0; hitPlayer(12, _v1.set(x,player.pos.y,z), 'alphaBody'); }
  }
  startHeave(){
    /* the rupture opens off to one side, ahead of the jeep — far enough to flee */
    const ang=player.heading+(Math.random()<0.5?-1:1)*(0.45+Math.random()*0.5);
    const off=this.mouthR*1.8;
    this.C.set(player.pos.x+Math.sin(ang)*off, 0, player.pos.z+Math.cos(ang)*off);
    this.bulge=addBigDeform(this.C.x,this.C.z,this.mouthR*3.0,0,true);
    this.animDeform(this.bulge,-70,6.2);          // a hill 70 m high, ~1.9 km across, swells up
    this.state='heave'; this.stateT=0; this.heaveDur=6.5; this.cine=true;
    showMsg('THE HORIZON IS RISING — TURN AWAY',3.2,'alpha');
    if(playSfx('alphaPreRoar', 1.0, 1, 0, {...ALPHA_SPATIAL, pos:{x:this.C.x,z:this.C.z}, long:true})) alphaSub(1400,false,0.5);
    else alphaRoar(1400,true,false);
  }
  erupt(){
    const C=this.C;
    /* a low, slow breach that rolls ACROSS the player's view, not toward them */
    _v3.set(C.x-player.pos.x,0,C.z-player.pos.z).normalize();
    const side=Math.random()<0.5?-1:1;
    this.arcDir.set(-_v3.z*side,0,_v3.x*side).addScaledVector(_v3,0.45).normalize();
    const gy=terrainH(C.x,C.z), D=this.headR*2.6, APEX=this.headR*0.5;
    this.P0.set(C.x, gy-this.headR*1.9, C.z);
    this.P1.set(C.x+this.arcDir.x*D*0.35, gy+APEX*2, C.z+this.arcDir.z*D*0.35);
    const ex=C.x+this.arcDir.x*D, ez=C.z+this.arcDir.z*D;
    this.P2.set(ex, terrainH(ex,ez)-this.headR*2.4, ez);
    this.state='lunge'; this.t=0; this.lungeDur=15; this.stateT=0; this.diveDone=false;
    this.carveCrater(C.x,C.z,this.bulge);
    alphaSandExplosion(C.x,C.z,this.mouthR,false);
    this.holes.push({x:C.x,z:C.z,t:0});
    this.blastCheck(C.x,C.z);
    this.cine=true;
    playSfx('alphaBreach', 0.9, 1, 0, {...ALPHA_SPATIAL, follow:()=>this.pos, long:true, delay:0.35});
    showMsg('ALPHA WORM',3.6,'alpha');
  }
  redive(){
    this.diveDone=true;
    const x=this.pos.x, z=this.pos.z;
    this.carveCrater(x,z,null);
    alphaSandExplosion(x,z,this.mouthR,true);
    this.holes.push({x,z,t:0});
    this.blastCheck(x,z);
  }
  pourTime(){ return 26; }
  holeDust(dt){
    for(const h of this.holes){
      h.t+=dt;
      if(h.t>(h.dur||this.pourTime())) continue;
      const gy=terrainH(h.x,h.z);
      for(let k=0;k<6;k++){
        const a=Math.random()*Math.PI*2, rr=this.mouthR*(0.9+Math.random()*0.5), j=0.85+Math.random()*0.2;
        spawnP(h.x+Math.cos(a)*rr, gy+10, h.z+Math.sin(a)*rr,
          Math.cos(a)*(15+Math.random()*30), 40+Math.random()*80, Math.sin(a)*(15+Math.random()*30),
          4+Math.random()*3, 60+Math.random()*70, 0.8*j,0.64*j,0.44*j, 12, 0.5);
      }
      if(Math.random()<dt*6){
        const a=Math.random()*Math.PI*2, rr=this.mouthR*(0.8+Math.random()*0.7);
        spawnBigCloud(h.x+Math.cos(a)*rr, gy+40+Math.random()*150, h.z+Math.sin(a)*rr,
          250+Math.random()*250, 9+Math.random()*5, 0.42, 12+Math.random()*14, Math.cos(a)*10, Math.sin(a)*10);
      }
    }
  }
  bodyDust(x,y,z,r,gy){
    const j=0.85+Math.random()*0.3;
    for(let k=0;k<4;k++){
      const a=Math.random()*Math.PI*2,sp=18+Math.random()*42;
      spawnP(x+(Math.random()-0.5)*r*1.5,Math.max(gy,y-r*0.4)+6+Math.random()*r*0.3,z+(Math.random()-0.5)*r*1.5,
        Math.cos(a)*sp,18+Math.random()*48,Math.sin(a)*sp,3+Math.random()*3,70+Math.random()*90,0.80*j,0.66*j,0.46*j,8,0.6);
    }
    const nC=Math.random()<0.7?2:1;
    for(let k=0;k<nC;k++){
      const a=Math.random()*Math.PI*2,rr=r*(0.6+Math.random()*0.9),cx=x+Math.cos(a)*rr,cz=z+Math.sin(a)*rr;
      const cy=Math.max(gy+8,y-r*0.15)+Math.random()*r*0.5;
      spawnBigCloud(cx,cy,cz,r*(2.4+Math.random()*1.4),6+Math.random()*3,0.5+Math.random()*0.2,6+Math.random()*8,0,0,0xb98a55);
    }
  }
  update(dt){
    if(this.state==='dormant'){ this.nearContrib=0; return; }
    this.stateT+=dt;
    this.stepAnims(dt);
    const dP=horizDist(this.pos,player.pos);

    if(this.state==='approach'){
      _v3.set(player.pos.x+player.vel.x*1.2, 0, player.pos.z+player.vel.z*1.2);
      this.steerToward(_v3, 1.0, dt, 0);
      this.spd+=(120-this.spd)*Math.min(1,dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yT=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yT-this.pos.y)*Math.min(1,3*dt);
      /* the whole desert shivers: sand ripples & dust shaken off the dunes */
      this.ripT-=dt;
      if(this.ripT<=0 && dP<2200){
        this.ripT=0.35;
        for(let k=0;k<26;k++){
          const a=Math.random()*Math.PI*2, rr=Math.random()*260;
          const x=player.pos.x+Math.cos(a)*rr, z=player.pos.z+Math.sin(a)*rr;
          spawnP(x, terrainH(x,z)+0.6, z, (Math.random()-0.5)*4, 2+Math.random()*5, (Math.random()-0.5)*4,
            1.6+Math.random(), 4+Math.random()*7, 0.8,0.64,0.44, 3, 1);
        }
      }
      shake=Math.max(shake, 0.12+0.45*clamp(1-dP/2600,0,1));
      if(dP<700 || this.stateT>16) this.startHeave();
    }
    else if(this.state==='heave'){
      _v3.set(this.C.x, terrainH(this.C.x,this.C.z)-this.headR*1.9, this.C.z);
      this.pos.lerp(_v3, Math.min(1, 1.2*dt));
      const k=this.stateT/this.heaveDur;
      shake=Math.max(shake, (0.4+1.1*k)*clamp(1-horizDist(this.C,player.pos)/2500,0.3,1));
      /* the swelling hill cracks and vents sand everywhere */
      const n=(8+k*30)|0;
      for(let i=0;i<n;i++){
        const a=Math.random()*Math.PI*2, rr=Math.sqrt(Math.random())*this.mouthR*2.8;
        const x=this.C.x+Math.cos(a)*rr, z=this.C.z+Math.sin(a)*rr, gy=terrainH(x,z), j=0.85+Math.random()*0.2;
        spawnP(x, gy+1, z, Math.cos(a)*(4+k*20), 4+Math.random()*(10+k*50), Math.sin(a)*(4+k*20),
          2+Math.random()*2.5, 14+Math.random()*(20+k*50), 0.82*j,0.66*j,0.45*j, 7, 0.8);
      }
      if(Math.random()<dt*(5+k*14)){
        const a=Math.random()*Math.PI*2, rr=this.mouthR*(0.5+Math.random()*2.2);
        const x=this.C.x+Math.cos(a)*rr, z=this.C.z+Math.sin(a)*rr;
        spawnBigCloud(x, terrainH(x,z)+20, z, 120+Math.random()*180, 5, 0.4, 6+Math.random()*10, Math.cos(a)*8, Math.sin(a)*8);
      }
      if(this.stateT>=this.heaveDur) this.erupt();
    }
    else if(this.state==='lunge'){
      this.t+=dt/this.lungeDur;
      if(this.t<1){
        const t=this.t, it=1-t;
        this.pos.copy(this.P0).multiplyScalar(it*it).addScaledVector(this.P1,2*it*t).addScaledVector(this.P2,t*t);
      } else {
        this.state='leave'; this.stateT=0; this.cine=false;
        this.dive3.copy(this.P2).sub(this.P1).normalize();
        this.dir.copy(this.arcDir);
      }
      if(this.t>0.88) this.cine=false;
      if(!this.diveDone && this.t>0.5 && this.pos.y<terrainH(this.pos.x,this.pos.z)+this.headR*0.2) this.redive();
      shake=Math.max(shake, 0.5*clamp(1-dP/3000,0.15,1));
    }
    else if(this.state==='leave'){
      this.dive3.lerp(_v3.set(this.arcDir.x,0,this.arcDir.z), Math.min(1,0.4*dt)).normalize();
      this.pos.addScaledVector(this.dive3, 140*dt);
      const floor=terrainH(this.pos.x,this.pos.z)-this.headR*3.2;
      if(this.pos.y<floor) this.pos.y+=(floor-this.pos.y)*Math.min(1,1.5*dt);
      shake=Math.max(shake, 0.3*Math.max(0,1-this.stateT/this.pourTime()));
      if(this.stateT>this.pourTime()-2){
        this.state='dormant'; this.active=false; this.group.visible=false; this.nearContrib=0;
        if(player.alive && gameState==='play'){
          alphaBonus+=2500;
          showMsg('YOU SURVIVED THE ALPHA  +2500',3.4,'alpha');
        }
        alphaAftermath();
        return;
      }
    }
    else if(this.state==='cinematic'){
      /* far out under the dunes: a hill of sand creeps along the horizon */
      this.cine=false; this.cineTarget=0;
      this.spd+=(45-this.spd)*Math.min(1,dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.depth+=(this.headR*2.4-this.depth)*Math.min(1,0.6*dt);
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,4,3);
      if(this.stateT>8){ this.state='distantJump'; this.stateT=0; }
    }
    else if(this.state==='distantJump'){
      /* it races beneath the far dunes — a travelling mountain of sand, still buried */
      this.cine=false; this.cineTarget=0;
      this.spd+=(200-this.spd)*Math.min(1,dt);
      _v3.set(player.pos.x+Math.sin(player.heading)*1800, 0, player.pos.z+Math.cos(player.heading)*1800);
      this.steerToward(_v3,0.4,dt,0);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.depth+=(this.headR*1.5-this.depth)*Math.min(1,1*dt);
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,12,4);
      shake=Math.max(shake,0.15*clamp(1-dP/2600,0,1));
      if(this.stateT>12){
        /* it sounds — the ground caves in behind it into a great sinkhole */
        const x=this.pos.x, z=this.pos.z, gy=terrainH(x,z);
        /* never swallow the jeep's ground: the sinkhole shrinks if it caves in close by */
        const sR=Math.min(this.headR*2.4, dP*0.7);
        if(sR>150){ const sink=addBigDeform(x,z,sR,0,true); this.animDeform(sink,55*sR/(this.headR*2.4),3.5); }
        spawnCloudCluster(_v1.set(x,gy+20,z), 24, 10*this.S, 6, 16, 3, 6, 0.6, true);
        burstDust(this.pos,200,40);
        spawnGroundShockwave(x,z,this.headR*5,2.0);
        /* no eruption sound here: it hasn't broken the surface yet — the approach stays silent */
        this.prepareEmergence();
      }
    }
    else if(this.state==='settle'){
      /* silence… then the ground beside the jeep starts to swell */
      const k=clamp(this.stateT/this.settleDur,0,1);
      this.spd+=(70-this.spd)*Math.min(1,dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.depth=lerp(this.headR*2.6, this.headR*1.1, k*k*(3-2*k));
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      const pre=this.settleDur-this.stateT;               // seconds until it breaks the surface
      this.cineTarget = pre<=ALPHA_CAM_LEAD ? 1 : 0;
      if(pre<=ALPHA_CAM_LEAD && !this.bulge){
        this.bulge=addBigDeform(this.E.x,this.E.z,this.mouthR*2.1,0,true);
        this.animDeform(this.bulge,-55,ALPHA_CAM_LEAD);    // the hill heaves up as the camera climbs
      }
      if(pre<=ALPHA_CAM_LEAD){
        const q=1-pre/ALPHA_CAM_LEAD;
        shake=Math.max(shake,(0.15+0.9*q)*clamp(1-horizDist(this.E,player.pos)/2600,0.3,1));
        const n=(6+q*26)|0;
        for(let i=0;i<n;i++){
          const a=Math.random()*Math.PI*2, rr=Math.sqrt(Math.random())*this.mouthR*2.0;
          const x=this.E.x+Math.cos(a)*rr, z=this.E.z+Math.sin(a)*rr, gy=terrainH(x,z), j=0.85+Math.random()*0.2;
          spawnP(x, gy+1, z, Math.cos(a)*(4+q*18), 4+Math.random()*(10+q*45), Math.sin(a)*(4+q*18),
            2+Math.random()*2.5, 14+Math.random()*(20+q*45), 0.82*j,0.66*j,0.45*j, 7, 0.8);
        }
        if(Math.random()<dt*(4+q*12)){
          const a=Math.random()*Math.PI*2, rr=this.mouthR*(0.4+Math.random()*1.8);
          const x=this.E.x+Math.cos(a)*rr, z=this.E.z+Math.sin(a)*rr;
          spawnBigCloud(x, terrainH(x,z)+20, z, 120+Math.random()*180, 5, 0.4, 6+Math.random()*10, Math.cos(a)*8, Math.sin(a)*8);
        }
      } else shake=Math.max(shake,0.05);
      /* one second before it breaks out: the Jump+swimming breach cue, from the top */
      if(!this.breachCue && pre<=1){
        this.breachCue=true;
        alphaSwimStart(true);
      }
      this.emitDust(dt,2,3);
      if(this.stateT>=this.settleDur) this.startEmerge();
    }
    else if(this.state==='emerge'){
      /* the breach: the head tears out of the swollen hill at a steep angle, rears up,
         then levels off into its swim — the body follows the exact same path out */
      const k=clamp(this.stateT/this.emergeDur,0,1), hr=this.headR;
      const up=1-Math.pow(1-Math.min(1,k/0.6),3);
      this.depth=lerp(lerp(hr*1.1, hr*0.3, up), ALPHA_CRUISE*hr, sstep(k,0.55,1));
      this.spd=lerp(95,58,k);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      this.cineTarget=1;
      this.emitDust(dt,30,5);
      shake=Math.max(shake,(1.1-0.8*k)*clamp(1-dP/3000,0.25,1));
      if(k>=1){
        this.state='colossalSwim'; this.stateT=0; this.swimDist=0;
        this.swimYaw0=Math.atan2(this.dir.x,this.dir.z);
        this.swimTargetDist=2800+Math.random()*900;
      }
    }
    else if(this.state==='colossalSwim'){
      /* slow, heavy, majestic: speed, depth and heading all follow the distance travelled
         (not the clock), so the body — which retraces the head's path — rolls through
         long, low swells and wide S-bends instead of bobbing */
      const hr=this.headR, k=this.swimDist/this.swimTargetDist;
      const targetSpd = 58 + 26*Math.sin(Math.min(k,1)*Math.PI);
      this.spd+=(targetSpd-this.spd)*Math.min(1,0.8*dt);
      const ph=this.swimDist/hr;
      /* a straight, unstoppable line */
      _v3.set(Math.sin(this.swimYaw0),0,Math.cos(this.swimYaw0));
      this.dir.lerp(_v3,Math.min(1,2*dt)).normalize();
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const dT=hr*(ALPHA_CRUISE + 0.075*Math.sin(ph*2*Math.PI/7) + 0.025*Math.sin(ph*2*Math.PI/2.9+0.7));
      this.depth+=(dT-this.depth)*Math.min(1,1.2*dt);
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      this.swimDist+=this.spd*dt;
      this.cineTarget = this.stateT<ALPHA_CAM_HOLD ? 1 : 0;
      this.emitDust(dt,20,4.5);
      shake=Math.max(shake,0.14*clamp(1-dP/2200,0,1));
      if(this.swimDist>=this.swimTargetDist){ this.state='finalDive'; this.stateT=0; this.diveRate=0; this.diveHole=false; this.sinkV=0; }
    }
    else if(this.state==='finalDive'){
      /* it noses down and sounds; the body keeps pouring into the hole after it */
      const hr=this.headR;
      this.cineTarget=0;
      this.diveRate=Math.min(70,(this.diveRate||0)+14*dt);
      this.depth+=this.diveRate*dt;
      this.spd+=(135-this.spd)*Math.min(1,0.45*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=baseTerrainH(this.pos.x,this.pos.z)-this.depth;
      if(!this.diveHole && this.depth>hr*1.05){
        this.diveHole=true;
        const x=this.pos.x, z=this.pos.z;
        const sink=addBigDeform(x,z,hr*1.7,0,true); this.animDeform(sink,45,4);
        this.holes.push({x,z,t:0,dur:120});            // keeps churning while the whole body pours in
        spawnGroundShockwave(x,z,hr*3,2.2);
        if(player.alive && gameState==='play') showMsg('THE ALPHA DIVES',3.2,'alpha');
      }
      if(this.depth<hr*1.4) this.emitDust(dt,20,4);
      /* the whole body follows the head down through the same hole, all of it */
      if(this.diveHole) shake=Math.max(shake,0.1*clamp(1-horizDist(this.focus,player.pos)/3000,0,1));
      if(this.stateT>4 && (this.bodyBuried() || this.stateT>150)){
        this.state='dormant'; this.active=false; this.group.visible=false; this.nearContrib=0; this.cineTarget=0;
        this.clearSwell(); alphaSwimStop(3);
        if(player.alive && gameState==='play'){
          alphaBonus+=2500;
          showMsg('YOU SURVIVED THE ALPHA  +2500',3.4,'alpha');
        }
        alphaAftermath();
        return;
      }
    }
    if(this.state==='cinematic'||this.state==='distantJump'||this.state==='settle'||
       this.state==='emerge'||this.state==='colossalSwim'||this.state==='finalDive'){
      this.alphaSwell(dt);
      this.depositWake(dt);
      this.alphaPlow(dt);
      /* the swim roar rides on the head while it is out of the sand */
      const hr=this.headR;
      /* the surface swim: silent while it is buried (the breach cue starts it 1 s out),
         then it opens right up and rides the head, fading as the last of the body slips under */
      const st=this.state, sk=clamp(this.stateT/this.settleDur,0,1);
      if(!alphaSwimV && (st==='emerge'||st==='colossalSwim')){   // missed the breach cue? start once it's out
        this.swimRetry=(this.swimRetry||0)-dt;
        if(this.swimRetry<=0){ this.swimRetry=0.5; alphaSwimStart(true); }
      }
      const lvl = st==='cinematic' ? 0.32
                : st==='distantJump' ? 0.32+0.2*clamp(this.stateT/12,0,1)
                : st==='settle' ? 0.55+0.45*sk*sk
                : st==='finalDive' ? clamp((this.exposed||0)*3,0,1) : 1;
      const open0 = st==='cinematic'||st==='distantJump' ? 0
                 : st==='settle' ? 0.3*sk*sk
                 : st==='emerge' ? 0.3+0.7*sstep(this.stateT,0,1.2)
                 : st==='finalDive' ? 0.45+0.55*clamp((this.exposed||0)*2.5,0,1) : 1;
      const open = (this.breachCue && (st==='settle'||st==='emerge')) ? Math.max(open0,0.9) : open0;   // the breach itself is never muffled
      const sp=(st==='settle'||st==='emerge'||st==='colossalSwim'||st==='finalDive') ? (this.focus.lengthSq()?this.focus:this.pos) : this.pos;
      alphaSwimLevel(lvl, st==='settle'?this.E:sp, 0.8+clamp(this.spd/120,0,1)*0.14, open);
      /* camera framing target */
      if(this.state==='settle'){ this.camF.set(this.E.x, baseTerrainH(this.E.x,this.E.z)+80, this.E.z); this.camExt=this.mouthR*2.4; }
      else { this.camF.copy(this.focus); this.camExt=Math.max(this.extent,this.headR*2); }
    }
    if(this.state==='lunge'||this.state==='leave'||this.state==='emerge'||this.state==='colossalSwim'||this.state==='finalDive') this.holeDust(dt);

    /* swallow check — the open maw itself */
    if((this.state==='lunge'||this.state==='emerge'||this.state==='colossalSwim') && player.alive && gameState==='play'){
      if(this.pos.distanceTo(player.pos)<this.mouthR+5) this.eatPlayer();
    }

    _v5.copy(this.pos).sub(this.prevPos);
    if(_v5.lengthSq()>1e-6) this.moveDir.copy(_v5).normalize();
    this.prevPos.copy(this.pos);
    _v6.set(this.moveDir.x, clamp(this.moveDir.y,-0.92,0.92), this.moveDir.z);
    if(_v6.lengthSq()<1e-4) _v6.set(this.dir.x,0,this.dir.z);
    _v6.normalize();
    /* The head stays on its neck: it faces between its motion and the first body ring,
       and turns smoothly, so it never swings ahead of the body or shows the throat seam */
    const s0=this.segs[0].position, dS=this.pos.distanceTo(s0);
    if(dS>this.headR*0.3 && dS<this.headR*3){
      _v5.copy(this.pos).sub(s0).normalize();
      _v6.multiplyScalar(0.4).addScaledVector(_v5,0.6).normalize();
    }
    if(!this.headFwd) this.headFwd=_v6.clone();
    else this.headFwd.lerp(_v6,Math.min(1,1.4*dt)).normalize();
    this.head.position.copy(this.pos);
    _v6.copy(this.headFwd).add(this.pos);
    this.head.lookAt(_v6);
    const td=this.head.userData;
    /* the maw brush slowly turns and breathes, exactly like the lesser worms' */
    td.brush.rotation.z+=dt*(0.22+0.10*Math.sin(elapsed*0.7));
    const brB=1+Math.sin(elapsed*1.3)*0.025;
    td.brush.scale.set(brB,brB,1);
    /* the throat slowly breathes — the rim flexes */
    const br=Math.sin(elapsed*0.9);
    td.throat.scale.set(1+br*0.03,1+br*0.03,1);

    const T=this.trail, h0=T[0], st2=this.trailStep*this.trailStep;
    if(!h0 || (h0.x-this.pos.x)**2+(h0.y-this.pos.y)**2+(h0.z-this.pos.z)**2>st2){
      T.unshift({x:this.pos.x,y:this.pos.y,z:this.pos.z});
      if(T.length>480) T.pop();
    }
    this.placeBody(dt);

    /* the body is a moving mountain — drive into it and it hurts */
    if((this.state==='lunge'||this.state==='leave'||this.state==='emerge'||this.state==='colossalSwim'||this.state==='finalDive') && player.alive && gameState==='play'){
      for(let i=1;i<this.N;i++){
        const m=this.segs[i], r=this.rad(i)*1.02;
        const dx=player.pos.x-m.position.x, dy=player.pos.y-m.position.y, dz=player.pos.z-m.position.z;
        if(Math.abs(dy)>=r) continue;
        const hr=Math.sqrt(r*r-dy*dy), hd=Math.hypot(dx,dz)||1;
        if(hd<hr+1.5){
          if(player.invuln<=0) hitPlayer(26, m.position, 'alphaBody');
          player.pos.x=m.position.x+dx/hd*(hr+2); player.pos.z=m.position.z+dz/hd*(hr+2);
          break;
        }
      }
    }

    if(this.state==='approach') this.nearContrib=0.45+0.7*clamp(1-dP/2600,0,1);
    else if(this.state==='heave') this.nearContrib=1.2;
    else if(this.state==='lunge') this.nearContrib=1.0;
    else if(this.state==='settle') this.nearContrib=0.5+0.7*clamp(this.stateT/this.settleDur,0,1);
    else if(this.state==='emerge') this.nearContrib=1.2;
    else if(this.state==='colossalSwim') this.nearContrib=0.55+0.55*clamp(1-dP/2600,0,1);
    else if(this.state==='finalDive') this.nearContrib=Math.max(0.2, 1.0-this.stateT*0.03);
    else this.nearContrib=Math.max(0, 1.0-this.stateT*0.04);
  }
}
const alpha = new AlphaWorm();
/* after the alpha: 15 s of quiet before the lesser worms (or anything else) come back,
   and a salvage cache spills out of the crater right next to the jeep */
let wormRecallAt = 0;
const WORM_SAFE_T = 15;
function alphaAftermath(){
  wormRecallAt = elapsed + WORM_SAFE_T;
  if(!(player.alive && gameState==='play')) return;
  /* toward the dive crater if it is close, but always within a short drive */
  let cx = player.pos.x + Math.sin(player.heading)*30, cz = player.pos.z + Math.cos(player.heading)*30;
  const h = alpha.holes[alpha.holes.length-1];
  if(h){
    const dx = h.x-player.pos.x, dz = h.z-player.pos.z, d = Math.hypot(dx,dz);
    if(d > 1){ const k = Math.min(45, d*0.35)/d; cx = player.pos.x+dx*k; cz = player.pos.z+dz*k; }
  }
  spawnRewardCache(cx, cz);
  setTimeout(()=>{ if(gameState==='play' && player.alive) showMsg('THE ALPHA LEFT SALVAGE IN ITS WAKE',3.2,'alpha'); }, 3600);
}
function updateWormRecall(){
  if(wormRecallAt > 0 && elapsed >= wormRecallAt && !alpha.active){ wormRecallAt = 0; recallWorms(); }
}
const wormsHeldBack = () => wormRecallAt > 0 && elapsed < wormRecallAt;
/* the alpha has gone — the lesser worms creep back in from the deep desert */
function recallWorms(){
  let n=0;
  worms.forEach((w,i)=>{
    if(w.state==='gone'||w.state==='flee'){ w.reset(520+Math.min(i,6)*110); w.state='cool'; w.cool=6+Math.min(i,6)*2; n++; }
  });
  if(n && player.alive && gameState==='play') setTimeout(()=>{ if(!alpha.active && gameState==='play') showMsg('THE LESSER WORMS RETURN',2.6); },3800);
}

function hitPlayer(dmg, from, cause){
  if(!player.alive||player.invuln>0) return;
  player.hp-=dmg; player.invuln=1.3; dmgFlash=1;
  _v5.copy(player.pos).sub(from); _v5.y=0;
  if(_v5.lengthSq()>0.001) _v5.normalize(); else _v5.set(1,0,0);
  player.vel.addScaledVector(_v5,16);
  shake+=0.9; impactSfx();
  wobble=Math.max(wobble, clamp(dmg*0.018, 0.18, 0.8));   // a hit lands as a sway too
  const gy=terrainH(player.pos.x, player.pos.z);
  spawnCloudCluster(_v1.set(player.pos.x, gy+0.9, player.pos.z), 5, 2.4, 2.5, 5.5, 1.3, 2.0, 0.42, false);
  if(player.hp<=0){ player.hp=0; die(cause, from); }
  else if(player.hp<30&&!lowHullWarned){ lowHullWarned=true; showMsg('HULL CRITICAL',2.5); }
}
function finalScore(){ return Math.floor(elapsed*10+spice*40+alphaBonus+digBonus); }
function die(cause, from){
  cancelAim();
  player.alive=false; gameState='dead'; deathReal=performance.now();
  deathCause = cause || 'generic';
  deathFrom  = from || null;
  shake=1.3;
  const sc=finalScore();
  best=Math.max(best,sc);
  $('ovTime').textContent=fmt(elapsed);
  $('ovSpice').textContent=spice;
  $('ovScore').textContent=sc;
  $('ovBest').textContent=best;
  startDeathSequence();     // burn (explosion) or swallow, per cause — see 15b-death.js
}
function resetGame(){
  player.pos.set(0,terrainH(0,0),0);
  player.vel.set(0,0,0); player.heading=0.6;
  player.hp=100; player.boost=0; player.invuln=0; player.alive=true; player.prevVf=0; player.latSlip=0;
  player.smN.set(0,1,0);
  player.pitch=0; player.roll=0; player.heave=0; player.accel=0; player.yawRate=0; player.bounce=0;
  player.steerAngle=0; player.handbrake=false; player.throttleIn=0;
  player.boostChain=0; player.overdrive=false;
  player.vy=0; player.grounded=true; player.airT=0; player.targetYPrev=null; player.jumpCd=0;
  player.jumping=false; player.climb=0; player.climbMem=0;
  timeScale=1;
  digBonus=0; diggerCount=1; expDiggerCount=0; resetDigger();
  carBody.rotation.set(0,0,0);
  carBody.position.set(0,0,0);
  carRoot.position.copy(player.pos);
  carRoot.quaternion.setFromEuler(_e.set(0, player.heading, 0, 'YXZ'));
  for(const w of wheels){ w.y=CAR.restY; w.vel=0; w.susp.position.y=CAR.restY; w.spin.rotation.x=0; w.steer.rotation.y=0; }
  if(antenna) for(const j of antenna.joints){ j.x=0; j.z=0; j.vx=0; j.vz=0; }
  wheelSpin=0;
  tireTrails.forEach(t=>{ t.clear(); });
  for(const w of wheels) w.spinVel=0;
  spice=0; attention=0.15; noiseLevel=0; wormNear=0; wormSeis=0; wormAttack=0; shake=0; wobble=0; timeScale=1;
  thumperCount=2; thumpRegenT=0;
  thumper.active=false; thumper.mesh.visible=false; thumper.takenBy.clear();
  proj.flying=false; cancelAim(); thumper.mesh.quaternion.identity();
  lowHullWarned=false; lastShaiMsg=-10; overShown=false; dmgFlash=0; lookBackAmt=0;
  collectFlash=0; airVigSm=0; slowMoActive=false;
  $('dmgFlash').style.opacity=0;
  $('healthVignette').style.opacity=0;
  $('airVignette').style.opacity=0;
  $('collectVignette').style.opacity=0;
  if(window.resetVehicleWear) window.resetVehicleWear();
  elapsed=0; resetSpawnQueue(); resetEcology();
  while(worms.length){
    const w=worms.pop(); w.dropSwell(); scene.remove(w.group); if(w.shadowGroup) scene.remove(w.shadowGroup);
    const v=swimVoices.get(w); if(v){ try{ v.s.stop(); }catch(e){} v.sp.dispose(); swimVoices.delete(w); }
  }
  worms.push(new WormRef(0));
  worms[0].reset(280);
  patches.forEach(placePatch);
  thumperPickups.forEach(p=>{ p.warned=false; placeThumperPickup(p); });
  sNoise.length=0; sWorm.length=0;
  pCount=0; pOwnCnt.fill(0); chunkRefreshQ.clear();
  while(dustClouds.length){ const c=dustClouds.pop(); scene.remove(c.sprite); c.sprite.material.dispose(); }
  cOwnCnt.fill(0);
  while(shockwaves.length){ const s=shockwaves.pop(); scene.remove(s.m); s.m.geometry.dispose(); s.m.material.dispose(); }
  /* Restore terrain under any live deformations, then wipe them */
  for(const df of deformers) invalidateChunksNear(df.x, df.z, df.r);
  for(const df of bigDeformers) invalidateChunksNear(df.x, df.z, df.r);
  deformers.length = 0; bigDeformers.length = 0; bigPermN = 0;
  clearWake();
  wormRecallAt = 0; clearRewardCache();
  stopLongSfx(0.3);
  alpha.reset(); alphaLast=-1e9; alphaRollT=0; alphaBonus=0; alphaCineW=0; alphaCineLin=0; alphaFog=0;
  player.eaten=false; carRoot.visible=true; carShadowGroup.visible=true;
  resetDeathFx();
  $('over').querySelector('.kicker').textContent='SIGNAL LOST';
  $('over').querySelector('h1').textContent='THE DESERT TAKES';
}
function startGame(){
  if(document.activeElement&&document.activeElement.blur) document.activeElement.blur();
  initAudio();
  resetGame();
  gameState='play';
  $('title').classList.add('hidden');
  $('over').classList.add('hidden');
  document.body.classList.remove('cinema');
  $('hud').classList.add('on');
  $('hint').classList.add('show');
  setTimeout(()=>$('hint').classList.remove('show'),12000);
  showMsg('THE DESERT IS LISTENING',3);
}
 $('startBtn').addEventListener('click',startGame);
 $('againBtn').addEventListener('click',startGame);

