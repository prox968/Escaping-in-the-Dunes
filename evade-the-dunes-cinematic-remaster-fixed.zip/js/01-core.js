/* Core: DOM helpers, renderer, scene, sky, noise, terrain deformation layer */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- dom / helpers ---------------- */
const $ = id => document.getElementById(id);
const clamp = THREE.MathUtils.clamp, lerp = THREE.MathUtils.lerp, sstep = THREE.MathUtils.smoothstep;
const _v1=new THREE.Vector3(),_v2=new THREE.Vector3(),_v3=new THREE.Vector3(),_v4=new THREE.Vector3(),
      _v5=new THREE.Vector3(),_v6=new THREE.Vector3(),_v7=new THREE.Vector3(),_n=new THREE.Vector3(),
      _q=new THREE.Quaternion(),_m=new THREE.Matrix4(),_pv=new THREE.Vector3(),_tv=new THREE.Vector3(),
      _e=new THREE.Euler();
const _wm=new THREE.Matrix4(), _ws=new THREE.Vector3();
const UP = new THREE.Vector3(0,1,0);
const VMAX = 46;
const horizDist = (a,b)=>Math.hypot(a.x-b.x, a.z-b.z);
const fmt = s => Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');

/* ---------------- renderer / scene ---------------- */
const renderer = new THREE.WebGLRenderer({
  antialias: GRAPHICS.antialias,
  powerPreference: GRAPHICS.mode === 'performance' ? 'default' : 'high-performance',
  alpha: false
});
renderer.setPixelRatio(Math.min(devicePixelRatio, GRAPHICS.pixelRatioCap));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = GRAPHICS.shadowEnabled;
renderer.shadowMap.type = GRAPHICS.shadowMode === 'soft'
  ? THREE.PCFSoftShadowMap
  : THREE.PCFShadowMap;
renderer.toneMapping = THREE.NoToneMapping;
/* NOTE: tone mapping + the display (sRGB) encode are done explicitly by the
   final GRADE pass of the post-FX chain in 17-graphics.js. three r160 skips
   tone mapping AND output encoding when rendering into EffectComposer's
   render targets, so leaving it to the renderer would dump raw linear HDR
   onto the sRGB canvas — the "cranked saturation" look. High mode grade
   pass: exposure -> ACES filmic -> grade -> sRGB. */
 $('app').appendChild(renderer.domElement);

const scene = new THREE.Scene();
/* ---------------- remastered palette (High mode) ----------------
   High gets its own light + atmosphere grade instead of "more of the
   same orange": whiter key light, cool sky bounce, a dusty blue zenith
   against a pale hazy horizon, and a desaturated golden-sand ground
   palette. Normal / Performance keep the classic look untouched. */
const HIGH_GFX = GRAPHICS.mode === 'high';
const SUN_COL   = HIGH_GFX ? 0xfff2da : 0xffdfb0;   // near-white key light
const HEMI_SKY  = HIGH_GFX ? 0xccd6e4 : 0xe8d2ab;   // cool ambient from the sky
const HEMI_GND  = HIGH_GFX ? 0x9a7850 : 0x8a6742;   // warm bounce off the sand
/* Fog is authored in linear space so it can sit slightly above 1.0: after
   ACES + sRGB it lands exactly on the graded sky-horizon colour, so the
   terrain melts into the haze with no seam. */
const FOG_COL = HIGH_GFX ? new THREE.Color(1.235, 0.588, 0.339) : new THREE.Color(0xecd6b0);
scene.fog = new THREE.Fog(FOG_COL, GRAPHICS.fogNear, GRAPHICS.fogFar);
renderer.setClearColor(HIGH_GFX ? 0xecd8b4 : FOG_COL);
const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, 0.1, 4000);

/* GOLDEN HOUR RIG — the sun sits low (≈17.5°) for long dramatic shadows,
   a sun disc that actually enters frame while driving, and god rays that
   fire when you crest a dune facing the light. */
const sunDir = new THREE.Vector3(-0.55, 0.218, -0.42).normalize();
const sun = new THREE.DirectionalLight(SUN_COL, GRAPHICS.sunIntensity);
sun.castShadow = GRAPHICS.shadowEnabled;
if(GRAPHICS.shadowEnabled){
  sun.shadow.mapSize.set(GRAPHICS.shadowMapSize, GRAPHICS.shadowMapSize);
  Object.assign(sun.shadow.camera,{
    left:-GRAPHICS.shadowCameraHalf, right:GRAPHICS.shadowCameraHalf,
    top:GRAPHICS.shadowCameraHalf,  bottom:-GRAPHICS.shadowCameraHalf,
    near:20, far:520
  });
  sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.bias = -0.00025; sun.shadow.normalBias = 0.7;
}
scene.add(sun, sun.target);
const hemiLight = new THREE.HemisphereLight(HEMI_SKY, HEMI_GND, GRAPHICS.hemiIntensity);
scene.add(hemiLight);

/* sky dome — colours come from uniforms so they're one-line tweaks.
   Per feedback the High remaster keeps the ORIGINAL desert sky hue
   (cream horizon -> dusty tan zenith) — NO blue. High values are the
   same tan sky pre-compensated through the ACES grade (the grade
   washes chroma, so the raw dome values sit warmer/deeper; solved
   numerically so graded output lands on the legacy sky within ~2/255).

   CINEMATIC REMASTER: the dome is now a physically-inspired dusty
   scattering model instead of a flat gradient —
     • optical-depth style horizon->zenith gradient (air mass grows
       toward the horizon, so the dust haze piles up there)
     • Henyey-Greenstein Mie forward-scattering around the sun (the
       wide, hot veil of a dust-loaded atmosphere)
     • an HDR sun DISC with limb darkening (drives bloom, god rays and
       the PMREM specular lobe on chrome/glass)
     • drifting fBm dust bands low over the horizon, animated slowly
       so the air itself is alive */
const SKY_HORIZON = HIGH_GFX ? new THREE.Color(1.225, 0.583, 0.314) : new THREE.Color(0.97, 0.87, 0.72);
const SKY_ZENITH  = HIGH_GFX ? new THREE.Color(0.171, 0.146, 0.091) : new THREE.Color(0.72, 0.57, 0.40);
/* horizon->zenith falloff: legacy pow(y,k) gradient in all modes */
const SKY_CURVE = 0.55;
const SKY_GLOW2 = 0.50;
const SKY_GLOW3 = 0.24;
const skyUniforms = {
  uSun:{value:sunDir},
  uHorizon:{value:SKY_HORIZON},
  uZenith:{value:SKY_ZENITH},
  uCurve:{value:SKY_CURVE},
  uGlow2:{value:SKY_GLOW2},
  uGlow3:{value:SKY_GLOW3},
  uTime:{value:0},
  /* sun disc radiance: High runs an HDR pipeline (grade pass tone maps),
     so the disc can sit far above 1.0 and feed bloom/god rays. Normal
     renders straight to the sRGB canvas, so it stays clamped but bright. */
  uSunDiscI:{value: HIGH_GFX ? 5.5 : 2.6},
  uMieI:{value: HIGH_GFX ? 1.0 : 0.55},
  uDustI:{value: HIGH_GFX ? 1.0 : 0.45},
};
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(2500, GRAPHICS.mode === 'performance' ? 24 : 48, 32),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite:false, fog:false,
    uniforms: skyUniforms,
    vertexShader:`varying vec3 vDir; void main(){ vDir=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader:`
      uniform vec3 uSun; uniform vec3 uHorizon; uniform vec3 uZenith;
      uniform float uCurve; uniform float uGlow2; uniform float uGlow3;
      uniform float uTime; uniform float uSunDiscI; uniform float uMieI; uniform float uDustI;
      varying vec3 vDir;

      /* ---- tileable value-noise fBm for the drifting dust bands ---- */
      float h21(vec2 p){
        p = fract(p * vec2(234.34, 435.345));
        p += dot(p, p + 34.23);
        return fract(p.x * p.y);
      }
      float vnoise(vec2 p){
        vec2 i = floor(p), f = fract(p);
        vec2 u = f*f*(3.0-2.0*f);
        float a = h21(i), b = h21(i+vec2(1.0,0.0)), c = h21(i+vec2(0.0,1.0)), d = h21(i+vec2(1.0,1.0));
        return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
      }
      float fbm4(vec2 p){
        float v = 0.0, a = 0.5;
        for(int i=0;i<4;i++){ v += vnoise(p)*a; p = p*2.03 + vec2(19.7, 7.3); a *= 0.5; }
        return v;
      }

      /* Henyey-Greenstein phase — forward-scattering dust aerosols */
      float hgPhase(float cosT, float g){
        float g2 = g*g;
        return (1.0 - g2) / (4.0 * 3.14159265 * pow(1.0 + g2 - 2.0*g*cosT, 1.5));
      }

      void main(){
        vec3 d = normalize(vDir);
        vec3 sd = normalize(uSun);
        float y = clamp(d.y,0.0,1.0);
        /* optical-depth-ish vertical falloff: dust density piles up at the
           horizon and thins fast toward the zenith (matches real air mass) */
        float t = (uCurve < 0.0) ? (1.0 - exp(y * uCurve)) : pow(y, uCurve);
        vec3 col = mix(uHorizon, uZenith, t);
        if(d.y<0.0) col = uHorizon;

        float cosT = clamp(dot(d,sd),0.0,1.0);

        /* Mie forward scatter — the hot dusty veil around the sun */
        float mie = hgPhase(cosT, 0.62) * 5.2 + hgPhase(cosT, 0.90) * 2.1;
        col += vec3(1.0,0.82,0.55) * mie * uGlow2 * uMieI;
        /* legacy tight glows kept for palette continuity */
        col += vec3(1.0,0.92,0.78)*pow(cosT,90.0)*uGlow2*0.45;
        col += vec3(1.0,0.84,0.58)*pow(cosT,14.0)*uGlow3*0.6;

        /* ---- HDR sun disc with limb darkening ----
           angular radius ~0.9 deg (a touch over real for presence);
           limb = darkened edge like the real photosphere. */
        float disc = smoothstep(0.999878, 0.999955, cosT);
        float limb = pow(max(1.0 - (1.0 - cosT) * 9000.0, 0.0), 0.45);
        col += vec3(1.0,0.95,0.85) * disc * (0.55 + 0.45*limb) * uSunDiscI;

        /* ---- drifting horizon dust bands ----
           fBm stretched hard horizontally, scrolling with the wind;
           brightens the haze toward the sun, cools it away from it. */
        float bandW = 1.0 - smoothstep(0.02, 0.24, abs(d.y - 0.055));
        if(bandW > 0.001 && d.y > -0.05){
          vec2 duv = vec2(atan(d.z, d.x) * 2.4, d.y * 22.0);
          float dn = fbm4(duv * 1.7 + vec2(uTime * 0.012, uTime * 0.004));
          float dn2 = fbm4(duv * 3.7 - vec2(uTime * 0.02, 0.0));
          float band = bandW * smoothstep(0.32, 0.78, dn * 0.72 + dn2 * 0.42);
          vec3 dustCol = mix(vec3(0.82,0.62,0.44), vec3(1.06,0.88,0.62), pow(cosT, 2.4));
          col = mix(col, dustCol, band * 0.30 * uDustI);
          col += dustCol * band * 0.10 * uDustI;
        }

        /* 8-bit banding killer: tiny ordered noise before the RT */
        col += (h21(gl_FragCoord.xy + fract(uTime) * 61.7) - 0.5) * (1.8/255.0);

        gl_FragColor = vec4(col,1.0);
      }`
  })
);
sky.renderOrder = -1;
scene.add(sky);

let envTex = null;
if(GRAPHICS.envMap){
  try{
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();
    envScene.add(new THREE.Mesh(sky.geometry, sky.material));
    const rt = pmrem.fromScene(envScene, 0.05, 1, 6000);
    envTex = rt.texture;
    pmrem.dispose();
  }catch(e){ envTex = null; }
}

/* ================================================================
   NOISE — shared value noise for terrain + procedural textures
   ================================================================ */
const SEED = 1337;
function hash2(ix, iz){
  let n = Math.imul(ix|0, 374761393) + Math.imul(iz|0, 668265263) + SEED;
  n = Math.imul(n ^ (n>>>13), 1274126177);
  n ^= n>>>16;
  return (n>>>0)/4294967295;
}
function noise2(x, z){
  const ix=Math.floor(x), iz=Math.floor(z), fx=x-ix, fz=z-iz;
  const ux=fx*fx*fx*(fx*(fx*6-15)+10), uz=fz*fz*fz*(fz*(fz*6-15)+10);
  const a=hash2(ix,iz), b=hash2(ix+1,iz), c=hash2(ix,iz+1), d=hash2(ix+1,iz+1);
  return a+(b-a)*ux+(c-a)*uz+(a-b-c+d)*ux*uz;
}

/* ================================================================
   TERRAIN DEFORMATION LAYER
   ---------------------------------------------------------------
   Deformations are subtractive Gaussian dents applied on top of
   the base terrain. Capped at DEFORM_MAX with FIFO eviction so the
   world stays scarrred but not infinitely chewed up.
   ================================================================ */
const DEFORM_MAX = 12;
const deformers = [];
/* Alpha-worm scars live in their own list so the small worms can't evict them.
   Negative depth = the ground BULGES upward (used while the alpha is rising). */
const BIG_DEFORM_MAX = 10;
const bigDeformers = [];
function applyDeformList(list, x, z){
  let d = 0;
  for(let i=0;i<list.length;i++){
    const df = list[i];
    const dx = x - df.x, dz = z - df.z;
    const d2 = dx*dx + dz*dz;
    if(d2 >= df.r2) continue;
    const t = 1 - d2/df.r2;
    d -= df.depth * t*t;
  }
  return d;
}
/* Swimming swell: sand heaved up around a worm's head and along its first body segments
   while it swims near the surface. Each worm owns one group; items are positive-height
   gaussian bumps (negative = furrow). Bounding radius R2 lets far-away groups be skipped. */
const swellGroups = [];
function swellOffset(x, z){
  let d = 0;
  for(let g=0; g<swellGroups.length; g++){
    const sg = swellGroups[g];
    if(sg.R2 === 0) continue;
    const gx = x - sg.x, gz = z - sg.z;
    if(gx*gx + gz*gz > sg.R2) continue;
    const it = sg.items;
    for(let i=0;i<it.length;i++){
      const dx = x - it[i].x, dz = z - it[i].z, d2 = dx*dx + dz*dz;
      if(d2 >= it[i].r2) continue;
      const t = 1 - d2/it[i].r2;
      d += it[i].h * t*t;
    }
  }
  return d;
}
/* swell offset of ONE group (the alpha uses it to ignore its own bow wave) */
function swellGroupOffset(sg, x, z){
  if(!sg || sg.R2 === 0) return 0;
  const gx = x - sg.x, gz = z - sg.z;
  if(gx*gx + gz*gz > sg.R2) return 0;
  let d = 0; const it = sg.items;
  for(let i=0;i<it.length;i++){
    const dx = x - it[i].x, dz = z - it[i].z, d2 = dx*dx + dz*dz;
    if(d2 >= it[i].r2) continue;
    const t = 1 - d2/it[i].r2;
    d += it[i].h * t*t;
  }
  return d;
}
/* ALPHA WAKE: the permanent scar the colossus ploughs through the desert — sand banks
   shoved up on both flanks and a trough along its path. Hundreds of bumps, so they
   live in a spatial hash (WAKE_CELL m cells) and every lookup only touches a few. */
const WAKE_CELL = 320, WAKE_MAX = 900;
const wakeItems = [];
const wakeGrid = new Map();
const wakeKey = (ix, iz) => (ix + 32768) * 65536 + (iz + 32768);
function wakeCells(it, fn){
  const r = it.r;
  const x0 = Math.floor((it.x-r)/WAKE_CELL), x1 = Math.floor((it.x+r)/WAKE_CELL);
  const z0 = Math.floor((it.z-r)/WAKE_CELL), z1 = Math.floor((it.z+r)/WAKE_CELL);
  for(let ix=x0; ix<=x1; ix++) for(let iz=z0; iz<=z1; iz++) fn(wakeKey(ix, iz));
}
/* perm = the alpha's scar: never evicted (only the giant's wake recycles) */
let wakePermN = 0;
function addWake(x, z, r, h, perm){
  const it = {x, z, r, r2:r*r, h, perm:!!perm};
  wakeItems.push(it); if(perm) wakePermN++;
  wakeCells(it, k => { let c = wakeGrid.get(k); if(!c){ c = []; wakeGrid.set(k, c); } c.push(it); });
  if(wakeItems.length - wakePermN > WAKE_MAX){
    const oi = wakeItems.findIndex(q => !q.perm);
    const old = wakeItems.splice(oi, 1)[0];
    wakeCells(old, k => { const c = wakeGrid.get(k); if(c){ const i = c.indexOf(old); if(i>=0) c.splice(i,1); if(!c.length) wakeGrid.delete(k); } });
    if(typeof invalidateChunksNear === 'function') invalidateChunksNear(old.x, old.z, old.r);
  }
  return it;
}
function clearWake(){
  for(const it of wakeItems) if(typeof invalidateChunksNear === 'function') invalidateChunksNear(it.x, it.z, it.r);
  wakeItems.length = 0; wakeGrid.clear(); wakePermN = 0;
}
function wakeOffset(x, z){
  if(wakeItems.length === 0) return 0;
  const c = wakeGrid.get(wakeKey(Math.floor(x/WAKE_CELL), Math.floor(z/WAKE_CELL)));
  if(!c) return 0;
  let d = 0;
  for(let i=0;i<c.length;i++){
    const it = c[i], dx = x - it.x, dz = z - it.z, d2 = dx*dx + dz*dz;
    if(d2 >= it.r2) continue;
    const t = 1 - d2/it.r2;
    d += it.h * t*t*(3-2*t);              // smoothstep falloff: soft, rounded sand banks
  }
  return d;
}
function deformOffset(x, z){
  if(deformers.length === 0 && bigDeformers.length === 0 && swellGroups.length === 0 && wakeItems.length === 0) return 0;
  return applyDeformList(deformers, x, z) + applyDeformList(bigDeformers, x, z) + swellOffset(x, z) + wakeOffset(x, z);
}
/* undeformed dunes only (no worm dents, swells or craters) */
function baseTerrainH(x, z){
  const wx = x + 70*noise2(x*0.0035+11.7, z*0.0035+3.1) - 35;
  const wz = z + 70*noise2(x*0.0035+7.3,  z*0.0035+19.7) - 35;
  let r = 1 - Math.abs(2*noise2(wx*0.0058, wz*0.0058) - 1);
  let h = (noise2(x*0.0011+31, z*0.0011+7)-0.5)*16;
  h += r*r*24;
  h += (noise2(x*0.017+5, z*0.017+9)-0.5)*6;
  h += (noise2(x*0.07+2,  z*0.07+4 )-0.5)*1.6;
  return h;
}
function terrainH(x, z){ return baseTerrainH(x, z) + deformOffset(x, z); }
function terrainNormal(x, z, out){
  const e=1.6;
  out.set(-(terrainH(x+e,z)-terrainH(x-e,z)), 2*e, -(terrainH(x,z+e)-terrainH(x,z-e))).normalize();
  return out;
}

const player={pos:new THREE.Vector3(0,terrainH(0,0),0), vel:new THREE.Vector3(), heading:0.6,
  speedF:0, prevVf:0, latSlip:0, boost:0, hp:100, invuln:0, alive:true, steer:0, smN:new THREE.Vector3(0,1,0),
  pitch:0, roll:0, heave:0, accel:0, yawRate:0, bounce:0, lastGroundVel:0,
  steerAngle:0, handbrake:false, throttleIn:0,
  /* spice boost chaining + SHIFT overdrive */
  boostChain:0, overdrive:false, susMaxV:0, susClunk:0,
  /* dune-jump vertical dynamics */
  vy:0, grounded:true, airT:0, targetYPrev:null, jumpCd:0, jumping:false, climb:0, climbMem:0};

