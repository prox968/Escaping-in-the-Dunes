/* Streaming terrain chunks, far ground, chunk refresh, deformation API */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- terrain chunks ----------------
   View radius scales with graphics mode (Performance streams a 5×5 grid,
   Normal 7×7, High 9×9). Sand tiling stays the same — the desert belongs
   to the world, not to the chunks streaming over it. */
const CHUNK=140, VIEW=GRAPHICS.viewDistance;
const TERRAIN_POLY_MAX = clamp(GRAPHICS.terrainPolyMax || 2600, 800, 5200);
const TRES = clamp(Math.round(Math.sqrt(TERRAIN_POLY_MAX / 2)), 16, 52);
const TRES_FAR = Math.max(12, Math.min(TRES - 2, Math.round(TRES * 0.58)));
const LOD_NEAR = 2;
const LODS = [TRES, TRES_FAR].map(res => {
  const W = res + 3;
  return {
    res,
    W,
    gridN: (res + 1) * (res + 1),
    hgrid: new Float32Array(W * W),
    dgrid: new Float32Array(W * W),
  };
});
function terrainLodFor(dx, dz){
  return Math.max(Math.abs(dx), Math.abs(dz)) <= LOD_NEAR ? 0 : 1;
}
/* one full sand tile spans SAND_TILE metres; chunk UVs are world-space so the
   pattern belongs to the desert, not to the chunks streaming over it */
const SAND_TILE=34, SAND_INV=1/SAND_TILE;
/* Ground palette — High mode swaps the rust-orange dune colours for a
   calmer golden-sand set (the vertex colours multiply the near-white
   sand albedo, so they define the desert's hue). */
const HIGH_GFX_T = GRAPHICS.mode === 'high';
const C_LOW =new THREE.Color(HIGH_GFX_T ? 0xb57e3d : 0xa5763f);  // hollows / low sand (warmer)
const C_HIGH=new THREE.Color(HIGH_GFX_T ? 0xeed49c : 0xeccb92);  // sunlit crests (warmer)
const C_RED =new THREE.Color(HIGH_GFX_T ? 0xbf8b53 : 0xc08046);  // rust patches (warmer)
const C_RED_MAX = HIGH_GFX_T ? 0.20 : 0.35;                      // rust patch strength

/* ================================================================
   REALISM LAYER — terrain shader enhancement
   ---------------------------------------------------------------
   The base PBR sheet is good, but a single tiled normal map at 34 m
   repeats and lacks close-up grain. This layer injects, via
   onBeforeCompile:
     1. a MICRO-DETAIL normal (fine wind-grained sand) whiteout-blended
        on top of the base normal at its own world scale + rotation —
        kills visible tiling and gives the surface a real grain
     2. ANIMATED SAND GLITTER — sparse per-cell glints that twinkle as
        the camera moves (quartz crystals catching the sun)
     3. SUN-TINTED AERIAL FOG — fog reddens/warms when looking toward
        the sun and cools away from it (true aerial perspective)
   ================================================================ */
function makeDetailNormalTexture(){
  const S=256, cv=document.createElement('canvas'); cv.width=cv.height=S;
  const g=cv.getContext('2d'), img=g.createImageData(S,S), d=img.data;
  const H=new Float32Array(S*S);
  const hI=(x,y)=>{ x=((x%S)+S)%S; y=((y%S)+S)%S;
    let h=Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+91;
    h=Math.imul(h^(h>>>13),1274126177); h^=h>>>16; return (h>>>0)/4294967296; };
  const vn=(x,y)=>{ const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const a=hI(xi,yi), b=hI(xi+1,yi), c=hI(xi,yi+1), e=hI(xi+1,yi+1);
    return a+(b-a)*u+(c-a)*v+(a-b-c+e)*u*v; };
  for(let py=0;py<S;py++) for(let px=0;px<S;px++){
    const nx=px/S, ny=py/S;
    /* fine anisotropic grain: stretched along wind + per-pixel grit + tiny dunes */
    const g1=vn(nx*2.0, ny*26.0), g2=vn(nx*40.0+13.1, ny*7.0+3.7), g3=vn(nx*90.0+51.0, ny*90.0+7.0);
    const hs=hI(px,py);
    H[py*S+px]=0.42*g1+0.24*g2+0.18*g3+0.16*hs;
  }
  let mn=1e9, mx=-1e9;
  for(let i=0;i<S*S;i++){ const h=H[i]; if(h<mn)mn=h; if(h>mx)mx=h; }
  const inv=1/Math.max(1e-6,mx-mn);
  for(let py=0;py<S;py++) for(let px=0;px<S;px++){
    const xc=(px+1)%S, xp=(px+S-1)%S, yc=(py+1)%S, yp=(py+S-1)%S;
    const dx=((H[py*S+xc]-H[py*S+xp])*inv)*3.4, dy=((H[yc*S+px]-H[yp*S+px])*inv)*3.4;
    let nx=-dx, ny=dy, nz=1;
    const l=Math.hypot(nx,ny,nz); nx/=l; ny/=l; nz/=l;
    const o=(py*S+px)*4;
    d[o]=(nx*0.5+0.5)*255; d[o+1]=(ny*0.5+0.5)*255; d[o+2]=(nz*0.5+0.5)*255; d[o+3]=255;
  }
  g.putImageData(img,0,0);
  const t=new THREE.CanvasTexture(cv);
  t.wrapS=t.wrapT=THREE.RepeatWrapping;
  t.anisotropy=Math.min(4, renderer.capabilities.getMaxAnisotropy());
  return t;
}
const detailNormalTex = makeDetailNormalTexture();

/* params per material instance: {detailScale, detailStr, glintScale, glintStr, fogSunMix} */
function enhanceTerrainMaterial(mat, params){
  const P = Object.assign({
    detailScale: 11.0, detailStr: 0.62, glintScale: 640.0, glintStr: 0.5, fogSunMix: 0.55,
  }, params||{});
  mat.userData.realismParams = P;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uDetailN    = { value: detailNormalTex };
    shader.uniforms.uDetailScale= { value: P.detailScale };
    shader.uniforms.uDetailStr  = { value: P.detailStr };
    shader.uniforms.uGlintScale = { value: P.glintScale };
    shader.uniforms.uGlintStr   = { value: P.glintStr };
    shader.uniforms.uFogSunCol  = { value: new THREE.Color(2.05, 1.24, 0.66) };
    shader.uniforms.uFogSunMix  = { value: P.fogSunMix };
    shader.uniforms.uSunDirW    = { value: new THREE.Vector3().copy(sunDir) };
    shader.uniforms.uGlintTime  = { value: 0 };
    mat.userData.realismShader = shader;

    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vRWPos;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvRWPos = (modelMatrix * vec4(transformed,1.0)).xyz;');

    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', [
        '#include <common>',
        'varying vec3 vRWPos;',
        'uniform sampler2D uDetailN;',
        'uniform float uDetailScale; uniform float uDetailStr;',
        'uniform float uGlintScale;  uniform float uGlintStr;',
        'uniform vec3  uFogSunCol;  uniform float uFogSunMix;',
        'uniform vec3  uSunDirW;    uniform float uGlintTime;',
        'float rlHash(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }',
        'vec3 rlWhiteout(vec3 a, vec3 b, float k){',
        '  a = a*2.0-1.0; b = b*2.0-1.0;',
        '  vec3 c = vec3(a.xy*k + b.xy, a.z);',
        '  float l = 1.0/sqrt(max(1e-5, dot(c.xy,c.xy) + c.z*c.z));',
        '  return normalize(c*l)*0.5+0.5;',
        '}'
      ].join('\n'))
      /* ---- 1) micro-detail normal ---- */
      .replace('#include <normal_fragment_maps>', [
        '#include <normal_fragment_maps>',
        '#ifdef USE_NORMALMAP_TANGENTSPACE',
        '  vec2 dUv = vec2(',
        '    vMapUv.x * 0.92977 - vMapUv.y * 0.36812,',
        '    vMapUv.x * 0.36812 + vMapUv.y * 0.92977);',        // rotated ~21.6deg
        '  dUv = dUv * uDetailScale + vec2(0.37, 0.71);',
        '  vec3 dN = texture2D(uDetailN, dUv).xyz;',
        '  vec3 baseN = texture2D(normalMap, vNormalMapUv).xyz;',
        '  vec3 rlMapN = rlWhiteout(baseN, dN, uDetailStr);',   // whiteout blend, tangent space
        '  rlMapN.xy *= normalScale;',
        '  normal = normalize(tbn * rlMapN);',                  // same TBN the base map uses
        '#endif'
      ].join('\n'))
      /* ---- 2) animated sand glitter ---- */
      .replace('#include <opaque_fragment>', [
        '{',
        '  vec2 gUv = vRWPos.xz * uGlintScale * 0.01;',
        '  vec2 cell = floor(gUv);',
        '  float rnd = rlHash(cell);',
        '  if(rnd > 0.90){',
        '    vec2 f = fract(gUv);',
        '    float ph = fract(rnd * 913.7 + uGlintTime * 0.35);',
        '    vec2 gp = vec2(fract(ph * 7.31), fract(ph * 13.77));',
        '    float dGl = length(f - gp);',
        '    float glint = smoothstep(0.16, 0.0, dGl);',
        '    glint *= 0.55 + 0.45 * sin(uGlintTime * 2.1 + ph * 40.0);',
        '    float sunSide = clamp(dot(normalize(vRWPos - cameraPosition), uSunDirW), 0.0, 1.0);',
        '    outgoingLight += vec3(1.0, 0.93, 0.78) * glint * uGlintStr * (0.25 + 0.75 * sunSide);',
        '  }',
        '}',
        '#include <opaque_fragment>'
      ].join('\n'))
      /* ---- 3) sun-tinted aerial fog ---- */
      .replace('#include <fog_fragment>', [
        '#ifdef USE_FOG',
        '  #ifdef FOG_EXP2',
        '    float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );',
        '  #else',
        '    float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );',
        '  #endif',
        '  vec3 rlViewW = normalize(vRWPos - cameraPosition);',
        '  float rlSunAmt = pow(max(dot(rlViewW, normalize(uSunDirW)), 0.0), 3.0);',
        '  vec3 rlFogCol = mix(fogColor, uFogSunCol, rlSunAmt * uFogSunMix);',
        '  gl_FragColor.rgb = mix( gl_FragColor.rgb, rlFogCol, fogFactor );',
        '#endif'
      ].join('\n'));
  };
  mat.customProgramCacheKey = () => 'terrain-realism-' + JSON.stringify(P);
}

const terrainMat = new THREE.MeshStandardMaterial({
  vertexColors:true, map:sandPBR.map,
  normalMap: GRAPHICS.sandNormalMap ? sandPBR.nmap : null,
  normalScale:new THREE.Vector2(0.9,0.9),
  roughnessMap: GRAPHICS.sandRoughnessMap ? sandPBR.rmap : null,
  roughness: GRAPHICS.sandRoughnessMap ? 1.0 : 0.95,
  metalness:0.0,
  envMap: GRAPHICS.envMap ? envTex : null, envMapIntensity:GRAPHICS.envMapIntensity
});
enhanceTerrainMaterial(terrainMat, { detailScale: 11.0, detailStr: HIGH_GFX_T ? 0.68 : 0.5, glintScale: 620.0, glintStr: HIGH_GFX_T ? 0.42 : 0.25, fogSunMix: 0.58 });
const chunks = new Map();
const _cn = new THREE.Vector3(), _cc = new THREE.Color();
/* Heights are sampled once on a grid with a 1-vertex border, and normals come from
   central differences on that grid: 1 terrainH per vertex instead of 5. Neighbouring
   chunks sample the same world positions, so the shading still matches across seams.
   This is what lets the Alpha reshape kilometres of sand without stale tiles. */
function fillChunkGeo(geo, mx, mz, lod){
  const L = LODS[lod || 0];
  const res = L.res, W = L.W, gridN = L.gridN, hgrid = L.hgrid, dgrid = L.dgrid;
  const posA = geo.attributes.position, norA = geo.attributes.normal;
  const colA = geo.attributes.color, uvA = geo.attributes.uv;
  const step = CHUNK/res, x0 = mx-CHUNK/2, z0 = mz-CHUNK/2;
  for(let j=0;j<W;j++){
    const wz = z0+(j-1)*step;
    for(let i=0;i<W;i++){
      const wx = x0+(i-1)*step, d = deformOffset(wx, wz);
      dgrid[j*W+i] = d; hgrid[j*W+i] = baseTerrainH(wx, wz) + d;
    }
  }
  for(let i=0;i<posA.count;i++){
    const wx = mx+posA.getX(i), wz = mz+posA.getZ(i);
    const gi = Math.round((wx-x0)/step)+1, gj = Math.round((wz-z0)/step)+1;
    const o = gj*W+gi;
    const h = hgrid[o];
    posA.setY(i, i<gridN ? h : h-SKIRT_D);
    _cn.set(-(hgrid[o+1]-hgrid[o-1]), 2*step, -(hgrid[o+W]-hgrid[o-W])).normalize();
    norA.setXYZ(i,_cn.x,_cn.y,_cn.z);
    const dfm = dgrid[o];
    _cc.copy(C_LOW).lerp(C_HIGH, sstep(h-dfm*0.8,1.5,23));
    if(dfm>2) _cc.lerp(C_HIGH, clamp(dfm/160,0,0.18));
    _cc.lerp(C_RED, clamp((noise2(wx*0.012+41, wz*0.012+17)-0.5)*0.8, 0, C_RED_MAX));
    _cc.multiplyScalar((1-(1-sstep(_cn.y,0.6,0.93))*0.25) * (1+(noise2(wx*0.6,wz*0.6)-0.5)*0.09));
    colA.setXYZ(i,_cc.r,_cc.g,_cc.b);
    uvA.setXY(i, wx*SAND_INV, wz*SAND_INV);
  }
  posA.needsUpdate = norA.needsUpdate = colA.needsUpdate = uvA.needsUpdate = true;
  geo.computeBoundingSphere();
}
/* Every chunk carries a SKIRT: a curtain hanging SKIRT_D m straight down from its edge.
   While the alpha reshapes the ground, a chunk can be re-meshed a frame or two before
   its neighbour; without skirts that left a crack you could see straight through. */
const SKIRT_D = 140;
function makeChunkGeo(res){
  const pl = new THREE.PlaneGeometry(CHUNK, CHUNK, res, res);
  pl.rotateX(-Math.PI/2);
  const W = res+1, gridN = W*W, per = [];
  for(let i=0;i<res;i++) per.push(i);
  for(let j=0;j<res;j++) per.push(j*W+res);
  for(let i=res;i>0;i--) per.push(res*W+i);
  for(let j=res;j>0;j--) per.push(j*W);
  const n = gridN + per.length;
  const pos = new Float32Array(n*3), uv = new Float32Array(n*2);
  pos.set(pl.attributes.position.array); uv.set(pl.attributes.uv.array);
  per.forEach((g,k) => {
    const o = gridN+k;
    pos[o*3] = pl.attributes.position.array[g*3]; pos[o*3+2] = pl.attributes.position.array[g*3+2];
    uv[o*2] = pl.attributes.uv.array[g*2]; uv[o*2+1] = pl.attributes.uv.array[g*2+1];
  });
  const idx = Array.from(pl.index.array);
  for(let k=0;k<per.length;k++){
    const a = per[k], b = per[(k+1)%per.length], c = gridN+k, d = gridN+(k+1)%per.length;
    idx.push(a,c,b, b,c,d,  a,b,c, b,d,c);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos,3));
  geo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(n*3),3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uv,2));
  geo.setIndex(idx);
  pl.dispose();
  return geo;
}
function buildChunk(cx, cz, lod){
  const L = LODS[lod || 0];
  const geo = makeChunkGeo(L.res);
  const mx = cx*CHUNK + CHUNK/2, mz = cz*CHUNK + CHUNK/2;
  geo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count*3), 3));
  fillChunkGeo(geo, mx, mz, lod || 0);
  const mesh = new THREE.Mesh(geo, terrainMat);
  mesh.position.set(mx,0,mz);
  mesh.receiveShadow = true;
  mesh.castShadow = !!GRAPHICS.shadowEnabled && lod === 0;
  mesh.matrixAutoUpdate = false; mesh.updateMatrix();
  mesh.userData.cx = cx; mesh.userData.cz = cz; mesh.userData.lod = lod || 0;
  scene.add(mesh);
  chunks.set(cx+','+cz, mesh);
}
function replaceChunk(cx, cz, lod){
  const k = cx+','+cz;
  const old = chunks.get(k);
  if(old){
    scene.remove(old);
    old.geometry.dispose();
    chunks.delete(k);
  }
  buildChunk(cx, cz, lod);
}
/* view radius grows while the alpha is around so the catastrophe is visible */
const VIEW_MAX=7;
let viewR=VIEW;
const OFFS = [];
for(let dx=-VIEW_MAX;dx<=VIEW_MAX;dx++) for(let dz=-VIEW_MAX;dz<=VIEW_MAX;dz++) OFFS.push([dx,dz]);
OFFS.sort((a,b)=>(Math.abs(a[0])+Math.abs(a[1]))-(Math.abs(b[0])+Math.abs(b[1])));
function updateChunks(px, pz, budget){
  const ccx=Math.floor(px/CHUNK), ccz=Math.floor(pz/CHUNK);
  let built=0;
  for(const [dx,dz] of OFFS){
    if(Math.abs(dx)>viewR || Math.abs(dz)>viewR) continue;
    const lod=terrainLodFor(dx,dz);
    const k=(ccx+dx)+','+(ccz+dz);
    const m=chunks.get(k);
    if(!m){
      if(built<budget){ buildChunk(ccx+dx, ccz+dz, lod); built++; }
    }else if(m.userData.lod!==lod && built<budget){
      replaceChunk(ccx+dx, ccz+dz, lod);
      built++;
    }
  }
  for(const [k,m] of chunks){
    if(Math.abs(m.userData.cx-ccx)>viewR+1 || Math.abs(m.userData.cz-ccz)>viewR+1){
      scene.remove(m); m.geometry.dispose(); chunks.delete(k);
    }
  }
}
for(let dx=-VIEW;dx<=VIEW;dx++) for(let dz=-VIEW;dz<=VIEW;dz++) buildChunk(dx,dz,terrainLodFor(dx,dz));
/* far desert floor: a coarse low-detail copy of the real terrain (craters included)
   that fills the horizon beyond the streamed chunks. It used to be a flat disc at
   y=-9, which showed up as a "plate" inside the Alpha's 120 m-deep craters.
   Where streamed chunks exist it sinks well below them so it can never poke through. */
const FAR_SEG=72, FAR_SIZE=7200, FAR_STEP=FAR_SIZE/FAR_SEG;      // 100 m cells
const farGeo=new THREE.PlaneGeometry(FAR_SIZE,FAR_SIZE,FAR_SEG,FAR_SEG); farGeo.rotateX(-Math.PI/2);
const farGround = new THREE.Mesh(farGeo,
  new THREE.MeshStandardMaterial({color: HIGH_GFX_T ? 0xcaa776 : 0xc39a62, roughness:1, metalness:0,
    map:sandPBR.map,
    normalMap: GRAPHICS.sandNormalMap ? sandPBR.nmap : null,
    normalScale:new THREE.Vector2(0.8,0.8),
    roughnessMap: GRAPHICS.sandRoughnessMap ? sandPBR.rmap : null,
    envMap: GRAPHICS.envMap ? envTex : null, envMapIntensity:GRAPHICS.envMapIntensity}));
if (farGround.material.map) enhanceTerrainMaterial(farGround.material, { detailScale: 5.0, detailStr: 0.4, glintScale: 180.0, glintStr: 0.12, fogSunMix: 0.62 });
farGround.renderOrder=-0.5; farGround.frustumCulled=false;
scene.add(farGround);
const FAR_LX=new Float32Array(farGeo.attributes.position.count), FAR_LZ=new Float32Array(farGeo.attributes.position.count);
for(let i=0;i<FAR_LX.length;i++){ FAR_LX[i]=farGeo.attributes.position.getX(i); FAR_LZ[i]=farGeo.attributes.position.getZ(i); }
/* same world-space UVs as the streamed chunks (the shared texture objects
   already carry their per-map repeat/rotation), so the horizon-floor sand
   matches the sand under the wheels */
{
  const uvA=farGeo.attributes.uv;
  for(let i=0;i<FAR_LX.length;i++) uvA.setXY(i, FAR_LX[i]*SAND_INV, FAR_LZ[i]*SAND_INV);
  uvA.needsUpdate=true;
}
const farState={cx:NaN, cz:NaN, nChunks:-1, t:0, deformSig:''};
const FAR_CR=VIEW_MAX+3, FAR_CW=FAR_CR*2+1, farHave=new Uint8Array(FAR_CW*FAR_CW);
function rebuildFarGround(){
  const cx=Math.round(player.pos.x/FAR_STEP)*FAR_STEP, cz=Math.round(player.pos.z/FAR_STEP)*FAR_STEP;
  farGround.position.set(cx,0,cz);
  /* which streamed chunks exist around the player (small grid, no string lookups per vertex) */
  const pcx=Math.floor(player.pos.x/CHUNK), pcz=Math.floor(player.pos.z/CHUNK);
  farHave.fill(0);
  for(const m of chunks.values()){
    const ix=m.userData.cx-pcx+FAR_CR, iz=m.userData.cz-pcz+FAR_CR;
    if(ix>=0&&iz>=0&&ix<FAR_CW&&iz<FAR_CW) farHave[iz*FAR_CW+ix]=1;
  }
  const has=(x,z)=>{
    const ix=Math.floor(x/CHUNK)-pcx+FAR_CR, iz=Math.floor(z/CHUNK)-pcz+FAR_CR;
    return ix>=0&&iz>=0&&ix<FAR_CW&&iz<FAR_CW&&farHave[iz*FAR_CW+ix]===1;
  };
  const pos=farGeo.attributes.position, S=FAR_STEP;
  for(let i=0;i<FAR_LX.length;i++){
    const wx=cx+FAR_LX[i], wz=cz+FAR_LZ[i];
    /* fully under loaded chunks (incl. every neighbouring cell) → hide deep below */
    const covered=has(wx,wz)&&has(wx-S,wz-S)&&has(wx+S,wz-S)&&has(wx-S,wz+S)&&has(wx+S,wz+S);
    pos.setY(i, terrainH(wx,wz)-(covered?70:12));
  }
  pos.needsUpdate=true;
  farGeo.computeVertexNormals();
}
function updateFarGround(dt){
  farState.t-=dt;
  const cx=Math.round(player.pos.x/FAR_STEP), cz=Math.round(player.pos.z/FAR_STEP);
  const moved=cx!==farState.cx||cz!==farState.cz;
  const sig=bigDeformers.length+':'+deformers.length;
  const changed=moved||chunks.size!==farState.nChunks||sig!==farState.deformSig;
  /* while big deformations animate (the Alpha), keep re-sampling a few times a second */
  farState.hot = alpha.active ? 6 : (farState.hot||0)-dt;   // keep sampling until craters settle
  if((changed||farState.hot>0) && farState.t<=0){
    farState.cx=cx; farState.cz=cz; farState.nChunks=chunks.size; farState.deformSig=sig;
    farState.t=farState.hot>0?0.25:0.4;
    rebuildFarGround();
  }
}

/* Re-sample chunks that overlap a deformation IN PLACE (no holes in the world).
   Work is queued and spread over frames so giant craters don't hitch. */
const chunkRefreshQ = new Set();
function invalidateChunksNear(x, z, radius){
  const cMinX = Math.floor((x-radius)/CHUNK), cMaxX = Math.floor((x+radius)/CHUNK);
  const cMinZ = Math.floor((z-radius)/CHUNK), cMaxZ = Math.floor((z+radius)/CHUNK);
  for(let cx=cMinX;cx<=cMaxX;cx++) for(let cz=cMinZ;cz<=cMaxZ;cz++){
    const k = cx+','+cz;
    if(chunks.has(k)) chunkRefreshQ.add(k);
  }
}
function refreshChunk(m){ fillChunkGeo(m.geometry, m.position.x, m.position.z, m.userData.lod || 0); }
function processChunkRefresh(budget, px, pz){
  if(chunkRefreshQ.size===0) return;
  /* closest chunks first, so the ground under the jeep is always current */
  const list=[];
  for(const k of chunkRefreshQ){
    const m=chunks.get(k);
    if(!m){ chunkRefreshQ.delete(k); continue; }
    list.push([(m.position.x-px)**2+(m.position.z-pz)**2, k, m]);
  }
  list.sort((a,b)=>a[0]-b[0]);
  /* `budget` chunks are guaranteed; while the alpha is out it keeps going up to a
     time cap, so huge swells land in one or two frames instead of rippling across */
  const t0=performance.now(), cap=alpha.active?7:2.5, maxN=alpha.active?60:budget*3;
  for(let i=0;i<list.length && i<maxN;i++){
    if(i>=budget && performance.now()-t0>cap) break;
    chunkRefreshQ.delete(list[i][1]); refreshChunk(list[i][2]);
  }
}
/* perm = an alpha scar: it never gets evicted, the desert keeps it for the rest of the run */
let bigPermN = 0;
function addBigDeform(x, z, radius, depth, perm){
  const df = {x, z, r: radius, r2: radius*radius, depth, perm:!!perm};
  bigDeformers.push(df); if(perm) bigPermN++;
  if(bigDeformers.length - bigPermN > BIG_DEFORM_MAX){
    const oi = bigDeformers.findIndex(q => !q.perm);
    const old = bigDeformers.splice(oi, 1)[0];
    invalidateChunksNear(old.x, old.z, old.r);
  }
  invalidateChunksNear(x, z, radius);
  return df;
}
function setBigDeformDepth(df, depth){
  df.depth = depth;
  invalidateChunksNear(df.x, df.z, df.r);
}
function addDeform(x, z, radius, depth){
  deformers.push({x, z, r: radius, r2: radius*radius, depth});
  if(deformers.length > DEFORM_MAX){
    const old = deformers.shift();
    invalidateChunksNear(old.x, old.z, old.r);
  }
  invalidateChunksNear(x, z, radius);
}

