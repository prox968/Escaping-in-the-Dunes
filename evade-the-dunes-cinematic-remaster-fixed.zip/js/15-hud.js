/* HUD updates: time, score, seismic feed, speed, hull */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- HUD ---------------- */
let hudT=0, seisAcc=0;
function updateHUD(rdt){
  if(gameState==='title') return;
  seisAcc+=rdt;
  if(seisAcc>0.032){
    seisAcc=0;
    const now=performance.now();
    const wig=0.62+0.38*Math.sin(now*0.025+Math.sin(now*0.004)*7);
    const hotWig=1+clamp(wormAttack,0,1)*0.16*Math.sin(now*0.08);
    /* environment: the jeep's rhythm and tools; worms are the separate trace */
    sNoise.push(Math.min(noiseLevel*0.82+digRumble*0.38+0.02,1.12));
    sWorm.push(Math.min(wormSeis*1.05*wig*hotWig,1.12));
    if(sNoise.length>130){ sNoise.shift(); sWorm.shift(); }
  }
  drawSeismo();
  hudT+=rdt;
  if(hudT>0.12){
    hudT=0;
    $('speed').textContent=Math.round(Math.abs(player.speedF)*3.6);
    $('statTime').textContent=fmt(elapsed);
    $('statScore').textContent=finalScore();
    $('statSpice').textContent=spice;
    const hf=$('hull');
    hf.querySelector('i').style.width=player.hp+'%';
    hf.classList.toggle('low',player.hp<35);
    const ab=$('attBar');
    ab.querySelector('i').style.width=(attention*100)+'%';
    ab.classList.toggle('warm',attention>0.38&&attention<=0.55);
    ab.classList.toggle('hot',attention>0.55);
    /* spice chain + overdrive readouts */
    const sc=$('spiceChain');
    if(player.boost>0 && player.boostChain>0){
      sc.textContent='SPICE CHAIN ×'+(player.boostChain+1)+' · +'+(player.boostChain===1?20:35)+' KM/H';
      sc.style.opacity=1;
    } else sc.style.opacity=0;
    const dslots=document.querySelectorAll('#diggerBox .slot');
    if(dslots.length===3){
      dslots[0].classList.toggle('on',diggerCount>=1);
      dslots[1].classList.toggle('on',diggerCount>=2);
      dslots[2].classList.toggle('on',expDiggerCount>=1);
    }
    $('odrive').style.opacity=(player.overdrive&&gameState==='play')?0.9:0;
    const slots=document.querySelectorAll('#thumpBox .slot');
    slots.forEach((s,i)=>s.classList.toggle('on',i<thumperCount));
    if(attention>0.45&&!updateHUD.huntFlag){ updateHUD.huntFlag=true; showMsg('SOMETHING STIRS BENEATH THE SAND',2.6); }
    if(attention<0.3) updateHUD.huntFlag=false;
  }
  const hp=player.hp;
  let cr=228, cg=225, cb=214;
  if(hp>=65){
    const t=clamp((100-hp)/35,0,1);
    cr=Math.round(lerp(228,205,t)); cg=Math.round(lerp(225,44,t)); cb=Math.round(lerp(214,18,t));
  }else if(hp>=30){
    const t=clamp((65-hp)/35,0,1);
    cr=Math.round(lerp(205,128,t)); cg=Math.round(lerp(44,14,t)); cb=Math.round(lerp(18,7,t));
  }else{
    const t=clamp((30-hp)/30,0,1);
    cr=Math.round(lerp(128,58,t)); cg=Math.round(lerp(14,4,t)); cb=Math.round(lerp(7,2,t));
  }
  dmgFlash=Math.max(0,dmgFlash-rdt*2.6);
  const dmgEl=$('dmgFlash');
  dmgEl.style.setProperty('--dmg-col','rgba('+cr+','+cg+','+cb+',0.88)');
  dmgEl.style.opacity=(dmgFlash*0.92).toFixed(3);

  const low=clamp((30-hp)/30,0,1);
  const pulseRate=lerp(0.85,2.8,low);
  const pulse=0.5+0.5*Math.sin(performance.now()*0.001*Math.PI*2*pulseRate);
  $('healthVignette').style.opacity=(low*(0.12+0.18*pulse)).toFixed(3);

  const airTarget=(typeof slowMoActive!=='undefined' && slowMoActive)?1:0;
  airVigSm+=(airTarget-airVigSm)*Math.min(1,rdt*(airTarget?7:10));
  $('airVignette').style.opacity=(airVigSm*0.78).toFixed(3);

  collectFlash=Math.max(0,collectFlash-rdt*2.2);
  $('collectVignette').style.opacity=(collectFlash*0.60).toFixed(3);
}
function flashCollectVignette(){ collectFlash=1; }
window.flashCollectVignette=flashCollectVignette;

