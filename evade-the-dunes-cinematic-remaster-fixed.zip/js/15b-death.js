/* ================================================================
   DEATH SEQUENCES
   ----------------------------------------------------------------
   When the player dies the cause decides HOW the jeep goes out:

     explosion | lesser | giant(air) | alphaBody | generic
         -> the jeep is wrecked. It burns: fire pours from its own
            hotspots (engine, fuel tank, cab), atomised fuel sprays out
            as oil that arcs, lands and ignites a puddle, and burning
            bodywork is thrown clear. Real fire — a white-hot core
            cooling to orange then red, lit by a flickering point light.

     giant | alphaMouth
         -> the jeep is swallowed: it is torn off the sand and dragged
            up into the maw, tumbling and shrinking away.

   die() / hitPlayer() live in 12-alpha-worm.js; this file only owns the
   visuals + the "how long until the overlay" timing. updateDeathFx(dt)
   is called once per frame from 16-main.js.
   ================================================================ */

let deathCause    = 'generic';   // what killed us (see kill sites)
let deathFrom     = null;        // world Vector3 the blow came from (for feedback)
let deathWatchPos = null;        // live Vector3 of the maw we are being dragged into
let deathOverlayMs= 1700;        // ms after deathReal before the overlay is shown
let deathFx       = null;        // active sequence state, or null
let deathSlow     = null;        // slow-motion curve driving timeScale during the wreck

/* a flickering fire light that lives at the wreck */
const fireLight = new THREE.PointLight(0xff7a2a, 0, 120, 2.0);
fireLight.position.set(0, -999, 0);
scene.add(fireLight);

/* ---- burning car pieces thrown clear of the wreck ----
   Real parts off the buggy: painted body panels, a tyre, dark pipework,
   a bright chrome scrap and plain metal chunks — sharing geometry, so the
   only per-piece cost is one cloned material for its cooling glow. */
const _debrisGeo = {
  panel: new THREE.BoxGeometry(0.92, 0.07, 0.72),                     // a torn body panel
  wheel: new THREE.CylinderGeometry(0.42, 0.42, 0.30, 14).rotateZ(Math.PI/2),   // a whole tyre
  pipe : new THREE.BoxGeometry(1.35, 0.10, 0.10),                     // exhaust / axle bar
  pipe2: new THREE.BoxGeometry(0.55, 0.14, 0.14),                     // manifold stub
  chunk: new THREE.BoxGeometry(0.34, 0.26, 0.50),                     // smashed bodywork
  chrome:new THREE.BoxGeometry(0.30, 0.18, 0.22)                      // bright scrap
};
const _debrisStyle = {
  panel: { color:0xb3371f, metalness:0.30, roughness:0.52 },  // the buggy's red paint
  wheel: { color:0x3f3b33, metalness:0.35, roughness:0.78 },  // tyre / rim
  pipe : { color:0x1b1814, metalness:0.50, roughness:0.55 },  // dark pipework
  pipe2: { color:0x655e50, metalness:0.30, roughness:0.70 },  // dull metal
  chunk: { color:0x474239, metalness:0.30, roughness:0.72 },  // wrecked chassis
  chrome:{ color:0xd6d9dc, metalness:0.90, roughness:0.28 }   // bright trim
};
const _debrisKinds = ['panel','panel','wheel','pipe','pipe2','chunk','chunk','chrome'];
const debris = [];
function clearDebris(){
  for(const d of debris){ scene.remove(d.m); d.m.material.dispose(); }
  debris.length = 0;
}
function spawnDebris(p, n){
  for(let k=0; k<n && debris.length<18; k++){
    const kind = _debrisKinds[(Math.random()*_debrisKinds.length)|0];
    const st   = _debrisStyle[kind];
    const m = new THREE.Mesh(_debrisGeo[kind], new THREE.MeshStandardMaterial({
      color:st.color, metalness:st.metalness, roughness:st.roughness,
      emissive:0xff5410, emissiveIntensity:0.7 }));
    m.scale.setScalar(0.75 + Math.random()*0.6);
    m.position.set(p.x+(Math.random()-0.5)*1.8, p.y+0.5+Math.random()*1.2, p.z+(Math.random()-0.5)*1.8);
    m.rotation.set(Math.random()*3, Math.random()*3, Math.random()*3);
    scene.add(m);
    const a=Math.random()*Math.PI*2, el=0.42+Math.random()*0.8, s=7+Math.random()*13;
    debris.push({ m, age:0, hot:1.7, trailAcc:0,
      vx:Math.cos(a)*Math.cos(el)*s, vy:Math.sin(el)*s+4.5, vz:Math.sin(a)*Math.cos(el)*s,
      rx:(Math.random()-0.5)*10, ry:(Math.random()-0.5)*10, rz:(Math.random()-0.5)*10 });
  }
}
function updateDebris(dt, rate){
  for(let i=debris.length-1; i>=0; i--){
    const d=debris[i], m=d.m; d.age+=dt;
    d.vy-=30*dt;
    m.position.x+=d.vx*dt; m.position.y+=d.vy*dt; m.position.z+=d.vz*dt;
    m.rotation.x+=d.rx*dt; m.rotation.y+=d.ry*dt; m.rotation.z+=d.rz*dt;
    const gy=terrainH(m.position.x, m.position.z)+0.13;
    if(m.position.y<gy){
      const impact = Math.abs(d.vy);
      m.position.y=gy; d.vy*=-0.26; d.vx*=0.58; d.vz*=0.58;
      d.rx*=0.5; d.ry*=0.5; d.rz*=0.5;
      /* kick up a little dust + smoke where it lands */
      if(impact>3.2){
        burstDust(m.position, 5, Math.min(9, impact*0.5));
        for(let q=0;q<3;q++)
          spawnP(m.position.x+(Math.random()-0.5)*0.6, gy+0.2, m.position.z+(Math.random()-0.5)*0.6,
            (Math.random()-0.5)*3, 1.2+Math.random()*2.5, (Math.random()-0.5)*3,
            0.7+Math.random()*0.7, 0.8+Math.random()*1.2, 0.28,0.26,0.24, 0.6, 0.9, PT_SMOKE);
        if(!d.puffed){
          d.puffed = true;
          spawnCloud(_v1.set(m.position.x, gy+0.28, m.position.z), 2.2+Math.random()*2, 1.0+Math.random()*1.0, 0.30, 0xcbb083);
        }
      }
      if(Math.abs(d.vy)<1.4) d.vy=0;
    }
    if(d.hot>0){
      d.hot-=dt;
      m.material.emissiveIntensity = 0.7*Math.max(0, d.hot/1.7);
      /* fire stays glued to the flying piece, with a trailing plume of smoke */
      if(Math.random()<rate*3.0){
        spawnP(m.position.x+(Math.random()-0.5)*0.5, m.position.y+0.28, m.position.z+(Math.random()-0.5)*0.5,
          (Math.random()-0.5)*2.4, 2.8+Math.random()*3.4, (Math.random()-0.5)*2.4,
          0.30+Math.random()*0.42, 0.8+Math.random()*1.2, 1.0,0.5,0.14, 0, 1.8, PT_FLAME);
      }
      if(Math.random()<rate*0.8){
        spawnP(m.position.x, m.position.y+0.3, m.position.z,
          (Math.random()-0.5)*3.4, 4.5+Math.random()*5, (Math.random()-0.5)*3.4,
          0.5+Math.random()*0.6, 0.35, 1.0,0.62,0.22, 0, 1.0, PT_SPARK);
      }
      d.trailAcc += dt;
      if(d.trailAcc>0.10){
        d.trailAcc=0;
        spawnP(m.position.x, m.position.y+0.25, m.position.z,
          (Math.random()-0.5)*1.2, 1.6+Math.random()*1.6, (Math.random()-0.5)*1.2,
          1.2+Math.random()*1.2, 1.3+Math.random()*1.4, 0.24,0.23,0.22, 0.5, 0.7, PT_SMOKE);
      }
    }
    if(d.age>12){ scene.remove(m); m.material.dispose(); debris.splice(i,1); }
  }
}

/* ----------------------------------------------------------------
   CAR SHATTER
   The intact jeep is one rigid body spinning on the spot — not a wreck.
   So on a burning death we take the REAL buggy apart: every mesh under
   carRoot is lifted out unchanged, clustered by where it sits in space,
   and each cluster is flung as a burning piece of the car. The pieces are
   the actual panels, cage, pipes and wheels you were driving — not props.
   Everything is remembered so resetGame() can rebuild the jeep intact.
   ---------------------------------------------------------------- */
const carChunks = [];             // { grp, age, hot, trailAcc, vx,vy,vz, rx,ry,rz }
let carShattered = false;

function shatterCar(center){
  if(carShattered) return;
  carRoot.updateMatrixWorld(true);
  const meshes = [];
  carRoot.traverse(o => { if(o.isMesh && o.visible) meshes.push(o); });
  if(meshes.length < 6) return;
  carShattered = true;

  const wp  = new THREE.Vector3();
  const box = new THREE.Box3();
  for(const m of meshes){ m.getWorldPosition(wp); box.expandByPoint(wp); }
  const min  = box.min.clone();
  const size = box.getSize(new THREE.Vector3());
  const nx=2, ny=2, nz=4;                      // ~16 spatial cells over the jeep

  const buckets = new Map();
  for(const m of meshes){
    m.getWorldPosition(wp);
    const cx = clamp(Math.floor((wp.x-min.x)/(size.x||1)*nx), 0, nx-1);
    const cy = clamp(Math.floor((wp.y-min.y)/(size.y||1)*ny), 0, ny-1);
    const cz = clamp(Math.floor((wp.z-min.z)/(size.z||1)*nz), 0, nz-1);
    const key = (cx*ny+cy)*nz + cz;
    let b = buckets.get(key); if(!b){ b=[]; buckets.set(key,b); }
    b.push(m);
  }

  const cen = new THREE.Vector3();
  for(const ms of buckets.values()){
    if(carChunks.length >= 18) break;
    cen.set(0,0,0);
    for(const m of ms){ m.getWorldPosition(wp); cen.add(wp); }
    cen.multiplyScalar(1/ms.length);

    /* remember where each piece lived so we can rebuild the jeep later */
    for(const m of ms){
      if(!m.userData._home)
        m.userData._home = { parent:m.parent, p:m.position.clone(), q:m.quaternion.clone(), s:m.scale.clone() };
    }

    const grp = new THREE.Group(); grp.position.copy(cen); scene.add(grp);
    for(const m of ms) grp.attach(m);          // reparent, preserving world pose

    let dx=cen.x-center.x, dy=Math.abs(cen.y-center.y)+0.45, dz=cen.z-center.z;
    const dl=Math.hypot(dx,dy,dz) || 1;
    const s = 8 + Math.random()*13;
    carChunks.push({ grp, age:0, hot:2.6, trailAcc:0,
      vx:dx/dl*s+(Math.random()-0.5)*3, vy:dy/dl*s+4.5, vz:dz/dl*s+(Math.random()-0.5)*3,
      rx:(Math.random()-0.5)*7, ry:(Math.random()-0.5)*7, rz:(Math.random()-0.5)*7 });
  }
  carShadowGroup.visible = false;              // no ghost car shadow under the flying wreck
}

function updateCarChunks(dt, rate){
  for(let i=carChunks.length-1; i>=0; i--){
    const b=carChunks[i], g=b.grp; b.age+=dt;
    b.vy -= 30*dt;
    g.position.x += b.vx*dt; g.position.y += b.vy*dt; g.position.z += b.vz*dt;
    g.rotation.x += b.rx*dt; g.rotation.y += b.ry*dt; g.rotation.z += b.rz*dt;
    const gy = terrainH(g.position.x, g.position.z) + 0.16;
    if(g.position.y < gy){
      const imp = Math.abs(b.vy);
      g.position.y = gy; b.vy*=-0.22; b.vx*=0.5; b.vz*=0.5; b.rx*=0.4; b.ry*=0.4; b.rz*=0.4;
      if(imp > 3){
        burstDust(g.position, 6, Math.min(11, imp*0.6));
        for(let q=0;q<2;q++)
          spawnP(g.position.x+(Math.random()-0.5)*0.8, gy+0.2, g.position.z+(Math.random()-0.5)*0.8,
            (Math.random()-0.5)*3, 1.2+Math.random()*2.4, (Math.random()-0.5)*3,
            0.7+Math.random()*0.7, 0.9+Math.random()*1.3, 0.26,0.24,0.22, 0.6, 0.9, PT_SMOKE);
        if(!b.puffed){
          b.puffed = true;
          spawnCloud(_v1.set(g.position.x, gy+0.35, g.position.z), 3.2+Math.random()*3, 1.3+Math.random()*1.4, 0.34, 0xcbb083);
        }
      }
      if(Math.abs(b.vy) < 1.6) b.vy = 0;
    }
    if(b.hot > 0){
      b.hot -= dt;
      const hx=g.position.x, hy=g.position.y, hz=g.position.z;
      if(Math.random() < rate*5){
        spawnP(hx+(Math.random()-0.5)*1.0, hy+0.3, hz+(Math.random()-0.5)*1.0,
          (Math.random()-0.5)*2.4, 2.8+Math.random()*3.6, (Math.random()-0.5)*2.4,
          0.30+Math.random()*0.45, 0.9+Math.random()*1.4, 1.0,0.5,0.14, 0, 1.8, PT_FLAME);
      }
      if(Math.random() < rate*1.2){
        spawnP(hx, hy+0.35, hz,
          (Math.random()-0.5)*3.6, 4.5+Math.random()*5, (Math.random()-0.5)*3.6,
          0.5+Math.random()*0.6, 0.35, 1.0,0.62,0.22, 0, 1.0, PT_SPARK);
      }
      b.trailAcc += dt;
      if(b.trailAcc > 0.11){
        b.trailAcc = 0;
        spawnP(hx, hy+0.3, hz,
          (Math.random()-0.5)*1.3, 1.8+Math.random()*1.8, (Math.random()-0.5)*1.3,
          1.3+Math.random()*1.4, 1.5+Math.random()*1.6, 0.22,0.21,0.20, 0.5, 0.7, PT_SMOKE);
      }
    }
  }
}

function restoreCar(){
  if(!carShattered) return;
  for(const b of carChunks){
    for(const m of b.grp.children.slice()){
      const h = m.userData._home;
      if(h && h.parent){ h.parent.add(m); m.position.copy(h.p); m.quaternion.copy(h.q); m.scale.copy(h.s); }
    }
    scene.remove(b.grp);
  }
  carChunks.length = 0; carShattered = false;
  carShadowGroup.visible = true;
}

/* vehicle hotspots in carBody space: engine block, fuel tank, cab, flanks */
const _HOTSPOTS = [[0,0.62,1.30],[0,0.52,-1.18],[0,0.96,-0.12],[0.62,0.55,0.42],[-0.62,0.55,0.42]];
const _dTmp = new THREE.Vector3();

/* ----------------------------------------------------------------
   BURN: the jeep explodes and becomes a fire
   ---------------------------------------------------------------- */
function startBurnDeath(){
  deathOverlayMs = 5000;                            // long enough to watch the wreck come apart
  timeScale = 1;
  /* slow-motion curve: snap down, hold while the pieces fly, ease back up as
     they settle and the dust drifts off */
  deathSlow = { t:0, down:0.30, hold:1.6, recover:2.4, lo:0.20 };
  deathSpin.set((Math.random()-0.5)*4,(Math.random()-0.5)*6,(Math.random()-0.5)*4);
  const p = player.pos, gy = terrainH(p.x, p.z);

  /* the blast */
  boomSfx(0, p);                                   // Explosion.wav at the wreck
  fireLight.position.set(p.x, p.y+1.7, p.z);
  fireLight.intensity = 46;

  /* immediate fireball — hot core out through orange */
  for(let k=0;k<80;k++){
    const a=Math.random()*Math.PI*2, el=Math.random()*0.8, s=3+Math.random()*15;
    spawnP(p.x+(Math.random()-0.5)*1.4, p.y+0.5+Math.random()*1.4, p.z+(Math.random()-0.5)*1.4,
      Math.cos(a)*Math.cos(el)*s, Math.sin(el)*s+3, Math.sin(a)*Math.cos(el)*s,
      0.35+Math.random()*0.6, 1.1+Math.random()*2.2, 1.0,0.6,0.20, 0, 1.7, PT_FLAME);
  }
  for(let k=0;k<30;k++){                            // embers thrown up
    const a=Math.random()*Math.PI*2, s=6+Math.random()*16;
    spawnP(p.x, p.y+0.8, p.z, Math.cos(a)*s, 6+Math.random()*10, Math.sin(a)*s,
      0.6+Math.random()*0.8, 0.35+Math.random()*0.3, 1.0,0.7,0.3, 0, 0.9, PT_SPARK);
  }
  /* atomised fuel: sprays out, arcs, lands and lights a puddle */
  for(let k=0;k<34;k++){
    const a=Math.random()*Math.PI*2, el=Math.random()*0.7, s=4+Math.random()*11;
    spawnP(p.x+(Math.random()-0.5)*0.8, p.y+0.55, p.z+(Math.random()-0.5)*0.8,
      Math.cos(a)*Math.cos(el)*s, Math.sin(el)*s+2.4, Math.sin(a)*Math.cos(el)*s,
      0.55+Math.random()*0.7, 0.5+Math.random()*0.6, 0.16,0.13,0.11, 0, 0.15, PT_OIL);
  }
  shatterCar(p);                                    // the actual jeep breaks into real pieces
  spawnDebris(p, 8);                                // plus a few extra shredded scraps

  /* ground disturbance: a small crater + rolling dust, a modest shockwave */
  addDeform(p.x, p.z, 7.5, 1.9);
  spawnGroundShockwave(p.x, p.z, 16, 0.9);
  burstDust(p, 90, 13);
  spawnRing(p, 20, 0.9);
  for(let k=0;k<5;k++)                              // orange fireball glow
    spawnCloud(_v1.set(p.x+(Math.random()-0.5)*3, gy+1.2+Math.random()*2, p.z+(Math.random()-0.5)*3),
      4+Math.random()*4, 0.55+Math.random()*0.4, 0.60, 0xff6a1e);
  spawnCloudCluster(_v1.set(p.x, gy+2, p.z), 12, 4.5, 4, 9, 3, 6, 0.5, true);   // dark smoke column
  spawnCloudCluster(_v1.set(p.x, gy+0.5, p.z), 8, 6.5, 4, 8, 2.5, 5, 0.42, false); // low rolling dust
  shake = Math.max(shake, 1.4);

  deathFx = { type:'burn', t:0, dur:8.0, flameAcc:0, smokeAcc:0, emberAcc:0, oilAcc:0 };
}

function updateBurn(dt){
  const fx=deathFx; fx.t+=dt; fx.clock=(fx.clock||0)+dt;
  const rate = nearCamScale(player.pos.x, player.pos.z);   // don't over-fill a lens sitting in it

  if(carRoot.visible) carRoot.updateMatrixWorld(true);

  /* fire + smoke pouring off the wreck's own hotspots, moving with it */
  if(fx.t < fx.dur){
    fx.flameAcc += dt * 34 * rate;
    while(fx.flameAcc>=1){
      fx.flameAcc-=1;
      const h=_HOTSPOTS[(Math.random()*_HOTSPOTS.length)|0];
      _dTmp.set(h[0],h[1],h[2]); carBody.localToWorld(_dTmp);
      spawnP(_dTmp.x+(Math.random()-0.5)*0.5, _dTmp.y+Math.random()*0.35, _dTmp.z+(Math.random()-0.5)*0.5,
        (Math.random()-0.5)*2.6, 2.6+Math.random()*4.6, (Math.random()-0.5)*2.6,
        0.32+Math.random()*0.55, 1.1+Math.random()*1.9, 1.0,0.55,0.16, 0, 1.6, PT_FLAME);
    }
    fx.smokeAcc += dt * 11 * rate;
    while(fx.smokeAcc>=1){
      fx.smokeAcc-=1;
      const h=_HOTSPOTS[(Math.random()*_HOTSPOTS.length)|0];
      _dTmp.set(h[0],h[1]+0.5,h[2]); carBody.localToWorld(_dTmp);
      spawnP(_dTmp.x, _dTmp.y, _dTmp.z,
        (Math.random()-0.5)*1.4, 2.4+Math.random()*2.6, (Math.random()-0.5)*1.4,
        1.9+Math.random()*1.8, 2.4+Math.random()*3.0, 0.16,0.15,0.15, 0.4, 0.55, PT_SMOKE);
    }
    fx.emberAcc += dt * 22 * rate;
    while(fx.emberAcc>=1){
      fx.emberAcc-=1;
      const h=_HOTSPOTS[(Math.random()*_HOTSPOTS.length)|0];
      _dTmp.set(h[0],h[1]+0.3,h[2]); carBody.localToWorld(_dTmp);
      spawnP(_dTmp.x, _dTmp.y, _dTmp.z,
        (Math.random()-0.5)*6, 5+Math.random()*7, (Math.random()-0.5)*6,
        0.7+Math.random()*0.9, 0.3+Math.random()*0.25, 1.0,0.72,0.3, 0, 0.7, PT_SPARK);
    }
  } else {
    /* burnt out: only a thin smoke column still rises */
    fx.smokeAcc += dt * 4;
    if(fx.smokeAcc>=1){
      fx.smokeAcc-=1;
      const gy=terrainH(player.pos.x, player.pos.z);
      spawnP(player.pos.x+(Math.random()-0.5)*1.5, gy+2.0, player.pos.z+(Math.random()-0.5)*1.5,
        (Math.random()-0.5)*1.2, 2+Math.random()*2, (Math.random()-0.5)*1.2,
        2.4+Math.random()*2.0, 2.6+Math.random()*2.4, 0.17,0.16,0.16, 0.35, 0.5, PT_SMOKE);
    }
  }

  /* flickering light: full through the blaze, then dims out over the last half */
  const fk = clamp((1 - fx.t/fx.dur)/0.5, 0, 1);
  const t  = fx.clock;
  const flick = 0.62 + 0.38*Math.abs(Math.sin(t*11.0) * Math.cos(t*4.3+1.7));
  fireLight.position.set(player.pos.x, player.pos.y+1.7, player.pos.z);
  fireLight.intensity = 46 * flick * fk;
}

/* the maw to be dragged into: an explicit watch point, else where the blow came from */
function swallowMaw(){
  if(deathWatchPos && deathWatchPos.isVector3) return deathWatchPos;
  if(deathFrom     && deathFrom.isVector3)     return deathFrom;
  return player.pos;
}

/* ----------------------------------------------------------------
   SWALLOW: torn off the sand and dragged into the maw
   ---------------------------------------------------------------- */
function startSwallowDeath(){
  deathOverlayMs = 5200;
  player.eaten = true;
  timeScale = 0.5;
  deathSpin.set(0,0,0);
  roar(0, true);
  const maw = swallowMaw();
  const d = Math.hypot(maw.x-player.pos.x, maw.z-player.pos.z);
  deathFx = { type:'swallow', t:0, dur: clamp(d/95, 0.7, 1.9),
              startPos: player.pos.clone(), done:false };
  burstDust(player.pos, 34, 9);
  spawnRing(player.pos, 16, 0.7);
  shake = Math.max(shake, 1.1);
}

function updateSwallow(dt){
  const fx=deathFx; fx.t+=dt;
  const maw = swallowMaw();
  const k  = clamp(fx.t/fx.dur, 0, 1);
  const e  = k*k*(3-2*k);                    // ease in-out

  _dTmp.copy(fx.startPos).lerp(maw, e);
  carRoot.position.copy(_dTmp);
  carRoot.scale.setScalar(Math.max(0.03, 1 - 0.97*e));
  carBody.rotation.y += 9*dt;
  carBody.rotation.x += 5*dt;

  /* sand torn off the ground as it is ripped free, then a trail upward */
  if(Math.random() < 0.7) burstDust(_dTmp, 3, 6);
  if(Math.random() < 0.5){
    spawnP(_dTmp.x+(Math.random()-0.5)*1.2, _dTmp.y, _dTmp.z+(Math.random()-0.5)*1.2,
      (Math.random()-0.5)*2, 1.5+Math.random()*3, (Math.random()-0.5)*2,
      0.6+Math.random()*0.6, 0.5+Math.random()*0.6, 0.85,0.74,0.55, 0.2, 0.9, PT_SMOKE);
  }

  if(k>=1 && !fx.done){
    fx.done = true;
    carRoot.visible = false; carShadowGroup.visible = false;
    spawnCloudCluster(_v1.set(maw.x, maw.y, maw.z), 10, 6, 5, 9, 2, 3.5, 0.5, true);
    shake = Math.max(shake, 0.6);
  }
}

/* ----------------------------------------------------------------
   dispatcher + per-frame update + reset
   ---------------------------------------------------------------- */
function updateDeathSlow(rdt){
  if(!deathSlow) return;
  const s = deathSlow; s.t += rdt;
  if     (s.t < s.down)                 timeScale = lerp(1, s.lo, s.t/s.down);
  else if(s.t < s.down+s.hold)          timeScale = s.lo;
  else if(s.t < s.down+s.hold+s.recover) timeScale = lerp(s.lo, 1, (s.t-s.down-s.hold)/s.recover);
  else { timeScale = 1; deathSlow = null; }
}

function startDeathSequence(){
  if(deathCause==='giant' || deathCause==='alphaMouth') startSwallowDeath();
  else                                                   startBurnDeath();
}

function updateDeathFx(dt, rdt){
  updateDeathSlow(rdt);
  const rate = nearCamScale(player.pos.x, player.pos.z);
  if(deathFx){
    if(deathFx.type==='burn') updateBurn(dt);
    else                      updateSwallow(dt);
    updateDebris(dt, rate);
  } else {
    updateDebris(dt, 0);
    if(fireLight.intensity>0) fireLight.intensity = Math.max(0, fireLight.intensity - dt*30);
  }
  updateCarChunks(dt, (deathFx && deathFx.type==='burn') ? rate : 0);
}

function resetDeathFx(){
  deathFx = null; deathCause = 'generic'; deathFrom = null; deathWatchPos = null;
  deathOverlayMs = 1700; deathSlow = null;
  restoreCar();
  clearDebris();
  fireLight.intensity = 0; fireLight.position.set(0, -999, 0);
  carRoot.scale.setScalar(1);
}
