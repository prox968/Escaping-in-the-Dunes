/* ==================================================================
   19-ui-particles.js — DOM-level sand particle effects for UI feedback
   ------------------------------------------------------------------
   A single full-viewport canvas (#uiFx) sits above every overlay and
   the HUD. It is pointer-events:none so it never blocks a click, but
   the document listens for click / pointerdown / pointermove / input
   events on UI buttons, tabs and sliders, and spawns short-lived sand
   particles at the event location.

   Three effect flavours:
     • puff    — quick radial burst of ~14 grains, used for button clicks
     • trickle — continuous fine stream while a slider is being dragged
     • scatter — sideways spray used on tab switches

   Tunable in the Settings panel (UI_PARTICLE_SETTINGS in 00-graphics.js):
     enabled, intensity, onButtons, onSliders, onTabs

   Particles are pure JS (no THREE) so they keep working when the WebGL
   canvas is hidden (e.g. on the title screen before the renderer boots).
   ================================================================== */

(function(){
  /* ---- canvas setup ---- */
  let canvas, ctx, W=0, H=0, DPR=1;
  function _makeCanvas(){
    canvas = document.createElement('canvas');
    canvas.id = 'uiFx';
    /* z-index 100 = above EVERYTHING: HUD (#hud z=20), overlays
       (.overlay z=40), settings panel (#setPanel z=46), pause menu
       (z=40, same as overlays), and cinematic bars (z=30). This way
       sand puffs render on top of every menu — title, pause, settings,
       game-over — not just the main menu. pointer-events:none keeps
       it from ever blocking a click. */
    canvas.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:100;';
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    _resize();
    addEventListener('resize', _resize);
  }
  function _resize(){
    DPR = Math.min(devicePixelRatio || 1, 2);
    W = innerWidth; H = innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }

  /* ---- particle pool ----
     Each particle: {x,y,vx,vy,life,maxLife,size,rot,vr,grav,drag,kind,seed}
     kind: 0=grain (small soft sand speck), 1=puff (soft lit puff),
           2=spark (faint bright glint, used on slider drag).
     `seed` is a random int per-particle used to pick which sprite variant
     a grain uses (sand vs dark grit) — kept stable across the particle's
     life so it doesn't flicker.
     The pool is a flat array; particles delete by swap+pop. */
  const POOL_MAX = 600;
  const pool = [];
  function _spawn(x, y, vx, vy, life, size, kind, hue){
    if(pool.length >= POOL_MAX) return;
    const maxLife = life;
    pool.push({
      x, y, vx, vy,
      life, maxLife,
      size,
      rot: Math.random()*Math.PI*2,
      vr: (Math.random()-0.5)*0.4,
      seed: (Math.random()*1000)|0,
      grav: kind===2 ? 0.04 : 0.10 + Math.random()*0.06,
      drag: 0.93 + Math.random()*0.04,
      kind
    });
  }

  /* ---- pre-rendered sprites for speed ----
     All sprites are SOFT ROUND textures — no square particles.
       puff   — large soft tan blob (the main "sand kicked up" look)
       grain  — small soft round sand speck (warm tan, with a brighter
                core and a soft edge — reads as a grain of sand, not a
                square pixel)
       spark  — bright glint (used sparingly on slider drag)
       dark   — small dark grit speck (rare, for visual texture) */
  let puffSprite, grainSprite, sparkSprite, darkSprite;
  function _makeSprites(){
    /* puff: 64² soft tan blob with internal sand specks */
    const ps = 64;
    const pc = document.createElement('canvas');
    pc.width = pc.height = ps;
    const pg = pc.getContext('2d');
    const c = ps/2;
    const gr = pg.createRadialGradient(c,c,0,c,c,c);
    gr.addColorStop(0,   'rgba(244,225,184,0.85)');
    gr.addColorStop(0.35,'rgba(220,190,140,0.55)');
    gr.addColorStop(0.75,'rgba(170,135,80,0.18)');
    gr.addColorStop(1,   'rgba(120,90,50,0)');
    pg.fillStyle = gr;
    pg.fillRect(0,0,ps,ps);
    /* a few darker specks inside the puff so it reads as sand not fog */
    pg.globalCompositeOperation = 'source-over';
    for(let i=0;i<10;i++){
      const a = Math.random()*Math.PI*2, r = Math.random()*c*0.6;
      const sx = c+Math.cos(a)*r, sy = c+Math.sin(a)*r;
      const sr = 1.4;
      const sgr = pg.createRadialGradient(sx, sy, 0, sx, sy, sr*1.4);
      sgr.addColorStop(0, `rgba(80,55,30,${0.35 + Math.random()*0.25})`);
      sgr.addColorStop(1, 'rgba(80,55,30,0)');
      pg.fillStyle = sgr;
      pg.beginPath(); pg.arc(sx, sy, sr*1.4, 0, Math.PI*2); pg.fill();
    }
    puffSprite = pc;

    /* grain: 16² soft round sand speck (NO square — fully circular) */
    const gs = 16;
    const gc = document.createElement('canvas');
    gc.width = gc.height = gs;
    const gg = gc.getContext('2d');
    const gc1 = gs/2;
    /* base: bright warm core with soft falloff */
    const ggr = gg.createRadialGradient(gc1, gc1, 0, gc1, gc1, gc1);
    ggr.addColorStop(0,   'rgba(244,225,184,1.0)');
    ggr.addColorStop(0.4, 'rgba(220,190,140,0.85)');
    ggr.addColorStop(0.75,'rgba(170,135,80,0.35)');
    ggr.addColorStop(1,   'rgba(120,90,50,0)');
    gg.fillStyle = ggr;
    gg.fillRect(0,0,gs,gs);
    /* a tiny brighter highlight off-centre for a "lit from above" look */
    const hl = gg.createRadialGradient(gc1-1.2, gc1-1.5, 0, gc1-1.2, gc1-1.5, 2.5);
    hl.addColorStop(0, 'rgba(255,245,210,0.95)');
    hl.addColorStop(1, 'rgba(255,245,210,0)');
    gg.fillStyle = hl;
    gg.fillRect(0,0,gs,gs);
    grainSprite = gc;

    /* dark grit: 12² small dark round speck (rare, for visual texture) */
    const ds = 12;
    const dc = document.createElement('canvas');
    dc.width = dc.height = ds;
    const dg = dc.getContext('2d');
    const dc1 = ds/2;
    const dgr = dg.createRadialGradient(dc1, dc1, 0, dc1, dc1, dc1);
    dgr.addColorStop(0,   'rgba(80,55,30,0.85)');
    dgr.addColorStop(0.5, 'rgba(60,42,22,0.55)');
    dgr.addColorStop(1,   'rgba(40,28,15,0)');
    dg.fillStyle = dgr;
    dg.fillRect(0,0,ds,ds);
    darkSprite = dc;

    /* spark: 16² bright glint */
    const ss = 16;
    const sc = document.createElement('canvas');
    sc.width = sc.height = ss;
    const sg = sc.getContext('2d');
    const sgr = sg.createRadialGradient(ss/2,ss/2,0,ss/2,ss/2,ss/2);
    sgr.addColorStop(0, 'rgba(255,240,200,0.95)');
    sgr.addColorStop(0.4, 'rgba(255,210,140,0.45)');
    sgr.addColorStop(1, 'rgba(255,180,80,0)');
    sg.fillStyle = sgr;
    sg.fillRect(0,0,ss,ss);
    sparkSprite = sc;
  }

  /* ---- particle update + draw ---- */
  function _step(dt){
    /* dt is in seconds; we'll use a simple semi-implicit Euler */
    for(let i=pool.length-1; i>=0; i--){
      const p = pool[i];
      p.life -= dt;
      if(p.life <= 0){ pool[i] = pool[pool.length-1]; pool.pop(); continue; }
      p.vy += p.grav;
      p.vx *= p.drag;
      p.vy *= p.drag;
      p.x += p.vx * dt * 60;
      p.y += p.vy * dt * 60;
      p.rot += p.vr;
    }
  }
  function _draw(){
    ctx.clearRect(0,0,W,H);
    if(pool.length === 0) return;
    ctx.save();
    for(let i=0;i<pool.length;i++){
      const p = pool[i];
      const t = p.life / p.maxLife;
      /* fade in fast, hold, fade out at the end — no harsh cuts */
      let alpha;
      if(t > 0.75)      alpha = 1;
      else if(t > 0.25) alpha = 1;
      else              alpha = t / 0.25;
      const a = (p.kind===2) ? alpha * 0.95 : alpha * 0.85;
      if(p.kind === 1){
        /* puff: soft round blob, scales up as it fades */
        const s = p.size * (1.2 - t*0.4);
        ctx.globalAlpha = a;
        ctx.drawImage(puffSprite, p.x - s/2, p.y - s/2, s, s);
      }else if(p.kind === 2){
        /* spark: bright glint, shrinks as it fades */
        const s = p.size * t;
        ctx.globalAlpha = a;
        ctx.drawImage(sparkSprite, p.x - s/2, p.y - s/2, s, s);
      }else{
        /* grain: soft round sand speck, with a chance to be darker grit.
           Both are circular sprites — never a square. */
        const s = p.size;
        ctx.globalAlpha = a;
        /* 1 in 7 grains is a dark grit speck for visual texture */
        const sprite = (p.seed % 7 === 0) ? darkSprite : grainSprite;
        ctx.drawImage(sprite, p.x - s/2, p.y - s/2, s, s);
      }
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  /* ---- public effect entry points ----
     Each respects UI_PARTICLE_SETTINGS, so the Settings panel can mute
     individual flavours. `intensity` scales the count and size. */
  function _puff(x, y, count, opts){
    if(!UI_PARTICLE_SETTINGS.enabled || !UI_PARTICLE_SETTINGS.onButtons) return;
    opts = opts || {};
    const inten = UI_PARTICLE_SETTINGS.intensity || 1;
    const n = Math.max(2, Math.round((count||14) * inten));
    for(let i=0;i<n;i++){
      const a = Math.random()*Math.PI*2;
      const sp = 1.2 + Math.random()*2.6;
      _spawn(x, y, Math.cos(a)*sp, Math.sin(a)*sp - 0.8,
        0.45 + Math.random()*0.35, 6 + Math.random()*8, 1);
    }
    /* a couple of grains too, for grit */
    const gn = Math.max(1, Math.round(4 * inten));
    for(let i=0;i<gn;i++){
      const a = Math.random()*Math.PI*2;
      const sp = 2 + Math.random()*3.5;
      _spawn(x, y, Math.cos(a)*sp, Math.sin(a)*sp - 1.2,
        0.55 + Math.random()*0.35, 3 + Math.random()*2.5, 0);
    }
  }
  function _trickle(x, y, dir){
    if(!UI_PARTICLE_SETTINGS.enabled || !UI_PARTICLE_SETTINGS.onSliders) return;
    const inten = UI_PARTICLE_SETTINGS.intensity || 1;
    const n = Math.max(1, Math.round(2 * inten));
    for(let i=0;i<n;i++){
      const a = (dir||0) + (Math.random()-0.5)*0.7;
      const sp = 0.5 + Math.random()*1.2;
      _spawn(x + (Math.random()-0.5)*4, y + (Math.random()-0.5)*2,
        Math.cos(a)*sp, Math.sin(a)*sp - 0.3,
        0.35 + Math.random()*0.25, 2 + Math.random()*2, 0);
    }
    /* a faint spark too so dragging a slider feels responsive */
    if(Math.random() < 0.25 * inten){
      _spawn(x, y, 0, -0.5, 0.30, 8 + Math.random()*4, 2);
    }
  }
  function _scatter(x, y, dirX){
    if(!UI_PARTICLE_SETTINGS.enabled || !UI_PARTICLE_SETTINGS.onTabs) return;
    const inten = UI_PARTICLE_SETTINGS.intensity || 1;
    const n = Math.max(3, Math.round(10 * inten));
    for(let i=0;i<n;i++){
      const a = (dirX>0 ? 0 : Math.PI) + (Math.random()-0.5)*1.4;
      const sp = 1.5 + Math.random()*2.8;
      _spawn(x, y, Math.cos(a)*sp, Math.sin(a)*sp - 0.5,
        0.40 + Math.random()*0.30, 4 + Math.random()*4, 0);
    }
  }

  /* ---- wire DOM events ----
     Listens at the document level (delegation) so dynamically-inserted
     buttons still get particles. Works in EVERY menu — title, pause,
     settings, game-over — because the document catches the click no
     matter which overlay is on top. */
  let _lastTrickleTime = 0;
  function _wireEvents(){
    /* click + key-activation on any button, .set-toggle, .set-tab,
       .set-apply, .set-preset, .pause-btn, .drive-btn, .title-btn,
       .gfx-btns button, or anything tagged [data-puff] */
    function _isInteractive(el){
      if(!el) return false;
      if(el.tagName === 'BUTTON') return true;
      if(el.classList && el.classList.contains('set-toggle')) return true;
      if(el.classList && el.classList.contains('set-tab')) return true;
      if(el.classList && el.classList.contains('set-apply')) return true;
      if(el.classList && el.classList.contains('set-preset')) return true;
      if(el.hasAttribute && el.hasAttribute('data-puff')) return true;
      return false;
    }
    const SEL = 'button, .set-toggle, .set-tab, .set-apply, .set-preset, .pause-btn, .drive-btn, .title-btn, [data-puff], #startBtn, #againBtn, #pauseResume, #pauseSettings, #pauseEnd';
    addEventListener('pointerdown', e=>{
      if(!UI_PARTICLE_SETTINGS.enabled || !UI_PARTICLE_SETTINGS.onButtons) return;
      const el = e.target.closest ? e.target.closest(SEL) : null;
      if(el && _isInteractive(el)){
        _puff(e.clientX, e.clientY, 14);
      }
    }, {passive:true});
    addEventListener('keydown', e=>{
      if(!UI_PARTICLE_SETTINGS.enabled || !UI_PARTICLE_SETTINGS.onButtons) return;
      if(e.code !== 'Enter' && e.code !== 'Space') return;
      const el = document.activeElement;
      if(el && _isInteractive(el)){
        const r = el.getBoundingClientRect();
        _puff(r.left + r.width/2, r.top + r.height/2, 14);
      }
    }, {passive:true});

    /* slider drag: trickle while pointer is down + moving over an
       input[type=range] OR a .set-slider. We track the drag state and
       the most recent pointer position. */
    let _dragging = null;     // {el, lastX, lastY, lastT}
    addEventListener('pointerdown', e=>{
      if(!UI_PARTICLE_SETTINGS.enabled) return;
      const el = e.target.closest ? e.target.closest('input[type=range], .set-slider') : null;
      if(el){
        _dragging = {el, lastX:e.clientX, lastY:e.clientY, lastT:performance.now()};
      }
    }, {passive:true});
    addEventListener('pointermove', e=>{
      if(!_dragging) return;
      const now = performance.now();
      if(now - _dragging.lastT < 16) return;   // throttle to ~60Hz
      const r = _dragging.el.getBoundingClientRect();
      /* trickle on the thumb (we approximate the thumb position from
         the value + slider width) */
      let frac = 0.5;
      if(_dragging.el.tagName === 'INPUT'){
        const min = +_dragging.el.min || 0;
        const max = +_dragging.el.max || 1;
        const v = +_dragging.el.value || 0;
        frac = (v - min) / Math.max(1e-6, max - min);
      }
      const tx = r.left + r.width * frac;
      const ty = r.top + r.height/2;
      const dx = e.clientX - _dragging.lastX;
      _trickle(tx, ty, dx > 0 ? 0 : Math.PI);
      _dragging.lastX = e.clientX; _dragging.lastY = e.clientY; _dragging.lastT = now;
    }, {passive:true});
    addEventListener('pointerup', ()=>{ _dragging = null; }, {passive:true});
    addEventListener('blur',      ()=>{ _dragging = null; }, {passive:true});

    /* tab switch: scatter when a .set-tab becomes .active */
    /* wired inside 18-settings-panel.js by calling uiParticles.scatter() */
  }

  /* ---- main animation loop ---- */
  let _last = performance.now();
  function _loop(){
    requestAnimationFrame(_loop);
    const now = performance.now();
    const dt = Math.min((now - _last)/1000, 0.05);
    _last = now;
    _step(dt);
    _draw();
  }

  /* ---- boot ---- */
  function boot(){
    _makeCanvas();
    _makeSprites();
    _wireEvents();
    _loop();
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  }else{
    boot();
  }

  /* expose for 18-settings-panel.js + 21-drive-wheel.js */
  window.uiParticles = {
    puff:    _puff,
    trickle: _trickle,
    scatter: _scatter,
    _spawn,  /* low-level spawn, used by the drive-wheel dust trail */
    pool,    /* for debugging */
  };
})();
