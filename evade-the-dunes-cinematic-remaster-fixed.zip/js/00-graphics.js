/* ==================================================================
   GRAPHICS MODE PRESETS â€” Normal / Performance / High
   ------------------------------------------------------------------
   Loaded BEFORE 01-core.js so every later module can read GRAPHICS.*
   at evaluation time.

   TWO LAYERS:
     1) GRAPHICS_PRESETS  â€” three complete looks (Performance / Normal / High).
                            Stored in localStorage('etd-graphics').
     2) GRAPHICS_OVERRIDES â€” per-setting tweaks the user makes inside the
                             Settings panel (e.g. bumping only the shadow
                             map size, or turning bloom off while keeping
                             the rest of High mode). Stored in
                             localStorage('etd-graphics-overrides') as JSON.

   Final settings = preset âŠ• overrides. The Settings panel reads/writes
   the overrides; switching presets keeps overrides where they still
   apply (and silently drops ones that don't exist on the new preset).

   Camera + UI-particle settings live separately in
   CAMERA_SETTINGS / UI_PARTICLE_SETTINGS (below) â€” they're live-tunable
   and don't need a reload.
   ================================================================== */
const GRAPHICS_PRESETS = {
  performance: {
    label: 'PERFORMANCE',
    tag:   'LOW-END / INTEGRATED',
    antialias:        false,     // MSAA off â€” biggest single fill-rate win
    pixelRatioCap:    1.0,       // never render above 1Ã— device pixels
    shadowEnabled:    false,     // no real-time shadow pass at all
    shadowMode:       'hard',
    shadowMapSize:    1024,
    shadowCameraHalf: 120,
    sandTexSize:      384,       // Â¼ the area of the 768Â² Normal sheet
    sandRoughnessMap: false,     // skip the roughness map entirely
    sandNormalMap:    true,      // keep the normal map (cheap, big visual win)
    sandAniso:        1,
    envMap:           false,     // skip PMREM (costs CPU + VRAM at boot)
    envMapIntensity:  0.0,
    viewDistance:     2,         // 5A-5 chunks instead of 7A-7
    terrainPolyMax:   1600,      // tri budget per near chunk; far LOD is cheaper
    fogFar:           360,
    fogNear:          45,
    particleMul:      0.45,      // ~half the dust
    hemiIntensity:    0.95,
    sunIntensity:     3.6,       // a touch brighter to keep contrast without shadows
    postFX:           false,
    lensFlare:        false,
    godRays:          false,
    godRayStrength:   0.42,
    caAmount:         1.2,
    filmGrain:        0.0,
    heatShimmer:      0.5,
    dustMotes:        false,
    // bloom (kept on the preset even when postFX is off, so the Settings
    // panel can preview the values)
    bloomStrength:    0.30,
    bloomRadius:      0.55,
    bloomThreshold:   0.82,
    bloomSky:         false,     // sky always excluded from bloom
    // final grade pass (only runs while the composer is active; neutral
    // defaults so enabling postFX here stays close to the base look)
    toneExposure:     1.0,
    gradeSat:         1.0,
    gradeVignette:    0.12,
    gradeStrength:    1.0,
  },
  normal: {
    label: 'NORMAL',
    tag:   'BASE GAME',
    antialias:        true,
    pixelRatioCap:    2.0,
    shadowEnabled:    true,
    shadowMode:       'hard',
    shadowMapSize:    2048,
    shadowCameraHalf: 130,
    sandTexSize:      768,
    sandRoughnessMap: true,
    sandNormalMap:    true,
    sandAniso:        16,
    envMap:           true,
    envMapIntensity:  0.15,
    viewDistance:     3,
    terrainPolyMax:   2600,
    fogFar:           470,
    fogNear:          55,
    particleMul:      1.0,
    hemiIntensity:    0.85,
    sunIntensity:     3.4,
    postFX:           false,
    lensFlare:        false,
    godRays:          false,
    godRayStrength:   0.42,
    caAmount:         1.6,
    filmGrain:        0.012,
    heatShimmer:      0.7,
    dustMotes:        false,
    bloomStrength:    0.30,
    bloomRadius:      0.55,
    bloomThreshold:   0.82,
    bloomSky:         false,
    // final grade pass defaults (neutral - see the `high` preset for the
    // remastered values)
    toneExposure:     1.0,
    gradeSat:         1.0,
    gradeVignette:    0.12,
    gradeStrength:    1.0,
  },
  high: {
    label: 'HIGH',
    tag:   'REMASTERED GRADE - SOFT SHADOWS - POST-FX',
    antialias:        true,
    pixelRatioCap:    2.0,
    shadowEnabled:    true,
    shadowMode:       'soft',
    shadowMapSize:    3072,
    shadowCameraHalf: 145,       // tighter than the old 190: sharper contact shadows
    sandTexSize:      1024,      // 1.78x the texel density of Normal
    sandRoughnessMap: true,
    sandNormalMap:    true,
    sandAniso:        16,
    envMap:           true,
    envMapIntensity:  0.15,      // was 0.24 - the warm PMREM sky was pumping orange into everything
    viewDistance:     4,         // 9x9 chunks
    terrainPolyMax:   3800,      // near chunks; far ring uses a coarser LOD
    fogFar:           600,       // airier horizon: more atmospheric depth, less wall of haze
    fogNear:          70,
    particleMul:      1.0,
    /* ---- remastered light rig ----
       The old High pushed hemi down to 0.52 so shadows read near-black
       orange - high contrast, but everything went rust. The remaster uses
       a near-white key light + a cool sky bounce (01-core.js swaps the
       hemi/sun colors for this mode), so shadows go soft and slightly
       blue while crests stay bright: filmic, not cranked. */
    hemiIntensity:    0.68,
    sunIntensity:     3.6,
    postFX:           true,      // EffectComposer + bloom + lens ghosts + film grade
    lensFlare:        true,      // lens-ghosting pass (kept key for saved settings)
    /* ---- cinematic remaster additions ----
       god rays, film grain, chromatic aberration, heat shimmer and
       near-camera dust motes — each live-tunable in the Settings panel. */
    godRays:          true,      // screen-space volumetric shafts from the HDR sun
    godRayStrength:   0.36,
    caAmount:         1.4,       // chromatic aberration, px at frame corners
    filmGrain:        0.030,
    heatShimmer:      1.0,       // horizon refraction amplitude multiplier
    dustMotes:        true,      // near-camera glitter motes catching the sun
    // bloom tuning - bright core, soft falloff, no neon edges.
    // Thresholds live in the HDR-linear space the composer runs in:
    // measured scene sits at sand ~0.30, sky ~0.27-0.59, sun disc ~3.5,
    // so 1.35 = sun + speculars only. The old 1.10 + strength 0.34 put a
    // wide white veil over the whole sky/sand near the sun.
    bloomStrength:    0.22,
    bloomRadius:      0.45,
    bloomThreshold:   1.35,
    bloomSky:         false,
    /* ---- final grade (17-graphics.js) ----
       exposure -> ACES filmic -> saturation 0.93 -> subtle cool-shadow /
       warm-highlight split-tone -> vignette -> sRGB. This is the actual
       "remaster": a proper display transform, not more saturation. */
    toneExposure:     1.10,
    gradeSat:         1.07,
    gradeVignette:    0.22,
    gradeStrength:    1.0,
  },
};

/* ----------------------------------------------------------------
   Settings the live-tunable Camera panel writes. Read by 14-camera.js
   every frame (the camera uses smoothing so changes feel silky).
   ---------------------------------------------------------------- */
const CAMERA_SETTINGS_DEFAULTS = {
  fovBase:       0,     // 0 = use the cam-mode default (presets per mode); 50-110 otherwise
  fovRush:       1.0,   // multiplier on the speed-based FOV rush
  distance:      1.0,   // multiplier on every cam mode's follow distance
  height:        1.0,   // multiplier on every cam mode's follow height
  shake:         1.0,   // multiplier on the shake/wobble amplitude
  roll:          1.0,   // multiplier on the camera roll/bank amount
  smoothing:     1.0,   // multiplier on the spring stiffness (higher = snappier)
  lookBack:      1.0,   // multiplier on the Q-look-back transition speed
};
const CAMERA_KEY = 'etd-camera-settings';

/* ----------------------------------------------------------------
   Settings for the DOM-level UI particle effects (sand puffs on
   button click, sand trickles on slider drag). Tunable in the panel.
   ---------------------------------------------------------------- */
const UI_PARTICLE_DEFAULTS = {
  enabled:   true,
  intensity: 1.0,        // 0..1.5 â€” particle count / size multiplier
  onButtons: true,        // sand puff on button click
  onSliders: true,        // sand trickle while dragging a slider
  onTabs:    true,        // sand scatter on tab switch
};
const UIP_KEY = 'etd-ui-particles';

/* ----------------------------------------------------------------
   Helper â€” read JSON from localStorage with a fallback.
   ---------------------------------------------------------------- */
function _lsGetJSON(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(raw == null) return fallback;
    const v = JSON.parse(raw);
    return (v && typeof v === 'object') ? v : fallback;
  }catch(e){ return fallback; }
}
function _lsSetJSON(key, val){
  try{ localStorage.setItem(key, JSON.stringify(val)); }catch(e){}
}

/* ---- preset + overrides ---- */
const GRAPHICS_KEY = 'etd-graphics';
function _readGraphicsMode(){
  try{
    const m = localStorage.getItem(GRAPHICS_KEY);
    if(m && GRAPHICS_PRESETS[m]) return m;
  }catch(e){ /* private mode etc */ }
  return 'high';   // cinematic remaster is the default experience
}
const GRAPHICS_MODE = _readGraphicsMode();
const GRAPHICS_OVERRIDES = _lsGetJSON('etd-graphics-overrides', {});
/* Merge preset + overrides into a single object the engine reads from. */
function _buildGraphicsSettings(){
  const preset = GRAPHICS_PRESETS[GRAPHICS_MODE] || GRAPHICS_PRESETS.normal;
  const merged = Object.assign({}, preset, GRAPHICS_OVERRIDES);
  merged.mode = GRAPHICS_MODE;
  merged.label = preset.label;
  merged.tag = preset.tag;
  return merged;
}
const GRAPHICS = _buildGraphicsSettings();

/* Camera + UI-particle live settings (kept on window so any module can
   read/write them at runtime; 14-camera.js and 19-ui-particles.js consume
   them every frame). */
const CAMERA_SETTINGS = Object.assign({}, CAMERA_SETTINGS_DEFAULTS, _lsGetJSON(CAMERA_KEY, {}));
const UI_PARTICLE_SETTINGS = Object.assign({}, UI_PARTICLE_DEFAULTS, _lsGetJSON(UIP_KEY, {}));

/* ---- APIs the Settings panel uses ---- */
/* Switching preset clears ALL overrides â€” the user asked for the modes
   to "switch completely, no custom settings", so a preset click is a
   hard reset to that preset's defaults. Individual overrides can still
   be made afterwards via the Settings panel. */
function setGraphicsMode(mode){
  if(!GRAPHICS_PRESETS[mode]) return;
  try{
    localStorage.setItem(GRAPHICS_KEY, mode);
    /* wipe the overrides so the new preset applies completely clean */
    for(const k in GRAPHICS_OVERRIDES) delete GRAPHICS_OVERRIDES[k];
    localStorage.removeItem('etd-graphics-overrides');
  }catch(e){}
  if(mode === GRAPHICS_MODE){
    /* already on this preset â€” but the user may have just wanted to
       clear overrides, so reload to apply the clean preset. */
    location.reload();
    return;
  }
  location.reload();
}
/* Override a single setting. Settings tagged `needsReload` rebuild
   textures/shadow maps, so the panel calls location.reload() after
   writing them. Live-tunable settings (bloom, FOV, camera multipliers,
   UI particles) apply immediately. */
const GRAPHICS_LIVE_KEYS = new Set([
  'bloomStrength','bloomRadius','bloomThreshold','bloomSky',
  'sunIntensity','hemiIntensity','fogNear','fogFar',
  'envMapIntensity','lensFlare','postFX',
  'godRays','godRayStrength','caAmount','filmGrain','heatShimmer','dustMotes',
  'toneExposure','gradeSat','gradeVignette','gradeStrength'
]);
function setGraphicsOverride(key, value){
  GRAPHICS_OVERRIDES[key] = value;
  _lsSetJSON('etd-graphics-overrides', GRAPHICS_OVERRIDES);
  /* apply live too so the preview updates without a reload */
  GRAPHICS[key] = value;
  if(window.onGraphicsLiveChange) window.onGraphicsLiveChange(key, value);
  if(!GRAPHICS_LIVE_KEYS.has(key)){
    /* texture / shadow / pixel-ratio / view-distance / particle-budget
       changes need a rebuild â€” the panel calls setGraphicsReloadSoon()
       on a small debounce rather than forcing reload per slider tick. */
    if(window._scheduleGraphicsReload) window._scheduleGraphicsReload();
  }
}
function clearGraphicsOverrides(){
  for(const k in GRAPHICS_OVERRIDES) delete GRAPHICS_OVERRIDES[k];
  _lsSetJSON('etd-graphics-overrides', GRAPHICS_OVERRIDES);
}
function setCameraSetting(key, value){
  CAMERA_SETTINGS[key] = value;
  _lsSetJSON(CAMERA_KEY, CAMERA_SETTINGS);
}
function setUIParticleSetting(key, value){
  UI_PARTICLE_SETTINGS[key] = value;
  _lsSetJSON(UIP_KEY, UI_PARTICLE_SETTINGS);
}

/* expose */
window.GRAPHICS = GRAPHICS;
window.GRAPHICS_MODE = GRAPHICS_MODE;
window.GRAPHICS_PRESETS = GRAPHICS_PRESETS;
window.GRAPHICS_OVERRIDES = GRAPHICS_OVERRIDES;
window.CAMERA_SETTINGS = CAMERA_SETTINGS;
window.CAMERA_SETTINGS_DEFAULTS = CAMERA_SETTINGS_DEFAULTS;
window.UI_PARTICLE_SETTINGS = UI_PARTICLE_SETTINGS;
window.UI_PARTICLE_DEFAULTS = UI_PARTICLE_DEFAULTS;
window.setGraphicsMode = setGraphicsMode;
window.setGraphicsOverride = setGraphicsOverride;
window.clearGraphicsOverrides = clearGraphicsOverrides;
window.setCameraSetting = setCameraSetting;
window.setUIParticleSetting = setUIParticleSetting;
window.GRAPHICS_LIVE_KEYS = GRAPHICS_LIVE_KEYS;

