/* The lesser Shai-Hulud worms */
/* Extracted from index.html. Load order matters: these run as deferred scripts, in tag order, sharing the global scope. */
/* ---------------- Shai-Hulud ---------------- */
/* Body plates: each segment is a turned armour collar rather than a bead —
   pinched where it meets the plate behind, swelling over a rounded crown,
   then rolling over a thick lip that tucks under the plate ahead. It is
   displaced with chunky facets, muscle lumps and rock jitter, and the
   vertex colours bake in the seam dirt and the shadow under each lip, so a
   stack of them reads as the banded hide of the reference worm. */
function makePlateGeo(){
  const prof=[
    [0.02,-0.58],[0.60,-0.56],[0.80,-0.50],[0.94,-0.34],[1.02,-0.10],
    [1.06, 0.12],[1.05, 0.28],[1.00, 0.40],[0.90, 0.50],[0.72, 0.58],
    [0.44, 0.62],[0.02, 0.62]
  ];
  const g=new THREE.LatheGeometry(prof.map(p=>new THREE.Vector2(p[0],p[1])),24);
  g.rotateX(Math.PI/2);
  const p=g.attributes.position, uv=g.attributes.uv, n=p.count;
  const col=new Float32Array(n*3);
  for(let i=0;i<n;i++){
    let x=p.getX(i), y=p.getY(i), z=p.getZ(i);
    const a=Math.atan2(y,x), v=uv.getY(i);
    const hs=Math.sin(i*12.9898)*43758.5453, jt=(hs-Math.floor(hs))-0.5;
    let f=1;
    f-=0.055*Math.pow(Math.abs(Math.sin(a*3+1.1)),6);          // chunky facets
    f-=0.030*Math.pow(Math.abs(Math.sin(a*6+2.7)),8);          // narrow cuts
    f+=0.045*Math.sin(a*3+0.7+z*1.5)+0.028*Math.sin(a*5+2.2-z*2.1);
    f+=0.018*Math.sin(a*9-z*3.4)+0.012*Math.sin(a*17+z*23);   // muscle + grain
    f+=0.012*Math.sin(v*24+a*0.5);                            // ring wrinkles
    f+=jt*0.024;                                              // rock jitter
    x*=f; y*=f; z*=f;
    if(z>0.30) z*=1+0.05*Math.sin(a*3+0.4)+0.028*Math.sin(a*6+1.9);   // uneven lip edge
    p.setXYZ(i,x,y,z);
    const sh=(0.50+0.50*sstep(v,0.16,0.48))*(1-0.45*(1-sstep(v,0,0.16)))*(1-0.34*sstep(v,0.74,0.98));
    const c=clamp(sh*(0.92+0.16*(jt+0.5)),0,1);
    col[i*3]=col[i*3+1]=col[i*3+2]=c;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col,3));
  g.computeVertexNormals();
  return g;
}
const wormSegGeo=makePlateGeo();
const moundGeo=new THREE.SphereGeometry(1,18,12);
/* Head crown: a stepped stone funnel that flares from the neck out to a
   thick, irregular rim, then turns inward to become the maw itself — a
   shallow inner cone the bristles root into. */
function makeCrownGeo(){
  /* the rim is a true rolled lip: the outer wall eases into a semicircular
     arc (centre 2.72/1.30, r 0.22) and the funnel keeps bending smoothly on
     into the maw, so the mouth opening reads completely round */
  const prof=[
    [0.02,-4.90],[1.30,-4.86],[2.06,-4.76],[2.28,-4.40],[2.38,-3.70],[2.40,-3.00],
    [2.28,-2.86],[2.38,-2.40],[2.44,-1.80],
    [2.30,-1.66],[2.40,-1.20],[2.48,-0.60],
    [2.34,-0.46],[2.44, 0.06],[2.54, 0.58],
    [2.42, 0.70],[2.56, 0.84],[2.68, 1.00],[2.82, 1.14],[2.905,1.24],
    /* rolled rim — semicircular arc, centre (2.72, 1.30), r 0.22 */
    [2.94, 1.31],[2.876,1.456],[2.72, 1.52],[2.564,1.456],[2.50, 1.30],
    /* inner funnel: a smooth bowl down into the dark */
    [2.36, 1.10],[2.22, 0.90],[1.98, 0.62],[1.66, 0.30],[1.30,-0.02],
    [0.98,-0.42],[0.72,-0.90],[0.50,-1.45],[0.34,-2.05],[0.10,-2.70]
  ];
  const g=new THREE.LatheGeometry(prof.map(p=>new THREE.Vector2(p[0],p[1])),32);
  g.rotateX(Math.PI/2);
  const p=g.attributes.position, uv=g.attributes.uv, n=p.count;
  const col=new Float32Array(n*3);
  for(let i=0;i<n;i++){
    let x=p.getX(i), y=p.getY(i), z=p.getZ(i);
    const a=Math.atan2(y,x), v=uv.getY(i);
    const hs=Math.sin(i*7.9898)*43758.5453, jt=(hs-Math.floor(hs))-0.5;
    let f=1;
    f-=0.045*Math.pow(Math.abs(Math.sin(a*2+0.6)),4);          // four big lobes
    f-=0.030*Math.pow(Math.abs(Math.sin(a*4+2.2)),6);
    f-=0.020*Math.pow(Math.abs(Math.sin(a*8+1.0)),8);
    f+=0.035*Math.sin(a*3+1.4+z*1.1)+0.022*Math.sin(a*5+2.8-z*1.7);
    f+=0.012*Math.sin(a*11+z*9);
    f+=jt*0.02;
    x*=f; y*=f; z*=f;
    p.setXYZ(i,x,y,z);
    const c=clamp((0.44+0.52*sstep(v,0.07,0.38))*(1-0.52*sstep(v,0.72,1.0))
                 *(1-0.5*(1-sstep(v,0,0.06)))*(0.94+0.12*(jt+0.5)),0,1);
    col[i*3]=col[i*3+1]=col[i*3+2]=c;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col,3));
  g.computeVertexNormals();
  return g;
}
const crownGeo=makeCrownGeo();
/* Maw brush: a dense bundle of bristles growing out of the funnel wall.
   Each fibre leaves the skin along the wall normal, then bends hard toward
   the mouth axis, so the bundle stands up out of the maw instead of lying
   flat against it — the bristle crown of the reference mouth. Welded into
   one geometry: a single draw call per worm. */
function makeBrushGeo(){
  /* socket line: the inner funnel wall as (radius, z) pairs, r increasing */
  const wall=[[0.12,-2.66],[0.34,-2.05],[0.50,-1.45],[0.72,-0.90],[0.98,-0.42],
              [1.30,-0.02],[1.66, 0.30],[1.98, 0.62],[2.22, 0.90],[2.36, 1.10],[2.48,1.28]];
  const wallZ=(r)=>{
    if(r<=wall[0][0]) return wall[0][1];
    for(let k=0;k<wall.length-1;k++){
      const A=wall[k], B=wall[k+1];
      if(r<=B[0]) return A[1]+(B[1]-A[1])*(r-A[0])/(B[0]-A[0]);
    }
    return wall[wall.length-1][1];
  };
  const N=340, pos=[], colr=[];
  const push=(x,y,z,c)=>{ pos.push(x,y,z); colr.push(c,c,c); };
  for(let i=0;i<N;i++){
    const a=(i/N)*Math.PI*2+(Math.random()-0.5)*0.6;
    const ca=Math.cos(a), sa=Math.sin(a);
    const rr=0.25+2.10*Math.pow(Math.random(),0.8), zr=wallZ(rr)-0.02;   // socket on the wall
    /* stand the fibre up: wall normal, then a strong forward bend */
    const s=(wallZ(Math.min(rr+0.08,2.48))-wallZ(rr))/0.08;
    let nr=-s, nz=1.0; const nl=Math.hypot(nr,nz); nr/=nl; nz/=nl;
    const fwd=0.30+1.0*(1-rr/2.5);
    let dr=nr*0.9, dz=nz*0.9+fwd;
    const dl=Math.hypot(dr,dz); dr/=dl; dz/=dl;
    let len=(0.35+0.85*(1-(zr+2.7)/4.0)+Math.random()*0.45)*(0.9+0.2*Math.random());
    if(dz>0.05 && zr+dz*len>1.56) len=Math.max(0.12,(1.56-zr)/dz);       // tips stay in the maw
    if(dr<0 && rr+dr*len<0.06) len=Math.max(0.12,(0.06-rr)/dr);          // no crossing the axis
    const bx=ca*rr, by=sa*rr;
    const tx=bx+ca*dr*len, ty=by+sa*dr*len, tz=zr+dz*len;
    const ux=-sa, uy=ca, uz=0;                                  // tangential
    const dx=ca*dr, dy=sa*dr;                                   // fibre axis (unit)
    const wx=dy*uz-dz*uy, wy=dz*ux-dx*uz, wz=dx*uy-dy*ux;       // second cross axis
    const th=0.026+Math.random()*0.022;
    const p0x=bx+ux*th,             p0y=by+uy*th,             p0z=zr+uz*th;
    const p1x=bx-ux*th*0.5+wx*th*0.866, p1y=by-uy*th*0.5+wy*th*0.866, p1z=zr-uz*th*0.5+wz*th*0.866;
    const p2x=bx-ux*th*0.5-wx*th*0.866, p2y=by-uy*th*0.5-wy*th*0.866, p2z=zr-uz*th*0.5-wz*th*0.866;
    const cr=0.38+Math.random()*0.14, ct=0.90+Math.random()*0.10;
    push(p0x,p0y,p0z,cr); push(p1x,p1y,p1z,cr); push(tx,ty,tz,ct);
    push(p1x,p1y,p1z,cr); push(p2x,p2y,p2z,cr); push(tx,ty,tz,ct);
    push(p2x,p2y,p2z,cr); push(p0x,p0y,p0z,cr); push(tx,ty,tz,ct);
  }
  const g=new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(colr,3));
  g.computeVertexNormals();
  return g;
}
const brushGeo=makeBrushGeo();
const ridgeGeo =new THREE.TorusGeometry(1,0.15,9,30);

/* Weathered grey hide: a high-detail 512² albedo + normal + roughness set
   built in 02-textures.js (wormHideMaps). Physical materials, vertex colours
   to bake the seam dirt in, and double-sided so the open plate collars and
   the maw funnel never show a see-through side. */
const wormHideTex = wormHideMaps.map;
const wormSkinMat =new THREE.MeshPhysicalMaterial({
  color:0xa49d8e, map:wormHideMaps.map,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.25,1.25),
  roughness:1.0, roughnessMap:wormHideMaps.rmap,
  sheen:0.12, sheenColor:new THREE.Color(0xcfc3ab), sheenRoughness:0.92,
  clearcoat:0.06, clearcoatRoughness:0.94, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.45
});
const wormHeadMat =new THREE.MeshPhysicalMaterial({
  color:0x9b9486, map:wormHideMaps.map,
  normalMap:wormHideMaps.nmap, normalScale:new THREE.Vector2(1.35,1.35),
  roughness:1.0, roughnessMap:wormHideMaps.rmap,
  sheen:0.14, sheenColor:new THREE.Color(0xcfc3ab), sheenRoughness:0.9,
  clearcoat:0.08, clearcoatRoughness:0.92, vertexColors:true, side:THREE.DoubleSide,
  envMap:envTex, envMapIntensity:0.5
});
/* bristles of the maw brush (shared by every worm) */
const brushMat=new THREE.MeshStandardMaterial({color:0x8f8768, roughness:0.6, metalness:0.02,
  vertexColors:true, side:THREE.DoubleSide, envMap:envTex, envMapIntensity:0.35});
const wormPlateMat=new THREE.MeshStandardMaterial({color:0x46402f, roughness:0.62, metalness:0.16,
  flatShading:true, envMap:envTex, envMapIntensity:0.6});
const wormRidgeMat=new THREE.MeshStandardMaterial({color:0x4a463a, roughness:0.95, metalness:0.04,
  envMap:envTex, envMapIntensity:0.35});
const mawMat      =new THREE.MeshBasicMaterial({color:0x020101});
const throatMat   =new THREE.MeshBasicMaterial({color:0x000000});
const toothMat    =new THREE.MeshStandardMaterial({color:0x9a9480, roughness:0.5, metalness:0.04,
  envMap:envTex, envMapIntensity:0.7});
const moundMat    =new THREE.MeshStandardMaterial({color:0xd8ab72, roughness:1});
/* Blast scars: small crusted patches parented to a body segment so they ride with the
   worm. Shared geometry/material, capped count, applied once per damage event. */
const scarGeo=new THREE.SphereGeometry(0.32,6,5);
const scarMat=new THREE.MeshStandardMaterial({color:0x241c12, roughness:1});
function scarWorm(w,n){
  if(!w||!w.segs) return;
  if(!w.scars) w.scars=[];
  for(let k=0;k<n;k++){
    if(w.scars.length>=6) return;
    const i=2+((Math.random()*(w.N-4))|0);
    const seg=w.segs[i]; if(!seg) continue;
    const s=new THREE.Mesh(scarGeo,scarMat);
    const a=Math.random()*Math.PI*2, up=0.15+Math.random()*0.6;
    s.position.set(Math.cos(a)*Math.cos(up),Math.sin(up),Math.sin(a)*Math.cos(up)).multiplyScalar(0.98);
    s.scale.set(0.16+Math.random()*0.12,0.06+Math.random()*0.05,0.2+Math.random()*0.16);
    s.rotation.set(Math.random()*3.14,Math.random()*3.14,Math.random()*3.14);
    seg.add(s);
    w.scars.push(s);
  }
}

/* ---- the giant, and the bravest worm ----
   While a giant is out, every lesser worm but one goes quiet and slips away. The one that
   stays (the closest: the bravest) gives the giant a wide berth and only hunts the jeep
   when the giant is far from it. It isn't afraid: the giant's din simply drowns out the
   jeep's engine, so near the giant it loses you and goes back to wandering. */
const BRAVE_KEEP=260;              // metres it keeps from any part of the giant
let lastMaskMsg=-99;
function activeGiant(){
  for(const w of worms) if(w.tier==='giant' && !w.removeMe && w.state!=='leaveG') return w;
  return null;
}
/* nearest point of a worm's head/body to p (horizontal); copied into out */
function wormNearest(w, p, out){
  let best=horizDist(w.pos,p); out.copy(w.pos);
  for(let i=2;i<w.N;i+=3){
    const q=w.segs[i].position, d=Math.hypot(q.x-p.x,q.z-p.z);
    if(d<best){ best=d; out.copy(q); }
  }
  return best;
}
/* how completely the giant's noise covers the jeep's engine, 0..1 */
function giantMask(g){
  const d=horizDist(g.pos,player.pos);
  return clamp(1-(d-240)/420,0,1)*(g.state==='approachG'?0.55:1);
}
const _gnp=new THREE.Vector3();

class Worm{
  constructor(idx, opts){
    opts=opts||{};
    this.idx=idx;
    this.S=opts.S||2.8; this.headR=3.0*this.S; this.N=opts.N||34;
    this.mats=opts.mats||{skin:wormSkinMat, head:wormHeadMat, plate:wormPlateMat, ridge:wormRidgeMat,
                          maw:mawMat, throat:throatMat, tooth:toothMat};
    this.group=new THREE.Group(); scene.add(this.group);
    this.segs=[];
    this.segSpin=new Float32Array(this.N);
    for(let i=0;i<this.N;i++){
      const m=new THREE.Mesh(wormSegGeo, this.mats.skin);
      m.castShadow=true; this.group.add(m); this.segs.push(m);
      this.segSpin[i]=Math.random()*Math.PI*2;      // rotate the hide so segments differ
    }
    this.headSpin=(Math.random()-0.5)*0.5;
    this.ridge=new THREE.InstancedMesh(ridgeGeo, this.mats.ridge, this.N);
    this.ridge.frustumCulled=false; this.ridge.castShadow=false; this.ridge.receiveShadow=false;
    this.ridge.visible=false;                     // the plate collars carry the banding now
    this.group.add(this.ridge);

    this.head=this.buildHead(); this.head.scale.setScalar(this.S); this.group.add(this.head);

    this.swell={x:0,z:0,R2:0,items:[],ox:0,oz:0,oR:0}; swellGroups.push(this.swell); this.swellT=0;
    this.shadowGroup=new THREE.Group();
    this.shadowMesh=new THREE.Mesh(new THREE.PlaneGeometry(1,1),
      new THREE.MeshBasicMaterial({map:shadowTex, transparent:true, opacity:0, depthWrite:false}));
    this.shadowMesh.rotation.x=-Math.PI/2;
    this.shadowGroup.add(this.shadowMesh);
    this.shadowGroup.visible=false;
    scene.add(this.shadowGroup);

    this.pos=new THREE.Vector3(); this.prevPos=new THREE.Vector3();
    this.dir=new THREE.Vector3(0,0,1); this.moveDir=new THREE.Vector3(0,0,1);
    this.wander=new THREE.Vector3(); this.wanderT=0;
    this.trail=[]; this.dustAcc=0;
    this.diveDir=new THREE.Vector3();
    this.P0=new THREE.Vector3(); this.P1=new THREE.Vector3(); this.P2=new THREE.Vector3();
    this.phase=Math.random()*10;
    this.voicePitch=0.94+Math.random()*0.12;      // each worm keeps its own slight detune
    this.seisLvl=0;                               // smoothed seismograph feed, see updateWorms()
    this.coilDeformDone=false;
    this.segDust=new Float32Array(this.N);
    this.scars=[];
    this.deadT=0; this.deadSpd=0; this.deadDir=new THREE.Vector3(); this.removeMe=false;
    this.reset(300+Math.min(idx,6)*60);
  }
  buildHead(){
    const g=new THREE.Group(), M=this.mats;
    const crown=new THREE.Mesh(crownGeo, M.head);
    crown.castShadow=true; g.add(crown);
    const brush=new THREE.Mesh(brushGeo, M.brush||brushMat);
    brush.position.z=0.06; g.add(brush);
    g.userData.brush=brush;
    return g;
  }
  rad(i){ return this.headR*(0.95-0.78*Math.pow(Math.min(i,this.N-1)/(this.N-1),0.85)); }
  die(dir){
    /* mortally wounded: sink deep beneath the sand, pushed by the blast if any */
    if(this.state==='gone'||this.state==='dead') return;
    this.state='dead'; this.deadT=0;
    this.deadSpd=dir?9+Math.random()*7:0;
    if(dir) this.deadDir.set(dir.x,0,dir.z).normalize();
  }
  reset(dist){
    const a=Math.random()*Math.PI*2;
    this.pos.set(player.pos.x+Math.cos(a)*dist, 0, player.pos.z+Math.sin(a)*dist);
    this.dir.set(-Math.cos(a),0,-Math.sin(a));
    this.moveDir.copy(this.dir);
    this.depth=this.headR*4.3; this.spd=22; this.state='roam'; this.stateT=0; this.cool=3;
    if(this.group) this.group.visible=true;
    this.wanderT=0;
    this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
    this.trail.length=0;
    for(let k=300;k>=0;k--){
      const bx=this.pos.x-this.dir.x*k*1.5, bz=this.pos.z-this.dir.z*k*1.5;
      this.trail.unshift({x:bx, y:terrainH(bx,bz)-this.depth, z:bz});
    }
    this.prevPos.copy(this.pos);
    this.nearContrib=0;
    this.coilDeformDone=false;
    this.segDust.fill(0);
    this._pd=this.depth;
    this.wallAcc=0; this.plowAcc=0; this.plowAcc2=0; this.plowAcc3=0; this.jetAcc=0;
    this.digCd=20+Math.random()*28; this.digMound=null; this.digDeform=0;
    this.digWarned=false; this.emergeX=0; this.emergeZ=0;
    this.coilCloudAcc=0; this.emergePuffAcc=0;
    this.seisLvl=0;
  }
  steerToward(target, rate, dt, weave){
    _v5.set(target.x-this.pos.x, 0, target.z-this.pos.z);
    const d=_v5.length(); if(d<0.001) return;
    _v5.divideScalar(d);
    if(weave>0){
      const s=Math.sin(elapsed*1.2+this.phase)*weave;
      _v7.set(-_v5.z,0,_v5.x);
      _v5.addScaledVector(_v7,s).normalize();
    }
    this.dir.lerp(_v5, Math.min(1,rate*dt)).normalize();
  }
  emitDust(dt, rate, sizeMul){
    if(rate<=0) return;
    this.dustAcc+=rate*dt;
    let n=this.dustAcc|0; this.dustAcc-=n;
    while(n-->0){
      const gy=terrainH(this.pos.x,this.pos.z);
      const j=0.9+Math.random()*0.2;
      spawnP(this.pos.x+(Math.random()-0.5)*4*this.S, Math.max(this.pos.y+1, gy+0.5), this.pos.z+(Math.random()-0.5)*4*this.S,
        -this.dir.x*this.spd*0.25+(Math.random()-0.5)*3, 2+Math.random()*4, -this.dir.z*this.spd*0.25+(Math.random()-0.5)*3,
        1+Math.random()*0.9, (5.0+Math.random()*2.8)*sizeMul, 0.78*j,0.62*j,0.42*j, 1.6, 1.0, PT_TRAIL);
    }
  }
  launch(focusThump){
    this.state='lunge'; this.t=0; this.lungeDur=1.05; this.hitDone=false; this.glanceDone=false;
    this.P0.copy(this.pos);
    let tx,tz;
    if(focusThump){
      if(digger.active){                      /* lead the moving digger */
        tx=digger.pos.x+digger.dir.x*digger.spd*0.55;
        tz=digger.pos.z+digger.dir.z*digger.spd*0.55;
      } else { tx=thumper.pos.x; tz=thumper.pos.z; }
    }
    else{
      tx=player.pos.x+player.vel.x*1.0; tz=player.pos.z+player.vel.z*1.0;
      const err=2.5+(1-attention)*8+Math.min(player.latSlip*0.5,6);
      tx+=(Math.random()*2-1)*err; tz+=(Math.random()*2-1)*err;
    }
    this.P2.set(tx, terrainH(tx,tz)+1.2, tz);
    this.P1.copy(this.P0).lerp(this.P2,0.42);
    this.P1.y+=24*this.S*0.7+horizDist(this.P0,this.P2)*0.2;

    const gy = terrainH(this.P0.x, this.P0.z);

    /* Terrain deformation — launch crater */
    addDeform(this.P0.x, this.P0.z, 14, 1.4);
    /* Ground shockwave — dust ring spreading */
    spawnGroundShockwave(this.P0.x, this.P0.z, 26, 1.1);
    /* Particle burst for immediate hit-feedback */
    burstDustClassic(this.P0,110,24);
    /* Volumetric eruption cluster — column shape (tall) */
    spawnCloudCluster(
      _v1.set(this.P0.x, gy+1.5, this.P0.z),
      16, 5.5*this.S, 3.5, 9.5, 2.2, 3.6, 0.5, true
    );
    /* Lower skirt of dust hugging the ground */
    spawnCloudCluster(
      _v1.set(this.P0.x, gy+0.6, this.P0.z),
      8, 4*this.S, 3, 7, 1.8, 2.8, 0.42, false
    );
    spawnRing(this.P0,18*this.S*0.8,0.7);
    shake = Math.max(shake, 0.85);
    wobble = Math.max(wobble, 0.95*clamp(1-horizDist(this.P0,player.pos)/160,0.12,1));
    { const dw=this.pos.distanceTo(player.pos);
      if(!playSfx('wormJump', 0.5, 0.94+Math.random()*0.12, dw*0.55, {pos:{x:this.P0.x,z:this.P0.z}, ref:40, rolloff:0.9}))
        roar(dw); }
    if(elapsed-lastShaiMsg>6){ lastShaiMsg=elapsed; showMsg('SHAI-HULUD!',1.6); }
  }
  update(dt){
    this.stateT+=dt; this.cool-=dt;
    const dP=horizDist(this.pos,player.pos);
    /* the alpha is coming: every lesser worm abandons the hunt and flees.
       A giant sends all of them away except the bravest one. */
    const giant = alpha.active ? null : activeGiant();
    if(!giant && this.brave) this.brave=false;
    const threat = alpha.active ? alpha.pos : (giant && !this.brave ? giant.pos : null);
    if(threat && this.state!=='flee' && this.state!=='gone' && this.state!=='lunge' && this.state!=='dive' && this.state!=='dead' && this.state!=='dig' && this.state!=='emerge'){
      this.state='flee'; this.stateT=0;
    }
    if(this.state==='gone'){
      this.clearSwell();
      this.group.visible=false; this.shadowGroup.visible=false; this.nearContrib=0; return;
    }
    const aggr=difficulty.aggr;
    let target=null, focusThump=false;
    const sated=thumper.active && thumper.takenBy.has(this);
    /* a running digger is the loudest thing under the sand: the moving lure wins */
    if(digger.active){ target=digger.pos; focusThump=true; }
    else if(thumper.active && !sated){ target=thumper.pos; focusThump=true; }
    else if(!sated && attention>0.42 && player.alive) target=player.pos;

    /* the bravest worm, sharing the desert with a giant */
    let gNear=1e9;
    const bold = this.brave && giant;
    if(bold){
      gNear=wormNearest(giant,this.pos,_gnp);
      this.gMask=(this.gMask||0)+(giantMask(giant)-(this.gMask||0))*Math.min(1,1.2*dt);
      const drowned = this.gMask>0.3 || horizDist(player.pos,giant.pos)<BRAVE_KEEP*1.8 || gNear<BRAVE_KEEP*1.3;
      if(target===player.pos && drowned){
        if(this.state==='hunt' && dP<420 && elapsed-lastMaskMsg>25 && gameState==='play'){
          lastMaskMsg=elapsed; showMsg('THE GIANT DROWNS OUT YOUR ENGINE',2.4);
        }
        target=null;
      }
      if(target && target!==player.pos && horizDist(target,giant.pos)<BRAVE_KEEP*1.6) target=null;
    } else this.gMask=0;

    if(this.state==='flee'){
      /* race away from the alpha / giant (and from the jeep), shallow enough that you
         can watch the sand mounds of the fleeing worms tear off over the dunes */
      const tp=threat||alpha.pos;
      _v3.set(this.pos.x-tp.x,0,this.pos.z-tp.z);
      if(_v3.lengthSq()<1) _v3.set(1,0,0);
      _v3.normalize();
      _v4.set(this.pos.x-player.pos.x,0,this.pos.z-player.pos.z);
      if(_v4.lengthSq()>1) _v3.addScaledVector(_v4.normalize(),0.8).normalize();
      this.dir.lerp(_v3, Math.min(1,1.8*dt)).normalize();
      this.spd+=(80-this.spd)*Math.min(1,1.4*dt);
      this.depth+=(this.headR*0.75-this.depth)*Math.min(1,2*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yT=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yT-this.pos.y)*Math.min(1,3.5*dt);
      this.emitDust(dt,55,this.S*0.8);
      if(horizDist(this.pos,player.pos)>650 || this.stateT>15){
        this.state='gone'; this.stateT=0;
        this.group.visible=false; this.shadowGroup.visible=false; this.nearContrib=0; return;
      }
    }
    else if(this.state==='roam'||this.state==='hunt'||this.state==='cool'){
      let speedT, depthT;
      if(this.state==='cool'){
        if(this.cool<=0){ this.state=target?'hunt':'roam'; this.stateT=0; }
        speedT=18; depthT=this.headR*4;
        if(target) this.steerToward(target,0.6,dt,0.1);
      } else if(target){
        this.state='hunt';
        speedT=36+aggr*18+Math.min(this.idx,5)*3;
        const d=horizDist(this.pos,target);
        if(d>150) speedT*=1.35; else if(d<40) speedT*=0.85;
        depthT=this.headR*0.5;
        this.steerToward(target,2.6,dt,d<40?0.15:0.45);
        if(this.cool<=0 && d<95 && (attention>0.45||focusThump) && !(bold && gNear<BRAVE_KEEP*2)){
          _v5.set(target.x-this.pos.x,0,target.z-this.pos.z).normalize();
          if(this.dir.dot(_v5)>0.2){
            this.state='coil'; this.stateT=0; this.coilDeformDone=false; this.coilCloudAcc=0;
            /* one clear ring at the worm's true position, plus a low positional
               pressure pulse: the coil is the last chance to change rhythm */
            spawnRing(this.pos, this.headR*1.35, 0.7);
            wormPressureSfx(this.pos, 0.9, this.voicePitch||1);
          }
        }
      } else {
        this.state='roam';
        this.wanderT-=dt;
        if(this.wanderT<=0 || horizDist(this.pos,this.wander)<40 || (bold && horizDist(this.wander,giant.pos)<BRAVE_KEEP*1.6)){
          if(bold){
            /* it lost the jeep in the giant's noise: drift around on the quiet side */
            const a=Math.atan2(player.pos.x-giant.pos.x, player.pos.z-giant.pos.z)+(Math.random()-0.5)*2.2;
            const r=220+Math.random()*180;
            this.wander.set(player.pos.x+Math.sin(a)*r, 0, player.pos.z+Math.cos(a)*r);
          } else {
            const a=Math.random()*Math.PI*2, r=180+Math.random()*160;
            this.wander.set(player.pos.x+Math.cos(a)*r, 0, player.pos.z+Math.sin(a)*r);
          }
          this.wanderT=9+Math.random()*8;
        }
        speedT=22; depthT=this.headR*4.3;
        this.steerToward(this.wander,0.8,dt,0.2);
      }
      if(bold){
        /* calm, unhurried: it curves off to give the giant room, never turns tail */
        const k=clamp((BRAVE_KEEP*2.0-gNear)/BRAVE_KEEP,0,1);
        if(k>0){
          /* away from the nearest part of the giant, and sideways out of its path */
          _v3.set(this.pos.x-_gnp.x,0,this.pos.z-_gnp.z);
          if(_v3.lengthSq()<1) _v3.set(-this.dir.z,0,this.dir.x);
          _v3.normalize();
          const gx=-giant.dir.z, gz=giant.dir.x, sd=Math.sign(_v3.x*gx+_v3.z*gz)||1;
          _v4.set(_v3.x+gx*sd*0.8, 0, _v3.z+gz*sd*0.8).normalize();
          _v4.addScaledVector(this.dir,0.5*(1-k)).normalize();
          this.dir.lerp(_v4,Math.min(1,(0.8+3*k)*dt)).normalize();
          /* deep and unhurried-looking, but it keeps pace with the giant */
          speedT=lerp(speedT, GIANT_SWIM_SPD*1.15, k);
          depthT=Math.max(depthT,this.headR*3.6);
          if(gNear<BRAVE_KEEP){                         // buried: a quiet nudge keeps the berth
            this.pos.addScaledVector(_v3,(BRAVE_KEEP-gNear)*Math.min(1,1.5*dt));
          }
        }
      }
      this.spd+=(speedT-this.spd)*Math.min(1,2*dt);
      this.depth+=(depthT-this.depth)*Math.min(1,2.4*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      const yT=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.pos.y+=(yT-this.pos.y)*Math.min(1,3.5*dt);
    }
    else if(this.state==='coil'){
      /* 0.55 s of visibly rising pressure: the tail end is the fair warning
         window before the lunge. Damage and lunge speed are unchanged. */
      const u=clamp(this.stateT/0.55,0,1);
      this.spd+=(6-this.spd)*Math.min(1,4*dt);
      this.depth+=(this.headR*0.5-this.depth)*Math.min(1,6*dt);
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,55+75*u,(1.3+0.5*u)*this.S*0.6);
      wobble=Math.max(wobble,0.06+0.10*this.nearContrib+0.04*u);

      /* Coil: grow a shallow crater under the worm early enough to read */
      if(!this.coilDeformDone && this.stateT > 0.14){
        this.coilDeformDone=true;
        addDeform(this.pos.x, this.pos.z, 17, 2.2);
        spawnGroundShockwave(this.pos.x, this.pos.z, 18, 0.8);
      }
      /* Small swirl of dust while coiling, thickening as the worm gathers itself */
      this.coilCloudAcc=(this.coilCloudAcc||0)+dt*(14+26*u);
      let nc=this.coilCloudAcc|0; this.coilCloudAcc-=nc;
      while(nc-->0){
        const a=Math.random()*Math.PI*2;
        const r=Math.random()*this.S*3.4*(0.7+0.5*u);
        const cx=this.pos.x+Math.cos(a)*r, cz=this.pos.z+Math.sin(a)*r;
        spawnCloud(_v1.set(cx, terrainH(cx,cz)+0.9+Math.random()*2.4, cz),
                   7+Math.random()*8, 1.4+Math.random()*0.9, 0.4, 0xc9a06a);
      }
      if(this.stateT>0.55) this.launch(focusThump);
    }
    else if(this.state==='dig'){
      /* fully underground: visible moving mound + deformation trail, then decide */
      this.spd+=(52-this.spd)*Math.min(1,1.6*dt);
      this.depth=this.headR*2.2;
      this.pos.addScaledVector(this.dir,this.spd*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      const urgency=clamp(1-this.digCd/2.2,0,1);
      this.emitDust(dt,14+18*urgency,1.4);
      wobble=Math.max(wobble,0.16*clamp(1-dP/330,0,1));

      /* the mound rides the worm's path, heaving up ahead and collapsing behind */
      const hr=this.headR;
      this.digMound={x:this.pos.x,y:this.pos.y+hr*0.7,z:this.pos.z,r:hr*2.0,t:this.digMound?this.digMound.t+dt:0};
      invalidateChunksNear(this.pos.x,this.pos.z,hr*3.2);
      this.digDeform=this.digDeform||addDeform(this.pos.x,this.pos.z,hr*2.4,1.4);
      if(Math.random()<dt*22){
        const a=Math.random()*Math.PI*2,rr=hr*(0.8+Math.random()*1.6);
        spawnCloud(_v1.set(this.pos.x+Math.cos(a)*rr,terrainH(this.pos.x+Math.cos(a)*rr,this.pos.z+Math.sin(a)*rr)+0.6,this.pos.z+Math.sin(a)*rr),hr*(1.6+Math.random()*1.4),1.2+Math.random()*0.6,0.4,0xc9a06a);
      }

      this.digCd-=dt;
      const canStrike = dP<150 && player.alive && !(bold && (this.gMask>0.3 || gNear<BRAVE_KEEP*2));
      if(!canStrike && this.digCd<=0.9) this.digWarned=false;   // re-entering range earns a fresh tell
      if(canStrike && !this.digWarned && this.digCd<=0.9){
        /* it has chosen: a last ring and a low pressure pulse at the true mound,
           then it commits to the strike point a moment later */
        this.digWarned=true;
        if(this.digCd<0.55) this.digCd=0.55;   // never warn and commit in the same frame
        spawnRing(this.pos,this.headR*1.35,0.8);
        wormPressureSfx(this.pos,0.75,(this.voicePitch||1)*1.05);
      }
      if(canStrike && this.digCd<=0){
        /* commit: emerge beneath the moving jeep. The strike point is locked
           here so the long pre-eruption heave is a real chance to move. */
        this.digMound=null; this.digDeform=0;
        const tx=player.pos.x+player.vel.x*1.5, tz=player.pos.z+player.vel.z*1.5;
        this.emergeX=tx; this.emergeZ=tz;
        this.pos.set(tx,0,tz);
        this.state='emerge'; this.stateT=0; this.emergeDone=false; this.emergePuffAcc=0;
        addDeform(this.pos.x,this.pos.z,this.headR*3.2,0.5);
        spawnRing(this.pos,this.headR*1.8,1.1);
        for(let k=0;k<4;k++){
          const a=Math.random()*Math.PI*2, rr=this.headR*(0.5+Math.random()*1.1);
          const cx=tx+Math.cos(a)*rr, cz=tz+Math.sin(a)*rr;
          spawnCloud(_v1.set(cx, terrainH(cx,cz)+0.35, cz),
                     this.headR*(1.5+Math.random()*0.9), 1.2+Math.random()*0.6,
                     0.34+Math.random()*0.12, 0xc59a63);
        }
        wormPressureSfx(this.pos,1.15,(this.voicePitch||1)*0.92);
      }
      commonWormTail(this, dt, 0.8);
      return;
    }
    else if(this.state==='emerge'){
      /* break surface under the jeep: a 0.9 s pressure build, then the eruption.
         The strike point was locked when the worm committed, so driving during
         the heave genuinely moves you out of the way. */
      const k=Math.min(1,this.stateT/0.9);
      const rise=sstep(k,0.28,1);
      const tx=this.emergeX||this.pos.x, tz=this.emergeZ||this.pos.z;
      this.pos.x+=(tx-this.pos.x)*Math.min(1,8*dt);
      this.pos.z+=(tz-this.pos.z)*Math.min(1,8*dt);
      this.depth=this.headR*(2.2+(0.1-2.2)*rise);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,24+34*(1-rise),1.8);
      this.emergePuffAcc=(this.emergePuffAcc||0)+dt*(6+16*(1-rise));
      let np=this.emergePuffAcc|0; this.emergePuffAcc-=np;
      while(np-->0){
        const a=Math.random()*Math.PI*2, rr=this.headR*(0.7+Math.random()*1.1);
        const cx=this.pos.x+Math.cos(a)*rr, cz=this.pos.z+Math.sin(a)*rr;
        spawnCloud(_v1.set(cx, terrainH(cx,cz)+0.4, cz),
                   this.headR*(1.5+Math.random()*1.0), 1.1+Math.random()*0.5,
                   0.36+Math.random()*0.1, 0xc59a63);
      }
      const dd=horizDist(this.pos,player.pos);
      if(k>=1 && !this.emergeDone){
        this.emergeDone=true;
        addDeform(this.pos.x,this.pos.z,this.headR*4,4.2);
        spawnGroundShockwave(this.pos.x,this.pos.z,this.headR*3,1.2);
        burstDustClassic(this.pos,100,24);
        this.depthSplash(30);
        spawnRing(this.pos,this.headR*2,1.0);
        splashSfx(horizDist(this.pos,player.pos),this.pos);
        shake=Math.max(shake,0.8);
        wobble=Math.max(wobble,0.9*clamp(1-horizDist(this.pos,player.pos)/150,0.12,1));
        if(horizDist(this.pos,player.pos)<this.headR*0.6+4 && player.alive) hitPlayer(14,this.pos,'lesser');
        else if(player.alive && dd<80) showMsg('IT IS BENEATH YOU',1.6);
      }
      if(this.stateT>1.2){
        /* verdict: back underground, or keep hunting */
        if(Math.random()<0.45 || this.stateT>12){ this.state='dig'; this.digCd=18+Math.random()*20; this.digWarned=false; }
        else this.state='cool'; this.cool=2+Math.random()*3;
        return;
      }
      commonWormTail(this, dt, 0.9);
      return;
    }
    else if(this.state==='lunge'||this.state==='dive'){
      if(this.state==='lunge'){
        this.t+=dt/this.lungeDur;
        if(this.t<1){
          const t=this.t, it=1-t;
          this.pos.copy(this.P0).multiplyScalar(it*it).addScaledVector(this.P1,2*it*t).addScaledVector(this.P2,t*t);
        } else {
          this.state='dive';
          this.diveDir.copy(this.P2).sub(this.P1).multiplyScalar(2).normalize();
        }
      } else {
        this.pos.addScaledVector(this.diveDir,70*dt);
        this.diveDir.y-=45*dt;
      }
      this.emitDust(dt,90,1.8*this.S*0.6);
      wobble=Math.max(wobble,0.18*clamp(1-this.pos.distanceTo(player.pos)/220,0.06,1));
      if(thumper.active && horizDist(this.pos,thumper.pos)<this.headR+5) strikeThumper(this,false);
      const dh=this.pos.distanceTo(player.pos);
      if(!this.hitDone && dh<this.headR+2.6){ this.hitDone=true; hitPlayer(50,this.pos,'lesser'); }
      else if(!this.glanceDone && !this.hitDone && dh<this.headR+6){ this.glanceDone=true; hitPlayer(18,this.pos,'lesser'); }
      if(this.state==='dive' && this.pos.y<terrainH(this.pos.x,this.pos.z)-this.headR*0.9){
        const bx = this.pos.x, bz = this.pos.z;
        const bgy = terrainH(bx, bz);

        /* Big splashdown crater */
        addDeform(bx, bz, 22, 3.2);
        /* Ground shockwave ring */
        spawnGroundShockwave(bx, bz, 42, 1.4);
        /* Particle blast */
        burstDustClassic(this.pos,140,26);
        /* Volumetric splashdown cloud — wide, both verticals & base */
        spawnCloudCluster(
          _v1.set(bx, bgy+1.5, bz),
          20, 7*this.S, 4, 11, 2.6, 4.2, 0.55, true
        );
        spawnCloudCluster(
          _v1.set(bx, bgy+0.6, bz),
          12, 6*this.S, 3.5, 9, 2.0, 3.2, 0.46, false
        );
        spawnRing(this.pos,26*this.S*0.8,0.8);
        splashSfx(horizDist(this.pos,player.pos), this.pos);
        shake = Math.max(shake, 0.9);
        wobble=Math.max(wobble, 0.9*clamp(1-horizDist(this.pos,player.pos)/180,0.12,1));

        if(horizDist(this.pos,player.pos)<this.headR+8 && player.alive) hitPlayer(10,this.pos,'lesser');
        this.dir.set(this.diveDir.x,0,this.diveDir.z); if(this.dir.lengthSq()<1e-6) this.dir.copy(this.moveDir); this.dir.normalize();
        this.state='cool'; this.cool=2.4+Math.random()*2-aggr*1.2; this.depth=this.headR*2;
        if(!this.hitDone && horizDist(this.pos,player.pos)<60 && player.alive) showMsg('IT MISSES — DRIVE',2);
      }
    }
    else if(this.state==='dead'){
      /* blown apart: the body sinks deep, pushed sideways by the blast, sand collapsing over it */
      this.deadT+=dt;
      this.depth+=(this.headR*9-this.depth)*Math.min(1,0.8*dt);
      this.pos.addScaledVector(this.deadDir,this.deadSpd*dt);
      this.deadSpd*=Math.exp(-2.2*dt);
      this.pos.y=terrainH(this.pos.x,this.pos.z)-this.depth;
      this.emitDust(dt,26,this.S*0.55);
      this.clearSwell();
      this.nearContrib=0;
      if(this.deadT>2.6) this.removeMe=true;
    }

    _v5.copy(this.pos).sub(this.prevPos);
    if(_v5.lengthSq()>1e-6) this.moveDir.copy(_v5).normalize();
    this.prevPos.copy(this.pos);
    _v6.set(this.moveDir.x, clamp(this.moveDir.y,-0.85,0.85), this.moveDir.z);
    if(_v6.lengthSq()<1e-4) _v6.set(this.dir.x,0,this.dir.z);
    _v6.normalize();
    this.head.position.copy(this.pos);
    this.head.lookAt(_v6.add(this.pos));
    this.head.rotateZ(this.headSpin);
    const td=this.head.userData;
    if(td.brush){
      td.brush.rotation.z+=dt*(0.22+0.10*Math.sin(elapsed*0.7+this.phase));
      const brB=1+Math.sin(elapsed*2.6+this.phase)*0.02;
      td.brush.scale.set(brB,brB,1);
    }

    const T=this.trail, h0=T[0];
    if(!h0 || (h0.x-this.pos.x)**2+(h0.y-this.pos.y)**2+(h0.z-this.pos.z)**2>2.0){
      T.unshift({x:this.pos.x,y:this.pos.y,z:this.pos.z});
      if(T.length>420) T.pop();
    }
    this.placeBody(dt);

    this.plowSand(dt);
    this.updateSwell(dt);
    this.swimWall(dt);
    if(this._pd===undefined) this._pd=this.depth;
    const dRate=Math.abs(this.depth-this._pd)/Math.max(dt,1e-3);
    if(dRate>4&&this.spd>3) this.depthSplash(Math.min(dRate,28));
    this._pd=this.depth;
    /* surface contact dust, plus a sparse trickle from the actual crest of a
       deep swimmer so its mound has a readable, grounded tell without painting
       a trail anywhere the worm is not */
    const swellAmt=clamp(1-this.depth/(this.headR*4.4),0.16,1);
    const nearP=clamp(1-horizDist(this.pos,player.pos)/300,0,1);
    const deepTrickle=(this.state==='roam'||this.state==='cool'||this.state==='hunt')?7*swellAmt*nearP:0;
    this.emitDust(dt, (this.depth<this.headR*1.8?40:0)+deepTrickle, this.S*0.7);

    const gY = terrainH(this.pos.x, this.pos.z);
    const depthRatio = clamp(1 - this.depth/(this.headR*2.8), 0, 1);
    const showShadow = depthRatio > 0.05 && this.state !== 'lunge' && this.state !== 'dive';
    this.shadowGroup.visible = showShadow;
    if(showShadow){
      this.shadowGroup.position.set(this.pos.x, gY + 0.11, this.pos.z);
      this.shadowGroup.rotation.y = Math.atan2(this.dir.x, this.dir.z);
      const s = this.headR * (1.1 + 0.9*depthRatio);
      this.shadowMesh.scale.set(s*0.9, s*2.4, 1);
      this.shadowMesh.material.opacity = 0.6 * depthRatio;
    }

    const prox=clamp(1-horizDist(this.pos,player.pos)/330,0,1);
    const act=(this.state==='roam'||this.state==='cool')?0.2:1;
    const dv=clamp(1-this.depth/(this.headR*4.3),0,1);
    this.nearContrib=prox*act*(0.25+0.75*dv);
    this.swimLvl=act*(0.25+0.75*dv);
  }
  placeBody(dt){
    const T=this.trail, L=T.length;
    let j=0, wx=this.pos.x, wy=this.pos.y, wz=this.pos.z, exhausted=(L<2);
    let rem=exhausted?1e9:Math.hypot(T[1].x-T[0].x,T[1].y-T[0].y,T[1].z-T[0].z);
    _pv.copy(this.pos);
    for(let i=0;i<this.N;i++){
      const r=this.rad(i), r2=this.rad(i+1);
      let need=(r+r2)*0.72;
      while(!exhausted && need>rem){
        need-=rem; j++;
        if(j>=L-1){ exhausted=true; wx=T[L-1].x; wy=T[L-1].y; wz=T[L-1].z; break; }
        wx=T[j].x; wy=T[j].y; wz=T[j].z;
        rem=Math.hypot(T[j+1].x-wx,T[j+1].y-wy,T[j+1].z-wz);
      }
      let ex=wx, ey=wy, ez=wz;
      if(!exhausted && j<L-1 && rem>0){
        const q=T[j+1], t=need/rem;
        ex=wx+(q.x-wx)*t; ey=wy+(q.y-wy)*t; ez=wz+(q.z-wz)*t;
        rem-=need; wx=ex; wy=ey; wz=ez;
      }
      const m=this.segs[i];
      m.position.set(ex,ey,ez);
      m.scale.set(r,r,r*1.62);
      _tv.copy(_pv); m.lookAt(_tv); m.rotateZ(this.segSpin[i]);
      _pv.set(ex,ey,ez);
      if(this.ridge.visible){
        _wm.compose(m.position, m.quaternion, _ws.set(r*1.07, r*1.07, r*0.5));
        this.ridge.setMatrixAt(i, _wm);
      }

      /* ---- sand contact: any segment touching the surface kicks up dust ---- */
      this.segDust[i]-=dt;
      if(this.segDust[i]<=0){
        const gy=terrainH(ex,ez);
        const cl=ey-gy;
        if(cl > -r*1.45 && cl < r*2.1){
          this.segDust[i]=0.055+Math.random()*0.075;
          this.bodyDust(ex, ey, ez, r, gy);
        }
      }
    }
    if(this.ridge.visible) this.ridge.instanceMatrix.needsUpdate=true;
  }

  clearSwell(){
    const sg=this.swell;
    if(sg.R2===0 && sg.items.length===0) return;
    invalidateChunksNear(sg.x, sg.z, Math.sqrt(sg.R2)+8);
    sg.items.length=0; sg.R2=0; this.swellT=0;
  }
  dropSwell(){ this.clearSwell(); const i=swellGroups.indexOf(this.swell); if(i>=0) swellGroups.splice(i,1); }

  /* The ground itself heaves: a crest of sand rides over the head, berms are pushed up to
     either side, a lip piles in front, and a ridge runs back along the first body segments
     with shallow furrows beside it. Rebuilt a few times a second and baked into the terrain. */
  updateSwell(dt){
    const st=this.state, sg=this.swell;
    /* A deep worm still leaves a subtle mound of disturbed sand; attacking worms
       press the sand up harder so the increase in danger is visible in the ground. */
    let s=(st==='lunge'||st==='dive'||st==='gone'||st==='dead'||this.inAir)?0:clamp(1-this.depth/(this.headR*4.4),0.16,1);
    if(st==='coil') s=Math.min(1.15,s*1.15);
    else if(st==='emerge') s=Math.min(1.2,s*1.2);
    else if(st==='dig') s=Math.min(1.08,s*1.08);
    if(s<0.06){ if(sg.items.length) this.clearSwell(); return; }
    this.swellT-=dt; if(this.swellT>0) return;
    this.swellT=0.11;
    const hr=this.headR, spdK=clamp(this.spd/70,0,1);
    const A=hr*0.56*s*(0.85+0.15*spdK);               // faster = a taller moving crest
    const dx=this.dir.x, dz=this.dir.z, px=-dz, pz=dx;
    const lead=hr*0.22+this.spd*0.075;                // run slightly ahead: the mesh refresh lags
    const hx=this.pos.x+dx*lead, hz=this.pos.z+dz*lead;
    const it=[]; const add=(x,z,r,h)=>it.push({x,z,r2:r*r,h});
    add(hx, hz, hr*2.5, A);                                         // crest over the head
    add(hx+dx*hr*2.0, hz+dz*hr*2.0, hr*1.5, A*(0.30+0.22*spdK));    // lip of sand piling ahead
    for(const sd of [-1,1]){
      add(hx+px*sd*hr*1.9+dx*hr*0.4, hz+pz*sd*hr*1.9+dz*hr*0.4, hr*1.6, A*0.6);   // pushed-up berms
    }
    const segs=this.segs, N=this.N;
    for(let k=1;k<=6;k++){
      const m=segs[Math.min(N-1,k*2)].position;
      add(m.x, m.z, hr*(2.3-0.12*k), A*(0.78-0.09*k));              // ridge over the buried body
      if(k===2||k===4||k===6){
        const f=0.5-0.05*k;
        for(const sd of [-1,1]) add(m.x+px*sd*hr*2.7, m.z+pz*sd*hr*2.7, hr*1.5, -A*f*0.5);   // furrows
      }
    }
    /* bounding disc for quick rejection */
    let R=0;
    for(const q of it){ const d=Math.hypot(q.x-hx,q.z-hz)+Math.sqrt(q.r2); if(d>R) R=d; }
    /* refresh both the area we leave and the area we cover */
    if(sg.R2>0) invalidateChunksNear(sg.x, sg.z, Math.sqrt(sg.R2)+4);
    sg.items=it; sg.x=hx; sg.z=hz; sg.R2=R*R;
    invalidateChunksNear(hx, hz, R+4);
  }

  /* Sand shoved aside by the head as the worm swims. Two things happen:
       - two jets of sand are blasted out from the flanks of the maw, right where
         the mouth cuts the sand — the displaced material has to go somewhere, and
         it goes sideways
       - a spray of grains and puffs comes off the whole contact arc, spawned
         right AT the sand surface (not above it) so it looks like it's being
         heaved out of the ground rather than sprinkled on top.
     The depth gate is tight: once the head is fully buried there is no contact
     point with the sand, so nothing spawns at all. */
  plowSand(dt){
    const st=this.state;
    if(st==='lunge'||st==='dive') return;
    /* only when the head is actually near the surface — a buried worm has no
       contact point with the sand, so it must not throw surface dust at all */
    const s=clamp((this.headR*1.0-this.depth)/(this.headR*0.6),0,1);
    if(s<0.04||this.spd<4) return;
    const sp=this.spd,dx=this.dir.x,dz=this.dir.z,px=-dz,pz=dx,hr=this.headR;

    /* ---- 2 JETS from the flanks of the maw ----
       The mouth is at the front of the head sphere. As it cuts through the sand,
       the displaced sand is thrown hard out to either side, right where the
       sphere's surface meets the ground. Dense, bright, and loading upward so
       the two plumes stand tall and read clearly from any distance. */
    this.jetAcc=(this.jetAcc||0)+dt*(230+sp*4.8)*s;
    let nj=this.jetAcc|0; this.jetAcc-=nj;
    while(nj-->0){
      const side=Math.random()<0.5?-1:1;
      /* slightly beyond the sphere edge, where the displaced sand actually goes */
      const fwdOff=hr*(0.58+Math.random()*0.32);
      const latOff=hr*(0.80+Math.random()*0.22);
      const jx=this.pos.x+dx*fwdOff+px*side*latOff;
      const jz=this.pos.z+dz*fwdOff+pz*side*latOff;
      const jgy=terrainH(jx,jz);
      /* buried at this point? the maw can't push surface dust here */
      if(jgy-this.pos.y>hr*1.15) continue;
      const outSpd=30+Math.random()*46+s*22;
      const fwdSpd=sp*(0.20+Math.random()*0.30);
      const upSpd=(5+Math.random()*18)*s;
      const j=0.90+Math.random()*0.25;
      const svx=px*side*outSpd+dx*fwdSpd;
      const svz=pz*side*outSpd+dz*fwdSpd;
      /* the core of the jet: fine spray spawned at the sand itself, thrown up
         by velocity rather than already floating above it */
      spawnP(jx, jgy+0.04+Math.random()*0.18, jz, svx, upSpd, svz,
        1.0+Math.random()*0.9, (3.4+Math.random()*4.4)*this.S*0.5,
        0.94*j,0.82*j,0.62*j, 4, 1.1, PT_SPRAY);
      /* a bigger puff riding the jet so it reads as a cloud, not just mist */
      if(Math.random()<0.5){
        spawnP(jx+(Math.random()-0.5)*hr*0.2, jgy+0.06+Math.random()*hr*0.10, jz+(Math.random()-0.5)*hr*0.2,
          svx*0.7+(Math.random()-0.5)*3, upSpd*0.7+3, svz*0.7+(Math.random()-0.5)*3,
          1.4+Math.random()*1.2, (4.5+Math.random()*4.5)*this.S*0.5,
          0.90*j,0.75*j,0.55*j, 2.5, 1.0, PT_DUST);
      }
      /* a rising billow: gives each jet a tall, buoyant head that climbs */
      if(Math.random()<0.5){
        spawnP(jx+(Math.random()-0.5)*hr*0.25, jgy+0.10+Math.random()*hr*0.12, jz+(Math.random()-0.5)*hr*0.25,
          svx*0.5+(Math.random()-0.5)*3, upSpd*0.9+6, svz*0.5+(Math.random()-0.5)*3,
          1.6+Math.random()*1.1, (5.0+Math.random()*6.0)*this.S*0.5,
          0.88*j,0.72*j,0.52*j, 1.2, 0.7, PT_BILLOW);
      }
      /* a few real grains so the jet arcs and lands again */
      if(Math.random()<0.55){
        spawnP(jx+(Math.random()-0.5)*hr*0.3, jgy+0.03, jz+(Math.random()-0.5)*hr*0.3,
          svx*(0.8+Math.random()*0.25), upSpd*0.8+2, svz*(0.8+Math.random()*0.25),
          1.1+Math.random()*0.9, (0.24+Math.random()*0.38)*Math.sqrt(this.S),
          0.86*j,0.70*j,0.50*j, 14, 0.12, PT_GRAIN);
      }
      /* a low billboard puff so the jet reads as volume */
      if(Math.random()<0.9){
        spawnCloud(_v1.set(jx, jgy+hr*0.05+Math.random()*hr*0.10, jz),
          hr*(1.6+Math.random()*1.6), 1.2+Math.random()*0.9, 0.44+Math.random()*0.24, 0xc59a63);
      }
    }

    /* ---- contact-arc spray ----
       Along the whole arc where the head meets the sand, sand is being heaved up
       and out. Particles spawn right at the surface; their upward velocity lifts
       them, so the column looks like it's being pushed out of the ground. */
    this.plowAcc=(this.plowAcc||0)+dt*(52+sp*1.6)*s;
    let n=this.plowAcc|0;this.plowAcc-=n;
    while(n-->0){
      const side=Math.random()<0.5?-1:1,f=0.55+Math.random()*0.6,latF=0.25+Math.random()*0.85;
      const x=this.pos.x+dx*hr*f+px*hr*latF*side,z=this.pos.z+dz*hr*f+pz*hr*latF*side,gy=terrainH(x,z);
      if(gy-this.pos.y>hr*1.2) continue;
      const out=((6+Math.random()*9)*(0.7+s*0.9)+sp*0.1)*(latF+0.25),fwd=sp*(0.45+Math.random()*0.45);
      const up=(4+Math.random()*7)*(0.5+s*0.8),j=0.88+Math.random()*0.24;
      const svx=px*side*out+dx*fwd, svz=pz*side*out+dz*fwd;
      /* spawn right at the sand surface — not floating above it */
      spawnP(x,gy+0.03+Math.random()*0.15,z,svx,up,svz,
        1.0+Math.random()*0.9,(1.8+Math.random()*2.2)*this.S*0.5,0.84*j,0.70*j,0.50*j,6,1.2,PT_SPRAY);
      if(Math.random()<0.35) spawnP(x,gy+0.05+Math.random()*0.12,z,svx*1.15,up*1.1,svz*1.15,
        0.8+Math.random()*0.6,(0.14+Math.random()*0.2)*Math.sqrt(this.S),0.80*j,0.66*j,0.46*j,14,0.1,PT_GRAIN);
    }
    this.plowAcc2=(this.plowAcc2||0)+dt*(26+sp*0.7)*s;
    let m=this.plowAcc2|0;this.plowAcc2-=m;
    while(m-->0){
      const side=Math.random()<0.5?-1:1,back=hr*(0.4+Math.random()*2.6),lat=hr*(0.9+Math.random()*0.6)*side;
      const x=this.pos.x-dx*back+px*lat,z=this.pos.z-dz*back+pz*lat,gy=terrainH(x,z);
      if(gy-this.pos.y>hr*1.25) continue;
      spawnP(x,gy+0.03+Math.random()*0.15,z,px*side*(3+Math.random()*5)+dx*sp*0.12,1.5+Math.random()*4,pz*side*(3+Math.random()*5)+dz*sp*0.12,
        0.9+Math.random()*0.9,(1.4+Math.random()*1.8)*this.S*0.5,0.82,0.68,0.48,5,1.2,PT_SPRAY);
    }
    this.plowAcc3=(this.plowAcc3||0)+dt*(4+sp*0.15)*s;
    let c=this.plowAcc3|0;this.plowAcc3-=c;if(c>2)c=2;
    while(c-->0){
      const side=Math.random()<0.5?-1:1,back=hr*(0.3+Math.random()*1.6),lat=hr*(0.7+Math.random()*0.5)*side;
      const cx=this.pos.x-dx*back+px*lat,cz=this.pos.z-dz*back+pz*lat,gy=terrainH(cx,cz);
      if(gy-this.pos.y>hr*1.2) continue;
      spawnCloud(_v1.set(cx,gy+hr*0.10+Math.random()*hr*0.22,cz),hr*(2.4+Math.random()*1.6),
                 1.9+Math.random()*1.1,0.5+Math.random()*0.2,0xb98a55);
    }
  }

  /* Dust kicked up wherever the body breaks the surface — the rolling cloud
     that trails a surfacing worm. */
  swimWall(dt){
    /* body segments retrace the head's path, so use the head's depth as proxy:
       if the head is buried, the body behind it is too — no wall dust at all */
    const s=clamp((this.headR*1.1-this.depth)/(this.headR*0.7),0,1);
    if(s<0.05||this.spd<3)return;
    this.wallAcc=(this.wallAcc||0)+dt*(14+this.spd*0.25)*s;
    let n=this.wallAcc|0;this.wallAcc-=n;if(n>4)n=4;
    for(;n>0;n--){
      const ii=1+((Math.random()*Math.min(this.N-1,8))|0),m=this.segs[ii],r=this.rad(ii);
      const gy=terrainH(m.position.x,m.position.z),a=Math.random()*Math.PI*2,rr=r*(0.7+Math.random()*1.05);
      const cx=m.position.x+Math.cos(a)*rr,cz=m.position.z+Math.sin(a)*rr;
      /* spawn right at the sand, not above it */
      const cy=gy+0.10+Math.random()*r*0.35;
      spawnCloud(_v1.set(cx,cy,cz),r*(2.7+Math.random()*2.3),1.9+Math.random()*1.3,
                 0.52+Math.random()*0.24,0xbb8d58);
    }
  }
  depthSplash(rate){
    const hr=this.headR,n=Math.min(24,(rate*0.9)|0);
    for(let k=0;k<n;k++){
      const a=Math.random()*Math.PI*2,rr=hr*(0.6+Math.random()*1.7),x=this.pos.x+Math.cos(a)*rr,z=this.pos.z+Math.sin(a)*rr,gy=terrainH(x,z),j=0.85+Math.random()*0.22;
      const sp=7+Math.random()*24;
      spawnP(x,gy+0.5+Math.random()*2.2,z,Math.cos(a)*sp,6+Math.random()*22,Math.sin(a)*sp,
        1.4+Math.random()*1.6,(5.5+Math.random()*6.5)*this.S*0.5,0.82*j,0.66*j,0.46*j,3,0.85);
    }
    const cx=this.pos.x,cz=this.pos.z,cy=terrainH(cx,cz)+hr*0.7;
    spawnCloud(_v1.set(cx,cy,cz),hr*(3.4+Math.random()*1.6),1.9,0.58,0xb98a55);
    if(Math.random()<0.6){
      const a=Math.random()*Math.PI*2;
      spawnCloud(_v1.set(cx+Math.cos(a)*hr*0.7,cy+hr*0.5,cz+Math.sin(a)*hr*0.7),hr*(2.4+Math.random()*1.4),2.2,0.45,0xb08050);
    }
  }
  bodyDust(x,y,z,r,gy){
    const j=0.85+Math.random()*0.3, sizeMul=this.S*0.5;
    const base=Math.max(gy+0.35,y-r*0.35);
    const n=4+((Math.random()*5)|0);
    for(let k=0;k<n;k++){
      const a=Math.random()*Math.PI*2, sp=3+Math.random()*10;
      spawnP(x+(Math.random()-0.5)*r*1.5,base+0.4+Math.random()*r*0.9,z+(Math.random()-0.5)*r*1.5,
        Math.cos(a)*sp,2+Math.random()*7,Math.sin(a)*sp,
        1.2+Math.random()*1.4,(4.6+Math.random()*5.6)*sizeMul,
        0.80*j,0.66*j,0.46*j,2.0,1.05);
    }
    if(Math.random()<0.78){
      const a=Math.random()*Math.PI*2,rr=r*(0.5+Math.random()*0.85);
      const cx=x+Math.cos(a)*rr,cz=z+Math.sin(a)*rr;
      const cy=Math.max(gy+0.5,y-r*0.1)+Math.random()*r*0.7;
      spawnCloud(_v1.set(cx,cy,cz),r*(2.5+Math.random()*1.9),1.7+Math.random()*1.1,
                 0.55+Math.random()*0.22,0xba8d58);
    }
    if(Math.random()<0.34){
      const a=Math.random()*Math.PI*2,rr=r*(0.5+Math.random()*0.9);
      const cx=x+Math.cos(a)*rr,cz=z+Math.sin(a)*rr;
      spawnCloud(_v1.set(cx,Math.max(gy+0.8,y)+r*0.5,cz),
                 r*(3.3+Math.random()*2.1),2.3+Math.random()*1.4,
                 0.45+Math.random()*0.18,0xb08758);
    }
  }
}