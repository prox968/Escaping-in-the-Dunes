SHAI-HULUD — Desert Run · CINEMATIC REMASTER
=============================================

A ground-up visual realism overhaul of the "Evade the Dunes" desert game.

WHAT'S NEW (vs the original build)
----------------------------------
1. ATMOSPHERIC SCATTERING SKY
   - Physically-inspired dusty-sky model: optical-depth horizon gradient,
     Henyey-Greenstein Mie forward-scatter veil around the sun, HDR sun
     disc with limb darkening, drifting fBm dust bands, banding dither.
2. CINEMATIC POST-FX CHAIN (High mode)
   - NEW God Rays pass (screen-space volumetric shafts, occluded by
     terrain and worms)
   - Upgraded film grade: chromatic aberration, animated film grain,
     unsharp-mask crispness, speed-scaled radial wind-rush blur,
     heat-shimmer refraction band above the horizon, ACES tonemap,
     split-tone, vignette, sRGB encode.
3. TERRAIN SHADER REALISM
   - Micro-detail normal (whiteout blend) at its own world scale/rotation
     — kills texture tiling, adds true grain.
   - Animated sand glitter: sparse quartz glints that twinkle as you move.
   - Sun-tinted aerial fog: haze warms toward the sun, cools away from it.
4. LIVING AIR
   - 260 near-camera dust motes, back-lit by the sun (phase-dependent).
   - Seven distant dust-storm curtains orbiting the horizon.
5. GOLDEN-HOUR LIGHT RIG
   - Sun lowered to ~17.5° elevation: long dramatic shadows, the sun disc
     actually enters frame while driving, god rays fire on crests.
6. MATERIAL POLISH
   - Jeep: real transmissive glass (IOR 1.52), deeper clearcoat paint,
     sharper chrome, all lit by the sky via IBL (PMREM of the new sky).
   - Worms (regular + alpha): sheen/clearcoat damp-hide response, boosted
     normals, environment reflections.
7. ENGINEERING
   - three.js r160 vendored locally (no CDN dependency).
   - New "21b-realism.js" module; surgical shader injections elsewhere.
   - HIGH preset is now the default experience; every new effect is
     live-tunable in SETTINGS > GRAPHICS (god rays, grain, aberration,
     shimmer, motes) and the old PERFORMANCE / NORMAL presets still work.

HOW TO RUN
----------
The game is static — serve the folder with any web server:

    cd evade-the-dunes
    python3 -m http.server 8000
    # open http://localhost:8000

(ES modules and audio require http:// — opening index.html directly from
disk will not work. This matches the original game's requirements.)

CONTROLS
--------
W A S D  drive            SHIFT   overdrive
SPACE    handbrake        Q       look back
E        drop thumper     F / G   digger / blast
V / 1-8  camera modes     R       cinematic slow-mo (airborne)
ESC      pause

All original gameplay, audio and UI are untouched — this is a pure
graphics remaster.
